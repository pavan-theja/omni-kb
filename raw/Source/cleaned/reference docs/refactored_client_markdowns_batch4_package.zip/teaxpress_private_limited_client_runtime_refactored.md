# Teaxpress Private Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: teaxpress_private_limited_client_runtime_cards_v2_1_refactored
  created_for: Teaxpress Private Limited
  generated_on: '2026-05-24'
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Teaxpress Private Limited.docx
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - logistics_domain.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - xpressbees_logistics.md
  design_rule: Tenant/Group identity is separated from table/runtime scope. group_id and group_level_id filters live only
    in Account Data Binding cards. Cross-domain logic is represented as Business Scope Set and Business Flow Binding cards.
  scope_key_policy:
    primary_runtime_scope_columns:
    - group_id
    - group_level_id
    tenant_id_handling: tenant_id is treated as a possible alias of group_id when a source table uses tenant_id instead of
      group_id; it is not duplicated in the binding unless verified per table.
    region_currency_handling: Region/currency values are represented as platform-account logical scope unless a concrete table
      column is confirmed.
  card_count: 46
  edge_count: 158
  version: v2_1_refactored
  generated_date: '2026-05-24'
  client_slug: teaxpress_private_limited
  source_json_bad_state: teaxpress_private_limited.json
  source_docx: Teaxpress Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.global_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.international_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.increff.in.wms_operations: platform_context.increff.in
      platform_context.shiprocket.in.oms_order_source: platform_context.shiprocket.in
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
      business_scope_set.volans_epic_llc.walmart_us_pending_context: business_scope_set.volans_epic_llc.walmart_us
      business_flow_binding.volans_epic_llc.walmart_pending_context: business_flow_binding.volans_epic_llc.walmart_marketplace_reconciliation
      business_scope_set.volans_uptown_llc.walmart_us_pending_context: business_scope_set.volans_uptown_llc.walmart_us
      business_flow_binding.volans_uptown_llc.walmart_pending_context: business_flow_binding.volans_uptown_llc.walmart_marketplace_reconciliation
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: teaxpress_private_limited.json
  source_docx: Teaxpress Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Remapped role-specific Shopify/Increff/Shiprocket/Amazon/Paytm/PhonePe context aliases to uploaded broader canonical contexts
    while preserving the role in account fields.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: group.teaxpress_private_limited.teabox
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce_order_sales_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.dtdc.primary.dtdc_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.razorpay.shared.razorpay_payin
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.axis_bank.shared.axis_bank_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.hdfc_bank.shared.hdfc_bank_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  status_changes:
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
    card_type: account_data_binding
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: platform_account.teaxpress_private_limited.bluedart.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: platform_account.teaxpress_private_limited.india_post.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: platform_account.teaxpress_private_limited.payu.shared
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  blocked_edge_count: 14
  canonical_resolution_gap_count: 14
  resolved_prior_review_count: 0
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.teaxpress_private_limited.docx.section.01_identity
  source_document: Teaxpress Private Limited.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L11
  summary: '* Business: D2C brand(s) — primarily own-website sales, minimal marketplace presence

    * Brand entities: Two operating brands — **Teabox** and **Sammvaad** — sharing logistics and payment infrastructure under
    one client account

    * OMS/WMS: Unicommerce (primary), Shopify (D2C storefront)

    * Logistics: Delhivery, Ekart, Bluedart, Xpressbees, DTDC, India Post

    * Payment gateways: Razorpay, PayU, Axis Bank, HDFC Bank

    * GROUP LEVEL ID : 190

    * GROUP ID : 52

    * CLEINT NAME :**Teaxpress Private Limited**

    * GROUP NAME : **TeaBox**'
  raw_lines:
  - '* Business: D2C brand(s) — primarily own-website sales, minimal marketplace presence'
  - '* Brand entities: Two operating brands — **Teabox** and **Sammvaad** — sharing logistics and payment infrastructure under
    one client account'
  - '* OMS/WMS: Unicommerce (primary), Shopify (D2C storefront)'
  - '* Logistics: Delhivery, Ekart, Bluedart, Xpressbees, DTDC, India Post'
  - '* Payment gateways: Razorpay, PayU, Axis Bank, HDFC Bank'
  - '* GROUP LEVEL ID : 190'
  - '* GROUP ID : 52'
  - '* CLEINT NAME :**Teaxpress Private Limited**'
  - '* GROUP NAME : **TeaBox**'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  source_document: Teaxpress Private Limited.docx
  source_section: Active sales channels
  evidence_type: docx_section
  source_lines: L12-L18
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Shopify | D2C OMS               |

    | Unicommerce | Sales, Returns, Cancellations, Sales order report |

    | Amazon  | Shipping invoice, Shipping settlement report (India Post routing) |

    > Note: No standard marketplace OMS or settlement files (Flipkart, Myntra, etc.) are configured. Amazon presence is logistics-only
    (shipping invoice reconciliation), not seller-central settlement.'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Shopify | D2C OMS               |'
  - '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  - '| Amazon  | Shipping invoice, Shipping settlement report (India Post routing) |'
  - '> Note: No standard marketplace OMS or settlement files (Flipkart, Myntra, etc.) are configured. Amazon presence is logistics-only
    (shipping invoice reconciliation), not seller-central settlement.'
  row_count: 3
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.teaxpress_private_limited.docx.row.02_active_sales_channels.01_shopify
  source_document: Teaxpress Private Limited.docx
  source_section: Active sales channels
  evidence_type: configured_source_row
  source_line: L15
  row_key: Shopify
  columns:
    channel: Shopify
    data_types_configured: D2C OMS
  raw_text: '| Shopify | D2C OMS               |'
  summary: 'Shopify: channel=Shopify; data_types_configured=D2C OMS'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  source_document: Teaxpress Private Limited.docx
  source_section: Active sales channels
  evidence_type: configured_source_row
  source_line: L16
  row_key: Unicommerce
  columns:
    channel: Unicommerce
    data_types_configured: Sales, Returns, Cancellations, Sales order report
  raw_text: '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  summary: 'Unicommerce: channel=Unicommerce; data_types_configured=Sales, Returns, Cancellations, Sales order report'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  source_document: Teaxpress Private Limited.docx
  source_section: Active sales channels
  evidence_type: configured_source_row
  source_line: L17
  row_key: Amazon
  columns:
    channel: Amazon
    data_types_configured: Shipping invoice, Shipping settlement report (India Post routing)
  raw_text: '| Amazon  | Shipping invoice, Shipping settlement report (India Post routing) |'
  summary: 'Amazon: channel=Amazon; data_types_configured=Shipping invoice, Shipping settlement report (India Post routing)'
  confidence: high
- id: ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: docx_section
  source_lines: L19-L27
  summary: '| Courier | Files configured | Invoice variants |

    |---------|------------------|------------------|

    | Bluedart | Settlement + Invoice | PP-Teabox, COD-Teabox, PP-Sammvaad, COD-Sammvaad |

    | Ekart   | Settlement + Invoice | Teabox, COD-Sammvaad |

    | Delhivery | Settlement + Invoice | Single (shared)  |

    | Xpressbees | Settlement + Settlement report + Invoice | Single (shared)  |

    | DTDC    | TL/LTL Invoice   | Single (shared)  |

    | India Post | Via amazon_shipping_settlement_report | Single (shared)  |'
  raw_lines:
  - '| Courier | Files configured | Invoice variants |'
  - '|---------|------------------|------------------|'
  - '| Bluedart | Settlement + Invoice | PP-Teabox, COD-Teabox, PP-Sammvaad, COD-Sammvaad |'
  - '| Ekart   | Settlement + Invoice | Teabox, COD-Sammvaad |'
  - '| Delhivery | Settlement + Invoice | Single (shared)  |'
  - '| Xpressbees | Settlement + Settlement report + Invoice | Single (shared)  |'
  - '| DTDC    | TL/LTL Invoice   | Single (shared)  |'
  - '| India Post | Via amazon_shipping_settlement_report | Single (shared)  |'
  row_count: 6
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.01_bluedart
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L22
  row_key: Bluedart
  columns:
    courier: Bluedart
    files_configured: Settlement + Invoice
    invoice_variants: PP-Teabox, COD-Teabox, PP-Sammvaad, COD-Sammvaad
  raw_text: '| Bluedart | Settlement + Invoice | PP-Teabox, COD-Teabox, PP-Sammvaad, COD-Sammvaad |'
  summary: 'Bluedart: courier=Bluedart; files_configured=Settlement + Invoice; invoice_variants=PP-Teabox, COD-Teabox, PP-Sammvaad,
    COD-Sammvaad'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.02_ekart
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L23
  row_key: Ekart
  columns:
    courier: Ekart
    files_configured: Settlement + Invoice
    invoice_variants: Teabox, COD-Sammvaad
  raw_text: '| Ekart   | Settlement + Invoice | Teabox, COD-Sammvaad |'
  summary: 'Ekart: courier=Ekart; files_configured=Settlement + Invoice; invoice_variants=Teabox, COD-Sammvaad'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.03_delhivery
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L24
  row_key: Delhivery
  columns:
    courier: Delhivery
    files_configured: Settlement + Invoice
    invoice_variants: Single (shared)
  raw_text: '| Delhivery | Settlement + Invoice | Single (shared)  |'
  summary: 'Delhivery: courier=Delhivery; files_configured=Settlement + Invoice; invoice_variants=Single (shared)'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L25
  row_key: Xpressbees
  columns:
    courier: Xpressbees
    files_configured: Settlement + Settlement report + Invoice
    invoice_variants: Single (shared)
  raw_text: '| Xpressbees | Settlement + Settlement report + Invoice | Single (shared)  |'
  summary: 'Xpressbees: courier=Xpressbees; files_configured=Settlement + Settlement report + Invoice; invoice_variants=Single
    (shared)'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.05_dtdc
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L26
  row_key: DTDC
  columns:
    courier: DTDC
    files_configured: TL/LTL Invoice
    invoice_variants: Single (shared)
  raw_text: '| DTDC    | TL/LTL Invoice   | Single (shared)  |'
  summary: 'DTDC: courier=DTDC; files_configured=TL/LTL Invoice; invoice_variants=Single (shared)'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  source_document: Teaxpress Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L27
  row_key: India Post
  columns:
    courier: India Post
    files_configured: Via amazon_shipping_settlement_report
    invoice_variants: Single (shared)
  raw_text: '| India Post | Via amazon_shipping_settlement_report | Single (shared)  |'
  summary: 'India Post: courier=India Post; files_configured=Via amazon_shipping_settlement_report; invoice_variants=Single
    (shared)'
  confidence: high
- id: ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: docx_section
  source_lines: L28-L36
  summary: '| Gateway | Brand entity | Pipeline target |

    |---------|--------------|-----------------|

    | Razorpay | Teabox       | razorpay_payin  |

    | Razorpay | Sammvaad     | razorpay_payin  |

    | PayU    | Teabox       | payu_settlement |

    | PayU    | Sammvaad     | payu_settlement |

    | Axis Bank | Shared       | axis_bank_settlement |

    | HDFC Bank | Shared       | hdfc_bank_settlement |'
  raw_lines:
  - '| Gateway | Brand entity | Pipeline target |'
  - '|---------|--------------|-----------------|'
  - '| Razorpay | Teabox       | razorpay_payin  |'
  - '| Razorpay | Sammvaad     | razorpay_payin  |'
  - '| PayU    | Teabox       | payu_settlement |'
  - '| PayU    | Sammvaad     | payu_settlement |'
  - '| Axis Bank | Shared       | axis_bank_settlement |'
  - '| HDFC Bank | Shared       | hdfc_bank_settlement |'
  row_count: 6
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.01_razorpay
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L31
  row_key: Razorpay
  columns:
    gateway: Razorpay
    brand_entity: Teabox
    pipeline_target: razorpay_payin
  raw_text: '| Razorpay | Teabox       | razorpay_payin  |'
  summary: 'Razorpay: gateway=Razorpay; brand_entity=Teabox; pipeline_target=razorpay_payin'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.02_razorpay
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L32
  row_key: Razorpay
  columns:
    gateway: Razorpay
    brand_entity: Sammvaad
    pipeline_target: razorpay_payin
  raw_text: '| Razorpay | Sammvaad     | razorpay_payin  |'
  summary: 'Razorpay: gateway=Razorpay; brand_entity=Sammvaad; pipeline_target=razorpay_payin'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.03_payu
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L33
  row_key: PayU
  columns:
    gateway: PayU
    brand_entity: Teabox
    pipeline_target: payu_settlement
  raw_text: '| PayU    | Teabox       | payu_settlement |'
  summary: 'PayU: gateway=PayU; brand_entity=Teabox; pipeline_target=payu_settlement'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.04_payu
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L34
  row_key: PayU
  columns:
    gateway: PayU
    brand_entity: Sammvaad
    pipeline_target: payu_settlement
  raw_text: '| PayU    | Sammvaad     | payu_settlement |'
  summary: 'PayU: gateway=PayU; brand_entity=Sammvaad; pipeline_target=payu_settlement'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.05_axis_bank
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L35
  row_key: Axis Bank
  columns:
    gateway: Axis Bank
    brand_entity: Shared
    pipeline_target: axis_bank_settlement
  raw_text: '| Axis Bank | Shared       | axis_bank_settlement |'
  summary: 'Axis Bank: gateway=Axis Bank; brand_entity=Shared; pipeline_target=axis_bank_settlement'
  confidence: high
- id: ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.06_hdfc_bank
  source_document: Teaxpress Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L36
  row_key: HDFC Bank
  columns:
    gateway: HDFC Bank
    brand_entity: Shared
    pipeline_target: hdfc_bank_settlement
  raw_text: '| HDFC Bank | Shared       | hdfc_bank_settlement |'
  summary: 'HDFC Bank: gateway=HDFC Bank; brand_entity=Shared; pipeline_target=hdfc_bank_settlement'
  confidence: high
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.teaxpress_private_limited
  canonical_id: tenant.teaxpress_private_limited
  name: Teaxpress Private Limited
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.01_identity
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.01_shopify
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  description: D2C-heavy India client using ZenStatement for Shopify and Unicommerce OMS, courier reconciliation, and payment
    gateway / bank settlement reasoning for Teabox and Sammvaad brand entities.
  fields:
    tenant_name: Teaxpress Private Limited
    tenant_code: TEAXPRESS
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.teaxpress_private_limited.teabox
  canonical_id: group.teaxpress_private_limited.teabox
  name: TeaBox
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Teaxpress Private Limited.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_name: TeaBox
    group_code: TEABOX
    group_type: brand
    business_meaning: Primary operating group/brand scope for Teaxpress. Source identifies GROUP ID 52 and GROUP LEVEL ID
      190. The client source also identifies Sammvaad as a second operating brand sharing logistics and payment infrastructure;
      brand-specific filtering is kept as logical scope until concrete source columns are confirmed.
    country_or_region: India
    default_currency: INR
    client_source_identifiers_note: Source doc gives GROUP ID 52 and GROUP LEVEL ID 190; these are applied as Account Data
      Binding filters, not as universal Group properties.
    currency_scope:
    - INR
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  canonical_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  name: Teaxpress Shopify D2C Store
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.01_shopify
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Teaxpress Shopify D2C Store
    account_type: d2c_store_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: 'Shopify configured: D2C OMS'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shopify
        source_documents:
        - shopify_d2c_oms_v2.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shopify.in_and_global.d2c_oms_client_config
        source_documents:
        - shopify_d2c_oms_v2.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in.d2c_oms
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  canonical_id: platform_account.teaxpress_private_limited.unicommerce.primary
  name: Teaxpress Unicommerce OMS Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.unicommerce
    platform_context_id: platform_context.unicommerce.in.d2c_oms
    account_name: Teaxpress Unicommerce OMS Account
    account_type: oms_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: 'Unicommerce configured: Sales, Returns, Cancellations, Sales order report'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.unicommerce
        source_documents:
        - unicommerce_d2c_oms.md
        - unicommerce_operations.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.unicommerce.in.d2c_oms
        source_documents:
        - unicommerce_d2c_oms.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  canonical_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  name: Teaxpress Amazon Shipping / India Post Routing Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Teaxpress Amazon Shipping / India Post Routing Account
    account_type: shipping_invoice_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: Amazon configured only for Shipping invoice and Shipping settlement report via India Post routing. Not
      seller-central marketplace settlement.
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.in
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client explicitly says Amazon presence is logistics-only, not standard seller-central marketplace OMS or settlement.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.bluedart.primary
  canonical_id: platform_account.teaxpress_private_limited.bluedart.primary
  name: Teaxpress Bluedart Courier Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.01_bluedart
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    account_name: Teaxpress Bluedart Courier Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: source_described_pending_platform_context
    source_evidence: 'Bluedart configured: Settlement + Invoice; variants PP-Teabox, COD-Teabox, PP-Sammvaad, COD-Sammvaad'
    declared_platform_id: platform.bluedart
    declared_platform_label: platform.bluedart
    declared_platform_context_id: platform_context.bluedart.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.bluedart
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.bluedart.in
    notes:
    - No Bluedart canonical logistics markdown was uploaded; bindings are source-described only.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.ekart.primary
  canonical_id: platform_account.teaxpress_private_limited.ekart.primary
  name: Teaxpress Ekart Courier Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.02_ekart
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.ekart
    platform_context_id: platform_context.ekart.in
    account_name: Teaxpress Ekart Courier Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: 'Ekart configured: Settlement + Invoice; variants Teabox, COD-Sammvaad'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.ekart
        source_documents:
        - ekart_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.ekart.in
        source_documents:
        - ekart_logistics.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.delhivery.primary
  canonical_id: platform_account.teaxpress_private_limited.delhivery.primary
  name: Teaxpress Delhivery Courier Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.03_delhivery
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.delhivery
    platform_context_id: platform_context.delhivery.in
    account_name: Teaxpress Delhivery Courier Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: 'Delhivery configured: Settlement + Invoice; single shared variant'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.delhivery
        source_documents:
        - delhivery_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.delhivery.in
        source_documents:
        - delhivery_logistics.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  canonical_id: platform_account.teaxpress_private_limited.xpressbees.primary
  name: Teaxpress Xpressbees Courier Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.xpressbees
    platform_context_id: platform_context.xpressbees.in
    account_name: Teaxpress Xpressbees Courier Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: 'Xpressbees configured: Settlement + Settlement report + Invoice; single shared variant'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.xpressbees
        source_documents:
        - xpressbees_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.xpressbees.in
        source_documents:
        - xpressbees_logistics.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.dtdc.primary
  canonical_id: platform_account.teaxpress_private_limited.dtdc.primary
  name: Teaxpress DTDC Courier Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.05_dtdc
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.dtdc
    platform_context_id: platform_context.dtdc.in
    account_name: Teaxpress DTDC Courier Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: 'DTDC configured: TL/LTL Invoice; single shared variant'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.dtdc
        source_documents:
        - dtdc_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.dtdc.in
        source_documents:
        - dtdc_logistics.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.india_post.primary
  canonical_id: platform_account.teaxpress_private_limited.india_post.primary
  name: Teaxpress India Post Routing Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    account_name: Teaxpress India Post Routing Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: source_described_pending_platform_context
    source_evidence: India Post configured via amazon_shipping_settlement_report; single shared variant
    declared_platform_id: platform.india_post
    declared_platform_label: platform.india_post
    declared_platform_context_id: platform_context.india_post.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.india_post
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.india_post.in
    notes:
    - India Post source is routed through Amazon shipping settlement report, not a native canonical India Post table in the
      uploaded corpus.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.razorpay.shared
  canonical_id: platform_account.teaxpress_private_limited.razorpay.shared
  name: Teaxpress Razorpay Shared Payin Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.01_razorpay
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.02_razorpay
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: Teaxpress Razorpay Shared Payin Account
    account_type: payment_gateway_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: Razorpay configured for Teabox and Sammvaad; pipeline target razorpay_payin
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.razorpay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.razorpay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.payu.shared
  canonical_id: platform_account.teaxpress_private_limited.payu.shared
  name: Teaxpress PayU Shared Settlement Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.03_payu
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.04_payu
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    account_name: Teaxpress PayU Shared Settlement Account
    account_type: payment_gateway_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: source_described_pending_platform_context
    source_evidence: PayU configured for Teabox and Sammvaad; pipeline target payu_settlement
    declared_platform_id: platform.payu
    declared_platform_label: PayU payment gateway
    declared_platform_context_id: platform_context.payu.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.payu
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.payu.in
    notes:
    - No PayU canonical payment markdown/table card is present in uploaded corpus.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  canonical_id: platform_account.teaxpress_private_limited.axis_bank.shared
  name: Teaxpress Axis Bank Settlement Source
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - bank_statement.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.05_axis_bank
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.axis_bank
    platform_context_id: platform_context.axis_bank.in
    account_name: Teaxpress Axis Bank Settlement Source
    account_type: bank_settlement_source_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: Axis Bank configured as shared payment/bank settlement target axis_bank_settlement
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.axis_bank
        source_documents:
        - bank_statement.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.axis_bank.in
        source_documents:
        - bank_statement.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  canonical_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  name: Teaxpress HDFC Bank Settlement Source
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - bank_statement.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.06_hdfc_bank
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    platform_id: platform.hdfc_bank
    platform_context_id: platform_context.hdfc_bank.in
    account_name: Teaxpress HDFC Bank Settlement Source
    account_type: bank_settlement_source_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: India
    default_currency: INR
    currency_scope:
    - INR
    canonical_platform_status: canonical
    source_evidence: HDFC Bank configured as shared payment/bank settlement target hdfc_bank_settlement
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.hdfc_bank
        source_documents:
        - bank_statement.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.hdfc_bank.in
        source_documents:
        - bank_statement.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
  canonical_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
  name: account data binding / teaxpress private limited / shopify d2c / primary / shopify oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.01_shopify
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: D2C OMS
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Shopify | D2C OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_oms
      source_documents:
      - logistics_domain.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce
  canonical_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce
  name: account data binding / teaxpress private limited / unicommerce / primary / unicommerce
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.unicommerce.primary
    table_id: table.zs_observe.unicommerce
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Sales, Returns, Cancellations
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Unicommerce | Sales, Returns, Cancellations
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.unicommerce
      source_documents:
      - unicommerce_d2c_oms.md
      - unicommerce_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce_order_sales_report
  canonical_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce_order_sales_report
  name: account data binding / teaxpress private limited / unicommerce / primary / unicommerce order sales report
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.unicommerce.primary
    table_id: table.zs_observe.unicommerce_order_sales_report
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Sales order report
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Unicommerce | Sales order report
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.unicommerce_order_sales_report
      source_documents:
      - unicommerce_d2c_oms.md
      - unicommerce_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
  canonical_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
  name: account data binding / teaxpress private limited / amazon shipping india post / primary / amazon shipping invoice
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Shipping invoice
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: semantic_exact
    source_evidence: Amazon | Shipping invoice
    declared_table_id: table.zs_observe.amazon_shipping_invoice
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.amazon_shipping_invoice
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
  canonical_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
  name: account data binding / teaxpress private limited / amazon shipping india post / primary / amazon shipping settlement
    report
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Shipping settlement report
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: source_described
    source_evidence: Amazon | Shipping settlement report via India Post routing
    declared_table_id: table.zs_observe.amazon_shipping_settlement_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.amazon_shipping_settlement_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
  name: account data binding / teaxpress private limited / bluedart / primary / bluedart settlement
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.01_bluedart
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.bluedart.primary
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
      invoice_variants:
      - PP-Teabox
      - COD-Teabox
      - PP-Sammvaad
      - COD-Sammvaad
    mapping_confidence: source_described
    source_evidence: Bluedart | Settlement
    declared_table_id: table.zs_observe.bluedart_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.bluedart_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
  canonical_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
  name: account data binding / teaxpress private limited / bluedart / primary / bluedart invoice
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.01_bluedart
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.bluedart.primary
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Invoice
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
      invoice_variants:
      - PP-Teabox
      - COD-Teabox
      - PP-Sammvaad
      - COD-Sammvaad
    mapping_confidence: source_described
    source_evidence: Bluedart | Invoice
    declared_table_id: table.zs_observe.bluedart_invoice
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.bluedart_invoice
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_settlement
  name: account data binding / teaxpress private limited / ekart / primary / ekart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.02_ekart
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.ekart.primary
    table_id: table.zs_observe.ekart_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
      invoice_variants:
      - Teabox
      - COD-Sammvaad
    mapping_confidence: exact
    source_evidence: Ekart | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.ekart_settlement
      source_documents:
      - ekart_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_invoice
  canonical_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_invoice
  name: account data binding / teaxpress private limited / ekart / primary / ekart invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.02_ekart
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.ekart.primary
    table_id: table.zs_observe.ekart_invoice
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Invoice
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
      invoice_variants:
      - Teabox
      - COD-Sammvaad
    mapping_confidence: exact
    source_evidence: Ekart | Invoice
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.ekart_invoice
      source_documents:
      - ekart_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_settlement
  name: account data binding / teaxpress private limited / delhivery / primary / delhivery settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.03_delhivery
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.delhivery.primary
    table_id: table.zs_observe.delhivery_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Delhivery | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.delhivery_settlement
      source_documents:
      - delhivery_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_invoice
  canonical_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_invoice
  name: account data binding / teaxpress private limited / delhivery / primary / delhivery invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.03_delhivery
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.delhivery.primary
    table_id: table.zs_observe.delhivery_invoice
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Invoice
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Delhivery | Invoice
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.delhivery_invoice
      source_documents:
      - delhivery_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement
  name: account data binding / teaxpress private limited / xpressbees / primary / xpressbees settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.xpressbees.primary
    table_id: table.zs_observe.xpressbees_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Xpressbees | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.xpressbees_settlement
      source_documents:
      - xpressbees_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
  canonical_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
  name: account data binding / teaxpress private limited / xpressbees / primary / xpressbees settlement report
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.xpressbees.primary
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement report
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: source_described
    source_evidence: Xpressbees | Settlement report
    declared_table_id: table.zs_observe.xpressbees_settlement_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.xpressbees_settlement_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
  canonical_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
  name: account data binding / teaxpress private limited / xpressbees / primary / xpressbees invoice
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.xpressbees.primary
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Invoice
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: source_described
    source_evidence: Xpressbees | Invoice
    declared_table_id: table.zs_observe.xpressbees_invoice
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.xpressbees_invoice
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.dtdc.primary.dtdc_invoice
  canonical_id: account_data_binding.teaxpress_private_limited.dtdc.primary.dtdc_invoice
  name: account data binding / teaxpress private limited / dtdc / primary / dtdc invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.05_dtdc
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.dtdc.primary
    table_id: table.zs_observe.dtdc_invoice
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: TL/LTL Invoice
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: DTDC | TL/LTL Invoice
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.dtdc_invoice
      source_documents:
      - dtdc_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
  canonical_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
  name: account data binding / teaxpress private limited / india post / primary / amazon shipping settlement report
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.india_post.primary
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: India Post shipping settlement via Amazon report
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: source_described
    source_evidence: India Post | Via amazon_shipping_settlement_report
    declared_table_id: table.zs_observe.amazon_shipping_settlement_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.amazon_shipping_settlement_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.razorpay.shared.razorpay_payin
  canonical_id: account_data_binding.teaxpress_private_limited.razorpay.shared.razorpay_payin
  name: account data binding / teaxpress private limited / razorpay / shared / razorpay payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.01_razorpay
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.02_razorpay
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.razorpay.shared
    table_id: table.zs_observe.razorpay_payin
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Razorpay payin for Teabox and Sammvaad
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
      brand_entities:
      - Teabox
      - Sammvaad
    mapping_confidence: exact
    source_evidence: Razorpay | Teabox/Sammvaad | razorpay_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
  name: account data binding / teaxpress private limited / payu / shared / payu settlement
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.03_payu
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.04_payu
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.payu.shared
    table_canonical_status: source_described_pending_platform_context
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: PayU settlement for Teabox and Sammvaad
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
      brand_entities:
      - Teabox
      - Sammvaad
    mapping_confidence: source_described
    source_evidence: PayU | Teabox/Sammvaad | payu_settlement
    declared_table_id: table.zs_observe.payu_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.payu_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    - Source/client document describes this pipeline target, but no canonical platform context/table card was available in
      the uploaded platform markdowns. Keep non-queryable until platform context is added.
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.axis_bank.shared.axis_bank_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.axis_bank.shared.axis_bank_settlement
  name: account data binding / teaxpress private limited / axis bank / shared / axis bank settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - bank_statement.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.05_axis_bank
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.axis_bank.shared
    table_id: table.zs_ingest.axis_bank_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Axis Bank shared settlement
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: Axis Bank | Shared | axis_bank_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_ingest.axis_bank_settlement
      source_documents:
      - bank_statement.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.teaxpress_private_limited.hdfc_bank.shared.hdfc_bank_settlement
  canonical_id: account_data_binding.teaxpress_private_limited.hdfc_bank.shared.hdfc_bank_settlement
  name: account data binding / teaxpress private limited / hdfc bank / shared / hdfc bank settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  - bank_statement.md
  evidence_refs:
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.06_hdfc_bank
  fields:
    platform_account_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
    table_id: table.zs_ingest.hdfc_bank_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 52
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 190
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: HDFC Bank shared settlement
    logical_scope:
      region_or_market: India
      currency_scope:
      - INR
    mapping_confidence: exact
    source_evidence: HDFC Bank | Shared | hdfc_bank_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_ingest.hdfc_bank_settlement
      source_documents:
      - bank_statement.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.teaxpress_private_limited.d2c_oms
  canonical_id: business_scope_set.teaxpress_private_limited.d2c_oms
  name: Teaxpress D2C OMS
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.01_shopify
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  description: Shopify D2C plus Unicommerce sales/returns/cancellations/order-sales-report.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    scope_name: Teaxpress D2C OMS
    scope_type: d2c_oms_scope
    platform_account_ids:
    - platform_account.teaxpress_private_limited.shopify_d2c.primary
    - platform_account.teaxpress_private_limited.unicommerce.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  canonical_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  name: Teaxpress courier reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  description: Courier reconciliation scope across configured India couriers and Amazon/India Post shipping route.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    scope_name: Teaxpress courier reconciliation
    scope_type: logistics_reconciliation_scope
    platform_account_ids:
    - platform_account.teaxpress_private_limited.bluedart.primary
    - platform_account.teaxpress_private_limited.ekart.primary
    - platform_account.teaxpress_private_limited.delhivery.primary
    - platform_account.teaxpress_private_limited.xpressbees.primary
    - platform_account.teaxpress_private_limited.dtdc.primary
    - platform_account.teaxpress_private_limited.india_post.primary
    - platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  canonical_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  name: Teaxpress canonical courier bindings
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  description: Courier subset with canonical logistics table cards currently available.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    scope_name: Teaxpress canonical courier bindings
    scope_type: logistics_reconciliation_scope
    platform_account_ids:
    - platform_account.teaxpress_private_limited.ekart.primary
    - platform_account.teaxpress_private_limited.delhivery.primary
    - platform_account.teaxpress_private_limited.xpressbees.primary
    - platform_account.teaxpress_private_limited.dtdc.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  canonical_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  name: Teaxpress payment and bank settlement sources
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.01_razorpay
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.02_razorpay
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.03_payu
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.04_payu
  description: Payment/bank settlement scope. Razorpay/Axis/HDFC are canonical; PayU is source-described pending platform
    context.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    scope_name: Teaxpress payment and bank settlement sources
    scope_type: payment_gateway_settlement_scope
    platform_account_ids:
    - platform_account.teaxpress_private_limited.razorpay.shared
    - platform_account.teaxpress_private_limited.payu.shared
    - platform_account.teaxpress_private_limited.axis_bank.shared
    - platform_account.teaxpress_private_limited.hdfc_bank.shared
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  canonical_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  name: Teaxpress Teabox brand scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.01_identity
  description: Logical brand scope for Teabox until concrete brand filter columns are confirmed.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    scope_name: Teaxpress Teabox brand scope
    scope_type: brand_scope
    platform_account_ids:
    - platform_account.teaxpress_private_limited.shopify_d2c.primary
    - platform_account.teaxpress_private_limited.unicommerce.primary
    - platform_account.teaxpress_private_limited.razorpay.shared
    - platform_account.teaxpress_private_limited.payu.shared
    - platform_account.teaxpress_private_limited.bluedart.primary
    - platform_account.teaxpress_private_limited.ekart.primary
    - platform_account.teaxpress_private_limited.delhivery.primary
    - platform_account.teaxpress_private_limited.xpressbees.primary
    - platform_account.teaxpress_private_limited.dtdc.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  canonical_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  name: Teaxpress Sammvaad brand scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.01_identity
  description: Logical brand scope for Sammvaad until concrete brand filter columns are confirmed.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    scope_name: Teaxpress Sammvaad brand scope
    scope_type: brand_scope
    platform_account_ids:
    - platform_account.teaxpress_private_limited.shopify_d2c.primary
    - platform_account.teaxpress_private_limited.unicommerce.primary
    - platform_account.teaxpress_private_limited.razorpay.shared
    - platform_account.teaxpress_private_limited.payu.shared
    - platform_account.teaxpress_private_limited.bluedart.primary
    - platform_account.teaxpress_private_limited.ekart.primary
    - platform_account.teaxpress_private_limited.delhivery.primary
    - platform_account.teaxpress_private_limited.xpressbees.primary
    - platform_account.teaxpress_private_limited.dtdc.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  canonical_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  name: Teaxpress D2C OMS to payment/bank settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.section.04_payment_gateway_reconciliation
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.01_shopify
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.02_unicommerce
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.03_payu
  - ev.teaxpress_private_limited.docx.row.04_payment_gateway_reconciliation.04_payu
  description: D2C order flow from Shopify/Unicommerce to payment gateway/bank settlement sources. PayU remains draft until
    canonical context is added.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    flow_name: Teaxpress D2C OMS to payment/bank settlement
    flow_type: d2c_oms_to_payment_gateway_and_bank_settlement
    participant_platform_account_ids:
    - platform_account.teaxpress_private_limited.shopify_d2c.primary
    - platform_account.teaxpress_private_limited.unicommerce.primary
    - platform_account.teaxpress_private_limited.razorpay.shared
    - platform_account.teaxpress_private_limited.payu.shared
    - platform_account.teaxpress_private_limited.axis_bank.shared
    - platform_account.teaxpress_private_limited.hdfc_bank.shared
    business_scope_set_ids:
    - business_scope_set.teaxpress_private_limited.d2c_oms
    - business_scope_set.teaxpress_private_limited.payment_settlement_sources
    required_runtime_resolution:
    - payment reference join keys per source
    - brand filter column confirmation for Teabox/Sammvaad
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  canonical_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  name: Teaxpress D2C COD/order logistics reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.01_bluedart
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  description: COD/shipping reconciliation from D2C OMS sources into configured courier settlement/invoice sources. Only canonical
    courier bindings should be used for automated routing until Bluedart/India Post/Xpressbees invoice context is added.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    flow_name: Teaxpress D2C COD/order logistics reconciliation
    flow_type: d2c_cod_to_logistics_settlement
    participant_platform_account_ids:
    - platform_account.teaxpress_private_limited.shopify_d2c.primary
    - platform_account.teaxpress_private_limited.unicommerce.primary
    - platform_account.teaxpress_private_limited.bluedart.primary
    - platform_account.teaxpress_private_limited.ekart.primary
    - platform_account.teaxpress_private_limited.delhivery.primary
    - platform_account.teaxpress_private_limited.xpressbees.primary
    - platform_account.teaxpress_private_limited.dtdc.primary
    - platform_account.teaxpress_private_limited.india_post.primary
    - platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
    business_scope_set_ids:
    - business_scope_set.teaxpress_private_limited.d2c_oms
    - business_scope_set.teaxpress_private_limited.logistics_couriers
    required_runtime_resolution:
    - AWB/shipment join keys
    - brand-specific invoice variant handling
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  canonical_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  name: Teaxpress canonical courier invoice/settlement reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.02_ekart
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.03_delhivery
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.04_xpressbees
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.05_dtdc
  description: 'Canonical courier subset currently safe for query routing: Delhivery, Ekart, Xpressbees settlement, and DTDC
    invoice.'
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    flow_name: Teaxpress canonical courier invoice/settlement reconciliation
    flow_type: logistics_invoice_settlement
    participant_platform_account_ids:
    - platform_account.teaxpress_private_limited.ekart.primary
    - platform_account.teaxpress_private_limited.delhivery.primary
    - platform_account.teaxpress_private_limited.xpressbees.primary
    - platform_account.teaxpress_private_limited.dtdc.primary
    business_scope_set_ids:
    - business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
    required_runtime_resolution: []
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.teaxpress_private_limited.amazon_shipping_india_post_pending
  canonical_id: business_flow_binding.teaxpress_private_limited.amazon_shipping_india_post_pending
  name: Teaxpress Amazon Shipping / India Post reconciliation pending canonical settlement report
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.02_active_sales_channels
  - ev.teaxpress_private_limited.docx.section.03_logistics_courier_reconciliation
  - ev.teaxpress_private_limited.docx.row.02_active_sales_channels.03_amazon
  - ev.teaxpress_private_limited.docx.row.03_logistics_courier_reconciliation.06_india_post
  description: Amazon presence is logistics-only via India Post routing, not marketplace seller settlement.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    flow_name: Teaxpress Amazon Shipping / India Post reconciliation pending canonical settlement report
    flow_type: shipping_invoice_settlement
    participant_platform_account_ids:
    - platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
    - platform_account.teaxpress_private_limited.india_post.primary
    business_scope_set_ids:
    - business_scope_set.teaxpress_private_limited.logistics_couriers
    required_runtime_resolution:
    - canonical amazon_shipping_settlement_report table card
    - India Post native platform context if needed
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  canonical_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  name: Teaxpress payment gateway to bank pending bank-account binding
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Teaxpress Private Limited.docx
  evidence_refs:
  - ev.teaxpress_private_limited.docx.section.01_identity
  description: Payment/bank settlement source tables are configured, but final bank-account cards/bank-statement bindings
    are not provided in the client doc.
  fields:
    tenant_id: tenant.teaxpress_private_limited
    group_id: group.teaxpress_private_limited.teabox
    flow_name: Teaxpress payment gateway to bank pending bank-account binding
    flow_type: payment_gateway_to_bank
    participant_platform_account_ids:
    - platform_account.teaxpress_private_limited.razorpay.shared
    - platform_account.teaxpress_private_limited.payu.shared
    - platform_account.teaxpress_private_limited.axis_bank.shared
    - platform_account.teaxpress_private_limited.hdfc_bank.shared
    business_scope_set_ids:
    - business_scope_set.teaxpress_private_limited.payment_settlement_sources
    required_runtime_resolution:
    - actual bank account identifiers
    - bank_statement Account Data Binding for deposit matching
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_data_type: D2C OMS
  mapped_table_id: table.zs_observe.shopify_oms
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Shopify | D2C OMS
  resolved_canonical_mapped_now:
  - table.zs_observe.shopify_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_data_type: Sales, Returns, Cancellations
  mapped_table_id: table.zs_observe.unicommerce
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Unicommerce | Sales, Returns, Cancellations
  resolved_canonical_mapped_now:
  - table.zs_observe.unicommerce
  - table.zs_observe.unicommerce_order_sales_report
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_data_type: Sales order report
  mapped_table_id: table.zs_observe.unicommerce_order_sales_report
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Unicommerce | Sales order report
  resolved_canonical_mapped_now:
  - table.zs_observe.unicommerce
  - table.zs_observe.unicommerce_order_sales_report
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  source_data_type: Shipping invoice
  mapped_table_id: table.zs_observe.amazon_shipping_invoice
  mapping_confidence: semantic_exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon | Shipping invoice
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  source_data_type: Shipping settlement report
  mapped_table_id: table.zs_observe.amazon_shipping_settlement_report
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: Amazon | Shipping settlement report via India Post routing
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.bluedart_settlement
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: Bluedart | Settlement
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_data_type: Invoice
  mapped_table_id: table.zs_observe.bluedart_invoice
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: Bluedart | Invoice
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.ekart.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.ekart_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Ekart | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.ekart_settlement
  - table.zs_observe.ekart_invoice
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.ekart.primary
  source_data_type: Invoice
  mapped_table_id: table.zs_observe.ekart_invoice
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Ekart | Invoice
  resolved_canonical_mapped_now:
  - table.zs_observe.ekart_settlement
  - table.zs_observe.ekart_invoice
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.delhivery_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Delhivery | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.delhivery_settlement
  - table.zs_observe.delhivery_invoice
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_data_type: Invoice
  mapped_table_id: table.zs_observe.delhivery_invoice
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Delhivery | Invoice
  resolved_canonical_mapped_now:
  - table.zs_observe.delhivery_settlement
  - table.zs_observe.delhivery_invoice
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.xpressbees_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Xpressbees | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.xpressbees_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_data_type: Settlement report
  mapped_table_id: table.zs_observe.xpressbees_settlement_report
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: Xpressbees | Settlement report
  resolved_canonical_mapped_now:
  - table.zs_observe.xpressbees_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_data_type: Invoice
  mapped_table_id: table.zs_observe.xpressbees_invoice
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: Xpressbees | Invoice
  resolved_canonical_mapped_now:
  - table.zs_observe.xpressbees_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_data_type: TL/LTL Invoice
  mapped_table_id: table.zs_observe.dtdc_invoice
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: DTDC | TL/LTL Invoice
  resolved_canonical_mapped_now:
  - table.zs_observe.dtdc_invoice
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.india_post.primary
  source_data_type: India Post shipping settlement via Amazon report
  mapped_table_id: table.zs_observe.amazon_shipping_settlement_report
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: India Post | Via amazon_shipping_settlement_report
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_data_type: Razorpay payin for Teabox and Sammvaad
  mapped_table_id: table.zs_observe.razorpay_payin
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Razorpay | Teabox/Sammvaad | razorpay_payin
  resolved_canonical_mapped_now:
  - table.zs_observe.razorpay_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.payu.shared
  source_data_type: PayU settlement for Teabox and Sammvaad
  mapped_table_id: table.zs_observe.payu_settlement
  mapping_confidence: source_described
  table_canonical_status: source_described_pending_platform_context
  status: draft
  source_evidence: PayU | Teabox/Sammvaad | payu_settlement
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.axis_bank.shared
  source_data_type: Axis Bank shared settlement
  mapped_table_id: table.zs_ingest.axis_bank_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Axis Bank | Shared | axis_bank_settlement
  resolved_canonical_mapped_now:
  - table.zs_ingest.axis_bank_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  platform_account_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  source_data_type: HDFC Bank shared settlement
  mapped_table_id: table.zs_ingest.hdfc_bank_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: HDFC Bank | Shared | hdfc_bank_settlement
  resolved_canonical_mapped_now:
  - table.zs_ingest.hdfc_bank_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  source_data_type: Settlement + Invoice with PP/COD and brand variants
  source_platform: Bluedart
  mapped_table_id: null
  mapping_confidence: not_mapped_canonical_context_missing
  table_canonical_status: missing_platform_context
  status: draft_gap
  reason: No Bluedart canonical logistics markdown or table cards in uploaded corpus.
  recommended_future_card_or_table: platform.bluedart, platform_context.bluedart.in, table.zs_observe.bluedart_settlement,
    table.zs_observe.bluedart_invoice
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  source_data_type: payu_settlement for Teabox and Sammvaad
  source_platform: PayU
  mapped_table_id: null
  mapping_confidence: not_mapped_canonical_context_missing
  table_canonical_status: missing_platform_context
  status: draft_gap
  reason: No PayU canonical payment gateway markdown/table card in uploaded corpus.
  recommended_future_card_or_table: platform.payu, platform_context.payu.in, table.zs_observe.payu_settlement
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  source_data_type: amazon_shipping_settlement_report via India Post routing
  source_platform: India Post / Amazon Shipping
  mapped_table_id: null
  mapping_confidence: not_mapped_canonical_context_missing
  table_canonical_status: missing_platform_context
  status: draft_gap
  reason: No canonical amazon_shipping_settlement_report or India Post logistics context in uploaded corpus.
  recommended_future_card_or_table: table.zs_observe.amazon_shipping_settlement_report, platform.india_post, platform_context.india_post.in
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Teaxpress Private Limited
  source_data_type: Settlement report + Invoice
  source_platform: Xpressbees
  mapped_table_id: null
  mapping_confidence: not_mapped_canonical_context_missing
  table_canonical_status: missing_platform_context
  status: draft_gap
  reason: Canonical Xpressbees settlement exists, but separate xpressbees_invoice and xpressbees_settlement_report table cards
    are not present.
  recommended_future_card_or_table: table.zs_observe.xpressbees_invoice, table.zs_observe.xpressbees_settlement_report
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.teaxpress_private_limited.has_group.b666b9ac8863
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.teaxpress_private_limited
  target_card_id: group.teaxpress_private_limited.teabox
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_GROUP
- edge_id: edge.teaxpress_private_limited.has_platform_account.e135bde226be
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.08f38eb48bf5
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  target_card_id: platform.shopify
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.5d60158a8a2e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  target_card_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.19cf7ba609d6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  target_card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.10b98ffcebc4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
  target_card_id: table.zs_observe.shopify_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.cab634fbfee3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.898d2263d218
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  target_card_id: platform.unicommerce
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.0113f0839c02
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  target_card_id: platform_context.unicommerce.in.d2c_oms
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.3d60d3d1805f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  target_card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.5d1a99cc9cca
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce
  target_card_id: table.zs_observe.unicommerce
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.e4836b68d090
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  target_card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce_order_sales_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.817d1e4c2109
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce_order_sales_report
  target_card_id: table.zs_observe.unicommerce_order_sales_report
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.55c453869715
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.16c138bf7919
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.bb43636fbfe8
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  target_card_id: platform_context.amazon.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.ba302c539452
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  target_card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.00b8fa01374b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  target_card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_platform_account.b71216336c62
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.cf2e9cf9ca12
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  target_card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.9b81bc5aa8e8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  target_card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_platform_account.1f9a23fda7fa
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.06d983f252f2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.ekart.primary
  target_card_id: platform.ekart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.2a97f9baed6b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.ekart.primary
  target_card_id: platform_context.ekart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.9869f1e24e39
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.ekart.primary
  target_card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.27ca26d66e41
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_settlement
  target_card_id: table.zs_observe.ekart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.8d5960ac3fdc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.ekart.primary
  target_card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.1ddb8fd5f3c4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_invoice
  target_card_id: table.zs_observe.ekart_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.d5e580c5d6fb
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.32b992062f45
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  target_card_id: platform.delhivery
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.c6bfd01cb414
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  target_card_id: platform_context.delhivery.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.9997149a3fbc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  target_card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.395abab9d17c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_settlement
  target_card_id: table.zs_observe.delhivery_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.c602ea5f2f45
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  target_card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.70d20e6a6ae4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_invoice
  target_card_id: table.zs_observe.delhivery_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.2124135f0c25
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.7c801899b02a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  target_card_id: platform.xpressbees
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.66939669c646
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  target_card_id: platform_context.xpressbees.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.3fd22c743f35
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  target_card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.d6e8bdd63d0b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement
  target_card_id: table.zs_observe.xpressbees_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.033cce6c49c5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  target_card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.ac2492c356be
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  target_card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_platform_account.f251875a72a7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.a2577f36e3ff
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  target_card_id: platform.dtdc
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.23c57a9dee41
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  target_card_id: platform_context.dtdc.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.e4497c10de11
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  target_card_id: account_data_binding.teaxpress_private_limited.dtdc.primary.dtdc_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.5a711d272662
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.dtdc.primary.dtdc_invoice
  target_card_id: table.zs_observe.dtdc_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.661b9f12511f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.india_post.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.4341eadbf3d5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.india_post.primary
  target_card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_platform_account.61a664a1f145
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.83ba60cffaf5
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  target_card_id: platform.razorpay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.c5ef180fd55e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  target_card_id: platform_context.razorpay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.a9049ce18202
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  target_card_id: account_data_binding.teaxpress_private_limited.razorpay.shared.razorpay_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.f9c0eac8bc16
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.razorpay.shared.razorpay_payin
  target_card_id: table.zs_observe.razorpay_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.9291f7d163d3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.payu.shared
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.b9874bd1a72c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.payu.shared
  target_card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.has_platform_account.b9d001d633ad
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.31f27b7ba7c2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  target_card_id: platform.axis_bank
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.c2d4c0797389
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  target_card_id: platform_context.axis_bank.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.34d196148c45
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  target_card_id: account_data_binding.teaxpress_private_limited.axis_bank.shared.axis_bank_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.ee68bc66ecbe
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.axis_bank.shared.axis_bank_settlement
  target_card_id: table.zs_ingest.axis_bank_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_platform_account.0adb06cd080f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.uses_platform.6acb56bc073a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  target_card_id: platform.hdfc_bank
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.teaxpress_private_limited.uses_platform_context.ea8bb882e19b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  target_card_id: platform_context.hdfc_bank.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.teaxpress_private_limited.has_account_data_binding.8202fd077e72
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  target_card_id: account_data_binding.teaxpress_private_limited.hdfc_bank.shared.hdfc_bank_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.teaxpress_private_limited.binds_to_table.2e0dea94a46a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.teaxpress_private_limited.hdfc_bank.shared.hdfc_bank_settlement
  target_card_id: table.zs_ingest.hdfc_bank_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.teaxpress_private_limited.has_business_scope_set.9b2b33d2a3ff
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_scope_set.teaxpress_private_limited.d2c_oms
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.includes_platform_account.7bca0f25355a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.d2c_oms
  target_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.da5419c8c9f4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.d2c_oms
  target_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_business_scope_set.492731d9db0c
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.includes_platform_account.89bee631dc22
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.af2c71784fe4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.64bd7de4e7fa
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.8662e2fdfb96
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.534946d965f3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.211ffae3cb47
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.india_post.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.dce9c6346b61
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_business_scope_set.7cba0de5cb77
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.includes_platform_account.e1f8b0c1aaae
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.8fecc44a3958
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.2f45d0d07006
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.0eb76cbc632b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_business_scope_set.70f1b2cd680f
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.includes_platform_account.de9883c71e0a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  target_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.b2f938b8f947
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  target_card_id: platform_account.teaxpress_private_limited.payu.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.4dbecafb730c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  target_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.9dca324415c2
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  target_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_business_scope_set.40893fd85d0a
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.includes_platform_account.82d47238b335
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.a7598d5da28f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.81aae88accbe
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.ff820eee42bf
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.payu.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.3bcc6fd7c37f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.b8ecf592f2a3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.8ef203974f44
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.ea34b98c56e2
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.1438fa171e20
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.teabox_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_business_scope_set.8145fa9d4a12
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.includes_platform_account.addf78b70670
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.bfea576c0d59
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.bac8a0fe63f3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.e0b74a4f4662
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.payu.shared
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.408b6f1717ac
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.2c8f1b153130
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.e0444ddaaa07
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.66a0d97d4b72
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.includes_platform_account.b6a95cca8606
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.teaxpress_private_limited.sammvaad_brand_scope
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.teaxpress_private_limited.has_business_flow_binding.f7d1b7c3dad0
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.015c996458d2
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: business_scope_set.teaxpress_private_limited.d2c_oms
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.f6805e9f3201
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.has_flow_participant.cefeda4825d5
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.28ec75ef4c4d
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.b4aa96560712
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.cf3ea46332a8
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: platform_account.teaxpress_private_limited.payu.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.ecd46ed2ead7
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.e360c086a391
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_oms_to_payment_settlement
  target_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_business_flow_binding.f529808a3e3f
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.2f9424c811b8
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: business_scope_set.teaxpress_private_limited.d2c_oms
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.b6647bb3b61f
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.has_flow_participant.a0f904bd5bde
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.ccfc7c96eb02
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.unicommerce.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.49b8e6a6bdb9
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.48eec1263e59
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.74aebd031925
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.a51494d0a3d3
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.5f5c7617a2f6
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.c7f9bdbfe1ea
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.india_post.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.324a3ff4453d
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.d2c_cod_to_logistics_settlement
  target_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_business_flow_binding.646a6816747c
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.1dc71a61f3af
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  target_card_id: business_scope_set.teaxpress_private_limited.canonical_logistics_couriers
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.has_flow_participant.ce51830c55cb
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  target_card_id: platform_account.teaxpress_private_limited.ekart.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.2e8a78f8e838
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  target_card_id: platform_account.teaxpress_private_limited.delhivery.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.54829f1b1959
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  target_card_id: platform_account.teaxpress_private_limited.xpressbees.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.25a6d2567346
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.canonical_courier_invoice_settlement
  target_card_id: platform_account.teaxpress_private_limited.dtdc.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_business_flow_binding.e69964f4d937
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_flow_binding.teaxpress_private_limited.amazon_shipping_india_post_pending
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.fd65f124c3d6
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.amazon_shipping_india_post_pending
  target_card_id: business_scope_set.teaxpress_private_limited.logistics_couriers
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.has_flow_participant.f086105d7fbc
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.amazon_shipping_india_post_pending
  target_card_id: platform_account.teaxpress_private_limited.amazon_shipping_india_post.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.314dfa3ac134
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.amazon_shipping_india_post_pending
  target_card_id: platform_account.teaxpress_private_limited.india_post.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_business_flow_binding.41e3db255635
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.teaxpress_private_limited.teabox
  target_card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.teaxpress_private_limited.uses_business_scope_set.a9640f246d39
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  target_card_id: business_scope_set.teaxpress_private_limited.payment_settlement_sources
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.teaxpress_private_limited.has_flow_participant.2c20b1f09d32
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  target_card_id: platform_account.teaxpress_private_limited.razorpay.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.55b5d15a4abf
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  target_card_id: platform_account.teaxpress_private_limited.payu.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.e6b4790405af
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  target_card_id: platform_account.teaxpress_private_limited.axis_bank.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.teaxpress_private_limited.has_flow_participant.9b9bd3a07216
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.teaxpress_private_limited.payment_gateway_to_bank_pending_bank_account
  target_card_id: platform_account.teaxpress_private_limited.hdfc_bank.shared
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch4
    source_json_edge_type: HAS_FLOW_PARTICIPANT
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.amazon_shipping_invoice
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.amazon_shipping_invoice
  original_edge:
    source: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
    edge: BINDS_TO_TABLE
    target: table.zs_observe.amazon_shipping_invoice
    table_canonical_status: canonical
- source_card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.amazon_shipping_settlement_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.amazon_shipping_settlement_report
  original_edge:
    source: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.amazon_shipping_settlement_report
    table_canonical_status: source_described_pending_platform_context
- source_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.bluedart
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.bluedart
  original_edge:
    source: platform_account.teaxpress_private_limited.bluedart.primary
    edge: USES_PLATFORM
    target: platform.bluedart
- source_card_id: platform_account.teaxpress_private_limited.bluedart.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.bluedart.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.bluedart.in
  original_edge:
    source: platform_account.teaxpress_private_limited.bluedart.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.bluedart.in
- source_card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.bluedart_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.bluedart_settlement
  original_edge:
    source: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.bluedart_settlement
    table_canonical_status: source_described_pending_platform_context
- source_card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.bluedart_invoice
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.bluedart_invoice
  original_edge:
    source: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
    edge: BINDS_TO_TABLE
    target: table.zs_observe.bluedart_invoice
    table_canonical_status: source_described_pending_platform_context
- source_card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.xpressbees_settlement_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.xpressbees_settlement_report
  original_edge:
    source: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.xpressbees_settlement_report
    table_canonical_status: source_described_pending_platform_context
- source_card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.xpressbees_invoice
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.xpressbees_invoice
  original_edge:
    source: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
    edge: BINDS_TO_TABLE
    target: table.zs_observe.xpressbees_invoice
    table_canonical_status: source_described_pending_platform_context
- source_card_id: platform_account.teaxpress_private_limited.india_post.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.india_post
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.india_post
  original_edge:
    source: platform_account.teaxpress_private_limited.india_post.primary
    edge: USES_PLATFORM
    target: platform.india_post
- source_card_id: platform_account.teaxpress_private_limited.india_post.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.india_post.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.india_post.in
  original_edge:
    source: platform_account.teaxpress_private_limited.india_post.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.india_post.in
- source_card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.amazon_shipping_settlement_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.amazon_shipping_settlement_report
  original_edge:
    source: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.amazon_shipping_settlement_report
    table_canonical_status: source_described_pending_platform_context
- source_card_id: platform_account.teaxpress_private_limited.payu.shared
  edge_type: USES_PLATFORM
  target_card_id: platform.payu
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.payu
  original_edge:
    source: platform_account.teaxpress_private_limited.payu.shared
    edge: USES_PLATFORM
    target: platform.payu
- source_card_id: platform_account.teaxpress_private_limited.payu.shared
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.payu.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.payu.in
  original_edge:
    source: platform_account.teaxpress_private_limited.payu.shared
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.payu.in
- source_card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.payu_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.payu_settlement
  original_edge:
    source: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.payu_settlement
    table_canonical_status: source_described_pending_platform_context
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: platform_context.bluedart.in
  missing_artifacts:
  - platform_context.bluedart.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.teaxpress_private_limited.bluedart.primary
  generated_by_refactor: true
- platform_or_area: platform_context.india_post.in
  missing_artifacts:
  - platform_context.india_post.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.teaxpress_private_limited.india_post.primary
  generated_by_refactor: true
- platform_or_area: platform_context.payu.in
  missing_artifacts:
  - platform_context.payu.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.teaxpress_private_limited.payu.shared
  generated_by_refactor: true
- platform_or_area: platform.bluedart
  missing_artifacts:
  - platform.bluedart
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.teaxpress_private_limited.bluedart.primary
  generated_by_refactor: true
- platform_or_area: platform.india_post
  missing_artifacts:
  - platform.india_post
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.teaxpress_private_limited.india_post.primary
  generated_by_refactor: true
- platform_or_area: platform.payu
  missing_artifacts:
  - platform.payu
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.teaxpress_private_limited.payu.shared
  generated_by_refactor: true
- platform_or_area: table.zs_observe.amazon_shipping_invoice
  missing_artifacts:
  - table.zs_observe.amazon_shipping_invoice
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
  generated_by_refactor: true
- platform_or_area: table.zs_observe.amazon_shipping_settlement_report
  missing_artifacts:
  - table.zs_observe.amazon_shipping_settlement_report
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
  - account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
  generated_by_refactor: true
- platform_or_area: table.zs_observe.bluedart_invoice
  missing_artifacts:
  - table.zs_observe.bluedart_invoice
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
  generated_by_refactor: true
- platform_or_area: table.zs_observe.bluedart_settlement
  missing_artifacts:
  - table.zs_observe.bluedart_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.payu_settlement
  missing_artifacts:
  - table.zs_observe.payu_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.xpressbees_invoice
  missing_artifacts:
  - table.zs_observe.xpressbees_invoice
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
  generated_by_refactor: true
- platform_or_area: table.zs_observe.xpressbees_settlement_report
  missing_artifacts:
  - table.zs_observe.xpressbees_settlement_report
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- severity: high
  item: Add or confirm canonical Bluedart, PayU, India Post, and amazon_shipping_settlement_report context before routing
    those queries.
  review_resolution_status: open
- severity: high
  item: Add actual bank account cards and bank-statement Account Data Bindings before activating payment_gateway_to_bank flow.
  review_resolution_status: open
- severity: medium
  item: Confirm whether Teabox/Sammvaad should be separate Group cards or remain logical brand scopes under group TeaBox.
  review_resolution_status: open
- severity: medium
  item: Confirm brand filter columns/values for Teabox and Sammvaad on Shopify, Unicommerce, Razorpay, PayU, and courier files.
  review_resolution_status: open
- severity: medium
  item: Confirm external merchant/store/courier account identifiers for all platform accounts.
  review_resolution_status: open
- item: platform_context.bluedart.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.teaxpress_private_limited.bluedart.primary
  generated_by_refactor: true
- item: platform_context.india_post.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.teaxpress_private_limited.india_post.primary
  generated_by_refactor: true
- item: platform_context.payu.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.teaxpress_private_limited.payu.shared
  generated_by_refactor: true
- item: platform.bluedart
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.teaxpress_private_limited.bluedart.primary
  generated_by_refactor: true
- item: platform.india_post
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.teaxpress_private_limited.india_post.primary
  generated_by_refactor: true
- item: platform.payu
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.teaxpress_private_limited.payu.shared
  generated_by_refactor: true
- item: table.zs_observe.amazon_shipping_invoice
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
  generated_by_refactor: true
- item: table.zs_observe.amazon_shipping_settlement_report
  issue: Referenced as table_id by 2 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
  - account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
  generated_by_refactor: true
- item: table.zs_observe.bluedart_invoice
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
  generated_by_refactor: true
- item: table.zs_observe.bluedart_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
  generated_by_refactor: true
- item: table.zs_observe.payu_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
  generated_by_refactor: true
- item: table.zs_observe.xpressbees_invoice
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
  generated_by_refactor: true
- item: table.zs_observe.xpressbees_settlement_report
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
  generated_by_refactor: true
resolved_review_items: []
non_blocking_declared_semantic_reference_gaps: []
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 46
  refactored_card_count: 46
  original_edge_count: 158
  refactored_edge_count: 144
  blocked_edge_count: 14
  source_evidence_count: 19
  source_row_evidence_count: 15
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 13
    account_data_binding: 20
    business_scope_set: 6
    business_flow_binding: 5
  status_counts:
    active: 33
    review_required: 11
    draft: 2
  review_status_counts:
    accepted: 33
    review_required: 13
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 14
  canonical_resolution_gap_type_counts:
    table_id: 8
    platform_id: 3
    platform_context_id: 3
  status_correction_count: 11
  status_changes:
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
    card_type: account_data_binding
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: platform_account.teaxpress_private_limited.bluedart.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: platform_account.teaxpress_private_limited.india_post.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  - card_id: platform_account.teaxpress_private_limited.payu.shared
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
    card_type: account_data_binding
    from_status: draft
    from_active: false
    to_status: review_required
    to_active: false
    reason: table_binding_missing_canonical_table_card
  id_or_source_replacement_count: 25
  id_or_source_replacements:
  - card_id: group.teaxpress_private_limited.teabox
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.teaxpress_private_limited.shopify_d2c.primary
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.unicommerce.primary.unicommerce_order_sales_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.amazon_shipping_india_post.primary.amazon_shipping_settlement_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.bluedart.primary.bluedart_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.ekart.primary.ekart_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.delhivery.primary.delhivery_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_settlement_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.xpressbees.primary.xpressbees_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.dtdc.primary.dtdc_invoice
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.india_post.primary.amazon_shipping_settlement_report
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.razorpay.shared.razorpay_payin
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.payu.shared.payu_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.axis_bank.shared.axis_bank_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.teaxpress_private_limited.hdfc_bank.shared.hdfc_bank_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  resolved_prior_review_count: 0
  open_review_count: 18
  future_context_gap_count: 13
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 0
  non_blocking_declared_semantic_reference_gap_type_counts: {}
  edge_status_counts:
    emitted: 144
    blocked_unresolved: 14
```
