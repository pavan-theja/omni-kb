# Independent Validation Report — Client Runtime Refactor Batch 4

This validation was run after generation against the emitted normalized JSON and markdown files. It checks parser YAML, edge references, active table bindings, forbidden client-layer card types, duplicate card IDs, status/active consistency, old Shopify source leakage, and Volans Walmart stale-pending cleanup.

```yaml
independent_validation_summary:
  independent_validation_result: pass
  clients_validated: 3
  canonical_ids_seen: 9918
  total_cards: 110
  total_edges: 314
  total_blocked_edges: 14
  yaml_parse_error_count: 0
  edge_reference_error_count: 0
  active_bindings_to_missing_tables_count: 0
  forbidden_card_count: 0
  duplicate_card_id_count: 0
  status_active_conflict_count: 0
  old_shopify_source_doc_count: 0
  stale_walmart_pending_id_count: 0
```

## Per-client checks

```yaml
client_validation_results:
- client_slug: teaxpress_private_limited
  markdown_file: teaxpress_private_limited_client_runtime_refactored.md
  cards: 46
  edges: 144
  blocked_edges: 14
  open_reviews: 18
  resolved_reviews: 0
  future_gaps: 13
  source_evidence: 19
  yaml_errors: 0
  edge_reference_errors: 0
  active_bindings_to_missing_tables: 0
  forbidden_cards: 0
  duplicate_card_ids: 0
  status_active_conflicts: 0
  old_shopify_source_docs: 0
  walmart_required_cards: []
  stale_walmart_pending_ids: []
- client_slug: volans_epic_llc
  markdown_file: volans_epic_llc_client_runtime_refactored.md
  cards: 32
  edges: 85
  blocked_edges: 0
  open_reviews: 4
  resolved_reviews: 1
  future_gaps: 0
  source_evidence: 12
  yaml_errors: 0
  edge_reference_errors: 0
  active_bindings_to_missing_tables: 0
  forbidden_cards: 0
  duplicate_card_ids: 0
  status_active_conflicts: 0
  old_shopify_source_docs: 0
  walmart_required_cards:
  - card_id: account_data_binding.volans_epic_llc.walmart_us.primary.walmart_oms
    present: true
    status: active
    active: true
  - card_id: account_data_binding.volans_epic_llc.walmart_us.primary.walmart_settlement
    present: true
    status: active
    active: true
  - card_id: account_data_binding.volans_epic_llc.walmart_us.primary.walmart_lookup
    present: true
    status: active
    active: true
  - card_id: business_scope_set.volans_epic_llc.walmart_us
    present: true
    status: active
    active: true
  - card_id: business_flow_binding.volans_epic_llc.walmart_marketplace_reconciliation
    present: true
    status: active
    active: true
  stale_walmart_pending_ids: []
- client_slug: volans_uptown_llc
  markdown_file: volans_uptown_llc_client_runtime_refactored.md
  cards: 32
  edges: 85
  blocked_edges: 0
  open_reviews: 4
  resolved_reviews: 1
  future_gaps: 0
  source_evidence: 12
  yaml_errors: 0
  edge_reference_errors: 0
  active_bindings_to_missing_tables: 0
  forbidden_cards: 0
  duplicate_card_ids: 0
  status_active_conflicts: 0
  old_shopify_source_docs: 0
  walmart_required_cards:
  - card_id: account_data_binding.volans_uptown_llc.walmart_us.primary.walmart_oms
    present: true
    status: active
    active: true
  - card_id: account_data_binding.volans_uptown_llc.walmart_us.primary.walmart_settlement
    present: true
    status: active
    active: true
  - card_id: account_data_binding.volans_uptown_llc.walmart_us.primary.walmart_lookup
    present: true
    status: active
    active: true
  - card_id: business_scope_set.volans_uptown_llc.walmart_us
    present: true
    status: active
    active: true
  - card_id: business_flow_binding.volans_uptown_llc.walmart_marketplace_reconciliation
    present: true
    status: active
    active: true
  stale_walmart_pending_ids: []
```

## Notes

- Volans Epic and Volans Uptown now include active Walmart OMS, settlement, and lookup bindings because the Walmart canonical markdown is available.

- Teaxpress still has blocked/non-materialized references for Bluedart, India Post, PayU, and Amazon-shipping/XpressBees supplemental table IDs that are not present in the uploaded canonical registry. These were preserved as review gaps instead of emitted as dangling edges.

- Shopify references resolve through `shopify_d2c_oms_v2.md`; the superseded Shopify source file is not present in emitted candidate card `source_documents`.
