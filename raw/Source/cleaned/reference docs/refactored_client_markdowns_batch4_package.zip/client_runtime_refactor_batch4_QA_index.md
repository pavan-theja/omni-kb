# Client Runtime Markdown Refactor — Batch 4 QA Index

This package contains parser-ready client runtime markdowns for Teaxpress Private Limited, Volans Epic LLC, and Volans Uptown LLC.

The refactor used the uploaded canonical marketplace/logistics/banking/payment/OMS/WMS markdowns, with `shopify_d2c_oms_v2.md` as the active Shopify source.

```yaml
batch_validation_summary:
  batch_id: client_runtime_refactor_batch4_v2_1
  generated_date: '2026-05-24'
  client_count: 3
  output_directory: /mnt/data/refactored_client_markdowns_batch4
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  active_shopify_canonical: shopify_d2c_oms_v2.md
  total_cards: 110
  total_emitted_edges: 314
  total_blocked_edges: 14
  total_source_evidence: 43
  total_row_evidence: 33
  total_open_reviews: 26
  total_resolved_reviews: 2
  yaml_parse_error_count: 0
  active_bindings_to_missing_tables: 0
  edge_reference_error_count: 0
  status_active_conflict_count: 0
  forbidden_candidate_card_count: 0
  client_outputs:
  - client_slug: teaxpress_private_limited
    client_name: Teaxpress Private Limited
    output_markdown: teaxpress_private_limited_client_runtime_refactored.md
    cards: 46
    emitted_edges: 144
    blocked_edges: 14
    source_evidence: 19
    row_evidence: 15
    open_reviews: 18
    resolved_reviews: 0
    future_context_gaps: 13
    status_corrections: 11
    canonical_resolution_gaps: 14
    result: pass
  - client_slug: volans_epic_llc
    client_name: Volans Epic LLC
    output_markdown: volans_epic_llc_client_runtime_refactored.md
    cards: 32
    emitted_edges: 85
    blocked_edges: 0
    source_evidence: 12
    row_evidence: 9
    open_reviews: 4
    resolved_reviews: 1
    future_context_gaps: 0
    status_corrections: 0
    canonical_resolution_gaps: 0
    result: pass
  - client_slug: volans_uptown_llc
    client_name: Volans Uptown LLC
    output_markdown: volans_uptown_llc_client_runtime_refactored.md
    cards: 32
    emitted_edges: 85
    blocked_edges: 0
    source_evidence: 12
    row_evidence: 9
    open_reviews: 4
    resolved_reviews: 1
    future_context_gaps: 0
    status_corrections: 0
    canonical_resolution_gaps: 0
    result: pass
  yaml_parse_errors: []
```

## Output Files

- `teaxpress_private_limited_client_runtime_refactored.md` — 46 cards, 144 emitted edges, 14 blocked edges, result `pass`.
- `volans_epic_llc_client_runtime_refactored.md` — 32 cards, 85 emitted edges, 0 blocked edges, result `pass`.
- `volans_uptown_llc_client_runtime_refactored.md` — 32 cards, 85 emitted edges, 0 blocked edges, result `pass`.
