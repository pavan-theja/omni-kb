# Mensa Brand Technologies Private Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: mensa_business_client_runtime_cards_v2_1_refactored
  created_for: Mensa Brand Technologies Private Limited
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  card_count: 117
  edge_count: 408
  design_rule: Tenant/group identity, platform accounts, account data bindings, business scope sets, and business flow bindings
    are client/runtime cards. Generic platform docs remain reusable and do not create tenant/group/account/binding cards.
  version: v2_1_refactored
  generated_date: '2026-05-24'
  client_slug: mensa_business
  source_json_bad_state: mensa_business.json
  source_docx: Mensa Brand Technologies Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: mensa_business.json
  source_docx: Mensa Brand Technologies Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: platform_account.mensa.nykaa_in.primary
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: platform_account.mensa.amazon_us.primary
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.amazon_ca.primary
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.amazon_uk.primary
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.amazon_mx.primary
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.mensa.shopify_d2c.primary
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: business_scope_set.mensa_brands.shopify_d2c
    kind: canonical_id
    from: platform_context.shopify.in
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  status_changes:
  - card_id: platform_account.mensa.amazon_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.flipkart_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.myntra_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.meesho_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.nykaa_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.jiomart_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.snapdeal_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.tatacliq_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.limeroad_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.firstcry_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.shop101_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.cred_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.klip_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.blitz_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.snapmint_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.amazon_us.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.amazon_ca.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.amazon_uk.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.amazon_mx.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.walmart_us.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shopify_d2c.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.unicommerce_oms.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.delhivery_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.ekart_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.xpressbees_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shadowfax_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.smartr_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.dtdc_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shiprocket_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shipturtle_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.razorpay_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.paytm_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.phonepe_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.cashfree_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.easebuzz_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    card_type: business_scope_set
    from_status: draft
    from_active: false
    to_status: active
    to_active: true
    reason: scope_is_source_confirmed_and_can_hold_partial_resolved_members_with_gaps_explicitly_declared
  blocked_edge_count: 18
  canonical_resolution_gap_count: 43
  resolved_prior_review_count: 1
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.mensa_business.docx.section.01_identity
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L11
  summary: '* Business: Large-scale multi-channel marketplace seller

    * Geography: India (primary) + International (US, CA, UK, MX)

    * OMS/WMS: Increff, Unicommerce, Shopify (D2C)

    * Logistics: Delhivery, Ekart, Xpressbees, Shadowfax, Smartr, DTDC, Shiprocket, Shipturtle

    * Payment gateways: Razorpay, Paytm, PhonePe, Cashfree, Easebuzz

    * GROUP LEVEL ID : 22

    * GROUP ID :8

    * GROUP NAME : **Mensa Brands**

    * CLIENT NAME : M**ensa Brand Technologies Private Limited**'
  raw_lines:
  - '* Business: Large-scale multi-channel marketplace seller'
  - '* Geography: India (primary) + International (US, CA, UK, MX)'
  - '* OMS/WMS: Increff, Unicommerce, Shopify (D2C)'
  - '* Logistics: Delhivery, Ekart, Xpressbees, Shadowfax, Smartr, DTDC, Shiprocket, Shipturtle'
  - '* Payment gateways: Razorpay, Paytm, PhonePe, Cashfree, Easebuzz'
  - '* GROUP LEVEL ID : 22'
  - '* GROUP ID :8'
  - '* GROUP NAME : **Mensa Brands**'
  - '* CLIENT NAME : M**ensa Brand Technologies Private Limited**'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mensa_business.docx.section.02_active_sales_channels_domestic
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: docx_section
  source_lines: L13-L29
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Amazon India | OMS (B2C + B2B), Settlement, Returns, Fee Preview, Disbursement, Transactions |

    | Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS), Transactions |

    | Myntra  | OMS (JIT + PPMP), Fwd/Rev Settlement, Returns (JIT + PPMP), Non-order Settlement, GSTR, VHS/VFS expenses,
    Seller reports, Transactions |

    | Meesho  | Sales/OMS, Settlement, Returns/RTO, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |

    | Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement per storefront, Payout summary, TDS,
    Additional shipping, MBTPT/GST mapper, Transactions |

    | FirstCry | OMS per state (MH/HR/MP/KA), Settlement per state, Returns + RTO per state |

    | JioMart | OMS, Settlement, Returns, Transactions |

    | Snapdeal | OMS, Settlement, Commission file (multi-sheet: payments, returns, non-order, commission), Transactions |

    | Tata Cliq | OMS, Settlement, Transactions |

    | Limeroad | OMS, Settlement (multi-sheet), Adjustment, Incentive, Transactions |

    | Shop101 | OMS, Settlement, Transactions, Adhoc |

    | Cred    | Sales/OMS, Settlement, Returns, Transactions |

    | Klip / Blitz / Snapmint | Settlement only       |

    | Shopify | D2C OMS               |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Returns, Fee Preview, Disbursement, Transactions |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS), Transactions |'
  - '| Myntra  | OMS (JIT + PPMP), Fwd/Rev Settlement, Returns (JIT + PPMP), Non-order Settlement, GSTR, VHS/VFS expenses,
    Seller reports, Transactions |'
  - '| Meesho  | Sales/OMS, Settlement, Returns/RTO, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |'
  - '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement per storefront, Payout summary, TDS,
    Additional shipping, MBTPT/GST mapper, Transactions |'
  - '| FirstCry | OMS per state (MH/HR/MP/KA), Settlement per state, Returns + RTO per state |'
  - '| JioMart | OMS, Settlement, Returns, Transactions |'
  - '| Snapdeal | OMS, Settlement, Commission file (multi-sheet: payments, returns, non-order, commission), Transactions |'
  - '| Tata Cliq | OMS, Settlement, Transactions |'
  - '| Limeroad | OMS, Settlement (multi-sheet), Adjustment, Incentive, Transactions |'
  - '| Shop101 | OMS, Settlement, Transactions, Adhoc |'
  - '| Cred    | Sales/OMS, Settlement, Returns, Transactions |'
  - '| Klip / Blitz / Snapmint | Settlement only       |'
  - '| Shopify | D2C OMS               |'
  row_count: 14
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L16
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Returns, Fee Preview, Disbursement, Transactions
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Returns, Fee Preview, Disbursement, Transactions |'
  summary: 'Amazon India: channel=Amazon India; data_types_configured=OMS (B2C + B2B), Settlement, Returns, Fee Preview, Disbursement,
    Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.02_flipkart
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L17
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS), Transactions
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS), Transactions |'
  summary: 'Flipkart: channel=Flipkart; data_types_configured=OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS),
    Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L18
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (JIT + PPMP), Fwd/Rev Settlement, Returns (JIT + PPMP), Non-order Settlement, GSTR, VHS/VFS
      expenses, Seller reports, Transactions
  raw_text: '| Myntra  | OMS (JIT + PPMP), Fwd/Rev Settlement, Returns (JIT + PPMP), Non-order Settlement, GSTR, VHS/VFS expenses,
    Seller reports, Transactions |'
  summary: 'Myntra: channel=Myntra; data_types_configured=OMS (JIT + PPMP), Fwd/Rev Settlement, Returns (JIT + PPMP), Non-order
    Settlement, GSTR, VHS/VFS expenses, Seller reports, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L19
  row_key: Meesho
  columns:
    channel: Meesho
    data_types_configured: Sales/OMS, Settlement, Returns/RTO, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
      Transactions
  raw_text: '| Meesho  | Sales/OMS, Settlement, Returns/RTO, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |'
  summary: 'Meesho: channel=Meesho; data_types_configured=Sales/OMS, Settlement, Returns/RTO, Fwd/Rev expenses, Other charges,
    Adjustment, Brand mapping, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L20
  row_key: Nykaa
  columns:
    channel: Nykaa
    data_types_configured: OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement per storefront, Payout
      summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions
  raw_text: '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement per storefront, Payout summary,
    TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  summary: 'Nykaa: channel=Nykaa; data_types_configured=OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement
    per storefront, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.06_firstcry
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L21
  row_key: FirstCry
  columns:
    channel: FirstCry
    data_types_configured: OMS per state (MH/HR/MP/KA), Settlement per state, Returns + RTO per state
  raw_text: '| FirstCry | OMS per state (MH/HR/MP/KA), Settlement per state, Returns + RTO per state |'
  summary: 'FirstCry: channel=FirstCry; data_types_configured=OMS per state (MH/HR/MP/KA), Settlement per state, Returns +
    RTO per state'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.07_jiomart
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L22
  row_key: JioMart
  columns:
    channel: JioMart
    data_types_configured: OMS, Settlement, Returns, Transactions
  raw_text: '| JioMart | OMS, Settlement, Returns, Transactions |'
  summary: 'JioMart: channel=JioMart; data_types_configured=OMS, Settlement, Returns, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L23
  row_key: Snapdeal
  columns:
    channel: Snapdeal
    data_types_configured: 'OMS, Settlement, Commission file (multi-sheet: payments, returns, non-order, commission), Transactions'
  raw_text: '| Snapdeal | OMS, Settlement, Commission file (multi-sheet: payments, returns, non-order, commission), Transactions
    |'
  summary: 'Snapdeal: channel=Snapdeal; data_types_configured=OMS, Settlement, Commission file (multi-sheet: payments, returns,
    non-order, commission), Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.09_tata_cliq
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L24
  row_key: Tata Cliq
  columns:
    channel: Tata Cliq
    data_types_configured: OMS, Settlement, Transactions
  raw_text: '| Tata Cliq | OMS, Settlement, Transactions |'
  summary: 'Tata Cliq: channel=Tata Cliq; data_types_configured=OMS, Settlement, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.10_limeroad
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L25
  row_key: Limeroad
  columns:
    channel: Limeroad
    data_types_configured: OMS, Settlement (multi-sheet), Adjustment, Incentive, Transactions
  raw_text: '| Limeroad | OMS, Settlement (multi-sheet), Adjustment, Incentive, Transactions |'
  summary: 'Limeroad: channel=Limeroad; data_types_configured=OMS, Settlement (multi-sheet), Adjustment, Incentive, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.11_shop101
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L26
  row_key: Shop101
  columns:
    channel: Shop101
    data_types_configured: OMS, Settlement, Transactions, Adhoc
  raw_text: '| Shop101 | OMS, Settlement, Transactions, Adhoc |'
  summary: 'Shop101: channel=Shop101; data_types_configured=OMS, Settlement, Transactions, Adhoc'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.12_cred
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L27
  row_key: Cred
  columns:
    channel: Cred
    data_types_configured: Sales/OMS, Settlement, Returns, Transactions
  raw_text: '| Cred    | Sales/OMS, Settlement, Returns, Transactions |'
  summary: 'Cred: channel=Cred; data_types_configured=Sales/OMS, Settlement, Returns, Transactions'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.13_klip_blitz_snapmint
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L28
  row_key: Klip / Blitz / Snapmint
  columns:
    channel: Klip / Blitz / Snapmint
    data_types_configured: Settlement only
  raw_text: '| Klip / Blitz / Snapmint | Settlement only       |'
  summary: 'Klip / Blitz / Snapmint: channel=Klip / Blitz / Snapmint; data_types_configured=Settlement only'
  confidence: high
- id: ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic
  evidence_type: configured_source_row
  source_line: L29
  row_key: Shopify
  columns:
    channel: Shopify
    data_types_configured: D2C OMS
  raw_text: '| Shopify | D2C OMS               |'
  summary: 'Shopify: channel=Shopify; data_types_configured=D2C OMS'
  confidence: high
- id: ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic / International
  evidence_type: docx_section
  source_lines: L30-L34
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Amazon US/CA/UK/MX | Settlement per region, B2C + B2B OMS, Exchange rates |

    | Walmart | OMS, Settlement, ASIN–SKU lookup |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Amazon US/CA/UK/MX | Settlement per region, B2C + B2B OMS, Exchange rates |'
  - '| Walmart | OMS, Settlement, ASIN–SKU lookup |'
  row_count: 2
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic / International
  evidence_type: configured_source_row
  source_line: L33
  row_key: Amazon US/CA/UK/MX
  columns:
    channel: Amazon US/CA/UK/MX
    data_types_configured: Settlement per region, B2C + B2B OMS, Exchange rates
  raw_text: '| Amazon US/CA/UK/MX | Settlement per region, B2C + B2B OMS, Exchange rates |'
  summary: 'Amazon US/CA/UK/MX: channel=Amazon US/CA/UK/MX; data_types_configured=Settlement per region, B2C + B2B OMS, Exchange
    rates'
  confidence: high
- id: ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.02_walmart
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Active sales channels / Domestic / International
  evidence_type: configured_source_row
  source_line: L34
  row_key: Walmart
  columns:
    channel: Walmart
    data_types_configured: OMS, Settlement, ASIN–SKU lookup
  raw_text: '| Walmart | OMS, Settlement, ASIN–SKU lookup |'
  summary: 'Walmart: channel=Walmart; data_types_configured=OMS, Settlement, ASIN–SKU lookup'
  confidence: high
- id: ev.mensa_business.docx.section.04_logistics_settlement_files
  source_document: Mensa Brand Technologies Private Limited.docx
  source_section: Logistics settlement files
  evidence_type: docx_section
  source_lines: L35-L36
  summary: Delhivery, Ekart, Xpressbees, Shadowfax, Smartr, DTDC — all configured for settlement reconciliation only (not
    OMS).
  raw_lines:
  - Delhivery, Ekart, Xpressbees, Shadowfax, Smartr, DTDC — all configured for settlement reconciliation only (not OMS).
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.mensa_brand_technologies
  canonical_id: tenant.mensa_brand_technologies
  name: Mensa Brand Technologies Private Limited
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  description: Large-scale multi-channel marketplace seller using ZenStatement for marketplace, D2C, OMS/WMS, logistics, payment-gateway,
    settlement, reconciliation, diagnostics, and money-flow reasoning.
  fields:
    tenant_name: Mensa Brand Technologies Private Limited
    tenant_code: MENSA
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.mensa_brands
  canonical_id: group.mensa_brands
  name: Mensa Brands
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_name: Mensa Brands
    group_code: MENSA_BRANDS
    group_type: operational_unit
    business_meaning: Mensa Brands operating group for the Mensa Brand Technologies Private Limited multi-channel commerce
      business. Source client scope uses GROUP ID 8 and GROUP LEVEL ID 22; table filtering is represented through Account
      Data Binding cards, not as a universal Group property.
    country_or_region: India primary; international sales contexts include US, CA, UK, and MX where separately bound.
    default_currency: INR
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.mensa.amazon_in.primary
  canonical_id: platform_account.mensa.amazon_in.primary
  name: Mensa Amazon India Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Mensa Amazon India Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.in
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.flipkart_in.primary
  canonical_id: platform_account.mensa.flipkart_in.primary
  name: Mensa Flipkart Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.02_flipkart
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Mensa Flipkart Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.flipkart
        source_documents:
        - flipkart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.flipkart.in
        source_documents:
        - flipkart_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.myntra_in.primary
  canonical_id: platform_account.mensa.myntra_in.primary
  name: Mensa Myntra Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: Mensa Myntra Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.myntra
        source_documents:
        - myntra_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.myntra.in
        source_documents:
        - myntra_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.meesho_in.primary
  canonical_id: platform_account.mensa.meesho_in.primary
  name: Mensa Meesho Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.meesho
    platform_context_id: platform_context.meesho.in
    account_name: Mensa Meesho Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.meesho
        source_documents:
        - meesho_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.meesho.in
        source_documents:
        - meesho_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.nykaa_in.primary
  canonical_id: platform_account.mensa.nykaa_in.primary
  name: Mensa Nykaa Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.nykaa
    platform_context_id: platform_context.nykaa_fashion.in
    account_name: Mensa Nykaa Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.nykaa
        source_documents:
        - nykaa_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.nykaa_fashion.in
        source_documents:
        - nykaa_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.nykaa.in
      to: platform_context.nykaa_fashion.in
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.jiomart_in.primary
  canonical_id: platform_account.mensa.jiomart_in.primary
  name: Mensa JioMart Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.07_jiomart
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.jiomart
    platform_context_id: platform_context.jiomart.in
    account_name: Mensa JioMart Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.jiomart
        source_documents:
        - jiomart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.jiomart.in
        source_documents:
        - jiomart_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.snapdeal_in.primary
  canonical_id: platform_account.mensa.snapdeal_in.primary
  name: Mensa Snapdeal Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.snapdeal
    platform_context_id: platform_context.snapdeal.in
    account_name: Mensa Snapdeal Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.snapdeal
        source_documents:
        - snapdeal_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.snapdeal.in
        source_documents:
        - snapdeal_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.tatacliq_in.primary
  canonical_id: platform_account.mensa.tatacliq_in.primary
  name: Mensa TataCliq Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.09_tata_cliq
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.tatacliq
    platform_context_id: platform_context.tatacliq.in
    account_name: Mensa TataCliq Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.tatacliq
        source_documents:
        - tatacliq_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.tatacliq.in
        source_documents:
        - tatacliq_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.limeroad_in.primary
  canonical_id: platform_account.mensa.limeroad_in.primary
  name: Mensa LimeRoad Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - limeroad_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.10_limeroad
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.limeroad
    platform_context_id: platform_context.limeroad.in
    account_name: Mensa LimeRoad Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.limeroad
        source_documents:
        - limeroad_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.limeroad.in
        source_documents:
        - limeroad_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.firstcry_in.primary
  canonical_id: platform_account.mensa.firstcry_in.primary
  name: Mensa FirstCry Seller Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.06_firstcry
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa FirstCry Seller Account
    account_type: seller_account
    source_account_identifier: null
    declared_platform_id: platform.firstcry
    declared_platform_label: FirstCry marketplace
    declared_platform_context_id: platform_context.firstcry.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.firstcry
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.firstcry.in
    notes:
    - Client document confirms channel is configured, but no canonical vendor table/context markdown was provided in this
      package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.shop101_in.primary
  canonical_id: platform_account.mensa.shop101_in.primary
  name: Mensa Shop101 Seller Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.11_shop101
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Shop101 Seller Account
    account_type: seller_account
    source_account_identifier: null
    declared_platform_id: platform.shop101
    declared_platform_label: Shop101 marketplace/channel
    declared_platform_context_id: platform_context.shop101.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.shop101
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.shop101.in
    notes:
    - Client document confirms channel is configured, but no canonical vendor table/context markdown was provided in this
      package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.cred_in.primary
  canonical_id: platform_account.mensa.cred_in.primary
  name: Mensa CRED Seller Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.12_cred
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa CRED Seller Account
    account_type: seller_account
    source_account_identifier: null
    declared_platform_id: platform.cred
    declared_platform_label: CRED marketplace/channel
    declared_platform_context_id: platform_context.cred.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.cred
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.cred.in
    notes:
    - Client document confirms channel is configured, but no canonical vendor table/context markdown was provided in this
      package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.klip_in.primary
  canonical_id: platform_account.mensa.klip_in.primary
  name: Mensa Klip Settlement Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.13_klip_blitz_snapmint
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Klip Settlement Account
    account_type: seller_account
    source_account_identifier: null
    declared_platform_id: platform.klip
    declared_platform_label: Klip channel
    declared_platform_context_id: platform_context.klip.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.klip
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.klip.in
    notes:
    - Client document confirms channel is configured, but no canonical vendor table/context markdown was provided in this
      package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.blitz_in.primary
  canonical_id: platform_account.mensa.blitz_in.primary
  name: Mensa Blitz Settlement Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.13_klip_blitz_snapmint
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Blitz Settlement Account
    account_type: seller_account
    source_account_identifier: null
    declared_platform_id: platform.blitz
    declared_platform_label: Blitz channel
    declared_platform_context_id: platform_context.blitz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.blitz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.blitz.in
    notes:
    - Client document confirms channel is configured, but no canonical vendor table/context markdown was provided in this
      package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.snapmint_in.primary
  canonical_id: platform_account.mensa.snapmint_in.primary
  name: Mensa Snapmint Settlement Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.13_klip_blitz_snapmint
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Snapmint Settlement Account
    account_type: seller_account
    source_account_identifier: null
    declared_platform_id: platform.snapmint
    declared_platform_label: Snapmint BNPL/settlement channel
    declared_platform_context_id: platform_context.snapmint.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.snapmint
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.snapmint.in
    notes:
    - Client document confirms channel is configured, but no canonical vendor table/context markdown was provided in this
      package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.amazon_us.primary
  canonical_id: platform_account.mensa.amazon_us.primary
  name: Mensa Amazon US Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Mensa Amazon US Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.us
      to: platform_context.amazon.international
    notes:
    - 'Client document confirms international channel. Exact source account identifier and country-specific table bindings
      are pending; default currency expected USD. '
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.amazon_ca.primary
  canonical_id: platform_account.mensa.amazon_ca.primary
  name: Mensa Amazon CA Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Mensa Amazon CA Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.ca
      to: platform_context.amazon.international
    notes:
    - 'Client document confirms international channel. Exact source account identifier and country-specific table bindings
      are pending; default currency expected CAD. '
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.amazon_uk.primary
  canonical_id: platform_account.mensa.amazon_uk.primary
  name: Mensa Amazon UK Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Mensa Amazon UK Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.uk
      to: platform_context.amazon.international
    notes:
    - 'Client document confirms international channel. Exact source account identifier and country-specific table bindings
      are pending; default currency expected GBP. '
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.amazon_mx.primary
  canonical_id: platform_account.mensa.amazon_mx.primary
  name: Mensa Amazon MX Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Mensa Amazon MX Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.mx
      to: platform_context.amazon.international
    notes:
    - 'Client document confirms international channel. Exact source account identifier and country-specific table bindings
      are pending; default currency expected MXN. '
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.walmart_us.primary
  canonical_id: platform_account.mensa.walmart_us.primary
  name: Mensa Walmart Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.02_walmart
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.walmart
    platform_context_id: platform_context.walmart.us
    account_name: Mensa Walmart Seller Account
    account_type: seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.walmart
        source_documents:
        - walmart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.walmart.us
        source_documents:
        - walmart_marketplace.md
    notes:
    - 'Client document confirms international channel. Exact source account identifier and country-specific table bindings
      are pending; default currency expected USD. '
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.shopify_d2c.primary
  canonical_id: platform_account.mensa.shopify_d2c.primary
  name: Mensa Shopify D2C Store Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Mensa Shopify D2C Store Account
    account_type: store_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shopify
        source_documents:
        - shopify_d2c_oms_v2.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shopify.in_and_global.d2c_oms_client_config
        source_documents:
        - shopify_d2c_oms_v2.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client doc confirms Shopify D2C OMS; client table context maps Shopify OMS and returns to PG/logistics/bank reconciliation
      use cases.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.increff_wms.primary
  canonical_id: platform_account.mensa.increff_wms.primary
  name: Mensa Increff WMS Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.increff
    platform_context_id: platform_context.increff.in
    account_name: Mensa Increff WMS Account
    account_type: wms_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.increff
        source_documents:
        - increff_operations.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.increff.in
        source_documents:
        - increff_operations.md
    notes:
    - Increff operations doc identifies Mensa Brand Technologies with group_level_id=22 and Increff sales/returns as cross-channel
      operations views.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mensa.unicommerce_oms.primary
  canonical_id: platform_account.mensa.unicommerce_oms.primary
  name: Mensa Unicommerce OMS/WMS Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.unicommerce
    platform_context_id: platform_context.unicommerce.in
    account_name: Mensa Unicommerce OMS/WMS Account
    account_type: oms_wms_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.unicommerce
        source_documents:
        - unicommerce_d2c_oms.md
        - unicommerce_operations.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.unicommerce.in
        source_documents:
        - unicommerce_operations.md
    notes:
    - Client doc confirms Unicommerce as OMS/WMS. Exact account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.delhivery_in.primary
  canonical_id: platform_account.mensa.delhivery_in.primary
  name: Mensa Delhivery Logistics Settlement Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.delhivery
    platform_context_id: platform_context.delhivery.in
    account_name: Mensa Delhivery Logistics Settlement Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.delhivery
        source_documents:
        - delhivery_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.delhivery.in
        source_documents:
        - delhivery_logistics.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.ekart_in.primary
  canonical_id: platform_account.mensa.ekart_in.primary
  name: Mensa Ekart Logistics Settlement Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.ekart
    platform_context_id: platform_context.ekart.in
    account_name: Mensa Ekart Logistics Settlement Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.ekart
        source_documents:
        - ekart_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.ekart.in
        source_documents:
        - ekart_logistics.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.xpressbees_in.primary
  canonical_id: platform_account.mensa.xpressbees_in.primary
  name: Mensa XpressBees Logistics Settlement Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.xpressbees
    platform_context_id: platform_context.xpressbees.in
    account_name: Mensa XpressBees Logistics Settlement Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.xpressbees
        source_documents:
        - xpressbees_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.xpressbees.in
        source_documents:
        - xpressbees_logistics.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.shadowfax_in.primary
  canonical_id: platform_account.mensa.shadowfax_in.primary
  name: Mensa Shadowfax Logistics Settlement Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - shadowfax_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.shadowfax
    platform_context_id: platform_context.shadowfax.in
    account_name: Mensa Shadowfax Logistics Settlement Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shadowfax
        source_documents:
        - shadowfax_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shadowfax.in
        source_documents:
        - shadowfax_logistics.md
    notes:
    - Client doc confirms Shadowfax logistics settlement configured; native canonical settlement table was not found in the
      current package, so table binding remains pending or may route through Shiprocket/fallback evidence when source-backed.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.smartr_in.primary
  canonical_id: platform_account.mensa.smartr_in.primary
  name: Mensa Smartr Logistics Settlement Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Smartr Logistics Settlement Account
    account_type: logistics_account
    source_account_identifier: null
    declared_platform_id: platform.smartr
    declared_platform_label: Smartr logistics
    declared_platform_context_id: platform_context.smartr.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.smartr
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.smartr.in
    notes:
    - Client doc confirms Smartr configured, but no canonical vendor table/context markdown was provided in this package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.dtdc_in.primary
  canonical_id: platform_account.mensa.dtdc_in.primary
  name: Mensa DTDC Logistics Settlement Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.dtdc
    platform_context_id: platform_context.dtdc.in
    account_name: Mensa DTDC Logistics Settlement Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.dtdc
        source_documents:
        - dtdc_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.dtdc.in
        source_documents:
        - dtdc_logistics.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.shiprocket_in.primary
  canonical_id: platform_account.mensa.shiprocket_in.primary
  name: Mensa Shiprocket Logistics/Aggregator Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.shiprocket
    platform_context_id: platform_context.shiprocket.in
    account_name: Mensa Shiprocket Logistics/Aggregator Account
    account_type: logistics_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shiprocket
        source_documents:
        - shiprocket_logistics.md
        - shiprocket_logistics_aggregator.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shiprocket.in
        source_documents:
        - shiprocket_logistics.md
        - shiprocket_logistics_aggregator.md
    notes:
    - Client doc confirms Shiprocket logistics configured; generic logistics docs model Shiprocket as both operational handoff
      partner and services aggregator.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.shipturtle_in.primary
  canonical_id: platform_account.mensa.shipturtle_in.primary
  name: Mensa Shipturtle Logistics Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Shipturtle Logistics Account
    account_type: logistics_account
    source_account_identifier: null
    declared_platform_id: platform.shipturtle
    declared_platform_label: Shipturtle logistics / marketplace ops
    declared_platform_context_id: platform_context.shipturtle.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.shipturtle
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.shipturtle.in
    notes:
    - Client doc confirms Shipturtle configured, but no canonical vendor table/context markdown was provided in this package.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mensa.razorpay_in.primary
  canonical_id: platform_account.mensa.razorpay_in.primary
  name: Mensa Razorpay Merchant Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: Mensa Razorpay Merchant Account
    account_type: merchant_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.razorpay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.razorpay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.paytm_in.primary
  canonical_id: platform_account.mensa.paytm_in.primary
  name: Mensa Paytm Merchant Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.paytm
    platform_context_id: platform_context.paytm.in
    account_name: Mensa Paytm Merchant Account
    account_type: merchant_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.paytm.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.phonepe_in.primary
  canonical_id: platform_account.mensa.phonepe_in.primary
  name: Mensa PhonePe Merchant Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.phonepe
    platform_context_id: platform_context.phonepe.in
    account_name: Mensa PhonePe Merchant Account
    account_type: merchant_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.phonepe
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.phonepe.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.cashfree_in.primary
  canonical_id: platform_account.mensa.cashfree_in.primary
  name: Mensa Cashfree Merchant Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: Mensa Cashfree Merchant Account
    account_type: merchant_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms the platform/channel is configured, but exact source account identifier was not provided.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mensa.easebuzz_in.primary
  canonical_id: platform_account.mensa.easebuzz_in.primary
  name: Mensa Easebuzz Merchant Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    account_name: Mensa Easebuzz Merchant Account
    account_type: merchant_account
    source_account_identifier: null
    declared_platform_id: platform.easebuzz
    declared_platform_label: Easebuzz payment gateway
    declared_platform_context_id: platform_context.easebuzz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.easebuzz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.easebuzz.in
    notes:
    - Client doc confirms Easebuzz payment gateway configured, but no Easebuzz canonical payment table was found in the current
      payment gateway markdown.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.mensa.amazon_in.primary.amazon_oms
  canonical_id: account_data_binding.mensa.amazon_in.primary.amazon_oms
  name: account data binding / mensa / amazon in / primary / amazon oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    platform_account_id: platform_account.mensa.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_oms
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.amazon_in.primary.amazon_settlement
  canonical_id: account_data_binding.mensa.amazon_in.primary.amazon_settlement
  name: account data binding / mensa / amazon in / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    platform_account_id: platform_account.mensa.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.amazon_in.primary.amazon_returns
  canonical_id: account_data_binding.mensa.amazon_in.primary.amazon_returns
  name: account data binding / mensa / amazon in / primary / amazon returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    platform_account_id: platform_account.mensa.amazon_in.primary
    table_id: table.zs_observe.amazon_returns
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_returns
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.amazon_in.primary.amazon_fee_preview
  canonical_id: account_data_binding.mensa.amazon_in.primary.amazon_fee_preview
  name: account data binding / mensa / amazon in / primary / amazon fee preview
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    platform_account_id: platform_account.mensa.amazon_in.primary
    table_id: table.zs_observe.amazon_fee_preview
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_fee_preview
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.amazon_in.primary.amazon_disbursment
  canonical_id: account_data_binding.mensa.amazon_in.primary.amazon_disbursment
  name: account data binding / mensa / amazon in / primary / amazon disbursment
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  fields:
    platform_account_id: platform_account.mensa.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_disbursment
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_oms
  canonical_id: account_data_binding.mensa.flipkart_in.primary.flipkart_oms
  name: account data binding / mensa / flipkart in / primary / flipkart oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.02_flipkart
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.flipkart_in.primary
    table_id: table.flipkart.oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.oms
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_settlement
  canonical_id: account_data_binding.mensa.flipkart_in.primary.flipkart_settlement
  name: account data binding / mensa / flipkart in / primary / flipkart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.02_flipkart
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.flipkart_in.primary
    table_id: table.flipkart.settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.settlement
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_commission
  canonical_id: account_data_binding.mensa.flipkart_in.primary.flipkart_commission
  name: account data binding / mensa / flipkart in / primary / flipkart commission
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.02_flipkart
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.flipkart_in.primary
    table_id: table.flipkart.commission
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.commission
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_cashback
  canonical_id: account_data_binding.mensa.flipkart_in.primary.flipkart_cashback
  name: account data binding / mensa / flipkart in / primary / flipkart cashback
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.02_flipkart
  fields:
    platform_account_id: platform_account.mensa.flipkart_in.primary
    table_id: table.flipkart.cashback
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.cashback
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms
  canonical_id: account_data_binding.mensa.myntra_in.primary.myntra_oms
  name: account data binding / mensa / myntra in / primary / myntra oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  fields:
    platform_account_id: platform_account.mensa.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_oms
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Mensa client text mentions broader Myntra artifacts, but current binding intentionally maps only canonical Myntra OMS,
      settlement, returns/reverse, non-order settlement, and the OMS-settlement reconciliation helper. GSTR, VHS/VFS expenses,
      seller reports, transactions remain future platform-context gaps.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.myntra_in.primary.myntra_settlement
  canonical_id: account_data_binding.mensa.myntra_in.primary.myntra_settlement
  name: account data binding / mensa / myntra in / primary / myntra settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  fields:
    platform_account_id: platform_account.mensa.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Mensa client text mentions broader Myntra artifacts, but current binding intentionally maps only canonical Myntra OMS,
      settlement, returns/reverse, non-order settlement, and the OMS-settlement reconciliation helper. GSTR, VHS/VFS expenses,
      seller reports, transactions remain future platform-context gaps.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.myntra_in.primary.myntra_reverse
  canonical_id: account_data_binding.mensa.myntra_in.primary.myntra_reverse
  name: account data binding / mensa / myntra in / primary / myntra reverse
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  fields:
    platform_account_id: platform_account.mensa.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_reverse
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Mensa client text mentions broader Myntra artifacts, but current binding intentionally maps only canonical Myntra OMS,
      settlement, returns/reverse, non-order settlement, and the OMS-settlement reconciliation helper. GSTR, VHS/VFS expenses,
      seller reports, transactions remain future platform-context gaps.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.myntra_in.primary.myntra_non_order_settlement
  canonical_id: account_data_binding.mensa.myntra_in.primary.myntra_non_order_settlement
  name: account data binding / mensa / myntra in / primary / myntra non order settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  fields:
    platform_account_id: platform_account.mensa.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_non_order_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Mensa client text mentions broader Myntra artifacts, but current binding intentionally maps only canonical Myntra OMS,
      settlement, returns/reverse, non-order settlement, and the OMS-settlement reconciliation helper. GSTR, VHS/VFS expenses,
      seller reports, transactions remain future platform-context gaps.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms_settlement
  canonical_id: account_data_binding.mensa.myntra_in.primary.myntra_oms_settlement
  name: account data binding / mensa / myntra in / primary / myntra oms settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.03_myntra
  fields:
    platform_account_id: platform_account.mensa.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_oms_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Mensa client text mentions broader Myntra artifacts, but current binding intentionally maps only canonical Myntra OMS,
      settlement, returns/reverse, non-order settlement, and the OMS-settlement reconciliation helper. GSTR, VHS/VFS expenses,
      seller reports, transactions remain future platform-context gaps.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_sales
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_sales
  name: account data binding / mensa / meesho in / primary / meesho sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_sales
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_sales
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_settlement
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_settlement
  name: account data binding / mensa / meesho in / primary / meesho settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_settlement
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_returns
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_returns
  name: account data binding / mensa / meesho in / primary / meesho returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_returns
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_returns
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse
  name: account data binding / mensa / meesho in / primary / meesho reverse
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_reverse
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_forward_expenses
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_forward_expenses
  name: account data binding / mensa / meesho in / primary / meesho forward expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_forward_expenses
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_forward_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse_expenses
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse_expenses
  name: account data binding / mensa / meesho in / primary / meesho reverse expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse_expenses
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_reverse_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_other_charges_expenses
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_other_charges_expenses
  name: account data binding / mensa / meesho in / primary / meesho other charges expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_other_charges_expenses
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_other_charges_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.meesho_in.primary.meesho_brand_mapping
  canonical_id: account_data_binding.mensa.meesho_in.primary.meesho_brand_mapping
  name: account data binding / mensa / meesho in / primary / meesho brand mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.04_meesho
  fields:
    platform_account_id: platform_account.mensa.meesho_in.primary
    table_id: table.zs_observe.meesho_brand_mapping
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_brand_mapping
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_oms
  canonical_id: account_data_binding.mensa.nykaa_in.primary.nykaa_oms
  name: account data binding / mensa / nykaa in / primary / nykaa oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  fields:
    platform_account_id: platform_account.mensa.nykaa_in.primary
    table_id: table.zs_observe.nykaa_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_oms
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_settlement
  canonical_id: account_data_binding.mensa.nykaa_in.primary.nykaa_settlement
  name: account data binding / mensa / nykaa in / primary / nykaa settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  fields:
    platform_account_id: platform_account.mensa.nykaa_in.primary
    table_id: table.zs_observe.nykaa_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_settlement
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_addition_charge
  canonical_id: account_data_binding.mensa.nykaa_in.primary.nykaa_addition_charge
  name: account data binding / mensa / nykaa in / primary / nykaa addition charge
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  fields:
    platform_account_id: platform_account.mensa.nykaa_in.primary
    table_id: table.zs_observe.nykaa_addition_charge
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_addition_charge
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapper_gst
  canonical_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapper_gst
  name: account data binding / mensa / nykaa in / primary / nykaa mapper gst
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  fields:
    platform_account_id: platform_account.mensa.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapper_gst
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_mapper_gst
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapping
  canonical_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapping
  name: account data binding / mensa / nykaa in / primary / nykaa mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.05_nykaa
  fields:
    platform_account_id: platform_account.mensa.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapping
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_mapping
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_oms
  canonical_id: account_data_binding.mensa.jiomart_in.primary.jiomart_oms
  name: account data binding / mensa / jiomart in / primary / jiomart oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.07_jiomart
  fields:
    platform_account_id: platform_account.mensa.jiomart_in.primary
    table_id: table.zs_observe.jiomart_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_oms
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_settlement
  canonical_id: account_data_binding.mensa.jiomart_in.primary.jiomart_settlement
  name: account data binding / mensa / jiomart in / primary / jiomart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.07_jiomart
  fields:
    platform_account_id: platform_account.mensa.jiomart_in.primary
    table_id: table.zs_observe.jiomart_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_settlement
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_returns
  canonical_id: account_data_binding.mensa.jiomart_in.primary.jiomart_returns
  name: account data binding / mensa / jiomart in / primary / jiomart returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.07_jiomart
  fields:
    platform_account_id: platform_account.mensa.jiomart_in.primary
    table_id: table.zs_observe.jiomart_returns
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_returns
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_shipment
  canonical_id: account_data_binding.mensa.jiomart_in.primary.jiomart_shipment
  name: account data binding / mensa / jiomart in / primary / jiomart shipment
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.07_jiomart
  fields:
    platform_account_id: platform_account.mensa.jiomart_in.primary
    table_id: table.zs_observe.jiomart_shipment
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_shipment
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_oms
  canonical_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_oms
  name: account data binding / mensa / snapdeal in / primary / snapdeal oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_oms
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_settlement
  canonical_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_settlement
  name: account data binding / mensa / snapdeal in / primary / snapdeal settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_settlement
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_payments
  canonical_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_payments
  name: account data binding / mensa / snapdeal in / primary / snapdeal payments
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_payments
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_payments
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_sales_return
  canonical_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_sales_return
  name: account data binding / mensa / snapdeal in / primary / snapdeal sales return
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_sales_return
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_sales_return
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_non_order
  canonical_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_non_order
  name: account data binding / mensa / snapdeal in / primary / snapdeal non order
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_non_order
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_non_order
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_commission
  canonical_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_commission
  name: account data binding / mensa / snapdeal in / primary / snapdeal commission
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.08_snapdeal
  fields:
    platform_account_id: platform_account.mensa.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_commission
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_commission
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_oms
  canonical_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_oms
  name: account data binding / mensa / tatacliq in / primary / tatacliq oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.09_tata_cliq
  fields:
    platform_account_id: platform_account.mensa.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tatacliq_oms
      source_documents:
      - tatacliq_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_settlement
  canonical_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_settlement
  name: account data binding / mensa / tatacliq in / primary / tatacliq settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.09_tata_cliq
  fields:
    platform_account_id: platform_account.mensa.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tatacliq_settlement
      source_documents:
      - tatacliq_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_oms
  canonical_id: account_data_binding.mensa.limeroad_in.primary.limeroad_oms
  name: account data binding / mensa / limeroad in / primary / limeroad oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - limeroad_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.10_limeroad
  fields:
    platform_account_id: platform_account.mensa.limeroad_in.primary
    table_id: table.zs_observe.limeroad_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.limeroad_oms
      source_documents:
      - limeroad_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_settlement
  canonical_id: account_data_binding.mensa.limeroad_in.primary.limeroad_settlement
  name: account data binding / mensa / limeroad in / primary / limeroad settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - limeroad_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.10_limeroad
  fields:
    platform_account_id: platform_account.mensa.limeroad_in.primary
    table_id: table.zs_observe.limeroad_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.limeroad_settlement
      source_documents:
      - limeroad_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
  canonical_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
  name: account data binding / mensa / shopify d2c / primary / shopify oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  fields:
    platform_account_id: platform_account.mensa.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_oms
      source_documents:
      - logistics_domain.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Shopify D2C orders/returns binding for Mensa. Use PG/logistics/bank flow bindings only when the user asks cross-platform
      reconciliation; single Shopify analytics only needs this Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
  canonical_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
  name: account data binding / mensa / shopify d2c / primary / shopify returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  fields:
    platform_account_id: platform_account.mensa.shopify_d2c.primary
    table_id: table.zs_observe.shopify_returns
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_returns
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Shopify D2C orders/returns binding for Mensa. Use PG/logistics/bank flow bindings only when the user asks cross-platform
      reconciliation; single Shopify analytics only needs this Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.increff_wms.primary.increff_sales
  canonical_id: account_data_binding.mensa.increff_wms.primary.increff_sales
  name: account data binding / mensa / increff wms / primary / increff sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    platform_account_id: platform_account.mensa.increff_wms.primary
    table_id: table.zs_observe.increff_sales
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.increff_sales
      source_documents:
      - increff_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.increff_wms.primary.increff_returns
  canonical_id: account_data_binding.mensa.increff_wms.primary.increff_returns
  name: account data binding / mensa / increff wms / primary / increff returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    platform_account_id: platform_account.mensa.increff_wms.primary
    table_id: table.zs_observe.increff_returns
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.increff_returns
      source_documents:
      - increff_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce
  canonical_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce
  name: account data binding / mensa / unicommerce oms / primary / unicommerce
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    platform_account_id: platform_account.mensa.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.unicommerce
      source_documents:
      - unicommerce_d2c_oms.md
      - unicommerce_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce_order_sales_report
  canonical_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce_order_sales_report
  name: account data binding / mensa / unicommerce oms / primary / unicommerce order sales report
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    platform_account_id: platform_account.mensa.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce_order_sales_report
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.unicommerce_order_sales_report
      source_documents:
      - unicommerce_d2c_oms.md
      - unicommerce_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_invoice
  canonical_id: account_data_binding.mensa.delhivery_in.primary.delhivery_invoice
  name: account data binding / mensa / delhivery in / primary / delhivery invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.delhivery_in.primary
    table_id: table.zs_observe.delhivery_invoice
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.delhivery_invoice
      source_documents:
      - delhivery_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_settlement
  canonical_id: account_data_binding.mensa.delhivery_in.primary.delhivery_settlement
  name: account data binding / mensa / delhivery in / primary / delhivery settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.delhivery_in.primary
    table_id: table.zs_observe.delhivery_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.delhivery_settlement
      source_documents:
      - delhivery_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_invoice
  canonical_id: account_data_binding.mensa.dtdc_in.primary.dtdc_invoice
  name: account data binding / mensa / dtdc in / primary / dtdc invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.dtdc_in.primary
    table_id: table.zs_observe.dtdc_invoice
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.dtdc_invoice
      source_documents:
      - dtdc_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_settlement
  canonical_id: account_data_binding.mensa.dtdc_in.primary.dtdc_settlement
  name: account data binding / mensa / dtdc in / primary / dtdc settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.dtdc_in.primary
    table_id: table.zs_observe.dtdc_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.dtdc_settlement
      source_documents:
      - dtdc_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.ekart_in.primary.ekart_invoice
  canonical_id: account_data_binding.mensa.ekart_in.primary.ekart_invoice
  name: account data binding / mensa / ekart in / primary / ekart invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.ekart_in.primary
    table_id: table.zs_observe.ekart_invoice
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.ekart_invoice
      source_documents:
      - ekart_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.ekart_in.primary.ekart_settlement
  canonical_id: account_data_binding.mensa.ekart_in.primary.ekart_settlement
  name: account data binding / mensa / ekart in / primary / ekart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.ekart_in.primary
    table_id: table.zs_observe.ekart_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.ekart_settlement
      source_documents:
      - ekart_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.xpressbees_in.primary.xpressbees_settlement
  canonical_id: account_data_binding.mensa.xpressbees_in.primary.xpressbees_settlement
  name: account data binding / mensa / xpressbees in / primary / xpressbees settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.xpressbees_in.primary
    table_id: table.zs_observe.xpressbees_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.xpressbees_settlement
      source_documents:
      - xpressbees_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
  canonical_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
  name: account data binding / mensa / shiprocket in / primary / shiprocket oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_oms
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shiprocket_oms
      source_documents:
      - shiprocket_logistics.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
  canonical_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
  name: account data binding / mensa / shiprocket in / primary / shiprocket invoice
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_invoice
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shiprocket_invoice
      source_documents:
      - shiprocket_logistics_aggregator.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
  canonical_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
  name: account data binding / mensa / shiprocket in / primary / shiprocket settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_settlement
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shiprocket_settlement
      source_documents:
      - shiprocket_logistics_aggregator.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
  canonical_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
  name: account data binding / mensa / shiprocket in / primary / shiprocket settlement report
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    platform_account_id: platform_account.mensa.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_settlement_report
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shiprocket_settlement_report
      source_documents:
      - shiprocket_logistics_aggregator.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payin
  canonical_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payin
  name: account data binding / mensa / razorpay in / primary / razorpay payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.razorpay_in.primary
    table_id: table.zs_observe.razorpay_payin
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payout
  canonical_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payout
  name: account data binding / mensa / razorpay in / primary / razorpay payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.razorpay_in.primary
    table_id: table.zs_observe.razorpay_payout
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payout
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
  canonical_id: account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
  name: account data binding / mensa / razorpay in / primary / razorpay transactions
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.razorpay_in.primary
    table_id: table.zs_observe.razorpay_transactions
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_transactions
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.paytm_in.primary.paytm_payin
  canonical_id: account_data_binding.mensa.paytm_in.primary.paytm_payin
  name: account data binding / mensa / paytm in / primary / paytm payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.paytm_in.primary
    table_id: table.zs_observe.paytm_payin
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.paytm_in.primary.paytm_payout
  canonical_id: account_data_binding.mensa.paytm_in.primary.paytm_payout
  name: account data binding / mensa / paytm in / primary / paytm payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.paytm_in.primary
    table_id: table.zs_observe.paytm_payout
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payout
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.phonepe_in.primary.phonepe_payin
  canonical_id: account_data_binding.mensa.phonepe_in.primary.phonepe_payin
  name: account data binding / mensa / phonepe in / primary / phonepe payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.phonepe_in.primary
    table_id: table.zs_observe.phonepe_payin
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.phonepe_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_payin
  canonical_id: account_data_binding.mensa.cashfree_in.primary.cashfree_payin
  name: account data binding / mensa / cashfree in / primary / cashfree payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.cashfree_in.primary
    table_id: table.zs_observe.cashfree_payin
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
  canonical_id: account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
  name: account data binding / mensa / cashfree in / primary / cashfree expense report
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    platform_account_id: platform_account.mensa.cashfree_in.primary
    table_id: table.zs_observe.cashfree_expense_report
    scope_keys:
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 22
      data_type: integer
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_expense_report
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime scope filter for Mensa Brands. Keep this filter in Account Data Binding, not in Table/Metric/Process cards.
    original_bad_state_status:
      status: active
      active: true
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  canonical_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  name: Mensa Brands Domestic Marketplace Canonical-Mapped Scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  description: Reusable scope for domestic marketplace seller accounts that currently have canonical marketplace table bindings
    in this package.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands Domestic Marketplace Canonical-Mapped Scope
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.mensa.amazon_in.primary
    - platform_account.mensa.flipkart_in.primary
    - platform_account.mensa.myntra_in.primary
    - platform_account.mensa.meesho_in.primary
    - platform_account.mensa.nykaa_in.primary
    - platform_account.mensa.jiomart_in.primary
    - platform_account.mensa.snapdeal_in.primary
    - platform_account.mensa.tatacliq_in.primary
    - platform_account.mensa.limeroad_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    - platform.meesho
    - platform.nykaa
    - platform.jiomart
    - platform.snapdeal
    - platform.tatacliq
    - platform.limeroad
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    - platform_context.meesho.in
    - platform_context.nykaa_fashion.in
    - platform_context.jiomart.in
    - platform_context.snapdeal.in
    - platform_context.tatacliq.in
    - platform_context.limeroad.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.nykaa.in
      to: platform_context.nykaa_fashion.in
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  canonical_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  name: Mensa Brands Domestic Marketplace Pending Context Scope
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  description: Reusable holding scope for configured domestic channels whose canonical platform context/table docs are pending.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands Domestic Marketplace Pending Context Scope
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.mensa.firstcry_in.primary
    - platform_account.mensa.shop101_in.primary
    - platform_account.mensa.cred_in.primary
    - platform_account.mensa.klip_in.primary
    - platform_account.mensa.blitz_in.primary
    - platform_account.mensa.snapmint_in.primary
    platform_ids: []
    platform_context_ids: []
    declared_unresolved_platform_ids:
    - platform.firstcry
    - platform.shop101
    - platform.cred
    - platform.klip
    - platform.blitz
    - platform.snapmint
    declared_unresolved_platform_context_ids:
    - platform_context.firstcry.in
    - platform_context.shop101.in
    - platform_context.cred.in
    - platform_context.klip.in
    - platform_context.blitz.in
    - platform_context.snapmint.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.shopify_d2c
  canonical_id: business_scope_set.mensa_brands.shopify_d2c
  name: Mensa Brands Shopify D2C Scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  description: Reusable scope for Mensa D2C Shopify OMS and returns analysis.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands Shopify D2C Scope
    scope_type: group_platform_scope
    platform_account_ids:
    - platform_account.mensa.shopify_d2c.primary
    platform_ids:
    - platform.shopify
    platform_context_ids:
    - platform_context.shopify.in_and_global.d2c_oms_client_config
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.operations_wms
  canonical_id: business_scope_set.mensa_brands.operations_wms
  name: Mensa Brands Operations WMS Scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - increff_operations.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  description: Reusable scope for cross-channel OMS/WMS operational evidence from Increff and Unicommerce.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands Operations WMS Scope
    scope_type: operational_scope
    platform_account_ids:
    - platform_account.mensa.increff_wms.primary
    - platform_account.mensa.unicommerce_oms.primary
    platform_ids:
    - platform.increff
    - platform.unicommerce
    platform_context_ids:
    - platform_context.increff.in
    - platform_context.unicommerce.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.logistics_settlement
  canonical_id: business_scope_set.mensa_brands.logistics_settlement
  name: Mensa Brands Logistics Settlement Scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - xpressbees_logistics.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  description: Reusable scope for logistics settlement, freight invoice, COD remittance, and courier reconciliation questions.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands Logistics Settlement Scope
    scope_type: cross_platform_reconciliation_scope
    platform_account_ids:
    - platform_account.mensa.delhivery_in.primary
    - platform_account.mensa.ekart_in.primary
    - platform_account.mensa.xpressbees_in.primary
    - platform_account.mensa.shadowfax_in.primary
    - platform_account.mensa.smartr_in.primary
    - platform_account.mensa.dtdc_in.primary
    - platform_account.mensa.shiprocket_in.primary
    - platform_account.mensa.shipturtle_in.primary
    platform_ids:
    - platform.delhivery
    - platform.ekart
    - platform.xpressbees
    - platform.shadowfax
    - platform.dtdc
    - platform.shiprocket
    platform_context_ids:
    - platform_context.delhivery.in
    - platform_context.ekart.in
    - platform_context.xpressbees.in
    - platform_context.shadowfax.in
    - platform_context.dtdc.in
    - platform_context.shiprocket.in
    declared_unresolved_platform_ids:
    - platform.smartr
    - platform.shipturtle
    declared_unresolved_platform_context_ids:
    - platform_context.smartr.in
    - platform_context.shipturtle.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.payment_gateways
  canonical_id: business_scope_set.mensa_brands.payment_gateways
  name: Mensa Brands Payment Gateway Scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  description: Reusable scope for configured payment gateway pay-in, payout, refund, and settlement analysis.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands Payment Gateway Scope
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.mensa.razorpay_in.primary
    - platform_account.mensa.paytm_in.primary
    - platform_account.mensa.phonepe_in.primary
    - platform_account.mensa.cashfree_in.primary
    - platform_account.mensa.easebuzz_in.primary
    platform_ids:
    - platform.razorpay
    - platform.paytm
    - platform.phonepe
    - platform.cashfree
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.paytm.in
    - platform_context.phonepe.in
    - platform_context.cashfree.in
    declared_unresolved_platform_ids:
    - platform.easebuzz
    declared_unresolved_platform_context_ids:
    - platform_context.easebuzz.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mensa_brands.international_marketplaces
  canonical_id: business_scope_set.mensa_brands.international_marketplaces
  name: Mensa Brands International Marketplace Scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - amazon_marketplace.md
  - walmart_marketplace.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.03_active_sales_channels_domestic_international
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.02_walmart
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.01_amazon_india
  - ev.mensa_business.docx.row.03_active_sales_channels_domestic_international.01_amazon_us_ca_uk_mx
  description: Reusable scope for international Amazon and Walmart contexts. Table/account bindings require country-specific
    confirmation.
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    scope_name: Mensa Brands International Marketplace Scope
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.mensa.amazon_us.primary
    - platform_account.mensa.amazon_ca.primary
    - platform_account.mensa.amazon_uk.primary
    - platform_account.mensa.amazon_mx.primary
    - platform_account.mensa.walmart_us.primary
    platform_ids:
    - platform.amazon
    - platform.walmart
    platform_context_ids:
    - platform_context.amazon.international
    - platform_context.walmart.us
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.us
      to: platform_context.amazon.international
    - kind: canonical_id
      from: platform_context.amazon.ca
      to: platform_context.amazon.international
    - kind: canonical_id
      from: platform_context.amazon.uk
      to: platform_context.amazon.international
    - kind: canonical_id
      from: platform_context.amazon.mx
      to: platform_context.amazon.international
    original_bad_state_status:
      status: draft
      active: false
    status_correction_reason: scope_is_source_confirmed_and_can_hold_partial_resolved_members_with_gaps_explicitly_declared
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  canonical_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  name: Mensa Brands Marketplace to Increff Operations Flow
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - increff_operations.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    binding_name: Mensa Brands Marketplace to Increff Operations Flow
    binding_type: operational_flow
    business_scope_set_id: business_scope_set.mensa_brands.operations_wms
    money_flow_paths:
    - marketplace_to_operations_wms
    - order_to_shipment
    - return_to_wms
    participating_accounts:
    - platform_account_id: platform_account.mensa.amazon_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.flipkart_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.myntra_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.meesho_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.nykaa_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.jiomart_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.snapdeal_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.tatacliq_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.limeroad_in.primary
      role: marketplace_order_source
      required: false
    - platform_account_id: platform_account.mensa.increff_wms.primary
      role: operations_wms_source
      required: true
    conditions:
    - concept: sales_channel
      operator: IN
      value:
      - MYNTRAV4
      - FLIPKARTV3
      - AMAZON_SC
      - NYKAA_FASHION
      - NYKAA
      - TATACLIQ
      - SNAPDEAL
      - LIMEROAD_MENSA_GURGAON
      - LIMEROAD_MENSA_BLR
      - LIMEROAD_MENSA_BHIWANDI
      - MENSA_MEESHO_BLR
      - MENSA_MEESHO_GGN
      - MENSA_MEESHO_MUM
    evidence_table_ids:
    - table.zs_observe.increff_sales
    - table.zs_observe.increff_returns
    account_data_binding_ids:
    - account_data_binding.mensa.increff_wms.primary.increff_sales
    - account_data_binding.mensa.increff_wms.primary.increff_returns
    relationship_ids: []
    fulfilment_ownership_model: null
    resolved_business_process_ids:
    - business_process.order_to_shipment_flow
    - business_process.warehouse_to_courier_handoff
    - business_process.delivery_rto_return_resolution
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids:
    - reconciliation_profile.order_to_shipment
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Use this flow for operational fulfillment/returns evidence, not for marketplace financial settlement. Marketplace settlement
      remains on marketplace-specific accounts/tables.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  canonical_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  name: Mensa Brands Shopify D2C Prepaid OMS to Payment Gateway Flow
  status: active
  active: true
  confidence: inferred
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - logistics_domain.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    binding_name: Mensa Brands Shopify D2C Prepaid OMS to Payment Gateway Flow
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.mensa_brands.shopify_d2c
    money_flow_paths:
    - ecommerce_store_to_payment_gateway
    - payment_gateway_settlement
    participating_accounts:
    - platform_account_id: platform_account.mensa.shopify_d2c.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.mensa.razorpay_in.primary
      role: payment_gateway_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.cashfree_in.primary
      role: payment_gateway_settlement_source
      required: false
    conditions:
    - concept: shopify_payment_mode
      operator: '!='
      value: cash_on_delivery
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.shopify_returns
    - table.zs_observe.razorpay_payin
    - table.zs_observe.cashfree_payin
    account_data_binding_ids:
    - account_data_binding.mensa.shopify_d2c.primary.shopify_oms
    - account_data_binding.mensa.shopify_d2c.primary.shopify_returns
    - account_data_binding.mensa.razorpay_in.primary.razorpay_payin
    - account_data_binding.mensa.razorpay_in.primary.razorpay_payout
    - account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
    - account_data_binding.mensa.cashfree_in.primary.cashfree_payin
    - account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
    relationship_ids: []
    fulfilment_ownership_model: null
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.payment_capture_to_gateway_settlement
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.oms_payment_to_gateway_settlement
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client Tables - Shopify identifies Shopify OMS/returns against Cashfree/Razorpay PG settlement. Bank leg remains unresolved
      until Mensa bank account cards are provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  canonical_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  name: Mensa Brands Shopify D2C COD to Shiprocket Remittance Flow
  status: active
  active: true
  confidence: inferred
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mensa_business.docx.section.02_active_sales_channels_domestic
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  - ev.mensa_business.docx.row.02_active_sales_channels_domestic.14_shopify
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    binding_name: Mensa Brands Shopify D2C COD to Shiprocket Remittance Flow
    binding_type: fulfilment_flow
    business_scope_set_id: business_scope_set.mensa_brands.shopify_d2c
    money_flow_paths:
    - order_to_shipment
    - cod_delivery_to_courier_remittance
    participating_accounts:
    - platform_account_id: platform_account.mensa.shopify_d2c.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.mensa.shiprocket_in.primary
      role: logistics_cod_remittance_source
      required: true
    conditions:
    - concept: shopify_payment_mode
      operator: '='
      value: cash_on_delivery
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.shiprocket_oms
    - table.zs_observe.shiprocket_settlement
    - table.zs_observe.shiprocket_settlement_report
    account_data_binding_ids:
    - account_data_binding.mensa.shopify_d2c.primary.shopify_oms
    - account_data_binding.mensa.shopify_d2c.primary.shopify_returns
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
    relationship_ids: []
    fulfilment_ownership_model: aggregator_routed
    resolved_business_process_ids:
    - business_process.order_to_shipment_flow
    - business_process.cod_delivery_to_courier_remittance
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids:
    - reconciliation_profile.cod_expected_to_courier_remittance
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client Tables - Shopify states COD remittance can come from Shiprocket/BlueDart; Mensa client doc confirms Shiprocket
      configured. BlueDart is not present as a Mensa platform account in the source client doc, so it is not activated here.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  canonical_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  name: Mensa Brands Marketplace Settlement to Bank Flow — Pending Bank Account
  status: draft
  active: false
  confidence: inferred
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    binding_name: Mensa Brands Marketplace Settlement to Bank Flow — Pending Bank Account
    binding_type: money_flow
    business_scope_set_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
    money_flow_paths:
    - marketplace_to_bank
    participating_accounts:
    - platform_account_id: platform_account.mensa.amazon_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.flipkart_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.myntra_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.meesho_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.nykaa_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.jiomart_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.snapdeal_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.tatacliq_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.limeroad_in.primary
      role: marketplace_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.bank.operating_pending
      role: bank_destination
      required: true
      unresolved: true
    conditions: []
    evidence_table_ids: []
    account_data_binding_ids:
    - account_data_binding.mensa.amazon_in.primary.amazon_oms
    - account_data_binding.mensa.amazon_in.primary.amazon_settlement
    - account_data_binding.mensa.amazon_in.primary.amazon_returns
    - account_data_binding.mensa.amazon_in.primary.amazon_fee_preview
    - account_data_binding.mensa.amazon_in.primary.amazon_disbursment
    - account_data_binding.mensa.flipkart_in.primary.flipkart_oms
    - account_data_binding.mensa.flipkart_in.primary.flipkart_settlement
    - account_data_binding.mensa.flipkart_in.primary.flipkart_commission
    - account_data_binding.mensa.flipkart_in.primary.flipkart_cashback
    - account_data_binding.mensa.myntra_in.primary.myntra_oms
    - account_data_binding.mensa.myntra_in.primary.myntra_settlement
    - account_data_binding.mensa.myntra_in.primary.myntra_reverse
    - account_data_binding.mensa.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.mensa.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.mensa.meesho_in.primary.meesho_sales
    - account_data_binding.mensa.meesho_in.primary.meesho_settlement
    - account_data_binding.mensa.meesho_in.primary.meesho_returns
    - account_data_binding.mensa.meesho_in.primary.meesho_reverse
    - account_data_binding.mensa.meesho_in.primary.meesho_forward_expenses
    - account_data_binding.mensa.meesho_in.primary.meesho_reverse_expenses
    - account_data_binding.mensa.meesho_in.primary.meesho_other_charges_expenses
    - account_data_binding.mensa.meesho_in.primary.meesho_brand_mapping
    - account_data_binding.mensa.nykaa_in.primary.nykaa_oms
    - account_data_binding.mensa.nykaa_in.primary.nykaa_settlement
    - account_data_binding.mensa.nykaa_in.primary.nykaa_addition_charge
    - account_data_binding.mensa.nykaa_in.primary.nykaa_mapper_gst
    - account_data_binding.mensa.nykaa_in.primary.nykaa_mapping
    - account_data_binding.mensa.jiomart_in.primary.jiomart_oms
    - account_data_binding.mensa.jiomart_in.primary.jiomart_settlement
    - account_data_binding.mensa.jiomart_in.primary.jiomart_returns
    - account_data_binding.mensa.jiomart_in.primary.jiomart_shipment
    - account_data_binding.mensa.snapdeal_in.primary.snapdeal_oms
    - account_data_binding.mensa.snapdeal_in.primary.snapdeal_settlement
    - account_data_binding.mensa.snapdeal_in.primary.snapdeal_payments
    - account_data_binding.mensa.snapdeal_in.primary.snapdeal_sales_return
    - account_data_binding.mensa.snapdeal_in.primary.snapdeal_non_order
    - account_data_binding.mensa.snapdeal_in.primary.snapdeal_commission
    - account_data_binding.mensa.tatacliq_in.primary.tatacliq_oms
    - account_data_binding.mensa.tatacliq_in.primary.tatacliq_settlement
    - account_data_binding.mensa.limeroad_in.primary.limeroad_oms
    - account_data_binding.mensa.limeroad_in.primary.limeroad_settlement
    relationship_ids: []
    fulfilment_ownership_model: null
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.marketplace_settlement_lifecycle
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.marketplace_settlement_to_bank_credit
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Do not activate until Mensa bank account/platform-account and bank-statement Account Data Binding cards are provided.
      Single marketplace analytics do not need this BFB.
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  canonical_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  name: Mensa Brands Payment Gateway to Bank Flow — Pending Bank Account
  status: draft
  active: false
  confidence: inferred
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mensa_business.docx.section.01_identity
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    binding_name: Mensa Brands Payment Gateway to Bank Flow — Pending Bank Account
    binding_type: money_flow
    business_scope_set_id: business_scope_set.mensa_brands.payment_gateways
    money_flow_paths:
    - payment_gateway_to_bank
    - refund_to_bank
    participating_accounts:
    - platform_account_id: platform_account.mensa.razorpay_in.primary
      role: payment_gateway_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.paytm_in.primary
      role: payment_gateway_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.phonepe_in.primary
      role: payment_gateway_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.cashfree_in.primary
      role: payment_gateway_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.easebuzz_in.primary
      role: payment_gateway_settlement_source
      required: false
    - platform_account_id: platform_account.mensa.bank.operating_pending
      role: bank_destination
      required: true
      unresolved: true
    conditions: []
    evidence_table_ids: []
    account_data_binding_ids:
    - account_data_binding.mensa.razorpay_in.primary.razorpay_payin
    - account_data_binding.mensa.razorpay_in.primary.razorpay_payout
    - account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
    - account_data_binding.mensa.paytm_in.primary.paytm_payin
    - account_data_binding.mensa.paytm_in.primary.paytm_payout
    - account_data_binding.mensa.phonepe_in.primary.phonepe_payin
    - account_data_binding.mensa.cashfree_in.primary.cashfree_payin
    - account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
    relationship_ids: []
    fulfilment_ownership_model: null
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.payment_gateway_to_bank_reconciliation
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.payment_gateway_payout_to_bank_credit
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bank destination account is missing from the client reference. Keep as draft until bank account and bank statement bindings
      are available.
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  canonical_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  name: Mensa Brands Logistics COD to Bank Flow — Pending Bank Account
  status: draft
  active: false
  confidence: inferred
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Mensa Brand Technologies Private Limited.docx
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  evidence_refs:
  - ev.mensa_business.docx.section.04_logistics_settlement_files
  fields:
    tenant_id: tenant.mensa_brand_technologies
    group_id: group.mensa_brands
    binding_name: Mensa Brands Logistics COD to Bank Flow — Pending Bank Account
    binding_type: money_flow
    business_scope_set_id: business_scope_set.mensa_brands.logistics_settlement
    money_flow_paths:
    - logistics_cod_to_bank
    participating_accounts:
    - platform_account_id: platform_account.mensa.delhivery_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.ekart_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.xpressbees_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.shadowfax_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.smartr_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.dtdc_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.shiprocket_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.shipturtle_in.primary
      role: logistics_cod_remittance_source
      required: false
    - platform_account_id: platform_account.mensa.bank.operating_pending
      role: bank_destination
      required: true
      unresolved: true
    conditions: []
    evidence_table_ids: []
    account_data_binding_ids:
    - account_data_binding.mensa.delhivery_in.primary.delhivery_invoice
    - account_data_binding.mensa.delhivery_in.primary.delhivery_settlement
    - account_data_binding.mensa.dtdc_in.primary.dtdc_invoice
    - account_data_binding.mensa.dtdc_in.primary.dtdc_settlement
    - account_data_binding.mensa.ekart_in.primary.ekart_invoice
    - account_data_binding.mensa.ekart_in.primary.ekart_settlement
    - account_data_binding.mensa.xpressbees_in.primary.xpressbees_settlement
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
    - account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
    relationship_ids: []
    fulfilment_ownership_model: null
    resolved_business_process_ids:
    - business_process.cod_delivery_to_courier_remittance
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.logistics_cod_to_bank_credit
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bank destination account is missing from the client reference. Shadowfax/Smartr/Shipturtle native table bindings are
      also pending.
    original_bad_state_status:
      status: draft
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- platform_account_id: platform_account.mensa.myntra_in.primary
  client_config_text: OMS (JIT + PPMP), Fwd/Rev Settlement, Returns (JIT + PPMP), Non-order Settlement, GSTR, VHS/VFS expenses,
    Seller reports, Transactions
  future_platform_context_gaps:
  - Myntra GSTR
  - Myntra VHS/VFS expenses
  - Myntra seller reports
  - Myntra transactions
  mapping_rule: Map client-described artifacts to existing canonical semantic coverage only. Do not invent table cards for
    missing client artifacts; add them later to platform context and bind then.
  resolved_canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.mensa_business.hasgroup.6a6f5302c4c4
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.mensa_brand_technologies
  target_card_id: group.mensa_brands
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_GROUP
- edge_id: edge.mensa_business.hasplatformaccount.35acb774d9a1
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.amazon_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.d4253cd7536c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.983e2b194c55
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: platform_context.amazon.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.e66399463c16
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.flipkart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.4246490653b1
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.flipkart_in.primary
  target_card_id: platform.flipkart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.a67419985a03
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.flipkart_in.primary
  target_card_id: platform_context.flipkart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.86bb0524f69f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.myntra_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.b4a0dbbbe664
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: platform.myntra
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.959ce80d0404
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: platform_context.myntra.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.91f0311c3037
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.meesho_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.fb4efa3ff2f3
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: platform.meesho
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.4d00a6f3cb92
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: platform_context.meesho.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.fa47da9b4104
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.nykaa_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.e2104d62283f
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: platform.nykaa
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.9b2410d8d161
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: platform_context.nykaa_fashion.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.464611fcf99c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.jiomart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.04f67363721c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.jiomart_in.primary
  target_card_id: platform.jiomart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.a0038dc82361
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.jiomart_in.primary
  target_card_id: platform_context.jiomart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.296afd467c78
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.snapdeal_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.61951ab424da
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: platform.snapdeal
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.e13b35f99ef5
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: platform_context.snapdeal.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.8b641e9344cf
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.tatacliq_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.f3b1b5b93eb6
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.tatacliq_in.primary
  target_card_id: platform.tatacliq
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.bc95d1f007a0
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.tatacliq_in.primary
  target_card_id: platform_context.tatacliq.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.2a51bceb34f5
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.limeroad_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.fa3136b645c5
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.limeroad_in.primary
  target_card_id: platform.limeroad
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.8701340926aa
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.limeroad_in.primary
  target_card_id: platform_context.limeroad.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.9ee185b820a2
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.firstcry_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.11677653962d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.shop101_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.641703fdb9b2
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.cred_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.5875f7491b69
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.klip_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.a28818770814
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.blitz_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.efa4f5b5a553
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.snapmint_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.65b70ae6c257
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.amazon_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.c735f3e6a108
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.amazon_us.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.de3c95c6dac4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.amazon_us.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.93a3c1e85fca
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.amazon_ca.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.9bb5ed023ac5
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.amazon_ca.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.1b3ec48058e0
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.amazon_ca.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.7ee0d776be4a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.amazon_uk.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.ed21194c7772
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.amazon_uk.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.446da6dc5647
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.amazon_uk.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.6480a72317ea
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.amazon_mx.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.a04dd5263e5a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.amazon_mx.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.f1b2e2034a56
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.amazon_mx.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.4e0c8372adc7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.walmart_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.0dd0fcf2d887
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.walmart_us.primary
  target_card_id: platform.walmart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.f02b437c9540
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.walmart_us.primary
  target_card_id: platform_context.walmart.us
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.69524a7788ae
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.shopify_d2c.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.8bcbd630738e
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.shopify_d2c.primary
  target_card_id: platform.shopify
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.94d949a6b23f
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.shopify_d2c.primary
  target_card_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.a4561a6ddcab
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.increff_wms.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.50eb76f23fc3
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.increff_wms.primary
  target_card_id: platform.increff
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.f7fa6a6d18de
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.increff_wms.primary
  target_card_id: platform_context.increff.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.5043b35ebc66
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.unicommerce_oms.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.0b09756a3e0a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.unicommerce_oms.primary
  target_card_id: platform.unicommerce
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.316a39092d8d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.unicommerce_oms.primary
  target_card_id: platform_context.unicommerce.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.76eac243fbde
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.delhivery_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.69a6e155463a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.delhivery_in.primary
  target_card_id: platform.delhivery
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.0929fe486039
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.delhivery_in.primary
  target_card_id: platform_context.delhivery.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.1331f5b4e6aa
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.ekart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.c0859a810fa5
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.ekart_in.primary
  target_card_id: platform.ekart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.df90961cf9f6
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.ekart_in.primary
  target_card_id: platform_context.ekart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.2e5f48cc422a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.xpressbees_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.831099c356c3
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.xpressbees_in.primary
  target_card_id: platform.xpressbees
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.c9cbf030a130
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.xpressbees_in.primary
  target_card_id: platform_context.xpressbees.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.d3d8afeedee9
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.shadowfax_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.d17f532dfbe6
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.shadowfax_in.primary
  target_card_id: platform.shadowfax
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.a9094545cc09
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.shadowfax_in.primary
  target_card_id: platform_context.shadowfax.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.f019cd1adcef
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.smartr_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.09badd0b8228
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.dtdc_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.4b79cdb471f8
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.dtdc_in.primary
  target_card_id: platform.dtdc
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.9aa9a72ccb3c
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.dtdc_in.primary
  target_card_id: platform_context.dtdc.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.4adb6f217f38
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.shiprocket_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.ece51b323bce
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.shiprocket_in.primary
  target_card_id: platform.shiprocket
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.662984a76c3e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.shiprocket_in.primary
  target_card_id: platform_context.shiprocket.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.eeaea2fefcb3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.shipturtle_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasplatformaccount.c363eeb1ed1b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.razorpay_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.2e3b1157e382
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.razorpay_in.primary
  target_card_id: platform.razorpay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.c6f154686270
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.razorpay_in.primary
  target_card_id: platform_context.razorpay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.647ee720be43
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.paytm_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.d8b185238bcd
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.paytm_in.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.0c8be49f72db
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.paytm_in.primary
  target_card_id: platform_context.paytm.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.39b1d3243c17
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.phonepe_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.978b5d351d27
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.phonepe_in.primary
  target_card_id: platform.phonepe
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.230c51d0223b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.phonepe_in.primary
  target_card_id: platform_context.phonepe.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.284dd84b76cc
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.cashfree_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatform.0470bc2b815f
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mensa.cashfree_in.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mensa_business.usesplatformcontext.bb82b16a22b3
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mensa.cashfree_in.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mensa_business.hasplatformaccount.a475f31d59e4
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mensa_brands
  target_card_id: platform_account.mensa.easebuzz_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasaccountdatabinding.30b9d06c72d3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.0b1c99c3b3d2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.amazon_in.primary.amazon_oms
  target_card_id: table.zs_observe.amazon_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.feb7bb478067
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.c780f863f67f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.amazon_in.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.a0b70aadcbf6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.2496f6a9c268
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.amazon_in.primary.amazon_returns
  target_card_id: table.zs_observe.amazon_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.ef20b2280de2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_fee_preview
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.88722ea5c224
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.amazon_in.primary.amazon_fee_preview
  target_card_id: table.zs_observe.amazon_fee_preview
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.a9665b79fc94
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.amazon_in.primary
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_disbursment
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.936ca633333b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.amazon_in.primary.amazon_disbursment
  target_card_id: table.zs_observe.amazon_disbursment
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.da78f2b13766
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.flipkart_in.primary
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.aa5d47be1a4b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_oms
  target_card_id: table.flipkart.oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.cca30394b397
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.flipkart_in.primary
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.72b586e8539a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_settlement
  target_card_id: table.flipkart.settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.3a49774b9908
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.flipkart_in.primary
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_commission
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.a8282c3e62c8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_commission
  target_card_id: table.flipkart.commission
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.4e3f3202ae2a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.flipkart_in.primary
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_cashback
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.4026e1d67de5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_cashback
  target_card_id: table.flipkart.cashback
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.8fcab5697784
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.9b3eed2ffb15
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms
  target_card_id: table.zs_observe.myntra_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.b8b043405fb2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.fb02f4947b12
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.myntra_in.primary.myntra_settlement
  target_card_id: table.zs_observe.myntra_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.cbe821f52a8c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_reverse
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.c7eb77021f6d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.myntra_in.primary.myntra_reverse
  target_card_id: table.zs_observe.myntra_reverse
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.750f1bd3417b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_non_order_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.7854a19285fb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.myntra_in.primary.myntra_non_order_settlement
  target_card_id: table.zs_observe.myntra_non_order_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.4667781bf9dd
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.myntra_in.primary
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.efcab6614b8b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms_settlement
  target_card_id: table.zs_observe.myntra_oms_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.0a21a2111b63
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.b1e6c831a85a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_sales
  target_card_id: table.zs_observe.meesho_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.43d7cc438ebb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.4751ff6bb0b0
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_settlement
  target_card_id: table.zs_observe.meesho_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.2af824465918
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.eefc3a1a77d1
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_returns
  target_card_id: table.zs_observe.meesho_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.51991b86c801
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.df93c4c1c895
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse
  target_card_id: table.zs_observe.meesho_reverse
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.a205c21a4f5c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_forward_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.90d3c77b20dc
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_forward_expenses
  target_card_id: table.zs_observe.meesho_forward_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.21f36cac7976
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.7ff4ec266dbf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse_expenses
  target_card_id: table.zs_observe.meesho_reverse_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.219828d01387
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_other_charges_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.6af4163511c9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_other_charges_expenses
  target_card_id: table.zs_observe.meesho_other_charges_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.ee6d9e0123f9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.meesho_in.primary
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_brand_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.7643714222e5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.meesho_in.primary.meesho_brand_mapping
  target_card_id: table.zs_observe.meesho_brand_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.33d20546c323
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.1b0a7eb69c39
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_oms
  target_card_id: table.zs_observe.nykaa_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.a2b4ddfa100c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.cde2193ef9b6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_settlement
  target_card_id: table.zs_observe.nykaa_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.c4df56033b76
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_addition_charge
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.70f74a867616
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_addition_charge
  target_card_id: table.zs_observe.nykaa_addition_charge
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.4aa31c3f7b50
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapper_gst
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.d4084e3db3d2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapper_gst
  target_card_id: table.zs_observe.nykaa_mapper_gst
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.c3c3bfabf11f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.nykaa_in.primary
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.63119ddf488e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapping
  target_card_id: table.zs_observe.nykaa_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.030bbf410b45
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.jiomart_in.primary
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.f0c67505f793
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_oms
  target_card_id: table.zs_observe.jiomart_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.90d446b69050
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.jiomart_in.primary
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.332b2170bbb7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_settlement
  target_card_id: table.zs_observe.jiomart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.7198fd31e12b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.jiomart_in.primary
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.6c728d49bddb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_returns
  target_card_id: table.zs_observe.jiomart_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.54dc94bab5fc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.jiomart_in.primary
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_shipment
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.c41793888183
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_shipment
  target_card_id: table.zs_observe.jiomart_shipment
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.041016410b41
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.e5e03d9f1a0d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_oms
  target_card_id: table.zs_observe.snapdeal_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.ff6020a7d62e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.f467a4cca427
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_settlement
  target_card_id: table.zs_observe.snapdeal_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.232da80afd4a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_payments
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.a2cfc8146ff9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_payments
  target_card_id: table.zs_observe.snapdeal_payments
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.c2089e10b7fb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_sales_return
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.80f380fa143c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_sales_return
  target_card_id: table.zs_observe.snapdeal_sales_return
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.8998a6a586b3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_non_order
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.b6402c3610a1
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_non_order
  target_card_id: table.zs_observe.snapdeal_non_order
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.d7e6d487b803
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.snapdeal_in.primary
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_commission
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.3beac2810f57
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_commission
  target_card_id: table.zs_observe.snapdeal_commission
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.93608cd60cea
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.tatacliq_in.primary
  target_card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.35c9086b7b16
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_oms
  target_card_id: table.zs_observe.tatacliq_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.14d47b5b2189
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.tatacliq_in.primary
  target_card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.86ed0687c8ed
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_settlement
  target_card_id: table.zs_observe.tatacliq_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.bae72297a7e1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.limeroad_in.primary
  target_card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.0b531dca2a24
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_oms
  target_card_id: table.zs_observe.limeroad_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.1eb5854aa813
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.limeroad_in.primary
  target_card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.fc1c652275c4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_settlement
  target_card_id: table.zs_observe.limeroad_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.f978ebae1a6a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.shopify_d2c.primary
  target_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.06f36ae27c2b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
  target_card_id: table.zs_observe.shopify_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.6bd60b554bf2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.shopify_d2c.primary
  target_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.c0d665c8920e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
  target_card_id: table.zs_observe.shopify_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.b271a7094e84
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.increff_wms.primary
  target_card_id: account_data_binding.mensa.increff_wms.primary.increff_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.1264bdc87dac
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.increff_wms.primary.increff_sales
  target_card_id: table.zs_observe.increff_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.d0ce2947445e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.increff_wms.primary
  target_card_id: account_data_binding.mensa.increff_wms.primary.increff_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.6415c095aa0c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.increff_wms.primary.increff_returns
  target_card_id: table.zs_observe.increff_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.1e381c98a6f1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.unicommerce_oms.primary
  target_card_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.7c1ca7586b68
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce
  target_card_id: table.zs_observe.unicommerce
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.055aed016188
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.unicommerce_oms.primary
  target_card_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce_order_sales_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.e5cfa9018bd5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.unicommerce_oms.primary.unicommerce_order_sales_report
  target_card_id: table.zs_observe.unicommerce_order_sales_report
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.62ae25cd5a26
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.delhivery_in.primary
  target_card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.58ad20f73747
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_invoice
  target_card_id: table.zs_observe.delhivery_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.774bbe436482
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.delhivery_in.primary
  target_card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.8791319f1ded
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_settlement
  target_card_id: table.zs_observe.delhivery_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.df91266c3887
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.dtdc_in.primary
  target_card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.efc036995e84
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_invoice
  target_card_id: table.zs_observe.dtdc_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.2a4165a0cf15
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.dtdc_in.primary
  target_card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.cecaec2a923e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_settlement
  target_card_id: table.zs_observe.dtdc_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.5586bbc019d6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.ekart_in.primary
  target_card_id: account_data_binding.mensa.ekart_in.primary.ekart_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.c03c78e1f56d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.ekart_in.primary.ekart_invoice
  target_card_id: table.zs_observe.ekart_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.ff78eb4a12d6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.ekart_in.primary
  target_card_id: account_data_binding.mensa.ekart_in.primary.ekart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.d0abcbb0c6cf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.ekart_in.primary.ekart_settlement
  target_card_id: table.zs_observe.ekart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.c45127df7d1c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.xpressbees_in.primary
  target_card_id: account_data_binding.mensa.xpressbees_in.primary.xpressbees_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.79fb153ae27d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.xpressbees_in.primary.xpressbees_settlement
  target_card_id: table.zs_observe.xpressbees_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.ed576b3ef93e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.shiprocket_in.primary
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.d6e3b7b22a17
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
  target_card_id: table.zs_observe.shiprocket_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.000ba1648845
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.shiprocket_in.primary
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.d34effb533c5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
  target_card_id: table.zs_observe.shiprocket_invoice
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.a1864a182cd6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.shiprocket_in.primary
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.ff1a80517304
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
  target_card_id: table.zs_observe.shiprocket_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.d717b5dc7393
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.shiprocket_in.primary
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.499346c643e3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
  target_card_id: table.zs_observe.shiprocket_settlement_report
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.c18924328edc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.razorpay_in.primary
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.428dc18c7332
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payin
  target_card_id: table.zs_observe.razorpay_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.19cb4735e16c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.razorpay_in.primary
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payout
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.e9de6f1ff9bd
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payout
  target_card_id: table.zs_observe.razorpay_payout
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.43c55ead3ac7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.razorpay_in.primary
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.41ca66113cf2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
  target_card_id: table.zs_observe.razorpay_transactions
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.89b9a651d017
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.paytm_in.primary
  target_card_id: account_data_binding.mensa.paytm_in.primary.paytm_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.ffca247fa048
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.paytm_in.primary.paytm_payin
  target_card_id: table.zs_observe.paytm_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.7443d9b625b8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.paytm_in.primary
  target_card_id: account_data_binding.mensa.paytm_in.primary.paytm_payout
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.e47784302ec2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.paytm_in.primary.paytm_payout
  target_card_id: table.zs_observe.paytm_payout
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.d52d1fd8486b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.phonepe_in.primary
  target_card_id: account_data_binding.mensa.phonepe_in.primary.phonepe_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.e6f1008953c9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.phonepe_in.primary.phonepe_payin
  target_card_id: table.zs_observe.phonepe_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.bc90f7dd677a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.cashfree_in.primary
  target_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.7a044b0d4f26
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_payin
  target_card_id: table.zs_observe.cashfree_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasaccountdatabinding.9d1e02818df8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mensa.cashfree_in.primary
  target_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.bindstotable.7ca154ae28e8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
  target_card_id: table.zs_observe.cashfree_expense_report
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mensa_business.hasbusinessscopeset.935b1f111a17
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.65f04824addf
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.amazon_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.e52e819b9eaf
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.flipkart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.e9ca6be61eba
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.myntra_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.0e859ad0c409
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.meesho_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.c7a526415e4d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.nykaa_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.a072fab89f7c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.jiomart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.68487fe44c6d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.snapdeal_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.b28e41cdb360
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.tatacliq_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.ebc8afb2b261
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  target_card_id: platform_account.mensa.limeroad_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessscopeset.28a560caf4b6
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.1eceaa7a7dc1
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  target_card_id: platform_account.mensa.firstcry_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.52e0a27ec3fe
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  target_card_id: platform_account.mensa.shop101_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.feea70d85f6d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  target_card_id: platform_account.mensa.cred_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.9266eefa3a0b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  target_card_id: platform_account.mensa.klip_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.4d0834ef5955
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  target_card_id: platform_account.mensa.blitz_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.39010542aeaf
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.domestic_marketplace_pending_context
  target_card_id: platform_account.mensa.snapmint_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessscopeset.63899dc24249
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.shopify_d2c
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.d2cc8e0eaa9e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.shopify_d2c
  target_card_id: platform_account.mensa.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessscopeset.22a7a59f8718
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.operations_wms
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.71ebee2e29f8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.operations_wms
  target_card_id: platform_account.mensa.increff_wms.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.31dbfff1be8f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.operations_wms
  target_card_id: platform_account.mensa.unicommerce_oms.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessscopeset.923cb78252de
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.logistics_settlement
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.521d0ed1fdf7
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.delhivery_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.fa05bd2ca860
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.ekart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.ebc9d8d075e7
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.xpressbees_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.bf0fbfbfd8d7
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.shadowfax_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.2011bf30d79a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.smartr_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.ec83a7a256da
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.dtdc_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.29315035a51a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.shiprocket_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.f5308d222dd6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.logistics_settlement
  target_card_id: platform_account.mensa.shipturtle_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessscopeset.27d1afa8f2b2
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.payment_gateways
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.db3dcd267ac4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.payment_gateways
  target_card_id: platform_account.mensa.razorpay_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.f3c38fc5295c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.payment_gateways
  target_card_id: platform_account.mensa.paytm_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.b0b9376763cc
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.payment_gateways
  target_card_id: platform_account.mensa.phonepe_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.b535da4585d9
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.payment_gateways
  target_card_id: platform_account.mensa.cashfree_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.4be5527b7df7
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.payment_gateways
  target_card_id: platform_account.mensa.easebuzz_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessscopeset.dc4ab802094f
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mensa_brands
  target_card_id: business_scope_set.mensa_brands.international_marketplaces
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.includesplatformaccount.75aadebca0da
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.international_marketplaces
  target_card_id: platform_account.mensa.amazon_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.b862577f53d8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.international_marketplaces
  target_card_id: platform_account.mensa.amazon_ca.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.b6aa24c20332
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.international_marketplaces
  target_card_id: platform_account.mensa.amazon_uk.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.ab2fc76c0c23
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.international_marketplaces
  target_card_id: platform_account.mensa.amazon_mx.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.includesplatformaccount.8dd2772e7de5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mensa_brands.international_marketplaces
  target_card_id: platform_account.mensa.walmart_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.hasbusinessflowbinding.2ef67dfc3bef
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mensa_brands
  target_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mensa_business.usesbusinessscopeset.e233661e0153
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: business_scope_set.mensa_brands.operations_wms
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.usesplatformaccount.066f0b803b9d
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.amazon_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.2cd74712bb00
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.flipkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.9b4b704ed67c
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.myntra_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.90a9a3e1a5cf
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.meesho_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.11947178e574
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.nykaa_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.757bfb1152aa
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.jiomart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.64e8cf3b2bf3
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.snapdeal_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.13efdcf99587
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.tatacliq_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.a98f0e6c17bd
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.limeroad_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.a62e43aa14ff
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: platform_account.mensa.increff_wms.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesaccountdatabinding.7541d2364506
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: account_data_binding.mensa.increff_wms.primary.increff_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.31a33e450654
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_to_increff_operations
  target_card_id: account_data_binding.mensa.increff_wms.primary.increff_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.hasbusinessflowbinding.cc24e92a65d3
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mensa_brands
  target_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mensa_business.usesbusinessscopeset.c4bb1d129674
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: business_scope_set.mensa_brands.shopify_d2c
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.usesplatformaccount.3c39c6f2151b
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: platform_account.mensa.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.0cd4bd0f9dd1
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: platform_account.mensa.razorpay_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.406abab7e05c
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: platform_account.mensa.cashfree_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesaccountdatabinding.36e34bf0565a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.4cb1c41d930e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.4a51c5ad2e34
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.60ac04b28136
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.eafacb62f626
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.abb5ecf3bf8b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.84be6d9dc9ee
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  target_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.hasbusinessflowbinding.6a984d8d9dd6
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mensa_brands
  target_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mensa_business.usesbusinessscopeset.ce93cd004e42
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: business_scope_set.mensa_brands.shopify_d2c
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.usesplatformaccount.c7a0222cf716
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: platform_account.mensa.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.5e9a50b1b1c0
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: platform_account.mensa.shiprocket_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesaccountdatabinding.55c20d6eda7a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.ce8921f99454
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.455c7cbe7784
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.1bb6c386f14b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.c5ecda3abb4e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.5e40239ac5a0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.hasbusinessflowbinding.a1bd7c448d96
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mensa_brands
  target_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mensa_business.usesbusinessscopeset.e28457cf7857
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.usesplatformaccount.fa14d901436b
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.amazon_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.ed400dcb733d
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.flipkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.50d2054f2c6d
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.myntra_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.fd3c8bef0950
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.meesho_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.cf707cbd28b8
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.nykaa_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.4f336a140ffd
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.jiomart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.b4ff63833008
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.snapdeal_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.b7f1dc5d8730
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.tatacliq_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.18b3b8f3cdda
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: platform_account.mensa.limeroad_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesaccountdatabinding.2c54855a152d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.7215be45f19f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.fb6e0458f50a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.11658dbcec43
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_fee_preview
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.9460c4f8ce40
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.amazon_in.primary.amazon_disbursment
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.8b6ff28d8e95
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.5d65b9ba7b5b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.36190731d335
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_commission
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.e33237b5fc15
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.flipkart_in.primary.flipkart_cashback
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.3cf91bc5f44a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.766b45b026df
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.26ca975ed2e8
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_reverse
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.aaefa56062c2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_non_order_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.c39d2b40d58b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.myntra_in.primary.myntra_oms_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.50c4362219f6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.d1e6c367b303
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.21166c63589c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.792bf57d44a6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.f160057227e0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_forward_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.efc705a3f956
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_reverse_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.227574c92717
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_other_charges_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.6c7f022c65ec
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.meesho_in.primary.meesho_brand_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.48ae2efecf41
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.cb268fcb891c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.54a1b56e8458
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_addition_charge
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.5d74baecc43d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapper_gst
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.01e8c3e26e0a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.nykaa_in.primary.nykaa_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.54718fdb3219
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.a7c58e694640
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.3812dd65237d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.67a9e7b3909b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.jiomart_in.primary.jiomart_shipment
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.2fbe8ac9b207
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.ef08680bc28c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.6ae16013b180
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_payments
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.86c346a6a2b2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_sales_return
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.8905f9d931f5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_non_order
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.d459dee25df0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.snapdeal_in.primary.snapdeal_commission
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.6aafcf3ff76a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.32364e3c94d0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.tatacliq_in.primary.tatacliq_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.8c54d3280100
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.14dd2a9005c9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.limeroad_in.primary.limeroad_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.hasbusinessflowbinding.2b96230be3f4
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mensa_brands
  target_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mensa_business.usesbusinessscopeset.8e2b6b9c9a5d
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: business_scope_set.mensa_brands.payment_gateways
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.usesplatformaccount.e5b64a28cfd0
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: platform_account.mensa.razorpay_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.078d9272ed32
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: platform_account.mensa.paytm_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.6ab6e030bd0d
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: platform_account.mensa.phonepe_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.1225c4ed8de3
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: platform_account.mensa.cashfree_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.bf7ac5ff2240
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: platform_account.mensa.easebuzz_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesaccountdatabinding.605c9253666e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.6ce400f2894b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.544c88cbc206
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.razorpay_in.primary.razorpay_transactions
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.d179022a6b79
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.paytm_in.primary.paytm_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.f4115ec84416
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.paytm_in.primary.paytm_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.b2d132be39c9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.phonepe_in.primary.phonepe_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.232496a4d320
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.d8ce021826d1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.cashfree_in.primary.cashfree_expense_report
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.hasbusinessflowbinding.1767b45cc5b7
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mensa_brands
  target_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mensa_business.usesbusinessscopeset.53106082521c
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: business_scope_set.mensa_brands.logistics_settlement
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mensa_business.usesplatformaccount.52c8c5aa4fb8
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.delhivery_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.3893d256c500
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.ekart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.0d5182b32965
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.xpressbees_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.68aa69fbd94e
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.shadowfax_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.03175620f3da
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.smartr_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.38512e0e08a4
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.dtdc_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.2f2f5a939018
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.shiprocket_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesplatformaccount.e3c98f3b8c76
  edge_type: USES_PLATFORM_ACCOUNT
  canonical_edge_type: USES_PLATFORM_ACCOUNT
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: platform_account.mensa.shipturtle_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_ACCOUNT
- edge_id: edge.mensa_business.usesaccountdatabinding.b38818110cbe
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_invoice
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.042322af99ab
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.delhivery_in.primary.delhivery_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.61b4406ba430
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_invoice
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.e95cf5ca1582
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.dtdc_in.primary.dtdc_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.ca063fb051a0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.ekart_in.primary.ekart_invoice
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.d4f7630ac96e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.ekart_in.primary.ekart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.6f4a2b1136ba
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.xpressbees_in.primary.xpressbees_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.bdd3b866182a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.b3b6e30e3d1c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_invoice
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.759eba748f65
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mensa_business.usesaccountdatabinding.7810bf6a010d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  target_card_id: account_data_binding.mensa.shiprocket_in.primary.shiprocket_settlement_report
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: platform_account.mensa.firstcry_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.firstcry
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.firstcry
  original_edge:
    source: platform_account.mensa.firstcry_in.primary
    edge: USES_PLATFORM
    target: platform.firstcry
- source_card_id: platform_account.mensa.firstcry_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.firstcry.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.firstcry.in
  original_edge:
    source: platform_account.mensa.firstcry_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.firstcry.in
- source_card_id: platform_account.mensa.shop101_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.shop101
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.shop101
  original_edge:
    source: platform_account.mensa.shop101_in.primary
    edge: USES_PLATFORM
    target: platform.shop101
- source_card_id: platform_account.mensa.shop101_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.shop101.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.shop101.in
  original_edge:
    source: platform_account.mensa.shop101_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.shop101.in
- source_card_id: platform_account.mensa.cred_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.cred
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.cred
  original_edge:
    source: platform_account.mensa.cred_in.primary
    edge: USES_PLATFORM
    target: platform.cred
- source_card_id: platform_account.mensa.cred_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.cred.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.cred.in
  original_edge:
    source: platform_account.mensa.cred_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.cred.in
- source_card_id: platform_account.mensa.klip_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.klip
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.klip
  original_edge:
    source: platform_account.mensa.klip_in.primary
    edge: USES_PLATFORM
    target: platform.klip
- source_card_id: platform_account.mensa.klip_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.klip.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.klip.in
  original_edge:
    source: platform_account.mensa.klip_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.klip.in
- source_card_id: platform_account.mensa.blitz_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.blitz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.blitz
  original_edge:
    source: platform_account.mensa.blitz_in.primary
    edge: USES_PLATFORM
    target: platform.blitz
- source_card_id: platform_account.mensa.blitz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.blitz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.blitz.in
  original_edge:
    source: platform_account.mensa.blitz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.blitz.in
- source_card_id: platform_account.mensa.snapmint_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.snapmint
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.snapmint
  original_edge:
    source: platform_account.mensa.snapmint_in.primary
    edge: USES_PLATFORM
    target: platform.snapmint
- source_card_id: platform_account.mensa.snapmint_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.snapmint.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.snapmint.in
  original_edge:
    source: platform_account.mensa.snapmint_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.snapmint.in
- source_card_id: platform_account.mensa.smartr_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.smartr
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.smartr
  original_edge:
    source: platform_account.mensa.smartr_in.primary
    edge: USES_PLATFORM
    target: platform.smartr
- source_card_id: platform_account.mensa.smartr_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.smartr.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.smartr.in
  original_edge:
    source: platform_account.mensa.smartr_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.smartr.in
- source_card_id: platform_account.mensa.shipturtle_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.shipturtle
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.shipturtle
  original_edge:
    source: platform_account.mensa.shipturtle_in.primary
    edge: USES_PLATFORM
    target: platform.shipturtle
- source_card_id: platform_account.mensa.shipturtle_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.shipturtle.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.shipturtle.in
  original_edge:
    source: platform_account.mensa.shipturtle_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.shipturtle.in
- source_card_id: platform_account.mensa.easebuzz_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.easebuzz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.easebuzz
  original_edge:
    source: platform_account.mensa.easebuzz_in.primary
    edge: USES_PLATFORM
    target: platform.easebuzz
- source_card_id: platform_account.mensa.easebuzz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.easebuzz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.easebuzz.in
  original_edge:
    source: platform_account.mensa.easebuzz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.easebuzz.in
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: platform_context.blitz.in
  missing_artifacts:
  - platform_context.blitz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.blitz_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.cred.in
  missing_artifacts:
  - platform_context.cred.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.cred_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.easebuzz.in
  missing_artifacts:
  - platform_context.easebuzz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.easebuzz_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.firstcry.in
  missing_artifacts:
  - platform_context.firstcry.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.firstcry_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.klip.in
  missing_artifacts:
  - platform_context.klip.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.klip_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.shipturtle.in
  missing_artifacts:
  - platform_context.shipturtle.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.shipturtle_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.shop101.in
  missing_artifacts:
  - platform_context.shop101.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.shop101_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.smartr.in
  missing_artifacts:
  - platform_context.smartr.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.smartr_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.snapmint.in
  missing_artifacts:
  - platform_context.snapmint.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.snapmint_in.primary
  generated_by_refactor: true
- platform_or_area: platform.blitz
  missing_artifacts:
  - platform.blitz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.blitz_in.primary
  generated_by_refactor: true
- platform_or_area: platform.cred
  missing_artifacts:
  - platform.cred
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.cred_in.primary
  generated_by_refactor: true
- platform_or_area: platform.easebuzz
  missing_artifacts:
  - platform.easebuzz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.easebuzz_in.primary
  generated_by_refactor: true
- platform_or_area: platform.firstcry
  missing_artifacts:
  - platform.firstcry
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.firstcry_in.primary
  generated_by_refactor: true
- platform_or_area: platform.klip
  missing_artifacts:
  - platform.klip
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.klip_in.primary
  generated_by_refactor: true
- platform_or_area: platform.shipturtle
  missing_artifacts:
  - platform.shipturtle
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.shipturtle_in.primary
  generated_by_refactor: true
- platform_or_area: platform.shop101
  missing_artifacts:
  - platform.shop101
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.shop101_in.primary
  generated_by_refactor: true
- platform_or_area: platform.smartr
  missing_artifacts:
  - platform.smartr
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.smartr_in.primary
  generated_by_refactor: true
- platform_or_area: platform.snapmint
  missing_artifacts:
  - platform.snapmint
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mensa.snapmint_in.primary
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- item: tenant.mensa_brand_technologies
  issue: Confirm preferred tenant_code; MENSA is inferred from company name.
  severity: low
  review_resolution_status: open
- item: group.mensa_brands
  issue: Confirm whether group_type should remain operational_unit or be recast as business_unit/legal_entity. Do not move
    group_level_id=22 onto Group card.
  severity: low
  review_resolution_status: open
- item: platform_account.*
  issue: Exact seller IDs, merchant IDs, store IDs, and account identifiers are not in the client reference. Platform accounts
    are present but most account identifiers are null.
  severity: medium
  review_resolution_status: open
- item: bank platform account
  issue: No Mensa bank account or bank-statement table binding was provided. Marketplace-to-bank, PG-to-bank, and logistics-COD-to-bank
    BFBs remain draft.
  severity: high
  review_resolution_status: open
- item: myntra gaps
  issue: GSTR, VHS/VFS expenses, seller reports, and transactions mentioned in the client reference are intentionally not
    mapped until canonical platform-context/table cards exist.
  severity: medium
  review_resolution_status: open
- item: shadowfax/smartr/shipturtle/easebuzz
  issue: Configured in Mensa client reference, but native canonical table/context coverage was not found in the current package;
    bindings are pending.
  severity: medium
  review_resolution_status: open
- item: platform_context.blitz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.blitz_in.primary
  generated_by_refactor: true
- item: platform_context.cred.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.cred_in.primary
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.easebuzz_in.primary
  generated_by_refactor: true
- item: platform_context.firstcry.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.firstcry_in.primary
  generated_by_refactor: true
- item: platform_context.klip.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.klip_in.primary
  generated_by_refactor: true
- item: platform_context.shipturtle.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.shipturtle_in.primary
  generated_by_refactor: true
- item: platform_context.shop101.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.shop101_in.primary
  generated_by_refactor: true
- item: platform_context.smartr.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.smartr_in.primary
  generated_by_refactor: true
- item: platform_context.snapmint.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.snapmint_in.primary
  generated_by_refactor: true
- item: platform_context.blitz.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform_context.cred.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.payment_gateways
  generated_by_refactor: true
- item: platform_context.firstcry.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform_context.klip.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform_context.shipturtle.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.logistics_settlement
  generated_by_refactor: true
- item: platform_context.shop101.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform_context.smartr.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.logistics_settlement
  generated_by_refactor: true
- item: platform_context.snapmint.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform.blitz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.blitz_in.primary
  generated_by_refactor: true
- item: platform.cred
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.cred_in.primary
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.easebuzz_in.primary
  generated_by_refactor: true
- item: platform.firstcry
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.firstcry_in.primary
  generated_by_refactor: true
- item: platform.klip
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.klip_in.primary
  generated_by_refactor: true
- item: platform.shipturtle
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.shipturtle_in.primary
  generated_by_refactor: true
- item: platform.shop101
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.shop101_in.primary
  generated_by_refactor: true
- item: platform.smartr
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.smartr_in.primary
  generated_by_refactor: true
- item: platform.snapmint
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mensa.snapmint_in.primary
  generated_by_refactor: true
- item: platform.blitz
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform.cred
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.payment_gateways
  generated_by_refactor: true
- item: platform.firstcry
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform.klip
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform.shipturtle
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.logistics_settlement
  generated_by_refactor: true
- item: platform.shop101
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
- item: platform.smartr
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.logistics_settlement
  generated_by_refactor: true
- item: platform.snapmint
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mensa_brands.domestic_marketplace_pending_context
  generated_by_refactor: true
resolved_review_items:
- item: some prior uploads expired
  issue: The file tool reported that some earlier uploaded files had expired. Re-upload any missing source docs before final
    end-to-end validator lock.
  severity: medium
  review_resolution_status: resolved_by_current_refactor
  resolution_note: Canonical markdown files required for this batch were available locally in /mnt/data during refactor; keep
    as session note only.
non_blocking_declared_semantic_reference_gaps:
- reference_id: business_process.marketplace_settlement_lifecycle
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.payment_capture_to_gateway_settlement
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.payment_gateway_to_bank_reconciliation
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.logistics_cod_to_bank_credit
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.logistics_cod_to_bank.pending_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.marketplace_settlement_to_bank_credit
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.marketplace_settlement_to_bank.pending_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.oms_payment_to_gateway_settlement
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.payment_gateway_payout_to_bank_credit
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mensa_brands.payment_gateway_to_bank.pending_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 117
  refactored_card_count: 117
  original_edge_count: 408
  refactored_edge_count: 390
  blocked_edge_count: 18
  source_evidence_count: 20
  source_row_evidence_count: 16
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 36
    account_data_binding: 66
    business_scope_set: 7
    business_flow_binding: 6
  status_counts:
    active: 104
    review_required: 9
    draft: 4
  review_status_counts:
    accepted: 104
    review_required: 13
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 43
  canonical_resolution_gap_type_counts:
    platform_id: 9
    platform_context_id: 9
    platform_ids: 9
    platform_context_ids: 9
    business_process_ids: 3
    reconciliation_profile_ids: 4
  status_correction_count: 36
  status_changes:
  - card_id: platform_account.mensa.amazon_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.flipkart_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.myntra_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.meesho_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.nykaa_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.jiomart_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.snapdeal_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.tatacliq_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.limeroad_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.firstcry_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.shop101_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.cred_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.klip_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.blitz_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.snapmint_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.amazon_us.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.amazon_ca.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.amazon_uk.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.amazon_mx.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.walmart_us.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shopify_d2c.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.unicommerce_oms.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.delhivery_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.ekart_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.xpressbees_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shadowfax_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.smartr_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.dtdc_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shiprocket_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.shipturtle_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mensa.razorpay_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.paytm_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.phonepe_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.cashfree_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mensa.easebuzz_in.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    card_type: business_scope_set
    from_status: draft
    from_active: false
    to_status: active
    to_active: true
    reason: scope_is_source_confirmed_and_can_hold_partial_resolved_members_with_gaps_explicitly_declared
  id_or_source_replacement_count: 19
  id_or_source_replacements:
  - card_id: platform_account.mensa.nykaa_in.primary
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: platform_account.mensa.amazon_us.primary
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.amazon_ca.primary
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.amazon_uk.primary
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.amazon_mx.primary
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: platform_account.mensa.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.mensa.shopify_d2c.primary
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mensa.shopify_d2c.primary.shopify_returns
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_scope_set.mensa_brands.domestic_marketplace_canonical_mapped
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: business_scope_set.mensa_brands.shopify_d2c
    kind: canonical_id
    from: platform_context.shopify.in
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: business_scope_set.mensa_brands.international_marketplaces
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: business_flow_binding.mensa_brands.shopify_d2c_prepaid_oms_to_pg
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_flow_binding.mensa_brands.shopify_d2c_cod_to_shiprocket
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  resolved_prior_review_count: 1
  open_review_count: 42
  future_context_gap_count: 18
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 7
  non_blocking_declared_semantic_reference_gap_type_counts:
    business_process_ids: 3
    reconciliation_profile_ids: 4
  edge_status_counts:
    emitted: 390
    blocked_unresolved: 18
```
