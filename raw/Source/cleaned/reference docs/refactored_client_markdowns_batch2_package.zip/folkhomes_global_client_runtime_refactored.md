# Folkhomes Global — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: folkhomes_global_client_runtime_cards_v2_1_refactored
  created_for: Folkhomes Global
  created_on: '2026-05-24'
  version: v2_1_refactored
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - amazon_marketplace.md
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  - target_plus.md
  - walmart_marketplace.md
  source_client_profile:
    business: Omnichannel retail with Shopify D2C plus Amazon, Walmart, and Target Plus marketplace presence across US, UK,
      Mexico, and Canada.
    geography: US primary; UK, Mexico, and Canada marketplace contexts
    source_group_id: 8
    source_group_level_id: 123
    source_group_name: Mensa Brands
    default_currency: USD
    currencies_in_scope:
    - USD
    - GBP
    - MXN
    - CAD
  build_policy:
  - Create active bindings only for current canonical platform tables or explicit client-observed table evidence.
  - Represent source-confirmed artifacts without table context as review-required bindings or future context gaps, not active
    mappings.
  - Keep group_id and group_level_id in Account Data Binding scope_keys rather than generic platform/domain cards.
  - Create Business Flow Bindings only for reusable client/group-level cross-account flows.
  negative_scope_constraints:
  - No separate Shopify settlement table is configured in the client reference
  resolved_legacy_constraints:
  - constraint: Walmart source tables are confirmed by the client doc but canonical Walmart platform context is not available
      in the current uploaded KB
    resolution: resolved_by_uploaded_walmart_marketplace_canonical
  generated_date: '2026-05-24'
  client_slug: folkhomes_global
  source_json_bad_state: folkhomes_global.json
  source_docx: Folkhomes Global.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: folkhomes_global.json
  source_docx: Folkhomes Global.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: platform_account.folkhomes.shopify_us.primary
    kind: canonical_id
    from: platform_context.shopify.us_d2c
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.folkhomes.amazon_us.primary
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: platform_account.folkhomes.amazon_uk.primary
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: platform_account.folkhomes.amazon_mx.primary
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: platform_account.folkhomes.amazon_ca.primary
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.shopify_d2c
    kind: canonical_id
    from: platform_context.shopify.us_d2c
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  status_changes:
  - card_id: platform_account.folkhomes.walmart_us.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  blocked_edge_count: 0
  canonical_resolution_gap_count: 9
  resolved_prior_review_count: 2
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.folkhomes_global.docx.section.01_client_knowledge_base_analyst_agent_context
  source_document: Folkhomes Global.docx
  source_section: Client Knowledge Base — Analyst Agent Context
  evidence_type: docx_section
  source_lines: L2-L4
  summary: 'last_updated: 2026-05-20

    ---'
  raw_lines:
  - 'last_updated: 2026-05-20'
  - '---'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.section.02_identity
  source_document: Folkhomes Global.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L5-L13
  summary: '* **Business Model:** Omnichannel retail — own D2C website + multi-country marketplaces

    * **Geography:** US (primary), UK, Mexico, Canada

    * **Sales Stack:** Shopify (D2C), Amazon Seller Central (multi-country), Walmart Marketplace, Target Plus/Supplier

    * GROUP LEVEL ID : 123

    * GROUP ID : 8

    * CLIENT NAME : **Folkhomes Global**

    * GROUP NAME : **Mensa Brands**

    ---'
  raw_lines:
  - '* **Business Model:** Omnichannel retail — own D2C website + multi-country marketplaces'
  - '* **Geography:** US (primary), UK, Mexico, Canada'
  - '* **Sales Stack:** Shopify (D2C), Amazon Seller Central (multi-country), Walmart Marketplace, Target Plus/Supplier'
  - '* GROUP LEVEL ID : 123'
  - '* GROUP ID : 8'
  - '* CLIENT NAME : **Folkhomes Global**'
  - '* GROUP NAME : **Mensa Brands**'
  - '---'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.section.03_active_sales_channels
  source_document: Folkhomes Global.docx
  source_section: Active Sales Channels
  evidence_type: docx_section
  source_lines: L14-L21
  summary: '| Channel | Region(s) | Settlement Source | Key Identifiers |

    |---------|-----------|-------------------|-----------------|

    | Shopify | US        | Shopify OMS       | —               |

    | Amazon  | US, UK, MX, CA | amazon_settlement (per country) | ASIN            |

    | Walmart | US        | walmart_settlement | ASIN ↔ SKU (walmart_lookup) |

    | Target  | US        | target_settlement | TCIN (target_tcin_mapping) |

    ---'
  raw_lines:
  - '| Channel | Region(s) | Settlement Source | Key Identifiers |'
  - '|---------|-----------|-------------------|-----------------|'
  - '| Shopify | US        | Shopify OMS       | —               |'
  - '| Amazon  | US, UK, MX, CA | amazon_settlement (per country) | ASIN            |'
  - '| Walmart | US        | walmart_settlement | ASIN ↔ SKU (walmart_lookup) |'
  - '| Target  | US        | target_settlement | TCIN (target_tcin_mapping) |'
  - '---'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.row.03_active_sales_channels.01_shopify
  source_document: Folkhomes Global.docx
  source_section: Active Sales Channels
  evidence_type: configured_source_row
  source_line: L17
  row_key: Shopify
  columns:
    channel: Shopify
    region_s: US
    settlement_source: Shopify OMS
    key_identifiers: —
  raw_text: '| Shopify | US        | Shopify OMS       | —               |'
  summary: 'Shopify: channel=Shopify; region_s=US; settlement_source=Shopify OMS; key_identifiers=—'
  confidence: high
- id: ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  source_document: Folkhomes Global.docx
  source_section: Active Sales Channels
  evidence_type: configured_source_row
  source_line: L18
  row_key: Amazon
  columns:
    channel: Amazon
    region_s: US, UK, MX, CA
    settlement_source: amazon_settlement (per country)
    key_identifiers: ASIN
  raw_text: '| Amazon  | US, UK, MX, CA | amazon_settlement (per country) | ASIN            |'
  summary: 'Amazon: channel=Amazon; region_s=US, UK, MX, CA; settlement_source=amazon_settlement (per country); key_identifiers=ASIN'
  confidence: high
- id: ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  source_document: Folkhomes Global.docx
  source_section: Active Sales Channels
  evidence_type: configured_source_row
  source_line: L19
  row_key: Walmart
  columns:
    channel: Walmart
    region_s: US
    settlement_source: walmart_settlement
    key_identifiers: ASIN ↔ SKU (walmart_lookup)
  raw_text: '| Walmart | US        | walmart_settlement | ASIN ↔ SKU (walmart_lookup) |'
  summary: 'Walmart: channel=Walmart; region_s=US; settlement_source=walmart_settlement; key_identifiers=ASIN ↔ SKU (walmart_lookup)'
  confidence: high
- id: ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  source_document: Folkhomes Global.docx
  source_section: Active Sales Channels
  evidence_type: configured_source_row
  source_line: L20
  row_key: Target
  columns:
    channel: Target
    region_s: US
    settlement_source: target_settlement
    key_identifiers: TCIN (target_tcin_mapping)
  raw_text: '| Target  | US        | target_settlement | TCIN (target_tcin_mapping) |'
  summary: 'Target: channel=Target; region_s=US; settlement_source=target_settlement; key_identifiers=TCIN (target_tcin_mapping)'
  confidence: high
- id: ev.folkhomes_global.docx.section.04_data_sources_table_registry
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: docx_section
  source_lines: L22-L37
  summary: '| Table Key | Source Label | Purpose |

    |-----------|--------------|---------|

    | `shopify_oms` | Shopify      | D2C orders, fulfillment, inventory |

    | `amazon_oms` | Amazon OMS   | Amazon order-level data |

    | `walmart_oms` | Walmart OMS  | Walmart order-level data |

    | `amazon_settlement` | Amazon Settlement (US/UK/MX/CA) | Revenue, fees, reimbursements per marketplace country |

    | `walmart_settlement` | Walmart Settlement | Walmart payouts and fee breakdown |

    | `target_settlement` | Target Settlement | Target payouts and fee breakdown |

    | `target_sales` | Target Sales | Target sell-through and sales performance |

    | `amazon_returns` | Amazon Returns | Return requests, reasons, refund amounts (Amazon) |

    | `target_returns` | Target Returns | Return requests, reasons, refund amounts (Target) |

    | `amazon_fee_preview` | Amazon Fee Preview | Estimated FBA/referral fees before settlement |

    | `walmart_lookup` | Walmart ASIN↔SKU | Cross-reference table: Walmart item ID ↔ ASIN ↔ SKU |

    | `target_tcin_mapping` | Target TCIN Mapping | Cross-reference table: Target TCIN ↔ internal SKU |

    ---'
  raw_lines:
  - '| Table Key | Source Label | Purpose |'
  - '|-----------|--------------|---------|'
  - '| `shopify_oms` | Shopify      | D2C orders, fulfillment, inventory |'
  - '| `amazon_oms` | Amazon OMS   | Amazon order-level data |'
  - '| `walmart_oms` | Walmart OMS  | Walmart order-level data |'
  - '| `amazon_settlement` | Amazon Settlement (US/UK/MX/CA) | Revenue, fees, reimbursements per marketplace country |'
  - '| `walmart_settlement` | Walmart Settlement | Walmart payouts and fee breakdown |'
  - '| `target_settlement` | Target Settlement | Target payouts and fee breakdown |'
  - '| `target_sales` | Target Sales | Target sell-through and sales performance |'
  - '| `amazon_returns` | Amazon Returns | Return requests, reasons, refund amounts (Amazon) |'
  - '| `target_returns` | Target Returns | Return requests, reasons, refund amounts (Target) |'
  - '| `amazon_fee_preview` | Amazon Fee Preview | Estimated FBA/referral fees before settlement |'
  - '| `walmart_lookup` | Walmart ASIN↔SKU | Cross-reference table: Walmart item ID ↔ ASIN ↔ SKU |'
  - '| `target_tcin_mapping` | Target TCIN Mapping | Cross-reference table: Target TCIN ↔ internal SKU |'
  - '---'
  row_count: 12
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.01_shopifyoms
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L25
  row_key: '`shopify_oms`'
  columns:
    table_key: '`shopify_oms`'
    source_label: Shopify
    purpose: D2C orders, fulfillment, inventory
  raw_text: '| `shopify_oms` | Shopify      | D2C orders, fulfillment, inventory |'
  summary: '`shopify_oms`: table_key=`shopify_oms`; source_label=Shopify; purpose=D2C orders, fulfillment, inventory'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.02_amazonoms
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L26
  row_key: '`amazon_oms`'
  columns:
    table_key: '`amazon_oms`'
    source_label: Amazon OMS
    purpose: Amazon order-level data
  raw_text: '| `amazon_oms` | Amazon OMS   | Amazon order-level data |'
  summary: '`amazon_oms`: table_key=`amazon_oms`; source_label=Amazon OMS; purpose=Amazon order-level data'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.03_walmartoms
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L27
  row_key: '`walmart_oms`'
  columns:
    table_key: '`walmart_oms`'
    source_label: Walmart OMS
    purpose: Walmart order-level data
  raw_text: '| `walmart_oms` | Walmart OMS  | Walmart order-level data |'
  summary: '`walmart_oms`: table_key=`walmart_oms`; source_label=Walmart OMS; purpose=Walmart order-level data'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L28
  row_key: '`amazon_settlement`'
  columns:
    table_key: '`amazon_settlement`'
    source_label: Amazon Settlement (US/UK/MX/CA)
    purpose: Revenue, fees, reimbursements per marketplace country
  raw_text: '| `amazon_settlement` | Amazon Settlement (US/UK/MX/CA) | Revenue, fees, reimbursements per marketplace country
    |'
  summary: '`amazon_settlement`: table_key=`amazon_settlement`; source_label=Amazon Settlement (US/UK/MX/CA); purpose=Revenue,
    fees, reimbursements per marketplace country'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.05_walmartsettlement
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L29
  row_key: '`walmart_settlement`'
  columns:
    table_key: '`walmart_settlement`'
    source_label: Walmart Settlement
    purpose: Walmart payouts and fee breakdown
  raw_text: '| `walmart_settlement` | Walmart Settlement | Walmart payouts and fee breakdown |'
  summary: '`walmart_settlement`: table_key=`walmart_settlement`; source_label=Walmart Settlement; purpose=Walmart payouts
    and fee breakdown'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.06_targetsettlement
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L30
  row_key: '`target_settlement`'
  columns:
    table_key: '`target_settlement`'
    source_label: Target Settlement
    purpose: Target payouts and fee breakdown
  raw_text: '| `target_settlement` | Target Settlement | Target payouts and fee breakdown |'
  summary: '`target_settlement`: table_key=`target_settlement`; source_label=Target Settlement; purpose=Target payouts and
    fee breakdown'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.07_targetsales
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L31
  row_key: '`target_sales`'
  columns:
    table_key: '`target_sales`'
    source_label: Target Sales
    purpose: Target sell-through and sales performance
  raw_text: '| `target_sales` | Target Sales | Target sell-through and sales performance |'
  summary: '`target_sales`: table_key=`target_sales`; source_label=Target Sales; purpose=Target sell-through and sales performance'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.08_amazonreturns
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L32
  row_key: '`amazon_returns`'
  columns:
    table_key: '`amazon_returns`'
    source_label: Amazon Returns
    purpose: Return requests, reasons, refund amounts (Amazon)
  raw_text: '| `amazon_returns` | Amazon Returns | Return requests, reasons, refund amounts (Amazon) |'
  summary: '`amazon_returns`: table_key=`amazon_returns`; source_label=Amazon Returns; purpose=Return requests, reasons, refund
    amounts (Amazon)'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.09_targetreturns
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L33
  row_key: '`target_returns`'
  columns:
    table_key: '`target_returns`'
    source_label: Target Returns
    purpose: Return requests, reasons, refund amounts (Target)
  raw_text: '| `target_returns` | Target Returns | Return requests, reasons, refund amounts (Target) |'
  summary: '`target_returns`: table_key=`target_returns`; source_label=Target Returns; purpose=Return requests, reasons, refund
    amounts (Target)'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.10_amazonfeepreview
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L34
  row_key: '`amazon_fee_preview`'
  columns:
    table_key: '`amazon_fee_preview`'
    source_label: Amazon Fee Preview
    purpose: Estimated FBA/referral fees before settlement
  raw_text: '| `amazon_fee_preview` | Amazon Fee Preview | Estimated FBA/referral fees before settlement |'
  summary: '`amazon_fee_preview`: table_key=`amazon_fee_preview`; source_label=Amazon Fee Preview; purpose=Estimated FBA/referral
    fees before settlement'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.11_walmartlookup
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L35
  row_key: '`walmart_lookup`'
  columns:
    table_key: '`walmart_lookup`'
    source_label: Walmart ASIN↔SKU
    purpose: 'Cross-reference table: Walmart item ID ↔ ASIN ↔ SKU'
  raw_text: '| `walmart_lookup` | Walmart ASIN↔SKU | Cross-reference table: Walmart item ID ↔ ASIN ↔ SKU |'
  summary: '`walmart_lookup`: table_key=`walmart_lookup`; source_label=Walmart ASIN↔SKU; purpose=Cross-reference table: Walmart
    item ID ↔ ASIN ↔ SKU'
  confidence: high
- id: ev.folkhomes_global.docx.row.04_data_sources_table_registry.12_targettcinmapping
  source_document: Folkhomes Global.docx
  source_section: Data Sources & Table Registry
  evidence_type: configured_source_row
  source_line: L36
  row_key: '`target_tcin_mapping`'
  columns:
    table_key: '`target_tcin_mapping`'
    source_label: Target TCIN Mapping
    purpose: 'Cross-reference table: Target TCIN ↔ internal SKU'
  raw_text: '| `target_tcin_mapping` | Target TCIN Mapping | Cross-reference table: Target TCIN ↔ internal SKU |'
  summary: '`target_tcin_mapping`: table_key=`target_tcin_mapping`; source_label=Target TCIN Mapping; purpose=Cross-reference
    table: Target TCIN ↔ internal SKU'
  confidence: high
- id: ev.folkhomes_global.docx.section.05_key_identifier_mappings
  source_document: Folkhomes Global.docx
  source_section: Key Identifier Mappings
  evidence_type: docx_section
  source_lines: L38-L46
  summary: '| Channel | Platform ID | Internal Mapping Table | Notes |

    |---------|-------------|------------------------|-------|

    | Amazon  | ASIN        | —                      | Common across US/UK/MX/CA |

    | Walmart | Item ID     | `walmart_lookup`       | Maps Walmart Item ID ↔ ASIN ↔ SKU |

    | Target  | TCIN        | `target_tcin_mapping`  | Maps TCIN ↔ internal SKU |

    | Shopify | SKU / Order ID | `shopify_oms`          | Native SKU-level data |

    > ⚠️ **Always join via mapping tables** when correlating Walmart or Target data with internal SKUs. Direct ASIN/TCIN ↔
    SKU matches without these tables will cause fan-out or missing rows.

    ---'
  raw_lines:
  - '| Channel | Platform ID | Internal Mapping Table | Notes |'
  - '|---------|-------------|------------------------|-------|'
  - '| Amazon  | ASIN        | —                      | Common across US/UK/MX/CA |'
  - '| Walmart | Item ID     | `walmart_lookup`       | Maps Walmart Item ID ↔ ASIN ↔ SKU |'
  - '| Target  | TCIN        | `target_tcin_mapping`  | Maps TCIN ↔ internal SKU |'
  - '| Shopify | SKU / Order ID | `shopify_oms`          | Native SKU-level data |'
  - '> ⚠️ **Always join via mapping tables** when correlating Walmart or Target data with internal SKUs. Direct ASIN/TCIN
    ↔ SKU matches without these tables will cause fan-out or missing rows.'
  - '---'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  source_document: Folkhomes Global.docx
  source_section: Key Identifier Mappings
  evidence_type: configured_source_row
  source_line: L41
  row_key: Amazon
  columns:
    channel: Amazon
    platform_id: ASIN
    internal_mapping_table: —
    notes: Common across US/UK/MX/CA
  raw_text: '| Amazon  | ASIN        | —                      | Common across US/UK/MX/CA |'
  summary: 'Amazon: channel=Amazon; platform_id=ASIN; internal_mapping_table=—; notes=Common across US/UK/MX/CA'
  confidence: high
- id: ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  source_document: Folkhomes Global.docx
  source_section: Key Identifier Mappings
  evidence_type: configured_source_row
  source_line: L42
  row_key: Walmart
  columns:
    channel: Walmart
    platform_id: Item ID
    internal_mapping_table: '`walmart_lookup`'
    notes: Maps Walmart Item ID ↔ ASIN ↔ SKU
  raw_text: '| Walmart | Item ID     | `walmart_lookup`       | Maps Walmart Item ID ↔ ASIN ↔ SKU |'
  summary: 'Walmart: channel=Walmart; platform_id=Item ID; internal_mapping_table=`walmart_lookup`; notes=Maps Walmart Item
    ID ↔ ASIN ↔ SKU'
  confidence: high
- id: ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  source_document: Folkhomes Global.docx
  source_section: Key Identifier Mappings
  evidence_type: configured_source_row
  source_line: L43
  row_key: Target
  columns:
    channel: Target
    platform_id: TCIN
    internal_mapping_table: '`target_tcin_mapping`'
    notes: Maps TCIN ↔ internal SKU
  raw_text: '| Target  | TCIN        | `target_tcin_mapping`  | Maps TCIN ↔ internal SKU |'
  summary: 'Target: channel=Target; platform_id=TCIN; internal_mapping_table=`target_tcin_mapping`; notes=Maps TCIN ↔ internal
    SKU'
  confidence: high
- id: ev.folkhomes_global.docx.row.05_key_identifier_mappings.04_shopify
  source_document: Folkhomes Global.docx
  source_section: Key Identifier Mappings
  evidence_type: configured_source_row
  source_line: L44
  row_key: Shopify
  columns:
    channel: Shopify
    platform_id: SKU / Order ID
    internal_mapping_table: '`shopify_oms`'
    notes: Native SKU-level data
  raw_text: '| Shopify | SKU / Order ID | `shopify_oms`          | Native SKU-level data |'
  summary: 'Shopify: channel=Shopify; platform_id=SKU / Order ID; internal_mapping_table=`shopify_oms`; notes=Native SKU-level
    data'
  confidence: high
- id: ev.folkhomes_global.docx.section.06_settlement_structure
  source_document: Folkhomes Global.docx
  source_section: Settlement Structure
  evidence_type: docx_section
  source_lines: L47-L52
  summary: '* **Amazon:** Four separate settlement files by country — `US`, `UK`, `MX`, `CA`. Each contains revenue, FBA fees,
    referral fees, reimbursements, and adjustments. Use `amazon_fee_preview` for pre-settlement fee estimation.

    * **Walmart:** Single settlement file covering all US Walmart Marketplace transactions.

    * **Target:** Single settlement file; complement with `target_sales` for sell-through context and `target_returns` for
    return deductions.

    * **Shopify:** No separate settlement table — revenue derived directly from `shopify_oms`.

    ---'
  raw_lines:
  - '* **Amazon:** Four separate settlement files by country — `US`, `UK`, `MX`, `CA`. Each contains revenue, FBA fees, referral
    fees, reimbursements, and adjustments. Use `amazon_fee_preview` for pre-settlement fee estimation.'
  - '* **Walmart:** Single settlement file covering all US Walmart Marketplace transactions.'
  - '* **Target:** Single settlement file; complement with `target_sales` for sell-through context and `target_returns` for
    return deductions.'
  - '* **Shopify:** No separate settlement table — revenue derived directly from `shopify_oms`.'
  - '---'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.section.07_returns_coverage
  source_document: Folkhomes Global.docx
  source_section: Returns Coverage
  evidence_type: docx_section
  source_lines: L53-L59
  summary: '| Channel | Returns Table | Notes |

    |---------|---------------|-------|

    | Amazon  | `amazon_returns` | Includes return reason codes, refund amt |

    | Target  | `target_returns` | Includes return reason codes, refund amt |

    | Walmart | —             | Returns embedded in `walmart_settlement` |

    | Shopify | —             | Returns embedded in `shopify_oms` |'
  raw_lines:
  - '| Channel | Returns Table | Notes |'
  - '|---------|---------------|-------|'
  - '| Amazon  | `amazon_returns` | Includes return reason codes, refund amt |'
  - '| Target  | `target_returns` | Includes return reason codes, refund amt |'
  - '| Walmart | —             | Returns embedded in `walmart_settlement` |'
  - '| Shopify | —             | Returns embedded in `shopify_oms` |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  source_document: Folkhomes Global.docx
  source_section: Returns Coverage
  evidence_type: configured_source_row
  source_line: L56
  row_key: Amazon
  columns:
    channel: Amazon
    returns_table: '`amazon_returns`'
    notes: Includes return reason codes, refund amt
  raw_text: '| Amazon  | `amazon_returns` | Includes return reason codes, refund amt |'
  summary: 'Amazon: channel=Amazon; returns_table=`amazon_returns`; notes=Includes return reason codes, refund amt'
  confidence: high
- id: ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  source_document: Folkhomes Global.docx
  source_section: Returns Coverage
  evidence_type: configured_source_row
  source_line: L57
  row_key: Target
  columns:
    channel: Target
    returns_table: '`target_returns`'
    notes: Includes return reason codes, refund amt
  raw_text: '| Target  | `target_returns` | Includes return reason codes, refund amt |'
  summary: 'Target: channel=Target; returns_table=`target_returns`; notes=Includes return reason codes, refund amt'
  confidence: high
- id: ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  source_document: Folkhomes Global.docx
  source_section: Returns Coverage
  evidence_type: configured_source_row
  source_line: L58
  row_key: Walmart
  columns:
    channel: Walmart
    returns_table: —
    notes: Returns embedded in `walmart_settlement`
  raw_text: '| Walmart | —             | Returns embedded in `walmart_settlement` |'
  summary: 'Walmart: channel=Walmart; returns_table=—; notes=Returns embedded in `walmart_settlement`'
  confidence: high
- id: ev.folkhomes_global.docx.row.07_returns_coverage.04_shopify
  source_document: Folkhomes Global.docx
  source_section: Returns Coverage
  evidence_type: configured_source_row
  source_line: L59
  row_key: Shopify
  columns:
    channel: Shopify
    returns_table: —
    notes: Returns embedded in `shopify_oms`
  raw_text: '| Shopify | —             | Returns embedded in `shopify_oms` |'
  summary: 'Shopify: channel=Shopify; returns_table=—; notes=Returns embedded in `shopify_oms`'
  confidence: high
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.folkhomes_global
  canonical_id: tenant.folkhomes_global
  name: Folkhomes Global
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  evidence_refs:
  - ev.folkhomes_global.docx.section.02_identity
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.01_shopify
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.04_shopify
  - ev.folkhomes_global.docx.row.07_returns_coverage.04_shopify
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.01_shopifyoms
  description: Omnichannel international retail client using ZenStatement for Shopify D2C order analytics, multi-country marketplace
    settlement, returns, fee-preview, and SKU mapping reasoning.
  fields:
    tenant_name: Folkhomes Global
    tenant_code: FOLKHOMES
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.folkhomes_global.mensa_brands
  canonical_id: group.folkhomes_global.mensa_brands
  name: Mensa Brands
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  evidence_refs:
  - ev.folkhomes_global.docx.section.02_identity
  fields:
    tenant_id: tenant.folkhomes_global
    group_name: Mensa Brands
    group_code: MENSA_BRANDS
    group_type: operational_unit
    business_meaning: Mensa Brands operating scope for Folkhomes Global across Shopify, Amazon Seller Central, Walmart Marketplace,
      and Target Plus/Supplier channels.
    country_or_region: US primary; UK, Mexico, and Canada marketplace contexts
    default_currency: USD
    currency_scope:
    - USD
    - GBP
    - MXN
    - CAD
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    runtime_scope_policy: group_id and group_level_id are represented in Account Data Binding scope_keys; generic platform/domain
      cards remain reusable.
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.folkhomes.shopify_us.primary
  canonical_id: platform_account.folkhomes.shopify_us.primary
  name: Folkhomes Shopify US D2C Store
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.01_shopify
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.04_shopify
  - ev.folkhomes_global.docx.row.07_returns_coverage.04_shopify
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.01_shopifyoms
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Folkhomes Shopify US D2C Store
    account_type: d2c_store_account
    account_role: d2c_order_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: US
    currency_scope:
    - USD
    configured_data_types:
    - Shopify OMS
    source_config_text: 'Shopify US | Settlement Source: Shopify OMS'
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shopify
        source_documents:
        - shopify_d2c_oms_v2.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shopify.in_and_global.d2c_oms_client_config
        source_documents:
        - shopify_d2c_oms_v2.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.us_d2c
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.folkhomes.amazon_us.primary
  canonical_id: platform_account.folkhomes.amazon_us.primary
  name: Folkhomes Amazon US Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.02_amazonoms
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Folkhomes Amazon US Seller Account
    account_type: marketplace_seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: US
    currency_scope:
    - USD
    configured_data_types:
    - Amazon OMS
    - Amazon settlement
    - Amazon returns
    - Amazon fee preview
    source_config_text: Amazon US | amazon_settlement; data sources include amazon_oms, amazon_returns, amazon_fee_preview
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.us
      to: platform_context.amazon.international
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.folkhomes.amazon_uk.primary
  canonical_id: platform_account.folkhomes.amazon_uk.primary
  name: Folkhomes Amazon UK Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Folkhomes Amazon UK Seller Account
    account_type: marketplace_seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: UK
    currency_scope:
    - GBP
    configured_data_types:
    - Amazon settlement
    source_config_text: Amazon UK | amazon_settlement
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.uk
      to: platform_context.amazon.international
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.folkhomes.amazon_mx.primary
  canonical_id: platform_account.folkhomes.amazon_mx.primary
  name: Folkhomes Amazon Mexico Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Folkhomes Amazon Mexico Seller Account
    account_type: marketplace_seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: Mexico
    currency_scope:
    - MXN
    configured_data_types:
    - Amazon settlement
    source_config_text: Amazon MX | amazon_settlement
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.mx
      to: platform_context.amazon.international
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.folkhomes.amazon_ca.primary
  canonical_id: platform_account.folkhomes.amazon_ca.primary
  name: Folkhomes Amazon Canada Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Folkhomes Amazon Canada Seller Account
    account_type: marketplace_seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: Canada
    currency_scope:
    - CAD
    configured_data_types:
    - Amazon settlement
    source_config_text: Amazon CA | amazon_settlement
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.ca
      to: platform_context.amazon.international
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.folkhomes.walmart_us.primary
  canonical_id: platform_account.folkhomes.walmart_us.primary
  name: Folkhomes Walmart US Marketplace Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  - ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  - ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.11_walmartlookup
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.walmart
    platform_context_id: platform_context.walmart.us
    account_name: Folkhomes Walmart US Marketplace Account
    account_type: marketplace_seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: US
    currency_scope:
    - USD
    configured_data_types:
    - Walmart OMS
    - Walmart settlement
    - Walmart lookup
    source_config_text: Walmart US | walmart_settlement; walmart_lookup maps Walmart Item ID ↔ ASIN ↔ SKU
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.walmart
        source_documents:
        - walmart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.walmart.us
        source_documents:
        - walmart_marketplace.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.folkhomes.target_plus_us.primary
  canonical_id: platform_account.folkhomes.target_plus_us.primary
  name: Folkhomes Target Plus US Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.06_targetsettlement
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    platform_id: platform.target_plus
    platform_context_id: platform_context.target_plus.us
    account_name: Folkhomes Target Plus US Account
    account_type: marketplace_seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 8
      group_level_id: 123
      group_name: Mensa Brands
    country_or_region: US
    currency_scope:
    - USD
    configured_data_types:
    - Target settlement
    - Target sales
    - Target returns
    - Target TCIN mapping
    source_config_text: Target US | target_settlement, target_sales, target_returns, target_tcin_mapping
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.target_plus
        source_documents:
        - target_plus.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.target_plus.us
        source_documents:
        - target_plus.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
  canonical_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
  name: account data binding / folkhomes / shopify us / primary / shopify oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.04_shopify
  - ev.folkhomes_global.docx.row.07_returns_coverage.04_shopify
  - ev.folkhomes_global.docx.row.03_active_sales_channels.01_shopify
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.01_shopifyoms
  fields:
    platform_account_id: platform_account.folkhomes.shopify_us.primary
    table_id: table.zs_observe.shopify_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - shopify_d2c_oms
    source_config_text: 'Shopify US | Settlement Source: Shopify OMS'
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_oms
      source_documents:
      - logistics_domain.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_oms
  canonical_id: account_data_binding.folkhomes.amazon_us.primary.amazon_oms
  name: account data binding / folkhomes / amazon us / primary / amazon oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.02_amazonoms
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  fields:
    platform_account_id: platform_account.folkhomes.amazon_us.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: US
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_order_oms
    source_config_text: Amazon US | amazon_settlement; data sources include amazon_oms, amazon_returns, amazon_fee_preview
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_oms
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
  canonical_id: account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
  name: account data binding / folkhomes / amazon us / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    platform_account_id: platform_account.folkhomes.amazon_us.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: US
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_settlement
    source_config_text: Amazon US | amazon_settlement; data sources include amazon_oms, amazon_returns, amazon_fee_preview
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_returns
  canonical_id: account_data_binding.folkhomes.amazon_us.primary.amazon_returns
  name: account data binding / folkhomes / amazon us / primary / amazon returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.08_amazonreturns
  fields:
    platform_account_id: platform_account.folkhomes.amazon_us.primary
    table_id: table.zs_observe.amazon_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: US
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_returns
    source_config_text: Amazon US | amazon_settlement; data sources include amazon_oms, amazon_returns, amazon_fee_preview
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_returns
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
  canonical_id: account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
  name: account data binding / folkhomes / amazon us / primary / amazon fee preview
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.10_amazonfeepreview
  fields:
    platform_account_id: platform_account.folkhomes.amazon_us.primary
    table_id: table.zs_observe.amazon_fee_preview
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: US
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_fee_preview
    source_config_text: Amazon US | amazon_settlement; data sources include amazon_oms, amazon_returns, amazon_fee_preview
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_fee_preview
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  canonical_id: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  name: account data binding / folkhomes / amazon uk / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    platform_account_id: platform_account.folkhomes.amazon_uk.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: GBP
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: UK
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_uk_settlement
    source_config_text: Amazon UK | amazon_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
  canonical_id: account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
  name: account data binding / folkhomes / amazon mx / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    platform_account_id: platform_account.folkhomes.amazon_mx.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: MXN
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: Mexico
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_mexico_settlement
    source_config_text: Amazon MX | amazon_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
  canonical_id: account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
  name: account data binding / folkhomes / amazon ca / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.04_amazonsettlement
  fields:
    platform_account_id: platform_account.folkhomes.amazon_ca.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: CAD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    - business_key: marketplace_country_hint
      column_candidates:
      - marketplace_country
      - country
      - marketplace
      - currency_type
      operator: semantic_filter
      value: Canada
      data_type: string
      scope_note: Country/marketplace disambiguation hint; use the available country or currency column in the physical table.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_canada_settlement
    source_config_text: Amazon CA | amazon_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
  canonical_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
  name: account data binding / folkhomes / walmart us / primary / walmart oms
  status: active
  active: true
  confidence: source_confirmed
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  - ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  - ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.03_walmartoms
  fields:
    platform_account_id: platform_account.folkhomes.walmart_us.primary
    table_id: table.zs_observe.walmart_oms
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - walmart_oms
    source_config_text: Walmart US | walmart_settlement; walmart_lookup maps Walmart Item ID ↔ ASIN ↔ SKU
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.walmart_oms
      source_documents:
      - walmart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Walmart OMS, but no canonical Walmart table card is available in the current uploaded KB.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
  canonical_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
  name: account data binding / folkhomes / walmart us / primary / walmart settlement
  status: active
  active: true
  confidence: source_confirmed
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  - ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.05_walmartsettlement
  fields:
    platform_account_id: platform_account.folkhomes.walmart_us.primary
    table_id: table.zs_observe.walmart_settlement
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - walmart_settlement
    source_config_text: Walmart US | walmart_settlement; walmart_lookup maps Walmart Item ID ↔ ASIN ↔ SKU
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.walmart_settlement
      source_documents:
      - walmart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Walmart settlement, but no canonical Walmart table card is available in the current uploaded KB.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
  canonical_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
  name: account data binding / folkhomes / walmart us / primary / walmart lookup
  status: active
  active: true
  confidence: source_confirmed
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  - ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.11_walmartlookup
  - ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  fields:
    platform_account_id: platform_account.folkhomes.walmart_us.primary
    table_id: table.zs_observe.walmart_lookup
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - walmart_item_id_asin_sku_lookup
    source_config_text: Walmart US | walmart_settlement; walmart_lookup maps Walmart Item ID ↔ ASIN ↔ SKU
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.walmart_lookup
      source_documents:
      - walmart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source requires Walmart lookup for Item ID ↔ ASIN ↔ SKU mapping; canonical table card is not available yet.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.target_plus_us.primary.target_settlement
  canonical_id: account_data_binding.folkhomes.target_plus_us.primary.target_settlement
  name: account data binding / folkhomes / target plus us / primary / target settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.06_targetsettlement
  fields:
    platform_account_id: platform_account.folkhomes.target_plus_us.primary
    table_id: table.zs_observe.target_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - target_plus_settlement
    source_config_text: Target US | target_settlement, target_sales, target_returns, target_tcin_mapping
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.target_settlement
      source_documents:
      - target_plus.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.target_plus_us.primary.target_sales
  canonical_id: account_data_binding.folkhomes.target_plus_us.primary.target_sales
  name: account data binding / folkhomes / target plus us / primary / target sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.07_targetsales
  fields:
    platform_account_id: platform_account.folkhomes.target_plus_us.primary
    table_id: table.zs_observe.target_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - target_plus_sales
    source_config_text: Target US | target_settlement, target_sales, target_returns, target_tcin_mapping
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.target_sales
      source_documents:
      - target_plus.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.target_plus_us.primary.target_returns
  canonical_id: account_data_binding.folkhomes.target_plus_us.primary.target_returns
  name: account data binding / folkhomes / target plus us / primary / target returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.09_targetreturns
  fields:
    platform_account_id: platform_account.folkhomes.target_plus_us.primary
    table_id: table.zs_observe.target_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: USD
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - target_plus_returns
    source_config_text: Target US | target_settlement, target_sales, target_returns, target_tcin_mapping
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.target_returns
      source_documents:
      - target_plus.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
  canonical_id: account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
  name: account data binding / folkhomes / target plus us / primary / target tcin mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.12_targettcinmapping
  fields:
    platform_account_id: platform_account.folkhomes.target_plus_us.primary
    table_id: table.zs_observe.target_tcin_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 8
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 123
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - target_tcin_to_internal_sku_mapping
    source_config_text: Target US | target_settlement, target_sales, target_returns, target_tcin_mapping
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.target_tcin_mapping
      source_documents:
      - target_plus.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.folkhomes_global.shopify_d2c
  canonical_id: business_scope_set.folkhomes_global.shopify_d2c
  name: Folkhomes Shopify D2C
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.04_data_sources_table_registry
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.01_shopify
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.04_shopify
  - ev.folkhomes_global.docx.row.07_returns_coverage.04_shopify
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.01_shopifyoms
  description: Shopify US OMS-only D2C scope.
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    scope_name: Folkhomes Shopify D2C
    scope_type: d2c_order_scope
    platform_account_ids:
    - platform_account.folkhomes.shopify_us.primary
    platform_ids:
    - platform.shopify
    platform_context_ids:
    - platform_context.shopify.in_and_global.d2c_oms_client_config
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.us_d2c
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.folkhomes_global.amazon_multicountry
  canonical_id: business_scope_set.folkhomes_global.amazon_multicountry
  name: Folkhomes Amazon Multi-country
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.02_amazonoms
  description: Amazon Seller Central scope across US, UK, Mexico, and Canada.
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    scope_name: Folkhomes Amazon Multi-country
    scope_type: marketplace_account_group
    platform_account_ids:
    - platform_account.folkhomes.amazon_us.primary
    - platform_account.folkhomes.amazon_uk.primary
    - platform_account.folkhomes.amazon_mx.primary
    - platform_account.folkhomes.amazon_ca.primary
    platform_ids:
    - platform.amazon
    platform_context_ids:
    - platform_context.amazon.international
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.amazon.us
      to: platform_context.amazon.international
    - kind: canonical_id
      from: platform_context.amazon.uk
      to: platform_context.amazon.international
    - kind: canonical_id
      from: platform_context.amazon.mx
      to: platform_context.amazon.international
    - kind: canonical_id
      from: platform_context.amazon.ca
      to: platform_context.amazon.international
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.folkhomes_global.target_plus_us
  canonical_id: business_scope_set.folkhomes_global.target_plus_us
  name: Folkhomes Target Plus US
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.06_targetsettlement
  description: Target Plus settlement, sales, returns, and TCIN mapping scope.
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    scope_name: Folkhomes Target Plus US
    scope_type: marketplace_account_group
    platform_account_ids:
    - platform_account.folkhomes.target_plus_us.primary
    platform_ids:
    - platform.target_plus
    platform_context_ids:
    - platform_context.target_plus.us
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.folkhomes_global.walmart_pending_context
  canonical_id: business_scope_set.folkhomes_global.walmart_pending_context
  name: Folkhomes Walmart Pending Context
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  - ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.03_walmartoms
  description: Walmart US source scope requiring canonical platform/table context before active use.
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    scope_name: Folkhomes Walmart Pending Context
    scope_type: source_confirmed_requires_context
    platform_account_ids:
    - platform_account.folkhomes.walmart_us.primary
    platform_ids:
    - platform.walmart
    platform_context_ids:
    - platform_context.walmart.us
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  canonical_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  name: Folkhomes Amazon Multi-country Settlement
  status: active
  active: true
  confidence: high
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.02_amazon
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.01_amazon
  - ev.folkhomes_global.docx.row.07_returns_coverage.01_amazon
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.02_amazonoms
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    binding_name: Folkhomes Amazon Multi-country Settlement
    binding_type: marketplace_settlement_flow
    business_scope_set_id: business_scope_set.folkhomes_global.amazon_multicountry
    money_flow_paths:
    - marketplace_settlement_analysis
    participating_accounts:
    - platform_account_id: platform_account.folkhomes.amazon_us.primary
      role: amazon_us_settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.amazon_uk.primary
      role: amazon_uk_settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.amazon_mx.primary
      role: amazon_mx_settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.amazon_ca.primary
      role: amazon_ca_settlement_source
      required: true
    evidence_table_ids:
    - table.zs_observe.amazon_settlement
    account_data_binding_ids:
    - account_data_binding.folkhomes.amazon_us.primary.amazon_oms
    - account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
    - account_data_binding.folkhomes.amazon_us.primary.amazon_returns
    - account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
    - account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
    - account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
    - account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.marketplace_settlement_payout
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.amazon_settlement
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  canonical_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  name: Folkhomes Target Sales, Returns and Settlement
  status: active
  active: true
  confidence: high
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.04_target
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.03_target
  - ev.folkhomes_global.docx.row.07_returns_coverage.02_target
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.06_targetsettlement
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    binding_name: Folkhomes Target Sales, Returns and Settlement
    binding_type: marketplace_reconciliation_flow
    business_scope_set_id: business_scope_set.folkhomes_global.target_plus_us
    money_flow_paths:
    - target_sales_to_settlement
    - target_returns_to_settlement
    - tcin_to_sku_mapping
    participating_accounts:
    - platform_account_id: platform_account.folkhomes.target_plus_us.primary
      role: target_sales_returns_settlement_source
      required: true
    evidence_table_ids:
    - table.zs_observe.target_sales
    - table.zs_observe.target_returns
    - table.zs_observe.target_settlement
    - table.zs_observe.target_tcin_mapping
    account_data_binding_ids:
    - account_data_binding.folkhomes.target_plus_us.primary.target_settlement
    - account_data_binding.folkhomes.target_plus_us.primary.target_sales
    - account_data_binding.folkhomes.target_plus_us.primary.target_returns
    - account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.marketplace_order_to_settlement
    - business_process.marketplace_return_refund
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.target_sales_settlement_returns
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  canonical_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  name: Folkhomes Walmart Requires Platform Context
  status: draft
  active: false
  confidence: medium
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - walmart_marketplace.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.03_active_sales_channels
  - ev.folkhomes_global.docx.row.03_active_sales_channels.03_walmart
  - ev.folkhomes_global.docx.row.05_key_identifier_mappings.02_walmart
  - ev.folkhomes_global.docx.row.07_returns_coverage.03_walmart
  - ev.folkhomes_global.docx.row.04_data_sources_table_registry.03_walmartoms
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    binding_name: Folkhomes Walmart Requires Platform Context
    binding_type: marketplace_reconciliation_flow
    business_scope_set_id: business_scope_set.folkhomes_global.walmart_pending_context
    money_flow_paths:
    - walmart_order_to_settlement
    - walmart_lookup_mapping
    participating_accounts:
    - platform_account_id: platform_account.folkhomes.walmart_us.primary
      role: walmart_source_requires_context
      required: true
    evidence_table_ids:
    - table.zs_observe.walmart_oms
    - table.zs_observe.walmart_settlement
    - table.zs_observe.walmart_lookup
    account_data_binding_ids:
    - account_data_binding.folkhomes.walmart_us.primary.walmart_oms
    - account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
    - account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.marketplace_order_to_settlement
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.walmart_order_settlement
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  canonical_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  name: Folkhomes Marketplace Settlement to Bank Requires Bank Binding
  status: draft
  active: false
  confidence: medium
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Folkhomes Global.docx
  - amazon_marketplace.md
  - target_plus.md
  evidence_refs:
  - ev.folkhomes_global.docx.section.02_identity
  fields:
    tenant_id: tenant.folkhomes_global
    group_id: group.folkhomes_global.mensa_brands
    binding_name: Folkhomes Marketplace Settlement to Bank Requires Bank Binding
    binding_type: money_flow
    business_scope_set_id: business_scope_set.folkhomes_global.amazon_multicountry
    money_flow_paths:
    - marketplace_to_bank
    participating_accounts:
    - platform_account_id: platform_account.folkhomes.amazon_us.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.amazon_uk.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.amazon_mx.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.amazon_ca.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.folkhomes.target_plus_us.primary
      role: settlement_source
      required: false
    evidence_table_ids:
    - table.zs_observe.amazon_settlement
    - table.zs_observe.target_settlement
    account_data_binding_ids:
    - account_data_binding.folkhomes.amazon_us.primary.amazon_oms
    - account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
    - account_data_binding.folkhomes.amazon_us.primary.amazon_returns
    - account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
    - account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
    - account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
    - account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
    - account_data_binding.folkhomes.target_plus_us.primary.target_settlement
    - account_data_binding.folkhomes.target_plus_us.primary.target_sales
    - account_data_binding.folkhomes.target_plus_us.primary.target_returns
    - account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.marketplace_payout_to_bank
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.marketplace_settlement_to_bank
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Marketplace settlement evidence exists; bank account and bank-statement binding were not supplied in the client reference.
    original_bad_state_status:
      status: draft
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- platform_account_id: platform_account.folkhomes.shopify_us.primary
  client_config_text: 'Shopify US: Shopify OMS only; no separate Shopify settlement table'
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.shopify_oms
  unresolved_canonical_requested: []
- platform_account_id: platform_account.folkhomes.amazon_us.primary
  client_config_text: 'Amazon US: amazon_oms, amazon_settlement, amazon_returns, amazon_fee_preview'
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_returns
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
- platform_account_id: platform_account.folkhomes.amazon_uk.primary
  client_config_text: Amazon UK settlement
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
- platform_account_id: platform_account.folkhomes.amazon_mx.primary
  client_config_text: Amazon Mexico settlement
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
- platform_account_id: platform_account.folkhomes.amazon_ca.primary
  client_config_text: Amazon Canada settlement
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
- platform_account_id: platform_account.folkhomes.walmart_us.primary
  client_config_text: Walmart OMS, settlement, and lookup table
  source_confirmed_requires_context:
  - walmart_oms
  - walmart_settlement
  - walmart_lookup
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.walmart_oms
  - table.zs_observe.walmart_settlement
  - table.zs_observe.walmart_lookup
  unresolved_canonical_requested: []
- platform_account_id: platform_account.folkhomes.target_plus_us.primary
  client_config_text: Target settlement, sales, returns, TCIN mapping
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.target_settlement
  - table.zs_observe.target_sales
  - table.zs_observe.target_returns
  - table.zs_observe.target_tcin_mapping
  unresolved_canonical_requested: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.folkhomes_global.hasgroup.96b47f9ee615
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.folkhomes_global
  target_card_id: group.folkhomes_global.mensa_brands
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_GROUP
- edge_id: edge.folkhomes_global.hasplatformaccount.8642a8dec8fe
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.shopify_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.99167779f422
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.shopify_us.primary
  target_card_id: platform.shopify
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.9a2a860cfaef
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.shopify_us.primary
  target_card_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.30f80a9a6232
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.shopify_us.primary
  target_card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.3d548d9ebae4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
  target_card_id: table.zs_observe.shopify_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasplatformaccount.7b69cccbe515
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.amazon_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.cacdae9b0b52
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.amazon_us.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.16e13fc16a9b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.amazon_us.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.97966debaf60
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_us.primary
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.a6cc62a4e491
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_oms
  target_card_id: table.zs_observe.amazon_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.a4e99e4b61e5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_us.primary
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.7bc65d5bde82
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.97fe47fe4a39
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_us.primary
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.d22b6a5efcaf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_returns
  target_card_id: table.zs_observe.amazon_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.1fd688323b13
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_us.primary
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.547046d550c6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
  target_card_id: table.zs_observe.amazon_fee_preview
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasplatformaccount.cdf83c2d26f7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.amazon_uk.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.f6fa2166d92a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.amazon_uk.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.0ba89b97dd5a
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.amazon_uk.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.cf7468e1cd0b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_uk.primary
  target_card_id: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.d71763ed07a6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasplatformaccount.60e2f01ea7b4
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.amazon_mx.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.ae8a1e97aa4d
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.amazon_mx.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.cecda186f35b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.amazon_mx.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.aa7853547985
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_mx.primary
  target_card_id: account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.ed5204d31a14
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasplatformaccount.da7f416ba932
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.amazon_ca.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.9b6d12a1da17
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.amazon_ca.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.0b61b36d2c2d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.amazon_ca.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.452f3721cf94
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.amazon_ca.primary
  target_card_id: account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.81ca7949d6c1
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasplatformaccount.89bdb99cd3a7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.walmart_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.635a347d29a2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.walmart_us.primary
  target_card_id: platform.walmart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.9c16db3a63ee
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.walmart_us.primary
  target_card_id: platform_context.walmart.us
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.c62862936b4e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.walmart_us.primary
  target_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.b703c79b5634
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
  target_card_id: table.zs_observe.walmart_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.a1c78ab2cf2f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.walmart_us.primary
  target_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.9be2d21cbbac
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
  target_card_id: table.zs_observe.walmart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.a5b13a0fd564
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.walmart_us.primary
  target_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.c9f344de8d8e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
  target_card_id: table.zs_observe.walmart_lookup
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasplatformaccount.d887de1955c1
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: platform_account.folkhomes.target_plus_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.usesplatform.e01b55a6b17c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.folkhomes.target_plus_us.primary
  target_card_id: platform.target_plus
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.folkhomes_global.usesplatformcontext.1f9616dc88ee
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.folkhomes.target_plus_us.primary
  target_card_id: platform_context.target_plus.us
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.folkhomes_global.hasaccountdatabinding.f903cce0bede
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.target_plus_us.primary
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.ca1b8d82ac00
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_settlement
  target_card_id: table.zs_observe.target_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.733afb9bd456
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.target_plus_us.primary
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.37525837f588
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_sales
  target_card_id: table.zs_observe.target_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.a38b282a281a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.target_plus_us.primary
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.6034d7c691c5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_returns
  target_card_id: table.zs_observe.target_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasaccountdatabinding.6839f69a79f0
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.folkhomes.target_plus_us.primary
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.bindstotable.fb59f9ee54ad
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
  target_card_id: table.zs_observe.target_tcin_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.folkhomes_global.hasbusinessscopeset.055a46c29555
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_scope_set.folkhomes_global.shopify_d2c
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.includesplatformaccount.7732a2a57d02
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.shopify_d2c
  target_card_id: platform_account.folkhomes.shopify_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.hasbusinessscopeset.6b74439dcf9c
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.includesplatformaccount.6334b280ba90
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  target_card_id: platform_account.folkhomes.amazon_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.includesplatformaccount.b1965c47039c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  target_card_id: platform_account.folkhomes.amazon_uk.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.includesplatformaccount.7659764fb3e8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  target_card_id: platform_account.folkhomes.amazon_mx.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.includesplatformaccount.9fb918d5ef9a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  target_card_id: platform_account.folkhomes.amazon_ca.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.hasbusinessscopeset.0441ca67de38
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_scope_set.folkhomes_global.target_plus_us
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.includesplatformaccount.68215aeee8e7
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.target_plus_us
  target_card_id: platform_account.folkhomes.target_plus_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.hasbusinessscopeset.8998ec36c68c
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_scope_set.folkhomes_global.walmart_pending_context
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.includesplatformaccount.3b25862da00d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.folkhomes_global.walmart_pending_context
  target_card_id: platform_account.folkhomes.walmart_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.folkhomes_global.hasbusinessflowbinding.3a64daa2eabc
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.folkhomes_global.usesbusinessscopeset.d930a75f3665
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.participateswithaccount.986460e98c82
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: platform_account.folkhomes.amazon_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.fccf3aec08bc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: platform_account.folkhomes.amazon_uk.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.acc0ac1396da
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: platform_account.folkhomes.amazon_mx.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.581dd063378c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: platform_account.folkhomes.amazon_ca.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.usesaccountdatabinding.cea6e37ea7ab
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.17948c279394
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.f33d555e50ff
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.90d29da60627
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.b2e883b15fcb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.49ee17ec5f75
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.94b19881fccd
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesevidencetable.ff0a471640ce
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.hasbusinessflowbinding.47baf0e292df
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.folkhomes_global.usesbusinessscopeset.8a72c5890b78
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: business_scope_set.folkhomes_global.target_plus_us
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.participateswithaccount.f354ef40bc16
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: platform_account.folkhomes.target_plus_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.usesaccountdatabinding.7d01885c6a1c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.7646caa6b9ed
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.03768f580aa2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.9a1f9f604d05
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesevidencetable.d24f7a65edfd
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: table.zs_observe.target_sales
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.usesevidencetable.c2fbdc0fcf8d
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: table.zs_observe.target_returns
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.usesevidencetable.6ebe2fed0e2d
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: table.zs_observe.target_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.usesevidencetable.c41073730b47
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.target_sales_returns_settlement
  target_card_id: table.zs_observe.target_tcin_mapping
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.hasbusinessflowbinding.f148086f2a08
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.folkhomes_global.usesbusinessscopeset.c21518ae0f87
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: business_scope_set.folkhomes_global.walmart_pending_context
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.participateswithaccount.9b632120bfcc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: platform_account.folkhomes.walmart_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.usesaccountdatabinding.84bcbf260212
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.ca12a5d3094e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.21b4f225af3a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesevidencetable.57f83f666946
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: table.zs_observe.walmart_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.usesevidencetable.242125d306c9
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: table.zs_observe.walmart_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.usesevidencetable.21b110aa07d6
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.walmart_requires_platform_context
  target_card_id: table.zs_observe.walmart_lookup
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.hasbusinessflowbinding.dd6e0e0e4783
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.folkhomes_global.mensa_brands
  target_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.folkhomes_global.usesbusinessscopeset.85f5b90316e9
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: business_scope_set.folkhomes_global.amazon_multicountry
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.folkhomes_global.participateswithaccount.aa08b2d4adc5
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: platform_account.folkhomes.amazon_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.5118a324840a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: platform_account.folkhomes.amazon_uk.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.7b47078ed6a2
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: platform_account.folkhomes.amazon_mx.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.e60a61c9ce61
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: platform_account.folkhomes.amazon_ca.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.participateswithaccount.da174fe6aaf1
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: platform_account.folkhomes.target_plus_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.folkhomes_global.usesaccountdatabinding.95985b91fbf4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.74f1bdff369b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.f76e69e11f2b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.2fc6a179211a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_us.primary.amazon_fee_preview
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.d15acdd3e74f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.43eb45756c3a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_mx.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.71ccfbdc466a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.amazon_ca.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.03335b05f6f9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.30980388590f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.929c2bbb6a67
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesaccountdatabinding.14c56f9272ce
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: account_data_binding.folkhomes.target_plus_us.primary.target_tcin_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.folkhomes_global.usesevidencetable.53b5b5eeb02f
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: table.zs_observe.amazon_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.folkhomes_global.usesevidencetable.919a6b8a4470
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  target_card_id: table.zs_observe.target_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges: []
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: Walmart Marketplace
  source_confirmed_artifacts:
  - walmart_oms
  - walmart_settlement
  - walmart_lookup
  source_evidence_text: Client registry lists Walmart OMS, Walmart Settlement, and walmart_lookup.
  impact: Walmart order/settlement/mapping flows remain review-required until Walmart platform context is authored.
  required_action: author_platform_context_or_confirm_table_schema_then_add_account_data_binding
  severity: high
  source_documents:
  - Folkhomes Global.docx
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- item: account_data_binding.folkhomes.amazon_uk.primary.amazon_settlement
  issue: Confirm country/currency disambiguation column for non-US Amazon settlement rows when multiple Amazon countries share
    the same physical table.
  severity: medium
  blocking_for_active_ingestion: false
  review_resolution_status: open
resolved_review_items:
- item: platform_account.folkhomes.walmart_us.primary
  issue: Walmart is source-confirmed but lacks canonical platform/table context in the current uploaded KB; bindings are inactive
    review-required records.
  severity: high
  blocking_for_active_ingestion: false
  review_resolution_status: resolved_by_current_refactor
  resolution_note: Walmart platform/context/table cards are now present in uploaded marketplace markdowns.
- item: platform_account.folkhomes.walmart_us.primary
  resolution: source_confirmed_requires_context now maps to uploaded canonical table card(s)
  resolved_table_ids:
  - table.zs_observe.walmart_oms
  - table.zs_observe.walmart_settlement
  - table.zs_observe.walmart_lookup
  previous_requires_context:
  - walmart_oms
  - walmart_settlement
  - walmart_lookup
non_blocking_declared_semantic_reference_gaps:
- reference_id: business_process.marketplace_order_to_settlement
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.target_sales_returns_settlement
  - business_flow_binding.folkhomes_global.walmart_requires_platform_context
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.marketplace_payout_to_bank
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.marketplace_return_refund
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.target_sales_returns_settlement
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.marketplace_settlement_payout
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.amazon_settlement
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.amazon_multicountry_settlement
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.marketplace_settlement_to_bank
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.marketplace_settlement_to_bank_requires_bank_binding
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.target_sales_settlement_returns
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.target_sales_returns_settlement
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.walmart_order_settlement
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.folkhomes_global.walmart_requires_platform_context
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 32
  refactored_card_count: 32
  original_edge_count: 117
  refactored_edge_count: 117
  blocked_edge_count: 0
  source_evidence_count: 31
  source_row_evidence_count: 24
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 7
    account_data_binding: 15
    business_scope_set: 4
    business_flow_binding: 4
  status_counts:
    active: 29
    draft: 3
  review_status_counts:
    accepted: 29
    review_required: 3
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 9
  canonical_resolution_gap_type_counts:
    business_process_ids: 5
    reconciliation_profile_ids: 4
  status_correction_count: 4
  status_changes:
  - card_id: platform_account.folkhomes.walmart_us.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_oms
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_settlement
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.folkhomes.walmart_us.primary.walmart_lookup
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  id_or_source_replacement_count: 12
  id_or_source_replacements:
  - card_id: platform_account.folkhomes.shopify_us.primary
    kind: canonical_id
    from: platform_context.shopify.us_d2c
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.folkhomes.shopify_us.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.folkhomes.amazon_us.primary
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: platform_account.folkhomes.amazon_uk.primary
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: platform_account.folkhomes.amazon_mx.primary
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: platform_account.folkhomes.amazon_ca.primary
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.shopify_d2c
    kind: canonical_id
    from: platform_context.shopify.us_d2c
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.us
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.uk
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.mx
    to: platform_context.amazon.international
  - card_id: business_scope_set.folkhomes_global.amazon_multicountry
    kind: canonical_id
    from: platform_context.amazon.ca
    to: platform_context.amazon.international
  resolved_prior_review_count: 2
  open_review_count: 1
  future_context_gap_count: 1
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 8
  non_blocking_declared_semantic_reference_gap_type_counts:
    business_process_ids: 4
    reconciliation_profile_ids: 4
  edge_status_counts:
    emitted: 117
```
