# Client Runtime Markdown Refactor — Batch 2 QA Index

This package contains parser-ready client runtime markdowns for Caelum Arpit Brand Technologies, Folkhomes Global, Fraternitas Ventures, Mensa Brand Technologies, and MPL India.

The refactor used the uploaded canonical marketplace/logistics/banking/payment/OMS/WMS markdowns, with `shopify_d2c_oms_v2.md` as the active Shopify source.

```yaml
batch_validation_summary:
  batch_id: client_runtime_refactor_batch2_v2_1
  generated_date: '2026-05-24'
  client_count: 5
  output_directory: /mnt/data/refactored_client_markdowns_batch2
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  active_shopify_canonical: shopify_d2c_oms_v2.md
  total_cards: 246
  total_emitted_edges: 848
  total_blocked_edges: 40
  total_source_evidence: 92
  total_row_evidence: 68
  total_open_reviews: 81
  total_resolved_reviews: 4
  yaml_parse_error_count: 0
  active_bindings_to_missing_tables: 0
  edge_reference_error_count: 0
  status_active_conflict_count: 0
  forbidden_candidate_card_count: 0
  client_outputs:
  - client_slug: caelum_arpit_brand_technologies
    client_name: Caelum Arpit Brand Technologies Private Limited
    output_markdown: caelum_arpit_brand_technologies_client_runtime_refactored.md
    cards: 17
    emitted_edges: 58
    blocked_edges: 0
    source_evidence: 5
    row_evidence: 3
    open_reviews: 2
    resolved_reviews: 0
    future_context_gaps: 0
    status_corrections: 0
    canonical_resolution_gaps: 9
    result: pass
  - client_slug: folkhomes_global
    client_name: Folkhomes Global
    output_markdown: folkhomes_global_client_runtime_refactored.md
    cards: 32
    emitted_edges: 117
    blocked_edges: 0
    source_evidence: 31
    row_evidence: 24
    open_reviews: 1
    resolved_reviews: 2
    future_context_gaps: 1
    status_corrections: 4
    canonical_resolution_gaps: 9
    result: pass
  - client_slug: fraternitas_ventures
    client_name: Fraternitas Ventures Private Limited
    output_markdown: fraternitas_ventures_client_runtime_refactored.md
    cards: 30
    emitted_edges: 92
    blocked_edges: 4
    source_evidence: 12
    row_evidence: 7
    open_reviews: 8
    resolved_reviews: 1
    future_context_gaps: 5
    status_corrections: 2
    canonical_resolution_gaps: 14
    result: pass
  - client_slug: mensa_business
    client_name: Mensa Brand Technologies Private Limited
    output_markdown: mensa_business_client_runtime_refactored.md
    cards: 117
    emitted_edges: 390
    blocked_edges: 18
    source_evidence: 20
    row_evidence: 16
    open_reviews: 42
    resolved_reviews: 1
    future_context_gaps: 18
    status_corrections: 36
    canonical_resolution_gaps: 43
    result: pass
  - client_slug: mpl_india
    client_name: Mpl India
    output_markdown: mpl_india_client_runtime_refactored.md
    cards: 50
    emitted_edges: 191
    blocked_edges: 18
    source_evidence: 24
    row_evidence: 18
    open_reviews: 28
    resolved_reviews: 0
    future_context_gaps: 17
    status_corrections: 5
    canonical_resolution_gaps: 38
    result: pass
  yaml_parse_errors: []
```

## Output Files

- `caelum_arpit_brand_technologies_client_runtime_refactored.md` — 17 cards, 58 emitted edges, 0 blocked edges, result `pass`.
- `folkhomes_global_client_runtime_refactored.md` — 32 cards, 117 emitted edges, 0 blocked edges, result `pass`.
- `fraternitas_ventures_client_runtime_refactored.md` — 30 cards, 92 emitted edges, 4 blocked edges, result `pass`.
- `mensa_business_client_runtime_refactored.md` — 117 cards, 390 emitted edges, 18 blocked edges, result `pass`.
- `mpl_india_client_runtime_refactored.md` — 50 cards, 191 emitted edges, 18 blocked edges, result `pass`.
