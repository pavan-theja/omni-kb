# Mpl India — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: mpl_india_client_runtime_cards_v2_1_refactored
  created_for: Mpl India
  created_on: '2026-05-24'
  version: v2_1_refactored
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - bank_statement.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  source_client_profile:
    business: India digital gaming / fantasy sports wallet platform with deposit, withdrawal, gateway, payout, and bank reconciliation
      flows.
    geography: India
    source_group_id: 2
    source_group_level_id: 2
    source_group_name: MPL
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy:
  - Create active bindings only for current canonical platform tables or explicit client-observed table evidence.
  - Represent source-confirmed artifacts without table context as review-required bindings or future context gaps, not active
    mappings.
  - Keep group_id and group_level_id in Account Data Binding scope_keys rather than generic platform/domain cards.
  - Create Business Flow Bindings only for reusable client/group-level cross-account flows.
  negative_scope_constraints:
  - No marketplaces
  - No logistics
  - No Shopify
  - No Unicommerce
  - Product-commerce order lifecycle cards should not be applied
  generated_date: '2026-05-24'
  client_slug: mpl_india
  source_json_bad_state: mpl_india.json
  source_docx: MPL India.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: mpl_india.json
  source_docx: MPL India.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.mpl_india.rbl_payin.primary
    kind: canonical_id
    from: platform_context.rbl_bank.in_payin
    to: platform_context.rbl_bank.in
  - card_id: platform_account.mpl_india.idfc_bank.primary
    kind: canonical_id
    from: platform.idfc_bank
    to: platform.idfc_first_bank
  - card_id: platform_account.mpl_india.idfc_bank.primary
    kind: canonical_id
    from: platform_context.idfc_bank.in
    to: platform_context.idfc_first_bank.in
  - card_id: business_scope_set.mpl_india.active_payin_sources
    kind: canonical_id
    from: platform_context.rbl_bank.in_payin
    to: platform_context.rbl_bank.in
  - card_id: business_scope_set.mpl_india.bank_reconciliation
    kind: canonical_id
    from: platform.idfc_bank
    to: platform.idfc_first_bank
  - card_id: business_scope_set.mpl_india.bank_reconciliation
    kind: canonical_id
    from: platform_context.idfc_bank.in
    to: platform_context.idfc_first_bank.in
  status_changes:
  - card_id: platform_account.mpl_india.easebuzz_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mpl_india.paynimo_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mpl_india.yesbank_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mpl_india.yes_biz_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mpl_india.cashfree_payout.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  blocked_edge_count: 18
  canonical_resolution_gap_count: 38
  resolved_prior_review_count: 0
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.mpl_india.docx.section.01_identity
  source_document: MPL India.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L12
  summary: '* Business: Digital gaming / fantasy sports platform (wallet-based) — likely MPL (Mobile Premier League) or similar
    real-money gaming operator

    * Model: Users deposit funds into a platform wallet, play games/contests, and withdraw winnings — all reconciliation is
    financial flow, not product commerce

    * Geography: India

    * OMS: Proprietary platform OMS (deposit/withdrawal ledger — `mpl_oms_deposit` / `mpl_oms_withdrawal`)

    * No marketplaces, no logistics, no Shopify/Unicommerce configured

    * GROUP LEVEL ID : 2

    * GROUP ID :  2

    * GROUP NAME : MPL

    * CLIENT NAME : **Mpl India**

    > This client has zero product commerce configuration. All data flows are purely financial — wallet deposits (pay-in)
    and winnings withdrawals (pay-out). Reconciliation logic is fundamentally different from e-commerce: the core question
    is always "does money received via gateways match platform deposit ledger?" and "does money paid out via gateways match
    platform withdrawal ledger?"'
  raw_lines:
  - '* Business: Digital gaming / fantasy sports platform (wallet-based) — likely MPL (Mobile Premier League) or similar real-money
    gaming operator'
  - '* Model: Users deposit funds into a platform wallet, play games/contests, and withdraw winnings — all reconciliation
    is financial flow, not product commerce'
  - '* Geography: India'
  - '* OMS: Proprietary platform OMS (deposit/withdrawal ledger — `mpl_oms_deposit` / `mpl_oms_withdrawal`)'
  - '* No marketplaces, no logistics, no Shopify/Unicommerce configured'
  - '* GROUP LEVEL ID : 2'
  - '* GROUP ID :  2'
  - '* GROUP NAME : MPL'
  - '* CLIENT NAME : **Mpl India**'
  - '> This client has zero product commerce configuration. All data flows are purely financial — wallet deposits (pay-in)
    and winnings withdrawals (pay-out). Reconciliation logic is fundamentally different from e-commerce: the core question
    is always "does money received via gateways match platform deposit ledger?" and "does money paid out via gateways match
    platform withdrawal ledger?"'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mpl_india.docx.section.02_platform_wallet_ledger
  source_document: MPL India.docx
  source_section: Platform wallet ledger
  evidence_type: docx_section
  source_lines: L13-L17
  summary: '| File | Pipeline target | Purpose |

    |------|-----------------|---------|

    | OMS Deposit | mpl_oms_deposit | Platform-side record of user deposits into wallet |

    | OMS Withdrawal | mpl_oms_withdrawal | Platform-side record of user withdrawal requests/payouts |'
  raw_lines:
  - '| File | Pipeline target | Purpose |'
  - '|------|-----------------|---------|'
  - '| OMS Deposit | mpl_oms_deposit | Platform-side record of user deposits into wallet |'
  - '| OMS Withdrawal | mpl_oms_withdrawal | Platform-side record of user withdrawal requests/payouts |'
  row_count: 2
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  source_document: MPL India.docx
  source_section: Platform wallet ledger
  evidence_type: configured_source_row
  source_line: L16
  row_key: OMS Deposit
  columns:
    file: OMS Deposit
    pipeline_target: mpl_oms_deposit
    purpose: Platform-side record of user deposits into wallet
  raw_text: '| OMS Deposit | mpl_oms_deposit | Platform-side record of user deposits into wallet |'
  summary: 'OMS Deposit: file=OMS Deposit; pipeline_target=mpl_oms_deposit; purpose=Platform-side record of user deposits
    into wallet'
  confidence: high
- id: ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  source_document: MPL India.docx
  source_section: Platform wallet ledger
  evidence_type: configured_source_row
  source_line: L17
  row_key: OMS Withdrawal
  columns:
    file: OMS Withdrawal
    pipeline_target: mpl_oms_withdrawal
    purpose: Platform-side record of user withdrawal requests/payouts
  raw_text: '| OMS Withdrawal | mpl_oms_withdrawal | Platform-side record of user withdrawal requests/payouts |'
  summary: 'OMS Withdrawal: file=OMS Withdrawal; pipeline_target=mpl_oms_withdrawal; purpose=Platform-side record of user
    withdrawal requests/payouts'
  confidence: high
- id: ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: docx_section
  source_lines: L18-L31
  summary: 'Users fund their platform wallets through the following channels:

    | Gateway | Pipeline target | Notes |

    |---------|-----------------|-------|

    | Razorpay | razorpay_payin  |       |

    | Cashfree | cashfree_payin  | Settlement Txns sheet only |

    | Paytm   | paytm_payin     |       |

    | PhonePe | phonepe_payin   |       |

    | Easebuzz | easebuzz_payin  | Two sheets: Success Txns + Refund Txns — both route to same target |

    | Amazon Pay | amazon_payin    | Amazon Pay wallet used as deposit method |

    | Paynimo | paynimo_payin   |       |

    | RBL Bank | rbl_oms_payin   | Direct bank pay-in (OMS-labelled) |

    | Yes Bank | yesbank_oms_payin | Direct bank pay-in (OMS-labelled) |

    | Yes Biz | yes_biz_payin   | Yes Bank business product — two header variants |'
  raw_lines:
  - 'Users fund their platform wallets through the following channels:'
  - '| Gateway | Pipeline target | Notes |'
  - '|---------|-----------------|-------|'
  - '| Razorpay | razorpay_payin  |       |'
  - '| Cashfree | cashfree_payin  | Settlement Txns sheet only |'
  - '| Paytm   | paytm_payin     |       |'
  - '| PhonePe | phonepe_payin   |       |'
  - '| Easebuzz | easebuzz_payin  | Two sheets: Success Txns + Refund Txns — both route to same target |'
  - '| Amazon Pay | amazon_payin    | Amazon Pay wallet used as deposit method |'
  - '| Paynimo | paynimo_payin   |       |'
  - '| RBL Bank | rbl_oms_payin   | Direct bank pay-in (OMS-labelled) |'
  - '| Yes Bank | yesbank_oms_payin | Direct bank pay-in (OMS-labelled) |'
  - '| Yes Biz | yes_biz_payin   | Yes Bank business product — two header variants |'
  row_count: 10
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.01_razorpay
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L22
  row_key: Razorpay
  columns:
    gateway: Razorpay
    pipeline_target: razorpay_payin
    notes: ''
  raw_text: '| Razorpay | razorpay_payin  |       |'
  summary: 'Razorpay: gateway=Razorpay; pipeline_target=razorpay_payin; notes='
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L23
  row_key: Cashfree
  columns:
    gateway: Cashfree
    pipeline_target: cashfree_payin
    notes: Settlement Txns sheet only
  raw_text: '| Cashfree | cashfree_payin  | Settlement Txns sheet only |'
  summary: 'Cashfree: gateway=Cashfree; pipeline_target=cashfree_payin; notes=Settlement Txns sheet only'
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.03_paytm
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L24
  row_key: Paytm
  columns:
    gateway: Paytm
    pipeline_target: paytm_payin
    notes: ''
  raw_text: '| Paytm   | paytm_payin     |       |'
  summary: 'Paytm: gateway=Paytm; pipeline_target=paytm_payin; notes='
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.04_phonepe
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L25
  row_key: PhonePe
  columns:
    gateway: PhonePe
    pipeline_target: phonepe_payin
    notes: ''
  raw_text: '| PhonePe | phonepe_payin   |       |'
  summary: 'PhonePe: gateway=PhonePe; pipeline_target=phonepe_payin; notes='
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.05_easebuzz
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L26
  row_key: Easebuzz
  columns:
    gateway: Easebuzz
    pipeline_target: easebuzz_payin
    notes: 'Two sheets: Success Txns + Refund Txns — both route to same target'
  raw_text: '| Easebuzz | easebuzz_payin  | Two sheets: Success Txns + Refund Txns — both route to same target |'
  summary: 'Easebuzz: gateway=Easebuzz; pipeline_target=easebuzz_payin; notes=Two sheets: Success Txns + Refund Txns — both
    route to same target'
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.06_amazon_pay
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L27
  row_key: Amazon Pay
  columns:
    gateway: Amazon Pay
    pipeline_target: amazon_payin
    notes: Amazon Pay wallet used as deposit method
  raw_text: '| Amazon Pay | amazon_payin    | Amazon Pay wallet used as deposit method |'
  summary: 'Amazon Pay: gateway=Amazon Pay; pipeline_target=amazon_payin; notes=Amazon Pay wallet used as deposit method'
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.07_paynimo
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L28
  row_key: Paynimo
  columns:
    gateway: Paynimo
    pipeline_target: paynimo_payin
    notes: ''
  raw_text: '| Paynimo | paynimo_payin   |       |'
  summary: 'Paynimo: gateway=Paynimo; pipeline_target=paynimo_payin; notes='
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.08_rbl_bank
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L29
  row_key: RBL Bank
  columns:
    gateway: RBL Bank
    pipeline_target: rbl_oms_payin
    notes: Direct bank pay-in (OMS-labelled)
  raw_text: '| RBL Bank | rbl_oms_payin   | Direct bank pay-in (OMS-labelled) |'
  summary: 'RBL Bank: gateway=RBL Bank; pipeline_target=rbl_oms_payin; notes=Direct bank pay-in (OMS-labelled)'
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L30
  row_key: Yes Bank
  columns:
    gateway: Yes Bank
    pipeline_target: yesbank_oms_payin
    notes: Direct bank pay-in (OMS-labelled)
  raw_text: '| Yes Bank | yesbank_oms_payin | Direct bank pay-in (OMS-labelled) |'
  summary: 'Yes Bank: gateway=Yes Bank; pipeline_target=yesbank_oms_payin; notes=Direct bank pay-in (OMS-labelled)'
  confidence: high
- id: ev.mpl_india.docx.row.03_pay_in_deposit_gateways.10_yes_biz
  source_document: MPL India.docx
  source_section: Pay-in (deposit) gateways
  evidence_type: configured_source_row
  source_line: L31
  row_key: Yes Biz
  columns:
    gateway: Yes Biz
    pipeline_target: yes_biz_payin
    notes: Yes Bank business product — two header variants
  raw_text: '| Yes Biz | yes_biz_payin   | Yes Bank business product — two header variants |'
  summary: 'Yes Biz: gateway=Yes Biz; pipeline_target=yes_biz_payin; notes=Yes Bank business product — two header variants'
  confidence: high
- id: ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  source_document: MPL India.docx
  source_section: Pay-out (withdrawal) gateways
  evidence_type: docx_section
  source_lines: L32-L39
  summary: 'Platform disburses winnings/withdrawals to users through:

    | Gateway | Pipeline target | Notes |

    |---------|-----------------|-------|

    | Razorpay | razorpay_payout |       |

    | Cashfree | cashfree_payout |       |

    | Paytm   | paytm_payout    |       |

    | Yes Bank | yesbank_oms_payout | Direct bank payout |'
  raw_lines:
  - 'Platform disburses winnings/withdrawals to users through:'
  - '| Gateway | Pipeline target | Notes |'
  - '|---------|-----------------|-------|'
  - '| Razorpay | razorpay_payout |       |'
  - '| Cashfree | cashfree_payout |       |'
  - '| Paytm   | paytm_payout    |       |'
  - '| Yes Bank | yesbank_oms_payout | Direct bank payout |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.01_razorpay
  source_document: MPL India.docx
  source_section: Pay-out (withdrawal) gateways
  evidence_type: configured_source_row
  source_line: L36
  row_key: Razorpay
  columns:
    gateway: Razorpay
    pipeline_target: razorpay_payout
    notes: ''
  raw_text: '| Razorpay | razorpay_payout |       |'
  summary: 'Razorpay: gateway=Razorpay; pipeline_target=razorpay_payout; notes='
  confidence: high
- id: ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  source_document: MPL India.docx
  source_section: Pay-out (withdrawal) gateways
  evidence_type: configured_source_row
  source_line: L37
  row_key: Cashfree
  columns:
    gateway: Cashfree
    pipeline_target: cashfree_payout
    notes: ''
  raw_text: '| Cashfree | cashfree_payout |       |'
  summary: 'Cashfree: gateway=Cashfree; pipeline_target=cashfree_payout; notes='
  confidence: high
- id: ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.03_paytm
  source_document: MPL India.docx
  source_section: Pay-out (withdrawal) gateways
  evidence_type: configured_source_row
  source_line: L38
  row_key: Paytm
  columns:
    gateway: Paytm
    pipeline_target: paytm_payout
    notes: ''
  raw_text: '| Paytm   | paytm_payout    |       |'
  summary: 'Paytm: gateway=Paytm; pipeline_target=paytm_payout; notes='
  confidence: high
- id: ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.04_yes_bank
  source_document: MPL India.docx
  source_section: Pay-out (withdrawal) gateways
  evidence_type: configured_source_row
  source_line: L39
  row_key: Yes Bank
  columns:
    gateway: Yes Bank
    pipeline_target: yesbank_oms_payout
    notes: Direct bank payout
  raw_text: '| Yes Bank | yesbank_oms_payout | Direct bank payout |'
  summary: 'Yes Bank: gateway=Yes Bank; pipeline_target=yesbank_oms_payout; notes=Direct bank payout'
  confidence: high
- id: ev.mpl_india.docx.section.05_bank_reconciliation
  source_document: MPL India.docx
  source_section: Bank reconciliation
  evidence_type: docx_section
  source_lines: L40-L43
  summary: '| Bank | Pipeline target | Notes |

    |------|-----------------|-------|

    | IDFC Bank | idfc_bank       | Direct bank statement reconciliation |'
  raw_lines:
  - '| Bank | Pipeline target | Notes |'
  - '|------|-----------------|-------|'
  - '| IDFC Bank | idfc_bank       | Direct bank statement reconciliation |'
  row_count: 1
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mpl_india.docx.row.05_bank_reconciliation.01_idfc_bank
  source_document: MPL India.docx
  source_section: Bank reconciliation
  evidence_type: configured_source_row
  source_line: L43
  row_key: IDFC Bank
  columns:
    bank: IDFC Bank
    pipeline_target: idfc_bank
    notes: Direct bank statement reconciliation
  raw_text: '| IDFC Bank | idfc_bank       | Direct bank statement reconciliation |'
  summary: 'IDFC Bank: bank=IDFC Bank; pipeline_target=idfc_bank; notes=Direct bank statement reconciliation'
  confidence: high
- id: ev.mpl_india.docx.section.06_expense_tracking
  source_document: MPL India.docx
  source_section: Expense tracking
  evidence_type: docx_section
  source_lines: L44-L47
  summary: '| File | Pipeline target | Notes |

    |------|-----------------|-------|

    | Cashfree fee report | cashfree_expense_report | Gateway fee/charge tracking — separate from transaction flows |'
  raw_lines:
  - '| File | Pipeline target | Notes |'
  - '|------|-----------------|-------|'
  - '| Cashfree fee report | cashfree_expense_report | Gateway fee/charge tracking — separate from transaction flows |'
  row_count: 1
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  source_document: MPL India.docx
  source_section: Expense tracking
  evidence_type: configured_source_row
  source_line: L47
  row_key: Cashfree fee report
  columns:
    file: Cashfree fee report
    pipeline_target: cashfree_expense_report
    notes: Gateway fee/charge tracking — separate from transaction flows
  raw_text: '| Cashfree fee report | cashfree_expense_report | Gateway fee/charge tracking — separate from transaction flows
    |'
  summary: 'Cashfree fee report: file=Cashfree fee report; pipeline_target=cashfree_expense_report; notes=Gateway fee/charge
    tracking — separate from transaction flows'
  confidence: high
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.mpl_india
  canonical_id: tenant.mpl_india
  name: Mpl India
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.01_identity
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: India wallet-ledger client using ZenStatement for player deposit, withdrawal, pay-in gateway, payout gateway,
    bank statement, and gateway expense reconciliation.
  fields:
    tenant_name: Mpl India
    tenant_code: MPL_IN
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.mpl_india.mpl
  canonical_id: group.mpl_india.mpl
  name: MPL
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.01_identity
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_name: MPL
    group_code: MPL
    group_type: business_unit
    business_meaning: MPL India wallet-ledger operating scope for deposits, withdrawals, gateway settlements, payout rails,
      bank reconciliation, and expense tracking.
    country_or_region: India
    default_currency: INR
    currency_scope:
    - INR
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    runtime_scope_policy: group_id and group_level_id are represented in Account Data Binding scope_keys; generic platform/domain
      cards remain reusable.
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.mpl_india.wallet_ledger.primary
  canonical_id: platform_account.mpl_india.wallet_ledger.primary
  name: MPL India Proprietary Wallet Ledger
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.06_amazon_pay
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    account_name: MPL India Proprietary Wallet Ledger
    account_type: proprietary_wallet_ledger_account
    account_role: wallet_ledger_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - mpl_oms_deposit
    - mpl_oms_withdrawal
    source_config_text: OMS Deposit -> mpl_oms_deposit; OMS Withdrawal -> mpl_oms_withdrawal
    declared_platform_id: platform.mpl_proprietary
    declared_platform_label: MPL proprietary wallet ledger
    declared_platform_context_id: platform_context.mpl.wallet_ledger
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.mpl_proprietary
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.mpl.wallet_ledger
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.razorpay_payin.primary
  canonical_id: platform_account.mpl_india.razorpay_payin.primary
  name: MPL India Razorpay Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.01_razorpay
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.01_razorpay
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: MPL India Razorpay Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - razorpay_payin
    source_config_text: Razorpay | razorpay_payin
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.razorpay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.razorpay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.cashfree_payin.primary
  canonical_id: platform_account.mpl_india.cashfree_payin.primary
  name: MPL India Cashfree Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: MPL India Cashfree Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - cashfree_payin
    - Settlement Txns sheet only
    source_config_text: Cashfree | cashfree_payin | Settlement Txns sheet only
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.paytm_payin.primary
  canonical_id: platform_account.mpl_india.paytm_payin.primary
  name: MPL India Paytm Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.03_paytm
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.03_paytm
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.paytm
    platform_context_id: platform_context.paytm.in
    account_name: MPL India Paytm Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - paytm_payin
    source_config_text: Paytm | paytm_payin
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.paytm.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.phonepe_payin.primary
  canonical_id: platform_account.mpl_india.phonepe_payin.primary
  name: MPL India PhonePe Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.04_phonepe
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.phonepe
    platform_context_id: platform_context.phonepe.in
    account_name: MPL India PhonePe Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - phonepe_payin
    source_config_text: PhonePe | phonepe_payin
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.phonepe
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.phonepe.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.easebuzz_payin.primary
  canonical_id: platform_account.mpl_india.easebuzz_payin.primary
  name: MPL India Easebuzz Pay-in
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.05_easebuzz
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    account_name: MPL India Easebuzz Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source_requires_context
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - easebuzz_payin
    - Success Txns
    - Refund Txns
    source_config_text: Easebuzz | easebuzz_payin | Success Txns + Refund Txns route to same target
    declared_platform_id: platform.easebuzz
    declared_platform_label: Easebuzz payment gateway
    declared_platform_context_id: platform_context.easebuzz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.easebuzz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.easebuzz.in
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mpl_india.amazon_payin.primary
  canonical_id: platform_account.mpl_india.amazon_payin.primary
  name: MPL India Amazon Pay Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.06_amazon_pay
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.amazon_pay
    platform_context_id: platform_context.amazon_pay.in
    account_name: MPL India Amazon Pay Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - amazon_payin
    source_config_text: Amazon Pay | amazon_payin
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon_pay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon_pay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.paynimo_payin.primary
  canonical_id: platform_account.mpl_india.paynimo_payin.primary
  name: MPL India Paynimo Pay-in
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.07_paynimo
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    account_name: MPL India Paynimo Pay-in
    account_type: payment_gateway_merchant_account
    account_role: payin_source_requires_context
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - paynimo_payin
    source_config_text: Paynimo | paynimo_payin
    declared_platform_id: platform.paynimo
    declared_platform_label: Paynimo payment gateway
    declared_platform_context_id: platform_context.paynimo.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.paynimo
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.paynimo.in
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mpl_india.rbl_payin.primary
  canonical_id: platform_account.mpl_india.rbl_payin.primary
  name: MPL India RBL Bank Direct Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.08_rbl_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.rbl_bank
    platform_context_id: platform_context.rbl_bank.in
    account_name: MPL India RBL Bank Direct Pay-in
    account_type: bank_rail_account
    account_role: direct_bank_payin_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - rbl_oms_payin
    source_config_text: RBL Bank | rbl_oms_payin
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.rbl_bank
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.rbl_bank.in
        source_documents:
        - payment_gateway.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.rbl_bank.in_payin
      to: platform_context.rbl_bank.in
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.yesbank_payin.primary
  canonical_id: platform_account.mpl_india.yesbank_payin.primary
  name: MPL India Yes Bank Direct Pay-in
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.04_yes_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.yes_bank
    platform_context_id: platform_context.yes_bank.in
    account_name: MPL India Yes Bank Direct Pay-in
    account_type: bank_rail_account
    account_role: direct_bank_payin_requires_context
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - yesbank_oms_payin
    source_config_text: Yes Bank | yesbank_oms_payin
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.yes_bank
        source_documents:
        - bank_statement.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.yes_bank.in
        source_documents:
        - bank_statement.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mpl_india.yes_biz_payin.primary
  canonical_id: platform_account.mpl_india.yes_biz_payin.primary
  name: MPL India Yes Biz Pay-in
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.10_yes_biz
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    account_name: MPL India Yes Biz Pay-in
    account_type: bank_rail_account
    account_role: direct_bank_payin_requires_context
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - yes_biz_payin
    - two header variants
    source_config_text: Yes Biz | yes_biz_payin | two header variants
    declared_platform_id: platform.yes_biz
    declared_platform_label: Yes Biz bank/payment rail
    declared_platform_context_id: platform_context.yes_biz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.yes_biz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.yes_biz.in
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.mpl_india.razorpay_payout.primary
  canonical_id: platform_account.mpl_india.razorpay_payout.primary
  name: MPL India Razorpay Payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.01_razorpay
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.01_razorpay
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: MPL India Razorpay Payout
    account_type: payment_gateway_merchant_account
    account_role: payout_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - razorpay_payout
    source_config_text: Razorpay | razorpay_payout
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.razorpay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.razorpay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.cashfree_payout.primary
  canonical_id: platform_account.mpl_india.cashfree_payout.primary
  name: MPL India Cashfree Payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: MPL India Cashfree Payout
    account_type: payment_gateway_merchant_account
    account_role: payout_source_requires_context
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - cashfree_payout
    source_config_text: Cashfree | cashfree_payout
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
- card_type: platform_account
  card_id: platform_account.mpl_india.paytm_payout.primary
  canonical_id: platform_account.mpl_india.paytm_payout.primary
  name: MPL India Paytm Payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.03_paytm
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.03_paytm
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.paytm
    platform_context_id: platform_context.paytm.in
    account_name: MPL India Paytm Payout
    account_type: payment_gateway_merchant_account
    account_role: payout_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - paytm_payout
    source_config_text: Paytm | paytm_payout
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.paytm.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.yesbank_payout.primary
  canonical_id: platform_account.mpl_india.yesbank_payout.primary
  name: MPL India Yes Bank Payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.04_yes_bank
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.yes_bank
    platform_context_id: platform_context.yes_bank.in
    account_name: MPL India Yes Bank Payout
    account_type: bank_rail_account
    account_role: direct_bank_payout_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - yesbank_oms_payout
    source_config_text: Yes Bank | yesbank_oms_payout
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.yes_bank
        source_documents:
        - bank_statement.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.yes_bank.in
        source_documents:
        - bank_statement.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.idfc_bank.primary
  canonical_id: platform_account.mpl_india.idfc_bank.primary
  name: MPL India IDFC Bank Statement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.05_bank_reconciliation.01_idfc_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.08_rbl_bank
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.idfc_first_bank
    platform_context_id: platform_context.idfc_first_bank.in
    account_name: MPL India IDFC Bank Statement
    account_type: bank_statement_account
    account_role: bank_statement_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - idfc_bank
    source_config_text: IDFC Bank | idfc_bank
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.idfc_first_bank
        source_documents:
        - bank_statement.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.idfc_first_bank.in
        source_documents:
        - bank_statement.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform.idfc_bank
      to: platform.idfc_first_bank
    - kind: canonical_id
      from: platform_context.idfc_bank.in
      to: platform_context.idfc_first_bank.in
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.mpl_india.cashfree_expense.primary
  canonical_id: platform_account.mpl_india.cashfree_expense.primary
  name: MPL India Cashfree Expense Report
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: MPL India Cashfree Expense Report
    account_type: payment_gateway_expense_account
    account_role: gateway_fee_source
    source_account_identifier: null
    source_scope_identifiers:
      group_id: 2
      group_level_id: 2
      group_name: MPL
    country_or_region: India
    currency_scope:
    - INR
    configured_data_types:
    - cashfree_expense_report
    source_config_text: Cashfree fee report | cashfree_expense_report
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this account/channel context. Exact seller, merchant, store, gateway, courier, or bank account
      identifier was not supplied; runtime filtering is carried by Account Data Binding scope_keys.
    original_bad_state_status:
      status: active
      active: true
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  canonical_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  name: account data binding / mpl india / wallet ledger / primary / mpl oms deposit
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.06_amazon_pay
  fields:
    platform_account_id: platform_account.mpl_india.wallet_ledger.primary
    table_id: table.zs_observe.mpl_oms_deposit
    table_support_level: client_observed_table_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - wallet_deposit_ledger
    source_config_text: OMS Deposit -> mpl_oms_deposit; OMS Withdrawal -> mpl_oms_withdrawal
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.mpl_oms_deposit
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  canonical_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  name: account data binding / mpl india / wallet ledger / primary / mpl oms withdrawal
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.06_amazon_pay
  fields:
    platform_account_id: platform_account.mpl_india.wallet_ledger.primary
    table_id: table.zs_observe.mpl_oms_withdrawal
    table_support_level: client_observed_table_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - wallet_withdrawal_ledger
    source_config_text: OMS Deposit -> mpl_oms_deposit; OMS Withdrawal -> mpl_oms_withdrawal
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.mpl_oms_withdrawal
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
  canonical_id: account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
  name: account data binding / mpl india / razorpay payin / primary / razorpay payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.01_razorpay
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.01_razorpay
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.razorpay_payin.primary
    table_id: table.zs_observe.razorpay_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - payin_deposit_gateway
    source_config_text: Razorpay | razorpay_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  canonical_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  name: account data binding / mpl india / cashfree payin / primary / cashfree payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  fields:
    platform_account_id: platform_account.mpl_india.cashfree_payin.primary
    table_id: table.zs_observe.cashfree_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - payin_deposit_gateway
    source_config_text: Cashfree | cashfree_payin | Settlement Txns sheet only
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
  canonical_id: account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
  name: account data binding / mpl india / paytm payin / primary / paytm payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.03_paytm
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.03_paytm
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.paytm_payin.primary
    table_id: table.zs_observe.paytm_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - payin_deposit_gateway
    source_config_text: Paytm | paytm_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
  canonical_id: account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
  name: account data binding / mpl india / phonepe payin / primary / phonepe payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.04_phonepe
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.phonepe_payin.primary
    table_id: table.zs_observe.phonepe_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - payin_deposit_gateway
    source_config_text: PhonePe | phonepe_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.phonepe_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
  canonical_id: account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
  name: account data binding / mpl india / easebuzz payin / primary / easebuzz payin
  status: review_required
  active: false
  confidence: source_confirmed
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.05_easebuzz
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  fields:
    platform_account_id: platform_account.mpl_india.easebuzz_payin.primary
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - payin_deposit_gateway
    - payin_refund_sheet
    source_config_text: Easebuzz | easebuzz_payin | Success Txns + Refund Txns route to same target
    declared_table_id: table.zs_observe.easebuzz_payin
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.easebuzz_payin
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Easebuzz Success Txns and Refund Txns route to easebuzz_payin; canonical Easebuzz table context is not
      available in current uploaded KB.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
  canonical_id: account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
  name: account data binding / mpl india / amazon payin / primary / amazon payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.06_amazon_pay
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.amazon_payin.primary
    table_id: table.zs_observe.amazon_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - amazon_pay_wallet_deposit_gateway
    source_config_text: Amazon Pay | amazon_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
  canonical_id: account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
  name: account data binding / mpl india / paynimo payin / primary / paynimo payin
  status: review_required
  active: false
  confidence: source_confirmed
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.07_paynimo
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.paynimo_payin.primary
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - payin_deposit_gateway
    source_config_text: Paynimo | paynimo_payin
    declared_table_id: table.zs_observe.paynimo_payin
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.paynimo_payin
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Paynimo pay-in target; canonical Paynimo table context is not available in current uploaded KB.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
  canonical_id: account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
  name: account data binding / mpl india / rbl payin / primary / rbl oms payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.08_rbl_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  fields:
    platform_account_id: platform_account.mpl_india.rbl_payin.primary
    table_id: table.zs_observe.rbl_oms_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - direct_bank_payin
    source_config_text: RBL Bank | rbl_oms_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.rbl_oms_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
  canonical_id: account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
  name: account data binding / mpl india / yesbank payin / primary / yesbank oms payin
  status: review_required
  active: false
  confidence: source_confirmed
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.04_yes_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.yesbank_payin.primary
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - direct_bank_payin
    source_config_text: Yes Bank | yesbank_oms_payin
    declared_table_id: table.zs_observe.yesbank_oms_payin
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.yesbank_oms_payin
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Yes Bank pay-in target; payment-gateway KB lists yesbank_oms_payin in availability registry but no active
      table card exists.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
  canonical_id: account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
  name: account data binding / mpl india / yes biz payin / primary / yes biz payin
  status: review_required
  active: false
  confidence: source_confirmed
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.10_yes_biz
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.yes_biz_payin.primary
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - direct_bank_payin
    - two_header_variants
    source_config_text: Yes Biz | yes_biz_payin | two header variants
    declared_table_id: table.zs_observe.yes_biz_payin
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.yes_biz_payin
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Yes Biz pay-in target with two header variants; no active table card is available.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.razorpay_payout.primary.razorpay_payout
  canonical_id: account_data_binding.mpl_india.razorpay_payout.primary.razorpay_payout
  name: account data binding / mpl india / razorpay payout / primary / razorpay payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.01_razorpay
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.01_razorpay
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.razorpay_payout.primary
    table_id: table.zs_observe.razorpay_payout
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - wallet_withdrawal_payout_gateway
    source_config_text: Razorpay | razorpay_payout
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payout
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
  canonical_id: account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
  name: account data binding / mpl india / cashfree payout / primary / cashfree payout
  status: review_required
  active: false
  confidence: source_confirmed
  review_status: review_required
  create_action: upsert
  source_documents:
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  fields:
    platform_account_id: platform_account.mpl_india.cashfree_payout.primary
    table_support_level: source_described_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - wallet_withdrawal_payout_gateway
    source_config_text: Cashfree | cashfree_payout
    declared_table_id: table.zs_observe.cashfree_payout
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cashfree_payout
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Source confirms Cashfree payout target; no active cashfree_payout table card is available in current uploaded KB.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.paytm_payout.primary.paytm_payout
  canonical_id: account_data_binding.mpl_india.paytm_payout.primary.paytm_payout
  name: account data binding / mpl india / paytm payout / primary / paytm payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.03_paytm
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.03_paytm
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.paytm_payout.primary
    table_id: table.zs_observe.paytm_payout
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - wallet_withdrawal_payout_gateway
    source_config_text: Paytm | paytm_payout
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payout
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.yesbank_payout.primary.yesbank_oms_payout
  canonical_id: account_data_binding.mpl_india.yesbank_payout.primary.yesbank_oms_payout
  name: account data binding / mpl india / yesbank payout / primary / yesbank oms payout
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.04_yes_bank
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.09_yes_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    platform_account_id: platform_account.mpl_india.yesbank_payout.primary
    table_id: table.zs_ingest.yesbank_oms_payout
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - direct_bank_payout
    source_config_text: Yes Bank | yesbank_oms_payout
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_ingest.yesbank_oms_payout
      source_documents:
      - bank_statement.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.idfc_bank.primary.idfc_bank
  canonical_id: account_data_binding.mpl_india.idfc_bank.primary.idfc_bank
  name: account data binding / mpl india / idfc bank / primary / idfc bank
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.05_bank_reconciliation.01_idfc_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.08_rbl_bank
  fields:
    platform_account_id: platform_account.mpl_india.idfc_bank.primary
    table_id: table.zs_ingest.idfc_bank
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - bank_statement_reconciliation
    source_config_text: IDFC Bank | idfc_bank
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_ingest.idfc_bank
      source_documents:
      - bank_statement.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.mpl_india.cashfree_expense.primary.cashfree_expense_report
  canonical_id: account_data_binding.mpl_india.cashfree_expense.primary.cashfree_expense_report
  name: account data binding / mpl india / cashfree expense / primary / cashfree expense report
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.06_expense_tracking.01_cashfree_fee_report
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  fields:
    platform_account_id: platform_account.mpl_india.cashfree_expense.primary
    table_id: table.zs_observe.cashfree_expense_report
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Apply when the physical table exposes group_id; group_level_id remains mandatory client scope.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 2
      data_type: integer
      scope_note: Primary runtime scope key from the client document.
    - business_key: currency_type
      column: currency_type
      operator: '='
      value: INR
      data_type: string
      scope_note: Currency guard added from client geography/currency scope; apply where the table exposes currency_type.
    runtime_scope_precision: group_id_and_group_level_id_plus_source_specific_guards
    unresolved_scope_keys: []
    data_type_semantics:
    - gateway_fee_expense_report
    source_config_text: Cashfree fee report | cashfree_expense_report
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_expense_report
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific table binding. Account filters are held here; no generic platform card is made tenant-specific.
    original_bad_state_status:
      status: active
      active: true
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.wallet_ledger
  canonical_id: business_scope_set.mpl_india.wallet_ledger
  name: MPL India Wallet Ledger
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: MPL deposit and withdrawal ledger scope.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Wallet Ledger
    scope_type: proprietary_wallet_ledger_scope
    platform_account_ids:
    - platform_account.mpl_india.wallet_ledger.primary
    platform_ids: []
    platform_context_ids: []
    declared_unresolved_platform_ids:
    - platform.mpl_proprietary
    declared_unresolved_platform_context_ids:
    - platform_context.mpl.wallet_ledger
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.active_payin_sources
  canonical_id: business_scope_set.mpl_india.active_payin_sources
  name: MPL India Active Pay-in Sources
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: Canonical/client-supported pay-in sources for wallet deposits.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Active Pay-in Sources
    scope_type: payment_gateway_scope
    platform_account_ids:
    - platform_account.mpl_india.razorpay_payin.primary
    - platform_account.mpl_india.cashfree_payin.primary
    - platform_account.mpl_india.paytm_payin.primary
    - platform_account.mpl_india.phonepe_payin.primary
    - platform_account.mpl_india.amazon_payin.primary
    - platform_account.mpl_india.rbl_payin.primary
    platform_ids:
    - platform.razorpay
    - platform.cashfree
    - platform.paytm
    - platform.phonepe
    - platform.amazon_pay
    - platform.rbl_bank
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.cashfree.in
    - platform_context.paytm.in
    - platform_context.phonepe.in
    - platform_context.amazon_pay.in
    - platform_context.rbl_bank.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.rbl_bank.in_payin
      to: platform_context.rbl_bank.in
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  canonical_id: business_scope_set.mpl_india.payin_sources_requiring_context
  name: MPL India Pay-in Sources Requiring Context
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: Source-confirmed pay-in rails needing table context.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Pay-in Sources Requiring Context
    scope_type: source_confirmed_requires_context
    platform_account_ids:
    - platform_account.mpl_india.easebuzz_payin.primary
    - platform_account.mpl_india.paynimo_payin.primary
    - platform_account.mpl_india.yesbank_payin.primary
    - platform_account.mpl_india.yes_biz_payin.primary
    platform_ids:
    - platform.yes_bank
    platform_context_ids:
    - platform_context.yes_bank.in
    declared_unresolved_platform_ids:
    - platform.easebuzz
    - platform.paynimo
    - platform.yes_biz
    declared_unresolved_platform_context_ids:
    - platform_context.easebuzz.in
    - platform_context.paynimo.in
    - platform_context.yes_biz.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.active_payout_sources
  canonical_id: business_scope_set.mpl_india.active_payout_sources
  name: MPL India Active Payout Sources
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - bank_statement.md
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: Active payout sources for wallet withdrawals.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Active Payout Sources
    scope_type: payout_gateway_scope
    platform_account_ids:
    - platform_account.mpl_india.razorpay_payout.primary
    - platform_account.mpl_india.paytm_payout.primary
    - platform_account.mpl_india.yesbank_payout.primary
    platform_ids:
    - platform.razorpay
    - platform.paytm
    - platform.yes_bank
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.paytm.in
    - platform_context.yes_bank.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.payout_sources_requiring_context
  canonical_id: business_scope_set.mpl_india.payout_sources_requiring_context
  name: MPL India Payout Sources Requiring Context
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: Source-confirmed payout rail needing table context.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Payout Sources Requiring Context
    scope_type: source_confirmed_requires_context
    platform_account_ids:
    - platform_account.mpl_india.cashfree_payout.primary
    platform_ids:
    - platform.cashfree
    platform_context_ids:
    - platform_context.cashfree.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.bank_reconciliation
  canonical_id: business_scope_set.mpl_india.bank_reconciliation
  name: MPL India Bank Reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - bank_statement.md
  evidence_refs:
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.05_bank_reconciliation.01_idfc_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: IDFC bank statement reconciliation scope.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Bank Reconciliation
    scope_type: bank_statement_scope
    platform_account_ids:
    - platform_account.mpl_india.idfc_bank.primary
    platform_ids:
    - platform.idfc_first_bank
    platform_context_ids:
    - platform_context.idfc_first_bank.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform.idfc_bank
      to: platform.idfc_first_bank
    - kind: canonical_id
      from: platform_context.idfc_bank.in
      to: platform_context.idfc_first_bank.in
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.mpl_india.cashfree_expense
  canonical_id: business_scope_set.mpl_india.cashfree_expense
  name: MPL India Cashfree Expense
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  description: Cashfree gateway fee/charge report scope.
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    scope_name: MPL India Cashfree Expense
    scope_type: gateway_expense_scope
    platform_account_ids:
    - platform_account.mpl_india.cashfree_expense.primary
    platform_ids:
    - platform.cashfree
    platform_context_ids:
    - platform_context.cashfree.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  canonical_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  name: MPL India Wallet Deposit to Active Pay-in Sources
  status: active
  active: true
  confidence: high
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    binding_name: MPL India Wallet Deposit to Active Pay-in Sources
    binding_type: wallet_deposit_reconciliation_flow
    business_scope_set_id: business_scope_set.mpl_india.active_payin_sources
    money_flow_paths:
    - wallet_deposit_to_payin_gateway
    participating_accounts:
    - platform_account_id: platform_account.mpl_india.wallet_ledger.primary
      role: wallet_deposit_ledger
      required: true
    - platform_account_id: platform_account.mpl_india.razorpay_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.cashfree_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.paytm_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.phonepe_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.amazon_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.rbl_payin.primary
      role: direct_bank_payin_source
      required: false
    evidence_table_ids:
    - table.zs_observe.mpl_oms_deposit
    - table.zs_observe.razorpay_payin
    - table.zs_observe.cashfree_payin
    - table.zs_observe.paytm_payin
    - table.zs_observe.phonepe_payin
    - table.zs_observe.amazon_payin
    - table.zs_observe.rbl_oms_payin
    account_data_binding_ids:
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
    - account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
    - account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
    - account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
    - account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
    - account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
    - account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.wallet_deposit_capture
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.wallet_deposit_to_payin
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  canonical_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  name: MPL India Wallet Deposit Sources Requiring Context
  status: draft
  active: false
  confidence: medium
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    binding_name: MPL India Wallet Deposit Sources Requiring Context
    binding_type: wallet_deposit_reconciliation_flow
    business_scope_set_id: business_scope_set.mpl_india.payin_sources_requiring_context
    money_flow_paths:
    - wallet_deposit_to_payin_gateway
    participating_accounts:
    - platform_account_id: platform_account.mpl_india.wallet_ledger.primary
      role: wallet_deposit_ledger
      required: true
    - platform_account_id: platform_account.mpl_india.easebuzz_payin.primary
      role: payin_source_requires_context
      required: false
    - platform_account_id: platform_account.mpl_india.paynimo_payin.primary
      role: payin_source_requires_context
      required: false
    - platform_account_id: platform_account.mpl_india.yesbank_payin.primary
      role: direct_bank_payin_requires_context
      required: false
    - platform_account_id: platform_account.mpl_india.yes_biz_payin.primary
      role: direct_bank_payin_requires_context
      required: false
    evidence_table_ids:
    - table.zs_observe.mpl_oms_deposit
    account_data_binding_ids:
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
    - account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
    - account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
    - account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
    - account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
    conditions: []
    declared_unresolved_evidence_table_ids:
    - table.zs_observe.easebuzz_payin
    - table.zs_observe.paynimo_payin
    - table.zs_observe.yesbank_oms_payin
    - table.zs_observe.yes_biz_payin
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.wallet_deposit_capture
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.wallet_deposit_to_payin
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  canonical_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  name: MPL India Wallet Withdrawal to Active Payout Sources
  status: active
  active: true
  confidence: high
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - bank_statement.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    binding_name: MPL India Wallet Withdrawal to Active Payout Sources
    binding_type: wallet_withdrawal_reconciliation_flow
    business_scope_set_id: business_scope_set.mpl_india.active_payout_sources
    money_flow_paths:
    - wallet_withdrawal_to_payout_gateway
    participating_accounts:
    - platform_account_id: platform_account.mpl_india.wallet_ledger.primary
      role: wallet_withdrawal_ledger
      required: true
    - platform_account_id: platform_account.mpl_india.razorpay_payout.primary
      role: payout_source
      required: false
    - platform_account_id: platform_account.mpl_india.paytm_payout.primary
      role: payout_source
      required: false
    - platform_account_id: platform_account.mpl_india.yesbank_payout.primary
      role: direct_bank_payout_source
      required: false
    evidence_table_ids:
    - table.zs_observe.mpl_oms_withdrawal
    - table.zs_observe.razorpay_payout
    - table.zs_observe.paytm_payout
    - table.zs_ingest.yesbank_oms_payout
    account_data_binding_ids:
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
    - account_data_binding.mpl_india.razorpay_payout.primary.razorpay_payout
    - account_data_binding.mpl_india.paytm_payout.primary.paytm_payout
    - account_data_binding.mpl_india.yesbank_payout.primary.yesbank_oms_payout
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.wallet_withdrawal_payout
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.wallet_withdrawal_to_payout
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  canonical_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  name: MPL India Wallet Withdrawal to Cashfree Payout Requires Context
  status: draft
  active: false
  confidence: medium
  review_status: review_required
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    binding_name: MPL India Wallet Withdrawal to Cashfree Payout Requires Context
    binding_type: wallet_withdrawal_reconciliation_flow
    business_scope_set_id: business_scope_set.mpl_india.payout_sources_requiring_context
    money_flow_paths:
    - wallet_withdrawal_to_payout_gateway
    participating_accounts:
    - platform_account_id: platform_account.mpl_india.wallet_ledger.primary
      role: wallet_withdrawal_ledger
      required: true
    - platform_account_id: platform_account.mpl_india.cashfree_payout.primary
      role: payout_source_requires_context
      required: true
    evidence_table_ids:
    - table.zs_observe.mpl_oms_withdrawal
    account_data_binding_ids:
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
    - account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
    - account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
    conditions: []
    declared_unresolved_evidence_table_ids:
    - table.zs_observe.cashfree_payout
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.wallet_withdrawal_payout
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.wallet_withdrawal_to_payout
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  canonical_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  name: MPL India Pay-in Sources to IDFC Bank
  status: active
  active: true
  confidence: high
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - bank_statement.md
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.05_bank_reconciliation
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.05_bank_reconciliation.01_idfc_bank
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    binding_name: MPL India Pay-in Sources to IDFC Bank
    binding_type: bank_reconciliation_flow
    business_scope_set_id: business_scope_set.mpl_india.bank_reconciliation
    money_flow_paths:
    - payin_gateway_to_bank
    participating_accounts:
    - platform_account_id: platform_account.mpl_india.idfc_bank.primary
      role: bank_statement_source
      required: true
    - platform_account_id: platform_account.mpl_india.razorpay_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.cashfree_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.paytm_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.phonepe_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.amazon_payin.primary
      role: payin_source
      required: false
    - platform_account_id: platform_account.mpl_india.rbl_payin.primary
      role: direct_bank_payin_source
      required: false
    evidence_table_ids:
    - table.zs_ingest.idfc_bank
    - table.zs_observe.razorpay_payin
    - table.zs_observe.cashfree_payin
    - table.zs_observe.paytm_payin
    - table.zs_observe.phonepe_payin
    - table.zs_observe.amazon_payin
    - table.zs_observe.rbl_oms_payin
    account_data_binding_ids:
    - account_data_binding.mpl_india.idfc_bank.primary.idfc_bank
    - account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
    - account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
    - account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
    - account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
    - account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
    - account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.gateway_settlement_to_bank
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.gateway_to_bank
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  canonical_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  name: MPL India Cashfree Expense Tracking
  status: active
  active: true
  confidence: high
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - MPL India.docx
  - payment_gateway.md
  evidence_refs:
  - ev.mpl_india.docx.section.03_pay_in_deposit_gateways
  - ev.mpl_india.docx.section.06_expense_tracking
  - ev.mpl_india.docx.section.02_platform_wallet_ledger
  - ev.mpl_india.docx.section.04_pay_out_withdrawal_gateways
  - ev.mpl_india.docx.row.03_pay_in_deposit_gateways.02_cashfree
  - ev.mpl_india.docx.row.04_pay_out_withdrawal_gateways.02_cashfree
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.01_oms_deposit
  - ev.mpl_india.docx.row.02_platform_wallet_ledger.02_oms_withdrawal
  fields:
    tenant_id: tenant.mpl_india
    group_id: group.mpl_india.mpl
    binding_name: MPL India Cashfree Expense Tracking
    binding_type: expense_tracking_flow
    business_scope_set_id: business_scope_set.mpl_india.cashfree_expense
    money_flow_paths:
    - payment_gateway_fee_tracking
    participating_accounts:
    - platform_account_id: platform_account.mpl_india.cashfree_expense.primary
      role: gateway_fee_source
      required: true
    - platform_account_id: platform_account.mpl_india.cashfree_payin.primary
      role: cashfree_payin_source
      required: false
    evidence_table_ids:
    - table.zs_observe.cashfree_expense_report
    - table.zs_observe.cashfree_payin
    account_data_binding_ids:
    - account_data_binding.mpl_india.cashfree_expense.primary.cashfree_expense_report
    - account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.gateway_fee_tracking
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.gateway_expense_validation
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific reusable flow binding. Matching logic remains in generic reconciliation/query cards; account filters
      remain in Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- platform_account_id: platform_account.mpl_india.wallet_ledger.primary
  client_config_text: OMS Deposit/Withdrawal ledger
  source_confirmed_requires_context: []
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.mpl_oms_deposit
  - table.zs_observe.mpl_oms_withdrawal
  unresolved_canonical_requested: []
- platform_account_id: platform_account.mpl_india.easebuzz_payin.primary
  client_config_text: Easebuzz pay-in success/refund sheets
  source_confirmed_requires_context:
  - easebuzz_payin
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
- platform_account_id: platform_account.mpl_india.paynimo_payin.primary
  client_config_text: Paynimo pay-in
  source_confirmed_requires_context:
  - paynimo_payin
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
- platform_account_id: platform_account.mpl_india.cashfree_payout.primary
  client_config_text: Cashfree payout
  source_confirmed_requires_context:
  - cashfree_payout
  mapping_policy: Map source wording to current canonical or client-observed table coverage only. Source-confirmed artifacts
    without table context are recorded separately for future authoring, not emitted as active bindings.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.mpl_india.hasgroup.45fd8cdec751
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.mpl_india
  target_card_id: group.mpl_india.mpl
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_GROUP
- edge_id: edge.mpl_india.hasplatformaccount.5d53be4b3dbc
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.wallet_ledger.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasaccountdatabinding.1342eef12bcb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.wallet_ledger.primary
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.69ecef8e6454
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  target_card_id: table.zs_observe.mpl_oms_deposit
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasaccountdatabinding.b235f21c206e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.wallet_ledger.primary
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.ed0f1de451d8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  target_card_id: table.zs_observe.mpl_oms_withdrawal
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.d42f46a91796
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.razorpay_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.42fed29e3a6a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.razorpay_payin.primary
  target_card_id: platform.razorpay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.38937198948d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.razorpay_payin.primary
  target_card_id: platform_context.razorpay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.b2fe7053205d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.razorpay_payin.primary
  target_card_id: account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.ed0225c3ccf3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
  target_card_id: table.zs_observe.razorpay_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.709e20e9d9a8
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.cashfree_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.50f4a5289e1f
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.cashfree_payin.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.02b51af81929
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.cashfree_payin.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.b1a5413abace
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.cashfree_payin.primary
  target_card_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.8cb417115bd3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  target_card_id: table.zs_observe.cashfree_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.4c0b175af105
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.paytm_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.bf4ba4c58751
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.paytm_payin.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.d8c7effc3f11
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.paytm_payin.primary
  target_card_id: platform_context.paytm.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.f2aba1c40dea
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.paytm_payin.primary
  target_card_id: account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.9ed3e4ef5781
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
  target_card_id: table.zs_observe.paytm_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.227ddaa22c82
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.phonepe_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.f125a4f12275
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.phonepe_payin.primary
  target_card_id: platform.phonepe
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.00d815f6e4a4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.phonepe_payin.primary
  target_card_id: platform_context.phonepe.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.ed3ee0682f4c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.phonepe_payin.primary
  target_card_id: account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.401684a91517
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
  target_card_id: table.zs_observe.phonepe_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.ee36d9bc6479
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.easebuzz_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasaccountdatabinding.4364dd0fc68e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.easebuzz_payin.primary
  target_card_id: account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.hasplatformaccount.3aad51b28213
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.amazon_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.2c2ef303461a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.amazon_payin.primary
  target_card_id: platform.amazon_pay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.45a535ce72e2
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.amazon_payin.primary
  target_card_id: platform_context.amazon_pay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.8c868143e758
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.amazon_payin.primary
  target_card_id: account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.547a2f68aa59
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
  target_card_id: table.zs_observe.amazon_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.dfb05ad1cf1c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.paynimo_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasaccountdatabinding.960888724a82
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.paynimo_payin.primary
  target_card_id: account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.hasplatformaccount.3983220050cd
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.rbl_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.9083ae728e84
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.rbl_payin.primary
  target_card_id: platform.rbl_bank
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.3bb16874c288
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.rbl_payin.primary
  target_card_id: platform_context.rbl_bank.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.32b8d4edbc57
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.rbl_payin.primary
  target_card_id: account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.22f155fa0a4b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
  target_card_id: table.zs_observe.rbl_oms_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.f09b2261a91b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.yesbank_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.abc0690795c3
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.yesbank_payin.primary
  target_card_id: platform.yes_bank
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.0d4d9503bd81
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.yesbank_payin.primary
  target_card_id: platform_context.yes_bank.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.a6a92e878e2e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.yesbank_payin.primary
  target_card_id: account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.hasplatformaccount.b5802291d71c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.yes_biz_payin.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasaccountdatabinding.09b4b541e7fe
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.yes_biz_payin.primary
  target_card_id: account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.hasplatformaccount.94ef198cb2e6
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.razorpay_payout.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.d7357272ca19
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.razorpay_payout.primary
  target_card_id: platform.razorpay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.0be873cfb2bf
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.razorpay_payout.primary
  target_card_id: platform_context.razorpay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.9c643012042d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.razorpay_payout.primary
  target_card_id: account_data_binding.mpl_india.razorpay_payout.primary.razorpay_payout
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.bd9cfc1cf7f6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.razorpay_payout.primary.razorpay_payout
  target_card_id: table.zs_observe.razorpay_payout
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.15e64ab979fe
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.cashfree_payout.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.bc3ac81e46c1
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.cashfree_payout.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.204b5f74872c
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.cashfree_payout.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.d6f653b38623
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.cashfree_payout.primary
  target_card_id: account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.hasplatformaccount.a04119979b02
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.paytm_payout.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.879e6baa09f7
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.paytm_payout.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.41a76349c0d9
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.paytm_payout.primary
  target_card_id: platform_context.paytm.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.664648e70474
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.paytm_payout.primary
  target_card_id: account_data_binding.mpl_india.paytm_payout.primary.paytm_payout
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.3c8611801883
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.paytm_payout.primary.paytm_payout
  target_card_id: table.zs_observe.paytm_payout
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.a1844593ce21
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.yesbank_payout.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.5e617b9a4134
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.yesbank_payout.primary
  target_card_id: platform.yes_bank
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.83e892fbaed4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.yesbank_payout.primary
  target_card_id: platform_context.yes_bank.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.cc9745a495cf
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.yesbank_payout.primary
  target_card_id: account_data_binding.mpl_india.yesbank_payout.primary.yesbank_oms_payout
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.4ceeb5ad018b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.yesbank_payout.primary.yesbank_oms_payout
  target_card_id: table.zs_ingest.yesbank_oms_payout
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.2e53ec1158bb
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.idfc_bank.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.81a573636e42
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.idfc_bank.primary
  target_card_id: platform.idfc_first_bank
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.40294331c4a9
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.idfc_bank.primary
  target_card_id: platform_context.idfc_first_bank.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.a0c428e88f8a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.idfc_bank.primary
  target_card_id: account_data_binding.mpl_india.idfc_bank.primary.idfc_bank
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.d1a416baf076
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.idfc_bank.primary.idfc_bank
  target_card_id: table.zs_ingest.idfc_bank
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasplatformaccount.d8f28697e0d9
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.mpl_india.mpl
  target_card_id: platform_account.mpl_india.cashfree_expense.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.usesplatform.0bb203022dfa
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.mpl_india.cashfree_expense.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.mpl_india.usesplatformcontext.42056763723a
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.mpl_india.cashfree_expense.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.mpl_india.hasaccountdatabinding.b2f22cec2cc0
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.mpl_india.cashfree_expense.primary
  target_card_id: account_data_binding.mpl_india.cashfree_expense.primary.cashfree_expense_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.bindstotable.fd82a4c76bf6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.mpl_india.cashfree_expense.primary.cashfree_expense_report
  target_card_id: table.zs_observe.cashfree_expense_report
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.mpl_india.hasbusinessscopeset.1c1969d10b5b
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.wallet_ledger
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.a2341795bdd4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.wallet_ledger
  target_card_id: platform_account.mpl_india.wallet_ledger.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessscopeset.f9b7951398e0
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.active_payin_sources
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.a83cd5b695a1
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payin_sources
  target_card_id: platform_account.mpl_india.razorpay_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.9f649b7b4221
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payin_sources
  target_card_id: platform_account.mpl_india.cashfree_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.e0855194692e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payin_sources
  target_card_id: platform_account.mpl_india.paytm_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.533d457d1c4e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payin_sources
  target_card_id: platform_account.mpl_india.phonepe_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.b00e19ce7caa
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payin_sources
  target_card_id: platform_account.mpl_india.amazon_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.64f26bd0a06b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payin_sources
  target_card_id: platform_account.mpl_india.rbl_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessscopeset.035d8f0cfcdd
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.599a96b26adf
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  target_card_id: platform_account.mpl_india.easebuzz_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.400ebacc89ad
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  target_card_id: platform_account.mpl_india.paynimo_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.b0cbbaba49cc
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  target_card_id: platform_account.mpl_india.yesbank_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.e7d9596bc85e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  target_card_id: platform_account.mpl_india.yes_biz_payin.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessscopeset.484a08d37f01
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.active_payout_sources
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.20637d8ee662
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payout_sources
  target_card_id: platform_account.mpl_india.razorpay_payout.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.ce82fcc298ef
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payout_sources
  target_card_id: platform_account.mpl_india.paytm_payout.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.includesplatformaccount.24ceb1e768eb
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.active_payout_sources
  target_card_id: platform_account.mpl_india.yesbank_payout.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessscopeset.613c47cdc321
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.payout_sources_requiring_context
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.8850668b6ac4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.payout_sources_requiring_context
  target_card_id: platform_account.mpl_india.cashfree_payout.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessscopeset.ebb9c3e6e32e
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.bank_reconciliation
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.eb67be65998b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.bank_reconciliation
  target_card_id: platform_account.mpl_india.idfc_bank.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessscopeset.ff8a7ec6bd07
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.mpl_india.mpl
  target_card_id: business_scope_set.mpl_india.cashfree_expense
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.includesplatformaccount.7119f32fe716
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.mpl_india.cashfree_expense
  target_card_id: platform_account.mpl_india.cashfree_expense.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.mpl_india.hasbusinessflowbinding.3de382e3564b
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mpl_india.mpl
  target_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mpl_india.usesbusinessscopeset.9f21b73d92ef
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: business_scope_set.mpl_india.active_payin_sources
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.participateswithaccount.a81ded2e7280
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.wallet_ledger.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.8121f3261b5a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.razorpay_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.95ccdd11526a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.cashfree_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.8770fd1026d3
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.paytm_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.bd6bb46cb1a6
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.phonepe_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.dac6583118ce
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.amazon_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.5f935c44891e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: platform_account.mpl_india.rbl_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.usesaccountdatabinding.48911b1ca49a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.03f8cc8fd814
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.8255e24196ac
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.0a170de89131
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.21847aaaf37d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.28f53d39240c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.8a1a88a1b809
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.b0e1d4dfee73
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesevidencetable.3b355a476a9f
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.mpl_oms_deposit
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.08b65da825ed
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.razorpay_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.6570a59cce7e
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.cashfree_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.f21844e60651
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.paytm_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.4b16a8619a3a
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.phonepe_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.e2ec67600e15
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.amazon_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.1fca4aff48a1
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  target_card_id: table.zs_observe.rbl_oms_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.hasbusinessflowbinding.06c4c3069d18
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mpl_india.mpl
  target_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mpl_india.usesbusinessscopeset.845185c03096
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: business_scope_set.mpl_india.payin_sources_requiring_context
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.participateswithaccount.0ec9d43b37f6
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: platform_account.mpl_india.wallet_ledger.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.2eddc90ed828
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: platform_account.mpl_india.easebuzz_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.654dd989f35c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: platform_account.mpl_india.paynimo_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.26395dd0887b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: platform_account.mpl_india.yesbank_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.749fc5e2778d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: platform_account.mpl_india.yes_biz_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.usesaccountdatabinding.af97c1078ea2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.d6e43c434367
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.09e0f3fed133
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.5e2d79a7bca4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.8ffbda99c490
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.c476812d2ead
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesevidencetable.979e314896c7
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  target_card_id: table.zs_observe.mpl_oms_deposit
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.hasbusinessflowbinding.01c7d30dab40
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mpl_india.mpl
  target_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mpl_india.usesbusinessscopeset.39ff0cbc6515
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: business_scope_set.mpl_india.active_payout_sources
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.participateswithaccount.cccd35308e68
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: platform_account.mpl_india.wallet_ledger.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.fbdf23487004
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: platform_account.mpl_india.razorpay_payout.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.f6d3a8f07842
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: platform_account.mpl_india.paytm_payout.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.006cfc4c95fa
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: platform_account.mpl_india.yesbank_payout.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.usesaccountdatabinding.9b9fe36f4d49
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.5a926946abc7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.2f1e65e01743
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: account_data_binding.mpl_india.razorpay_payout.primary.razorpay_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.9e7c12ec1afa
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: account_data_binding.mpl_india.paytm_payout.primary.paytm_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.882a1d926d3e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: account_data_binding.mpl_india.yesbank_payout.primary.yesbank_oms_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesevidencetable.86c5070a34f8
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: table.zs_observe.mpl_oms_withdrawal
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.8ebdb944cdb3
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: table.zs_observe.razorpay_payout
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.0ab5d3d0ce00
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: table.zs_observe.paytm_payout
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.cc395e13a575
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  target_card_id: table.zs_ingest.yesbank_oms_payout
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.hasbusinessflowbinding.d70678ae4f27
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mpl_india.mpl
  target_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mpl_india.usesbusinessscopeset.c9dd749e829a
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: business_scope_set.mpl_india.payout_sources_requiring_context
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.participateswithaccount.7d49a68ace43
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: platform_account.mpl_india.wallet_ledger.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.bbe8e360db37
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: platform_account.mpl_india.cashfree_payout.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.usesaccountdatabinding.2ec36692613d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.c39999adf367
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.7e1842254a6a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesevidencetable.3658809577ec
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  target_card_id: table.zs_observe.mpl_oms_withdrawal
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.hasbusinessflowbinding.ff4485515ad8
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mpl_india.mpl
  target_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mpl_india.usesbusinessscopeset.d78a42a10b3b
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: business_scope_set.mpl_india.bank_reconciliation
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.participateswithaccount.d506b46eb85a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.idfc_bank.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.a63994757e52
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.razorpay_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.3bd6115c85dc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.cashfree_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.abe3a437f506
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.paytm_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.cccde15ca08e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.phonepe_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.6fddc61a9f7d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.amazon_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.8b40f32319db
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: platform_account.mpl_india.rbl_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.usesaccountdatabinding.a487586b7685
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.idfc_bank.primary.idfc_bank
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.eb11e49cca67
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.razorpay_payin.primary.razorpay_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.69c046f3cf1c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.7faac7dda2a2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.paytm_payin.primary.paytm_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.333a004196a4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.phonepe_payin.primary.phonepe_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.b2e19b137fe9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.amazon_payin.primary.amazon_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.e178a4080c8b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: account_data_binding.mpl_india.rbl_payin.primary.rbl_oms_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesevidencetable.80a3a880d031
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_ingest.idfc_bank
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.4a28ad223bb4
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_observe.razorpay_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.ed189229e147
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_observe.cashfree_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.f92926341e06
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_observe.paytm_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.54f443692b21
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_observe.phonepe_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.97a293d567ce
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_observe.amazon_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.eef2a6f8f139
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  target_card_id: table.zs_observe.rbl_oms_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.hasbusinessflowbinding.b9de5c7ce537
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.mpl_india.mpl
  target_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.mpl_india.usesbusinessscopeset.0988c8f1feb4
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: business_scope_set.mpl_india.cashfree_expense
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.mpl_india.participateswithaccount.dd0c22832423
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: platform_account.mpl_india.cashfree_expense.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.participateswithaccount.fd9685225265
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: platform_account.mpl_india.cashfree_payin.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.mpl_india.usesaccountdatabinding.58920c45790d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: account_data_binding.mpl_india.cashfree_expense.primary.cashfree_expense_report
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesaccountdatabinding.c08583dc5844
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: account_data_binding.mpl_india.cashfree_payin.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.mpl_india.usesevidencetable.eca9e4dd158b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: table.zs_observe.cashfree_expense_report
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.mpl_india.usesevidencetable.d5cc2a0297e6
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.mpl_india.cashfree_expense_tracking
  target_card_id: table.zs_observe.cashfree_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch2
    source_json_edge_type: USES_EVIDENCE_TABLE
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: platform_account.mpl_india.wallet_ledger.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.mpl_proprietary
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.mpl_proprietary
  original_edge:
    source: platform_account.mpl_india.wallet_ledger.primary
    edge: USES_PLATFORM
    target: platform.mpl_proprietary
    reference_status: external
- source_card_id: platform_account.mpl_india.wallet_ledger.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.mpl.wallet_ledger
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.mpl.wallet_ledger
  original_edge:
    source: platform_account.mpl_india.wallet_ledger.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.mpl.wallet_ledger
    reference_status: external
- source_card_id: platform_account.mpl_india.easebuzz_payin.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.easebuzz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.easebuzz
  original_edge:
    source: platform_account.mpl_india.easebuzz_payin.primary
    edge: USES_PLATFORM
    target: platform.easebuzz
    reference_status: external
- source_card_id: platform_account.mpl_india.easebuzz_payin.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.easebuzz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.easebuzz.in
  original_edge:
    source: platform_account.mpl_india.easebuzz_payin.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.easebuzz.in
    reference_status: external
- source_card_id: account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.easebuzz_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.easebuzz_payin
  original_edge:
    source: account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
    edge: BINDS_TO_TABLE
    target: table.zs_observe.easebuzz_payin
    reference_status: source_described_requires_platform_context
- source_card_id: platform_account.mpl_india.paynimo_payin.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.paynimo
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.paynimo
  original_edge:
    source: platform_account.mpl_india.paynimo_payin.primary
    edge: USES_PLATFORM
    target: platform.paynimo
    reference_status: external
- source_card_id: platform_account.mpl_india.paynimo_payin.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.paynimo.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.paynimo.in
  original_edge:
    source: platform_account.mpl_india.paynimo_payin.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.paynimo.in
    reference_status: external
- source_card_id: account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.paynimo_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.paynimo_payin
  original_edge:
    source: account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
    edge: BINDS_TO_TABLE
    target: table.zs_observe.paynimo_payin
    reference_status: source_described_requires_platform_context
- source_card_id: account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.yesbank_oms_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.yesbank_oms_payin
  original_edge:
    source: account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
    edge: BINDS_TO_TABLE
    target: table.zs_observe.yesbank_oms_payin
    reference_status: source_described_requires_platform_context
- source_card_id: platform_account.mpl_india.yes_biz_payin.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.yes_biz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.yes_biz
  original_edge:
    source: platform_account.mpl_india.yes_biz_payin.primary
    edge: USES_PLATFORM
    target: platform.yes_biz
    reference_status: external
- source_card_id: platform_account.mpl_india.yes_biz_payin.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.yes_biz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.yes_biz.in
  original_edge:
    source: platform_account.mpl_india.yes_biz_payin.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.yes_biz.in
    reference_status: external
- source_card_id: account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.yes_biz_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.yes_biz_payin
  original_edge:
    source: account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
    edge: BINDS_TO_TABLE
    target: table.zs_observe.yes_biz_payin
    reference_status: source_described_requires_platform_context
- source_card_id: account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cashfree_payout
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cashfree_payout
  original_edge:
    source: account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cashfree_payout
    reference_status: source_described_requires_platform_context
- source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.easebuzz_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.easebuzz_payin
  original_edge:
    source: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.easebuzz_payin
    reference_status: external
- source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.paynimo_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.paynimo_payin
  original_edge:
    source: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.paynimo_payin
    reference_status: external
- source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.yesbank_oms_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.yesbank_oms_payin
  original_edge:
    source: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.yesbank_oms_payin
    reference_status: external
- source_card_id: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.yes_biz_payin
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.yes_biz_payin
  original_edge:
    source: business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.yes_biz_payin
    reference_status: external
- source_card_id: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.cashfree_payout
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cashfree_payout
  original_edge:
    source: business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.cashfree_payout
    reference_status: external
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: Easebuzz
  source_confirmed_artifacts:
  - easebuzz_payin Success Txns
  - easebuzz_payin Refund Txns
  source_evidence_text: MPL India lists Easebuzz payin with two sheets routed to the same target.
  impact: Easebuzz cannot be used as active deposit evidence until table context is authored.
  required_action: author_platform_context_or_confirm_table_schema_then_add_account_data_binding
  severity: high
  source_documents:
  - MPL India.docx
- platform_or_area: Paynimo
  source_confirmed_artifacts:
  - paynimo_payin
  source_evidence_text: MPL India lists Paynimo pay-in.
  impact: Paynimo cannot participate in active deposit reconciliation until table context is authored.
  required_action: author_platform_context_or_confirm_table_schema_then_add_account_data_binding
  severity: medium
  source_documents:
  - MPL India.docx
- platform_or_area: Cashfree payout
  source_confirmed_artifacts:
  - cashfree_payout
  source_evidence_text: MPL India lists Cashfree payout.
  impact: Cashfree payout cannot be active withdrawal evidence until table context is authored.
  required_action: author_platform_context_or_confirm_table_schema_then_add_account_data_binding
  severity: high
  source_documents:
  - MPL India.docx
- platform_or_area: Yes Bank pay-in
  source_confirmed_artifacts:
  - yesbank_oms_payin
  - yes_biz_payin
  source_evidence_text: MPL India lists Yes Bank and Yes Biz pay-in targets.
  impact: Yes Bank pay-in direct-bank rails require active table context before production use.
  required_action: author_platform_context_or_confirm_table_schema_then_add_account_data_binding
  severity: medium
  source_documents:
  - MPL India.docx
  - payment_gateway.md
- platform_or_area: table.zs_observe.cashfree_payout
  missing_artifacts:
  - table.zs_observe.cashfree_payout
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  generated_by_refactor: true
- platform_or_area: table.zs_observe.easebuzz_payin
  missing_artifacts:
  - table.zs_observe.easebuzz_payin
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- platform_or_area: table.zs_observe.paynimo_payin
  missing_artifacts:
  - table.zs_observe.paynimo_payin
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- platform_or_area: table.zs_observe.yes_biz_payin
  missing_artifacts:
  - table.zs_observe.yes_biz_payin
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- platform_or_area: table.zs_observe.yesbank_oms_payin
  missing_artifacts:
  - table.zs_observe.yesbank_oms_payin
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- platform_or_area: platform_context.easebuzz.in
  missing_artifacts:
  - platform_context.easebuzz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.easebuzz_payin.primary
  generated_by_refactor: true
- platform_or_area: platform_context.mpl.wallet_ledger
  missing_artifacts:
  - platform_context.mpl.wallet_ledger
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.wallet_ledger.primary
  generated_by_refactor: true
- platform_or_area: platform_context.paynimo.in
  missing_artifacts:
  - platform_context.paynimo.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.paynimo_payin.primary
  generated_by_refactor: true
- platform_or_area: platform_context.yes_biz.in
  missing_artifacts:
  - platform_context.yes_biz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.yes_biz_payin.primary
  generated_by_refactor: true
- platform_or_area: platform.easebuzz
  missing_artifacts:
  - platform.easebuzz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.easebuzz_payin.primary
  generated_by_refactor: true
- platform_or_area: platform.mpl_proprietary
  missing_artifacts:
  - platform.mpl_proprietary
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.wallet_ledger.primary
  generated_by_refactor: true
- platform_or_area: platform.paynimo
  missing_artifacts:
  - platform.paynimo
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.paynimo_payin.primary
  generated_by_refactor: true
- platform_or_area: platform.yes_biz
  missing_artifacts:
  - platform.yes_biz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.mpl_india.yes_biz_payin.primary
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- item: tenant.mpl_india
  issue: Client name appears as 'Mpl India' in the source; tenant code normalized to MPL_IN. Confirm preferred display capitalization.
  severity: low
  blocking_for_active_ingestion: false
  review_resolution_status: open
- item: business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  issue: Active flow covers canonical/client-observed pay-in sources only; Easebuzz, Paynimo, Yes Bank pay-in, and Yes Biz
    remain review-required.
  severity: medium
  blocking_for_active_ingestion: false
  review_resolution_status: open
- item: table.zs_observe.cashfree_payout
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  generated_by_refactor: true
- item: table.zs_observe.easebuzz_payin
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- item: table.zs_observe.paynimo_payin
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- item: table.zs_observe.yes_biz_payin
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- item: table.zs_observe.yesbank_oms_payin
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.easebuzz_payin.primary
  generated_by_refactor: true
- item: platform_context.mpl.wallet_ledger
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.wallet_ledger.primary
  generated_by_refactor: true
- item: platform_context.paynimo.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.paynimo_payin.primary
  generated_by_refactor: true
- item: platform_context.yes_biz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.yes_biz_payin.primary
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.payin_sources_requiring_context
  generated_by_refactor: true
- item: platform_context.mpl.wallet_ledger
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.wallet_ledger
  generated_by_refactor: true
- item: platform_context.paynimo.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.payin_sources_requiring_context
  generated_by_refactor: true
- item: platform_context.yes_biz.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.payin_sources_requiring_context
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.easebuzz_payin.primary
  generated_by_refactor: true
- item: platform.mpl_proprietary
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.wallet_ledger.primary
  generated_by_refactor: true
- item: platform.paynimo
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.paynimo_payin.primary
  generated_by_refactor: true
- item: platform.yes_biz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.mpl_india.yes_biz_payin.primary
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.payin_sources_requiring_context
  generated_by_refactor: true
- item: platform.mpl_proprietary
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.wallet_ledger
  generated_by_refactor: true
- item: platform.paynimo
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.payin_sources_requiring_context
  generated_by_refactor: true
- item: platform.yes_biz
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.mpl_india.payin_sources_requiring_context
  generated_by_refactor: true
- item: table.zs_observe.cashfree_payout
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.mpl_india.cashfree_payout.primary.cashfree_payout
  generated_by_refactor: true
- item: table.zs_observe.easebuzz_payin
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.mpl_india.easebuzz_payin.primary.easebuzz_payin
  generated_by_refactor: true
- item: table.zs_observe.paynimo_payin
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.mpl_india.paynimo_payin.primary.paynimo_payin
  generated_by_refactor: true
- item: table.zs_observe.yes_biz_payin
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.mpl_india.yes_biz_payin.primary.yes_biz_payin
  generated_by_refactor: true
- item: table.zs_observe.yesbank_oms_payin
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.mpl_india.yesbank_payin.primary.yesbank_oms_payin
  generated_by_refactor: true
resolved_review_items: []
non_blocking_declared_semantic_reference_gaps:
- reference_id: business_process.gateway_fee_tracking
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.cashfree_expense_tracking
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.gateway_settlement_to_bank
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.wallet_deposit_capture
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: business_process.wallet_withdrawal_payout
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  - business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.gateway_expense_validation
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.cashfree_expense_tracking
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.gateway_to_bank
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.payin_sources_to_idfc_bank
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.wallet_deposit_to_payin
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_deposit_to_active_payin_sources
  - business_flow_binding.mpl_india.wallet_deposit_to_sources_requiring_context
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.wallet_withdrawal_to_payout
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.mpl_india.wallet_withdrawal_to_active_payout_sources
  - business_flow_binding.mpl_india.wallet_withdrawal_to_cashfree_payout_requires_context
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 50
  refactored_card_count: 50
  original_edge_count: 209
  refactored_edge_count: 191
  blocked_edge_count: 18
  source_evidence_count: 24
  source_row_evidence_count: 18
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 17
    account_data_binding: 18
    business_scope_set: 7
    business_flow_binding: 6
  status_counts:
    active: 38
    review_required: 8
    draft: 4
  review_status_counts:
    accepted: 37
    review_required: 13
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 38
  canonical_resolution_gap_type_counts:
    platform_id: 4
    platform_context_id: 4
    table_id: 5
    platform_ids: 4
    platform_context_ids: 4
    business_process_ids: 6
    reconciliation_profile_ids: 6
    evidence_table_ids: 5
  status_correction_count: 5
  status_changes:
  - card_id: platform_account.mpl_india.easebuzz_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mpl_india.paynimo_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mpl_india.yesbank_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  - card_id: platform_account.mpl_india.yes_biz_payin.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.mpl_india.cashfree_payout.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: active
    to_active: true
    reason: source_confirmed_platform_account_with_resolved_context_or_resolved_table_binding
  id_or_source_replacement_count: 8
  id_or_source_replacements:
  - card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_deposit
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.mpl_india.wallet_ledger.primary.mpl_oms_withdrawal
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.mpl_india.rbl_payin.primary
    kind: canonical_id
    from: platform_context.rbl_bank.in_payin
    to: platform_context.rbl_bank.in
  - card_id: platform_account.mpl_india.idfc_bank.primary
    kind: canonical_id
    from: platform.idfc_bank
    to: platform.idfc_first_bank
  - card_id: platform_account.mpl_india.idfc_bank.primary
    kind: canonical_id
    from: platform_context.idfc_bank.in
    to: platform_context.idfc_first_bank.in
  - card_id: business_scope_set.mpl_india.active_payin_sources
    kind: canonical_id
    from: platform_context.rbl_bank.in_payin
    to: platform_context.rbl_bank.in
  - card_id: business_scope_set.mpl_india.bank_reconciliation
    kind: canonical_id
    from: platform.idfc_bank
    to: platform.idfc_first_bank
  - card_id: business_scope_set.mpl_india.bank_reconciliation
    kind: canonical_id
    from: platform_context.idfc_bank.in
    to: platform_context.idfc_first_bank.in
  resolved_prior_review_count: 0
  open_review_count: 28
  future_context_gap_count: 17
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 8
  non_blocking_declared_semantic_reference_gap_type_counts:
    business_process_ids: 4
    reconciliation_profile_ids: 4
  edge_status_counts:
    emitted: 191
    blocked_unresolved: 18
```
