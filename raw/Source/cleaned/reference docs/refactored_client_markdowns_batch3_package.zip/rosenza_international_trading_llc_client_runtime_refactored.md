# Rosenza International Trading L.L.C — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: rosenza_international_trading_llc_client_runtime_cards_v2_1_refactored
  created_for: Rosenza International Trading L.L.C
  generated_on: '2026-05-24'
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  design_rule: Tenant/Group identity is separated from table/runtime scope. group_id and group_level_id filters live only
    in Account Data Binding cards. Cross-domain logic is represented as Business Scope Set and Business Flow Binding cards.
  scope_key_policy:
    primary_runtime_scope_columns:
    - group_id
    - group_level_id
    tenant_id_handling: tenant_id is treated as a possible alias of group_id when a source table uses tenant_id instead of
      group_id; it is not duplicated in the binding unless verified per table.
    region_currency_handling: Region/currency values are represented as platform-account logical scope unless a concrete table
      column is confirmed.
  card_count: 37
  edge_count: 131
  version: v2_1_refactored
  generated_date: '2026-05-24'
  client_slug: rosenza_international_trading_llc
  source_json_bad_state: rosenza_international_trading_llc.json
  source_docx: Rosenza International Trading L.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.global_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.international_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.increff.in.wms_operations: platform_context.increff.in
      platform_context.shiprocket.in.oms_order_source: platform_context.shiprocket.in
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: rosenza_international_trading_llc.json
  source_docx: Rosenza International Trading L.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Remapped role-specific Shopify/Increff/Shiprocket/Amazon/Paytm/PhonePe context aliases to uploaded broader canonical contexts
    while preserving the role in account fields.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: group.rosenza_international_trading_llc.mensa_brands
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_returns
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_fee_preview
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_ca.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_mx.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_uk.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_de.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_fr.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_es.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_se.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_ae.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_ksa.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  status_changes:
  - card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  blocked_edge_count: 4
  canonical_resolution_gap_count: 4
  resolved_prior_review_count: 0
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.rosenza_international_trading_llc.docx.section.01_identity
  source_document: Rosenza International Trading L.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L13
  summary: '* Business: Global product brand — multi-region marketplace + D2C, with Middle East as a distinct focus market

    * Geography: Americas (US, CA, MX), Europe (UK, DE, France, Spain, SE), Middle East (UAE, KSA)

    * OMS/WMS: Shopify (D2C), native marketplace OMS feeds

    * Logistics: Not configured — courier reconciliation not in scope

    * Payment gateways: Not configured — all settlements via marketplace payouts

    * Currencies in scope: USD, CAD, MXN, GBP, EUR, SEK, AED, SAR (minimum 8 currencies)

    * GROUP LEVEL ID :  133

    * GROUP ID :  9

    * GROUP NAME : Mensa Brands

    * CLIENT NAME : **Rosenza International Trading L.L.C**

    > Fully international client — no Indian marketplace or INR exposure. Middle East presence is significant enough to warrant
    two separate platforms (Noon + Namshi). FX normalisation is critical before any cross-region roll-up.'
  raw_lines:
  - '* Business: Global product brand — multi-region marketplace + D2C, with Middle East as a distinct focus market'
  - '* Geography: Americas (US, CA, MX), Europe (UK, DE, France, Spain, SE), Middle East (UAE, KSA)'
  - '* OMS/WMS: Shopify (D2C), native marketplace OMS feeds'
  - '* Logistics: Not configured — courier reconciliation not in scope'
  - '* Payment gateways: Not configured — all settlements via marketplace payouts'
  - '* Currencies in scope: USD, CAD, MXN, GBP, EUR, SEK, AED, SAR (minimum 8 currencies)'
  - '* GROUP LEVEL ID :  133'
  - '* GROUP ID :  9'
  - '* GROUP NAME : Mensa Brands'
  - '* CLIENT NAME : **Rosenza International Trading L.L.C**'
  - '> Fully international client — no Indian marketplace or INR exposure. Middle East presence is significant enough to warrant
    two separate platforms (Noon + Namshi). FX normalisation is critical before any cross-region roll-up.'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas
  evidence_type: docx_section
  source_lines: L15-L21
  summary: '| Channel | Region | Data types configured |

    |---------|--------|-----------------------|

    | Amazon  | US     | OMS, Settlement, Returns, Fee preview |

    | Amazon  | Canada | Settlement            |

    | Amazon  | Mexico | Settlement            |

    | Shopify | D2C    | OMS                   |'
  raw_lines:
  - '| Channel | Region | Data types configured |'
  - '|---------|--------|-----------------------|'
  - '| Amazon  | US     | OMS, Settlement, Returns, Fee preview |'
  - '| Amazon  | Canada | Settlement            |'
  - '| Amazon  | Mexico | Settlement            |'
  - '| Shopify | D2C    | OMS                   |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas
  evidence_type: configured_source_row
  source_line: L18
  row_key: Amazon
  columns:
    channel: Amazon
    region: US
    data_types_configured: OMS, Settlement, Returns, Fee preview
  raw_text: '| Amazon  | US     | OMS, Settlement, Returns, Fee preview |'
  summary: 'Amazon: channel=Amazon; region=US; data_types_configured=OMS, Settlement, Returns, Fee preview'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas
  evidence_type: configured_source_row
  source_line: L19
  row_key: Amazon
  columns:
    channel: Amazon
    region: Canada
    data_types_configured: Settlement
  raw_text: '| Amazon  | Canada | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=Canada; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas
  evidence_type: configured_source_row
  source_line: L20
  row_key: Amazon
  columns:
    channel: Amazon
    region: Mexico
    data_types_configured: Settlement
  raw_text: '| Amazon  | Mexico | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=Mexico; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.04_shopify
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas
  evidence_type: configured_source_row
  source_line: L21
  row_key: Shopify
  columns:
    channel: Shopify
    region: D2C
    data_types_configured: OMS
  raw_text: '| Shopify | D2C    | OMS                   |'
  summary: 'Shopify: channel=Shopify; region=D2C; data_types_configured=OMS'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.section.03_active_sales_channels_americas_europe
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Europe
  evidence_type: docx_section
  source_lines: L22-L29
  summary: '| Channel | Region | Data types configured |

    |---------|--------|-----------------------|

    | Amazon  | UK     | Settlement            |

    | Amazon  | Germany | Settlement            |

    | Amazon  | France | Settlement            |

    | Amazon  | Spain  | Settlement            |

    | Amazon  | Sweden | Settlement            |'
  raw_lines:
  - '| Channel | Region | Data types configured |'
  - '|---------|--------|-----------------------|'
  - '| Amazon  | UK     | Settlement            |'
  - '| Amazon  | Germany | Settlement            |'
  - '| Amazon  | France | Settlement            |'
  - '| Amazon  | Spain  | Settlement            |'
  - '| Amazon  | Sweden | Settlement            |'
  row_count: 5
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Europe
  evidence_type: configured_source_row
  source_line: L25
  row_key: Amazon
  columns:
    channel: Amazon
    region: UK
    data_types_configured: Settlement
  raw_text: '| Amazon  | UK     | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=UK; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.02_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Europe
  evidence_type: configured_source_row
  source_line: L26
  row_key: Amazon
  columns:
    channel: Amazon
    region: Germany
    data_types_configured: Settlement
  raw_text: '| Amazon  | Germany | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=Germany; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.03_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Europe
  evidence_type: configured_source_row
  source_line: L27
  row_key: Amazon
  columns:
    channel: Amazon
    region: France
    data_types_configured: Settlement
  raw_text: '| Amazon  | France | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=France; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.04_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Europe
  evidence_type: configured_source_row
  source_line: L28
  row_key: Amazon
  columns:
    channel: Amazon
    region: Spain
    data_types_configured: Settlement
  raw_text: '| Amazon  | Spain  | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=Spain; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.05_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Europe
  evidence_type: configured_source_row
  source_line: L29
  row_key: Amazon
  columns:
    channel: Amazon
    region: Sweden
    data_types_configured: Settlement
  raw_text: '| Amazon  | Sweden | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=Sweden; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.section.04_active_sales_channels_americas_middle_east
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Middle East
  evidence_type: docx_section
  source_lines: L30-L36
  summary: '| Channel | Region | Data types configured |

    |---------|--------|-----------------------|

    | Amazon  | UAE    | Settlement            |

    | Amazon  | KSA    | Settlement            |

    | Noon    | UAE/KSA | OMS (order report + export report), Settlement |

    | Namshi  | UAE/KSA | OMS (order report + return report + KSA export), Settlement |'
  raw_lines:
  - '| Channel | Region | Data types configured |'
  - '|---------|--------|-----------------------|'
  - '| Amazon  | UAE    | Settlement            |'
  - '| Amazon  | KSA    | Settlement            |'
  - '| Noon    | UAE/KSA | OMS (order report + export report), Settlement |'
  - '| Namshi  | UAE/KSA | OMS (order report + return report + KSA export), Settlement |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.01_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Middle East
  evidence_type: configured_source_row
  source_line: L33
  row_key: Amazon
  columns:
    channel: Amazon
    region: UAE
    data_types_configured: Settlement
  raw_text: '| Amazon  | UAE    | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=UAE; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.02_amazon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Middle East
  evidence_type: configured_source_row
  source_line: L34
  row_key: Amazon
  columns:
    channel: Amazon
    region: KSA
    data_types_configured: Settlement
  raw_text: '| Amazon  | KSA    | Settlement            |'
  summary: 'Amazon: channel=Amazon; region=KSA; data_types_configured=Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.03_noon
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Middle East
  evidence_type: configured_source_row
  source_line: L35
  row_key: Noon
  columns:
    channel: Noon
    region: UAE/KSA
    data_types_configured: OMS (order report + export report), Settlement
  raw_text: '| Noon    | UAE/KSA | OMS (order report + export report), Settlement |'
  summary: 'Noon: channel=Noon; region=UAE/KSA; data_types_configured=OMS (order report + export report), Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.04_namshi
  source_document: Rosenza International Trading L.docx
  source_section: Active sales channels / Americas / Middle East
  evidence_type: configured_source_row
  source_line: L36
  row_key: Namshi
  columns:
    channel: Namshi
    region: UAE/KSA
    data_types_configured: OMS (order report + return report + KSA export), Settlement
  raw_text: '| Namshi  | UAE/KSA | OMS (order report + return report + KSA export), Settlement |'
  summary: 'Namshi: channel=Namshi; region=UAE/KSA; data_types_configured=OMS (order report + return report + KSA export),
    Settlement'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.section.05_reference_mapping_tables
  source_document: Rosenza International Trading L.docx
  source_section: Reference / mapping tables
  evidence_type: docx_section
  source_lines: L37-L41
  summary: '| File | Pipeline target | Purpose |

    |------|-----------------|---------|

    | Noon Namshi ASIN–SKU | noon_namshi_lookup | Maps Noon/Namshi item IDs to brand SKUs — shared across both platforms |

    | Amazon fee preview | amazon_fee_preview | Projected fee estimates ahead of settlement close |'
  raw_lines:
  - '| File | Pipeline target | Purpose |'
  - '|------|-----------------|---------|'
  - '| Noon Namshi ASIN–SKU | noon_namshi_lookup | Maps Noon/Namshi item IDs to brand SKUs — shared across both platforms
    |'
  - '| Amazon fee preview | amazon_fee_preview | Projected fee estimates ahead of settlement close |'
  row_count: 2
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.rosenza_international_trading_llc.docx.row.05_reference_mapping_tables.01_noon_namshi_asin_sku
  source_document: Rosenza International Trading L.docx
  source_section: Reference / mapping tables
  evidence_type: configured_source_row
  source_line: L40
  row_key: Noon Namshi ASIN–SKU
  columns:
    file: Noon Namshi ASIN–SKU
    pipeline_target: noon_namshi_lookup
    purpose: Maps Noon/Namshi item IDs to brand SKUs — shared across both platforms
  raw_text: '| Noon Namshi ASIN–SKU | noon_namshi_lookup | Maps Noon/Namshi item IDs to brand SKUs — shared across both platforms
    |'
  summary: 'Noon Namshi ASIN–SKU: file=Noon Namshi ASIN–SKU; pipeline_target=noon_namshi_lookup; purpose=Maps Noon/Namshi
    item IDs to brand SKUs — shared across both platforms'
  confidence: high
- id: ev.rosenza_international_trading_llc.docx.row.05_reference_mapping_tables.02_amazon_fee_preview
  source_document: Rosenza International Trading L.docx
  source_section: Reference / mapping tables
  evidence_type: configured_source_row
  source_line: L41
  row_key: Amazon fee preview
  columns:
    file: Amazon fee preview
    pipeline_target: amazon_fee_preview
    purpose: Projected fee estimates ahead of settlement close
  raw_text: '| Amazon fee preview | amazon_fee_preview | Projected fee estimates ahead of settlement close |'
  summary: 'Amazon fee preview: file=Amazon fee preview; pipeline_target=amazon_fee_preview; purpose=Projected fee estimates
    ahead of settlement close'
  confidence: high
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.rosenza_international_trading_llc
  canonical_id: tenant.rosenza_international_trading_llc
  name: Rosenza International Trading L.L.C
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.01_identity
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.04_shopify
  description: Global product brand using ZenStatement for multi-region marketplace and Shopify D2C settlement/revenue reasoning,
    with Americas, Europe, and Middle East coverage and FX-normalised rollups.
  fields:
    tenant_name: Rosenza International Trading L.L.C
    tenant_code: ROSENZA
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.rosenza_international_trading_llc.mensa_brands
  canonical_id: group.rosenza_international_trading_llc.mensa_brands
  name: Mensa Brands
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Rosenza International Trading L.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.01_identity
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_name: Mensa Brands
    group_code: MENSA_BRANDS_ROSENZA
    group_type: operational_unit
    business_meaning: Operational group from the Rosenza client scope. Source identifies GROUP ID 9 and GROUP LEVEL ID 133;
      these are applied through Account Data Binding filters. Rosenza is fully international with no Indian marketplace/INR
      exposure.
    country_or_region: Americas, Europe, Middle East
    default_currency: USD
    client_source_identifiers_note: Source doc gives GROUP ID 9 and GROUP LEVEL ID 133; these are applied as Account Data
      Binding filters, not as universal Group properties.
    currency_scope:
    - USD
    - CAD
    - MXN
    - GBP
    - EUR
    - SEK
    - AED
    - SAR
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  name: Rosenza Amazon US Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon US Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: US
    default_currency: USD
    currency_scope:
    - USD
    canonical_platform_status: canonical
    source_evidence: 'Amazon US configured: OMS, Settlement, Returns, Fee preview'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  name: Rosenza Amazon Canada Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon Canada Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: Canada
    default_currency: CAD
    currency_scope:
    - CAD
    canonical_platform_status: canonical
    source_evidence: 'Amazon Canada configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  name: Rosenza Amazon Mexico Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon Mexico Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: Mexico
    default_currency: MXN
    currency_scope:
    - MXN
    canonical_platform_status: canonical
    source_evidence: 'Amazon Mexico configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  name: Rosenza Amazon UK Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon UK Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: UK
    default_currency: GBP
    currency_scope:
    - GBP
    canonical_platform_status: canonical
    source_evidence: 'Amazon UK configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  name: Rosenza Amazon Germany Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon Germany Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: Germany
    default_currency: EUR
    currency_scope:
    - EUR
    canonical_platform_status: canonical
    source_evidence: 'Amazon Germany configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  name: Rosenza Amazon France Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon France Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: France
    default_currency: EUR
    currency_scope:
    - EUR
    canonical_platform_status: canonical
    source_evidence: 'Amazon France configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  name: Rosenza Amazon Spain Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon Spain Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: Spain
    default_currency: EUR
    currency_scope:
    - EUR
    canonical_platform_status: canonical
    source_evidence: 'Amazon Spain configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  name: Rosenza Amazon Sweden Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon Sweden Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: Sweden
    default_currency: SEK
    currency_scope:
    - SEK
    canonical_platform_status: canonical
    source_evidence: 'Amazon Sweden configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  name: Rosenza Amazon UAE Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon UAE Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: UAE
    default_currency: AED
    currency_scope:
    - AED
    canonical_platform_status: canonical
    source_evidence: 'Amazon UAE configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  canonical_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  name: Rosenza Amazon KSA Seller Account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.international
    account_name: Rosenza Amazon KSA Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: KSA
    default_currency: SAR
    currency_scope:
    - SAR
    canonical_platform_status: canonical
    source_evidence: 'Amazon KSA configured: Settlement'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.international
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  canonical_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  name: Rosenza Shopify D2C Store
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.04_shopify
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Rosenza Shopify D2C Store
    account_type: d2c_store_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: D2C/global
    default_currency: USD
    currency_scope:
    - USD
    - CAD
    - MXN
    - GBP
    - EUR
    - SEK
    - AED
    - SAR
    canonical_platform_status: canonical
    source_evidence: 'Shopify D2C configured: OMS'
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shopify
        source_documents:
        - shopify_d2c_oms_v2.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shopify.in_and_global.d2c_oms_client_config
        source_documents:
        - shopify_d2c_oms_v2.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.d2c_oms
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Client document confirms the platform/channel is configured; exact external account identifier was not provided.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  canonical_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  name: Rosenza Noon UAE/KSA Seller Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.03_noon
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    account_name: Rosenza Noon UAE/KSA Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: UAE/KSA
    default_currency: AED
    currency_scope:
    - AED
    - SAR
    canonical_platform_status: source_described_pending_platform_context
    source_evidence: 'Noon UAE/KSA configured: OMS order report + export report, Settlement'
    declared_platform_id: platform.noon
    declared_platform_label: Noon Middle East marketplace
    declared_platform_context_id: platform_context.noon.middle_east
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.noon
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.noon.middle_east
    notes:
    - Client confirms Noon coverage, but no Noon canonical marketplace markdown was uploaded. Do not route queries until platform
      context/table cards exist.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  canonical_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  name: Rosenza Namshi UAE/KSA Seller Account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.04_namshi
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    account_name: Rosenza Namshi UAE/KSA Seller Account
    account_type: marketplace_seller_account
    source_account_identifier: null
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    region_or_market: UAE/KSA
    default_currency: AED
    currency_scope:
    - AED
    - SAR
    canonical_platform_status: source_described_pending_platform_context
    source_evidence: 'Namshi UAE/KSA configured: OMS order report + return report + KSA export, Settlement'
    declared_platform_id: platform.namshi
    declared_platform_label: Namshi Middle East marketplace
    declared_platform_context_id: platform_context.namshi.middle_east
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.namshi
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.namshi.middle_east
    notes:
    - Client confirms Namshi coverage, but no Namshi canonical marketplace markdown was uploaded. Do not route queries until
      platform context/table cards exist.
    original_bad_state_status:
      status: draft
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_oms
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_oms
  name: account data binding / rosenza international trading llc / amazon us / primary / amazon oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
    table_id: table.zs_observe.amazon_oms
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: OMS
    logical_scope:
      region_or_market: US
      currency_scope:
      - USD
    mapping_confidence: exact
    source_evidence: Amazon US | OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_oms
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon us / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: US
      currency_scope:
      - USD
    mapping_confidence: exact
    source_evidence: Amazon US | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_returns
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_returns
  name: account data binding / rosenza international trading llc / amazon us / primary / amazon returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
    table_id: table.zs_observe.amazon_returns
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Returns
    logical_scope:
      region_or_market: US
      currency_scope:
      - USD
    mapping_confidence: exact
    source_evidence: Amazon US | Returns
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_returns
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_fee_preview
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_fee_preview
  name: account data binding / rosenza international trading llc / amazon us / primary / amazon fee preview
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.05_reference_mapping_tables.02_amazon_fee_preview
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
    table_id: table.zs_observe.amazon_fee_preview
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Fee preview
    logical_scope:
      region_or_market: US
      currency_scope:
      - USD
    mapping_confidence: exact
    source_evidence: Amazon US | Fee preview
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_fee_preview
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_ca.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_ca.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon ca / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: Canada
      currency_scope:
      - CAD
    mapping_confidence: exact
    source_evidence: Amazon Canada | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_mx.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_mx.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon mx / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: Mexico
      currency_scope:
      - MXN
    mapping_confidence: exact
    source_evidence: Amazon Mexico | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_uk.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_uk.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon uk / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: UK
      currency_scope:
      - GBP
    mapping_confidence: exact
    source_evidence: Amazon UK | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_de.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_de.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon de / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: Germany
      currency_scope:
      - EUR
    mapping_confidence: exact
    source_evidence: Amazon Germany | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_fr.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_fr.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon fr / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: France
      currency_scope:
      - EUR
    mapping_confidence: exact
    source_evidence: Amazon France | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_es.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_es.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon es / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: Spain
      currency_scope:
      - EUR
    mapping_confidence: exact
    source_evidence: Amazon Spain | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_se.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_se.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon se / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: Sweden
      currency_scope:
      - SEK
    mapping_confidence: exact
    source_evidence: Amazon Sweden | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_ae.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_ae.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon ae / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: UAE
      currency_scope:
      - AED
    mapping_confidence: exact
    source_evidence: Amazon UAE | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.amazon_ksa.primary.amazon_settlement
  canonical_id: account_data_binding.rosenza_international_trading_llc.amazon_ksa.primary.amazon_settlement
  name: account data binding / rosenza international trading llc / amazon ksa / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
    table_id: table.zs_observe.amazon_settlement
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: Settlement
    logical_scope:
      region_or_market: KSA
      currency_scope:
      - SAR
    mapping_confidence: exact
    source_evidence: Amazon KSA | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
  canonical_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
  name: account data binding / rosenza international trading llc / shopify d2c / primary / shopify oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.04_shopify
  fields:
    platform_account_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    table_canonical_status: canonical
    scope_keys:
    - business_key: client_group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
      source: client_identity_doc
      notes: shopify_d2c_oms_v2.md describes group_id as the tenant/client identifier column; keep it in Account Data Binding,
        not on generic table/metric cards.
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 133
      data_type: integer
      source: client_identity_doc
      notes: Client-specific sub-entity/file-scope filter. This belongs in Account Data Binding, not on Group/Table/Metric
        cards.
    data_type_configured: D2C OMS
    logical_scope:
      region_or_market: D2C/global
      currency_scope:
      - USD
      - CAD
      - MXN
      - GBP
      - EUR
      - SEK
      - AED
      - SAR
    mapping_confidence: exact
    source_evidence: Shopify | D2C | OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_oms
      source_documents:
      - logistics_domain.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Runtime scope uses client group_id and group_level_id from the client identity document. Do not move these filters into
      generic platform/domain cards.
    original_bad_state_status:
      status: active
      active: true
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  canonical_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  name: Rosenza Amazon international marketplaces
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  description: All Rosenza Amazon marketplace contexts currently canonical-mappable.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    scope_name: Rosenza Amazon international marketplaces
    scope_type: marketplace_settlement_scope
    platform_account_ids:
    - platform_account.rosenza_international_trading_llc.amazon_us.primary
    - platform_account.rosenza_international_trading_llc.amazon_ca.primary
    - platform_account.rosenza_international_trading_llc.amazon_mx.primary
    - platform_account.rosenza_international_trading_llc.amazon_uk.primary
    - platform_account.rosenza_international_trading_llc.amazon_de.primary
    - platform_account.rosenza_international_trading_llc.amazon_fr.primary
    - platform_account.rosenza_international_trading_llc.amazon_es.primary
    - platform_account.rosenza_international_trading_llc.amazon_se.primary
    - platform_account.rosenza_international_trading_llc.amazon_ae.primary
    - platform_account.rosenza_international_trading_llc.amazon_ksa.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.rosenza_international_trading_llc.shopify_d2c
  canonical_id: business_scope_set.rosenza_international_trading_llc.shopify_d2c
  name: Rosenza Shopify D2C
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.04_shopify
  description: Shopify OMS scope for Rosenza D2C store.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    scope_name: Rosenza Shopify D2C
    scope_type: d2c_oms_scope
    platform_account_ids:
    - platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
  canonical_id: business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
  name: Rosenza Middle East marketplaces pending platform context
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.03_noon
  - ev.rosenza_international_trading_llc.docx.row.04_active_sales_channels_americas_middle_east.04_namshi
  description: Noon and Namshi coverage exists in client source but canonical platform cards/tables are not yet present.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    scope_name: Rosenza Middle East marketplaces pending platform context
    scope_type: marketplace_pending_context_scope
    platform_account_ids:
    - platform_account.rosenza_international_trading_llc.noon_me.primary
    - platform_account.rosenza_international_trading_llc.namshi_me.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_scope_set
  card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  canonical_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  name: Rosenza cross-region FX rollup scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.01_identity
  description: Cross-region rollup scope requiring FX normalization across USD, CAD, MXN, GBP, EUR, SEK, AED, and SAR.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    scope_name: Rosenza cross-region FX rollup scope
    scope_type: reporting_scope
    platform_account_ids:
    - platform_account.rosenza_international_trading_llc.amazon_us.primary
    - platform_account.rosenza_international_trading_llc.amazon_ca.primary
    - platform_account.rosenza_international_trading_llc.amazon_mx.primary
    - platform_account.rosenza_international_trading_llc.amazon_uk.primary
    - platform_account.rosenza_international_trading_llc.amazon_de.primary
    - platform_account.rosenza_international_trading_llc.amazon_fr.primary
    - platform_account.rosenza_international_trading_llc.amazon_es.primary
    - platform_account.rosenza_international_trading_llc.amazon_se.primary
    - platform_account.rosenza_international_trading_llc.amazon_ae.primary
    - platform_account.rosenza_international_trading_llc.amazon_ksa.primary
    - platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    - platform_account.rosenza_international_trading_llc.noon_me.primary
    - platform_account.rosenza_international_trading_llc.namshi_me.primary
    account_data_binding_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  canonical_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  name: Rosenza Amazon marketplace OMS/settlement/returns reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.01_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.02_amazon
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.03_amazon
  - ev.rosenza_international_trading_llc.docx.row.03_active_sales_channels_americas_europe.01_amazon
  description: Amazon flow using canonical Amazon OMS/settlement/returns/fee-preview where configured. Non-US Amazon contexts
    are settlement-only per client source.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    flow_name: Rosenza Amazon marketplace OMS/settlement/returns reconciliation
    flow_type: marketplace_oms_settlement_returns
    participant_platform_account_ids:
    - platform_account.rosenza_international_trading_llc.amazon_us.primary
    - platform_account.rosenza_international_trading_llc.amazon_ca.primary
    - platform_account.rosenza_international_trading_llc.amazon_mx.primary
    - platform_account.rosenza_international_trading_llc.amazon_uk.primary
    - platform_account.rosenza_international_trading_llc.amazon_de.primary
    - platform_account.rosenza_international_trading_llc.amazon_fr.primary
    - platform_account.rosenza_international_trading_llc.amazon_es.primary
    - platform_account.rosenza_international_trading_llc.amazon_se.primary
    - platform_account.rosenza_international_trading_llc.amazon_ae.primary
    - platform_account.rosenza_international_trading_llc.amazon_ksa.primary
    business_scope_set_ids:
    - business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
    required_runtime_resolution: []
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.rosenza_international_trading_llc.shopify_d2c_oms
  canonical_id: business_flow_binding.rosenza_international_trading_llc.shopify_d2c_oms
  name: Rosenza Shopify D2C OMS flow
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.02_active_sales_channels_americas
  - ev.rosenza_international_trading_llc.docx.row.02_active_sales_channels_americas.04_shopify
  description: D2C OMS flow for Shopify. No payment gateway account is configured in source; settlement-to-bank/PG bindings
    are not created.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    flow_name: Rosenza Shopify D2C OMS flow
    flow_type: d2c_oms
    participant_platform_account_ids:
    - platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    business_scope_set_ids:
    - business_scope_set.rosenza_international_trading_llc.shopify_d2c
    required_runtime_resolution: []
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  canonical_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  name: Rosenza marketplace settlement to bank pending bank binding
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.01_identity
  description: Client states settlements are via marketplace payouts, but no bank account/bank-statement binding is provided.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    flow_name: Rosenza marketplace settlement to bank pending bank binding
    flow_type: marketplace_to_bank
    participant_platform_account_ids:
    - platform_account.rosenza_international_trading_llc.amazon_us.primary
    - platform_account.rosenza_international_trading_llc.amazon_ca.primary
    - platform_account.rosenza_international_trading_llc.amazon_mx.primary
    - platform_account.rosenza_international_trading_llc.amazon_uk.primary
    - platform_account.rosenza_international_trading_llc.amazon_de.primary
    - platform_account.rosenza_international_trading_llc.amazon_fr.primary
    - platform_account.rosenza_international_trading_llc.amazon_es.primary
    - platform_account.rosenza_international_trading_llc.amazon_se.primary
    - platform_account.rosenza_international_trading_llc.amazon_ae.primary
    - platform_account.rosenza_international_trading_llc.amazon_ksa.primary
    - platform_account.rosenza_international_trading_llc.noon_me.primary
    - platform_account.rosenza_international_trading_llc.namshi_me.primary
    business_scope_set_ids:
    - business_scope_set.rosenza_international_trading_llc.fx_rollup
    required_runtime_resolution:
    - bank_platform_account
    - bank_statement_account_data_binding
    - per-region settlement currency/account mapping
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.rosenza_international_trading_llc.middle_east_marketplaces_pending_context
  canonical_id: business_flow_binding.rosenza_international_trading_llc.middle_east_marketplaces_pending_context
  name: Rosenza Noon/Namshi Middle East flow pending platform context
  status: draft
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Rosenza International Trading L.docx
  evidence_refs:
  - ev.rosenza_international_trading_llc.docx.section.01_identity
  description: Middle East marketplaces are configured but not query-routable until canonical context exists.
  fields:
    tenant_id: tenant.rosenza_international_trading_llc
    group_id: group.rosenza_international_trading_llc.mensa_brands
    flow_name: Rosenza Noon/Namshi Middle East flow pending platform context
    flow_type: marketplace_oms_settlement
    participant_platform_account_ids:
    - platform_account.rosenza_international_trading_llc.noon_me.primary
    - platform_account.rosenza_international_trading_llc.namshi_me.primary
    business_scope_set_ids:
    - business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
    required_runtime_resolution:
    - noon platform markdown
    - namshi platform markdown
    - Noon/Namshi table IDs and schemas
    source_evidence: null
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: draft
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_data_type: OMS
  mapped_table_id: table.zs_observe.amazon_oms
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon US | OMS
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_returns
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon US | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_returns
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_data_type: Returns
  mapped_table_id: table.zs_observe.amazon_returns
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon US | Returns
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_returns
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_data_type: Fee preview
  mapped_table_id: table.zs_observe.amazon_fee_preview
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon US | Fee preview
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_returns
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon Canada | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon Mexico | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon UK | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon Germany | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon France | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon Spain | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon Sweden | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon UAE | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  source_data_type: Settlement
  mapped_table_id: table.zs_observe.amazon_settlement
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Amazon KSA | Settlement
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  platform_account_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  source_data_type: D2C OMS
  mapped_table_id: table.zs_observe.shopify_oms
  mapping_confidence: exact
  table_canonical_status: canonical
  status: active
  source_evidence: Shopify | D2C | OMS
  resolved_canonical_mapped_now:
  - table.zs_observe.shopify_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  source_data_type: OMS order report + export report, Settlement, Noon/Namshi ASIN-SKU lookup
  source_platform: Noon
  mapped_table_id: null
  mapping_confidence: not_mapped_canonical_context_missing
  table_canonical_status: missing_platform_context
  status: draft_gap
  reason: No Noon canonical marketplace/platform markdown or table cards in uploaded platform corpus.
  recommended_future_card_or_table: platform.noon, platform_context.noon.middle_east, table.zs_observe.noon_oms, table.zs_observe.noon_settlement,
    table.zs_observe.noon_namshi_lookup
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- client: Rosenza International Trading L.L.C
  source_data_type: OMS order report + return report + KSA export, Settlement, Noon/Namshi ASIN-SKU lookup
  source_platform: Namshi
  mapped_table_id: null
  mapping_confidence: not_mapped_canonical_context_missing
  table_canonical_status: missing_platform_context
  status: draft_gap
  reason: No Namshi canonical marketplace/platform markdown or table cards in uploaded platform corpus.
  recommended_future_card_or_table: platform.namshi, platform_context.namshi.middle_east, table.zs_observe.namshi_oms, table.zs_observe.namshi_returns,
    table.zs_observe.namshi_settlement, table.zs_observe.noon_namshi_lookup
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.rosenza_international_trading_llc.has_group.51e6f6f1ff39
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.rosenza_international_trading_llc
  target_card_id: group.rosenza_international_trading_llc.mensa_brands
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_GROUP
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.01769a0ab675
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.b5fba406388b
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.10495d02f80f
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.cce6f370329e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.5e06a07df201
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_oms
  target_card_id: table.zs_observe.amazon_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.7abd8fc86036
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.6d26c7fd936e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.988df7019ecd
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.d8572d613580
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_returns
  target_card_id: table.zs_observe.amazon_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.d331f2bcbf2d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_fee_preview
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.0625114bdc7e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_fee_preview
  target_card_id: table.zs_observe.amazon_fee_preview
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.ed10a37c595b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.fa129f10b663
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.87263861a6b5
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.9e586946cf80
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_ca.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.f79b3e2d8a06
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_ca.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.d4f24947c399
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.475f21698814
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.c1b9369ced69
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.83c8a7092504
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_mx.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.1803a820ddc1
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_mx.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.fed9bb50c9c5
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.4e2d868605e9
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.f3c298a40227
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.94e4b90e58b9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_uk.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.a197c89c2d00
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_uk.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.d41ef94c052c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.4a7d23da4016
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.3b48514511c5
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.2f9d9feeaefb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_de.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.f989506674af
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_de.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.c338fdc3a168
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.107ec351a788
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.dc5ae527e067
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.81c48434dac6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_fr.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.cf5045bd9d49
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_fr.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.f71e170853c4
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.3549a60f073a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.50478512cf4d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.f601f7f74112
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_es.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.e027b21a8d6d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_es.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.5ba3f0703746
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.0d34b57e72f8
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.4c2dbd4d975e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.b39a177c6f8c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_se.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.9b16fc9f3f04
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_se.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.392dcd9c85ae
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.7b68c2aa806e
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.7dea4142aa4a
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.2b3c3285f067
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_ae.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.886122273062
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_ae.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.c50c4d988046
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.3e24ab05edb8
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.1759e616d36f
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  target_card_id: platform_context.amazon.international
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.2840de618198
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.amazon_ksa.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.984fc298daba
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.amazon_ksa.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.c2146643d4f1
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.uses_platform.feaa87ea49fb
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  target_card_id: platform.shopify
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.rosenza_international_trading_llc.uses_platform_context.a61d6c926df3
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  target_card_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.rosenza_international_trading_llc.has_account_data_binding.7189a824c527
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  target_card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.rosenza_international_trading_llc.binds_to_table.66ef5819b871
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
  target_card_id: table.zs_observe.shopify_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.b185ca61256d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.has_platform_account.b985e8eab174
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.has_business_scope_set.a8f9e4551fb2
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.d94ee5711d10
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.47e3dada2053
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.8115349e909f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.bf1fee9bd64d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.57b8431c6e4b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.1fcaa82dbf02
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.e31183e44357
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.8a15998dcecc
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.1f79a5a3c2ad
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.20ab517d9de5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.has_business_scope_set.c20f3c69e233
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_scope_set.rosenza_international_trading_llc.shopify_d2c
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.f63e71671708
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.shopify_d2c
  target_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.has_business_scope_set.81861f4eecf9
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.7f9ab4d630c8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
  target_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.14b1d65e4ee8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
  target_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.has_business_scope_set.fd34620267b5
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.1e06b0a498ed
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.486b7ac74be2
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.3bf4c5b79977
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.308f38f9f819
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.9b2b92a7ff2d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.7bfdcf8701c8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.18bccbe99cce
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.c23a9e35756f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.889dad4aae92
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.878e44bb700e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.1723b321bc50
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.09b1f4e47111
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.includes_platform_account.a2e46c7235fe
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  target_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.rosenza_international_trading_llc.has_business_flow_binding.9434003e100b
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.rosenza_international_trading_llc.uses_business_scope_set.a76e7595012f
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: business_scope_set.rosenza_international_trading_llc.amazon_international_marketplaces
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.d1dcbd92bd69
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.19774c607694
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.0d895b802fc8
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.1c9bb8a5cfc7
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.cdd647e5f003
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.ee50073ab29b
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.d5e44511eff1
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.d8fed7f90342
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.3d1b7736425c
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.5ab0c983b9ea
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.amazon_marketplace_reconciliation
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_business_flow_binding.f1fc55c7dc79
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_flow_binding.rosenza_international_trading_llc.shopify_d2c_oms
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.rosenza_international_trading_llc.uses_business_scope_set.d01426d9a264
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.rosenza_international_trading_llc.shopify_d2c_oms
  target_card_id: business_scope_set.rosenza_international_trading_llc.shopify_d2c
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.a7717345a736
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.shopify_d2c_oms
  target_card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_business_flow_binding.0207ff0f78ab
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.rosenza_international_trading_llc.uses_business_scope_set.c05fac1fcb5f
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: business_scope_set.rosenza_international_trading_llc.fx_rollup
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.95d881cb7c64
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_us.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.a2cd29b84ca0
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ca.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.fe7f5f5e0ef4
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_mx.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.0c85ac78ce13
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_uk.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.eff5e55ae4a3
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_de.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.c6323cb1b867
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_fr.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.170f9530731b
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_es.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.051e3a12d6da
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_se.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.6de9c916651e
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ae.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.95e7214193aa
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.amazon_ksa.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.75ba1c66f2d8
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.3aa28a2fea25
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.marketplace_settlement_to_bank_pending_bank
  target_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_business_flow_binding.d5db2e384406
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.rosenza_international_trading_llc.mensa_brands
  target_card_id: business_flow_binding.rosenza_international_trading_llc.middle_east_marketplaces_pending_context
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.rosenza_international_trading_llc.uses_business_scope_set.09fc2cb3e083
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.rosenza_international_trading_llc.middle_east_marketplaces_pending_context
  target_card_id: business_scope_set.rosenza_international_trading_llc.middle_east_pending_context
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.679b0c994824
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.middle_east_marketplaces_pending_context
  target_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
- edge_id: edge.rosenza_international_trading_llc.has_flow_participant.228f105c7fa7
  edge_type: HAS_FLOW_PARTICIPANT
  canonical_edge_type: HAS_FLOW_PARTICIPANT
  source_card_id: business_flow_binding.rosenza_international_trading_llc.middle_east_marketplaces_pending_context
  target_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_FLOW_PARTICIPANT
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.noon
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.noon
  original_edge:
    source: platform_account.rosenza_international_trading_llc.noon_me.primary
    edge: USES_PLATFORM
    target: platform.noon
- source_card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.noon.middle_east
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.noon.middle_east
  original_edge:
    source: platform_account.rosenza_international_trading_llc.noon_me.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.noon.middle_east
- source_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.namshi
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.namshi
  original_edge:
    source: platform_account.rosenza_international_trading_llc.namshi_me.primary
    edge: USES_PLATFORM
    target: platform.namshi
- source_card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.namshi.middle_east
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.namshi.middle_east
  original_edge:
    source: platform_account.rosenza_international_trading_llc.namshi_me.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.namshi.middle_east
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: platform_context.namshi.middle_east
  missing_artifacts:
  - platform_context.namshi.middle_east
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.namshi_me.primary
  generated_by_refactor: true
- platform_or_area: platform_context.noon.middle_east
  missing_artifacts:
  - platform_context.noon.middle_east
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.noon_me.primary
  generated_by_refactor: true
- platform_or_area: platform.namshi
  missing_artifacts:
  - platform.namshi
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.namshi_me.primary
  generated_by_refactor: true
- platform_or_area: platform.noon
  missing_artifacts:
  - platform.noon
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.noon_me.primary
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- severity: medium
  item: Confirm Rosenza default reporting currency. Source lists eight currencies and requires FX normalization; this pack
    uses USD as a working default because no reporting currency was specified.
  review_resolution_status: open
- severity: high
  item: Add bank account and bank-statement Account Data Binding cards before activating marketplace_to_bank flows.
  review_resolution_status: open
- severity: high
  item: Add Noon and Namshi canonical platform context/table cards before routing Middle East marketplace queries.
  review_resolution_status: open
- severity: medium
  item: Confirm whether Amazon region/country should be represented by source table columns or only by platform account logical
    scope.
  review_resolution_status: open
- severity: medium
  item: Confirm external seller/store/account identifiers for all marketplace and Shopify accounts.
  review_resolution_status: open
- item: platform_context.namshi.middle_east
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.namshi_me.primary
  generated_by_refactor: true
- item: platform_context.noon.middle_east
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.noon_me.primary
  generated_by_refactor: true
- item: platform.namshi
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.namshi_me.primary
  generated_by_refactor: true
- item: platform.noon
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.rosenza_international_trading_llc.noon_me.primary
  generated_by_refactor: true
resolved_review_items: []
non_blocking_declared_semantic_reference_gaps: []
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 37
  refactored_card_count: 37
  original_edge_count: 131
  refactored_edge_count: 127
  blocked_edge_count: 4
  source_evidence_count: 20
  source_row_evidence_count: 15
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 13
    account_data_binding: 14
    business_scope_set: 4
    business_flow_binding: 4
  status_counts:
    active: 32
    review_required: 2
    draft: 3
  review_status_counts:
    accepted: 32
    review_required: 5
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 4
  canonical_resolution_gap_type_counts:
    platform_id: 2
    platform_context_id: 2
  status_correction_count: 2
  status_changes:
  - card_id: platform_account.rosenza_international_trading_llc.noon_me.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.rosenza_international_trading_llc.namshi_me.primary
    card_type: platform_account
    from_status: draft
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  id_or_source_replacement_count: 19
  id_or_source_replacements:
  - card_id: group.rosenza_international_trading_llc.mensa_brands
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_returns
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_us.primary.amazon_fee_preview
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_ca.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_mx.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_uk.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_de.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_fr.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_es.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_se.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_ae.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.amazon_ksa.primary.amazon_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: platform_account.rosenza_international_trading_llc.shopify_d2c.primary
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.rosenza_international_trading_llc.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  resolved_prior_review_count: 0
  open_review_count: 9
  future_context_gap_count: 4
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 0
  non_blocking_declared_semantic_reference_gap_type_counts: {}
  edge_status_counts:
    emitted: 127
    blocked_unresolved: 4
```
