# Pine Labs — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: pine_labs_client_runtime_cards_v2_1_refactored
  version: v2_1_refactored
  generated_date: '2026-05-24'
  created_for: Pine Labs
  client_slug: pine_labs
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  source_client_profile:
    business: Gift card / stored value card issuer and distributor
    geography: India domestic
    source_group_id: 44
    source_group_level_id: 168
    source_group_name: Pine Labs Private Limited
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: Client/runtime packs contain tenant, group, platform_account, account_data_binding, business_scope_set, and
    business_flow_binding cards. Active Account Data Bindings are emitted only when currently available canonical platform
    context, client-table evidence, or explicit client table registry evidence supports the table. Configured artifacts without
    table support are preserved as future_context_gaps and review_required bindings instead of invented active mappings.
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  source_json_bad_state: pine_labs_runtime_cards_v1_0.json
  source_docx: Pine Labs.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.global_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.international_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.increff.in.wms_operations: platform_context.increff.in
      platform_context.shiprocket.in.oms_order_source: platform_context.shiprocket.in
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: pine_labs_runtime_cards_v1_0.json
  source_docx: Pine Labs.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Remapped role-specific Shopify/Increff/Shiprocket/Amazon/Paytm/PhonePe context aliases to uploaded broader canonical contexts
    while preserving the role in account fields.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.amica_technologies.primary.amica_technologies_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  status_changes:
  - card_id: platform_account.pine_labs.phonepe_giftcard.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.maximize_pay.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.dreamplug.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.payu_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.indusind_bank.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.giftcard_reference_reports.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.escrow_treasury.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.pine_labs.tata_digital.primary.tata_digital_settlement
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  - card_id: business_flow_binding.pine_labs.soa_ar_collection_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  blocked_edge_count: 48
  canonical_resolution_gap_count: 80
  resolved_prior_review_count: 0
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.pine_labs.docx.section.01_identity
  source_document: Pine Labs.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L13
  summary: '* Business: Gift card / stored value card (SVC) issuer and distributor

    * Primary platform: Woohoo (gift card OMS and distribution platform)

    * Distribution partners: Amazon, Flipkart, Paytm, PhonePe, Pinelabs (POS), and multiple fintech platforms

    * Bank: IndusInd Bank (primary settlement bank)

    * Payment gateways: Cashfree, PayU, Paytm, PhonePe

    * Geography: India domestic

    * GROUP LEVEL ID : 168

    * GROUP ID :  44

    * CLIENT NAME : **Pine Labs**

    * GROUP NAME : **Pine Labs Private Limited**

    > This is not a product/goods seller. Revenue and reconciliation logic revolves entirely around gift card issuance, distribution,
    redemption, breakage, and liability — fundamentally different from standard e-commerce flows.'
  raw_lines:
  - '* Business: Gift card / stored value card (SVC) issuer and distributor'
  - '* Primary platform: Woohoo (gift card OMS and distribution platform)'
  - '* Distribution partners: Amazon, Flipkart, Paytm, PhonePe, Pinelabs (POS), and multiple fintech platforms'
  - '* Bank: IndusInd Bank (primary settlement bank)'
  - '* Payment gateways: Cashfree, PayU, Paytm, PhonePe'
  - '* Geography: India domestic'
  - '* GROUP LEVEL ID : 168'
  - '* GROUP ID :  44'
  - '* CLIENT NAME : **Pine Labs**'
  - '* GROUP NAME : **Pine Labs Private Limited**'
  - '> This is not a product/goods seller. Revenue and reconciliation logic revolves entirely around gift card issuance, distribution,
    redemption, breakage, and liability — fundamentally different from standard e-commerce flows.'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.section.02_core_oms_and_order_data
  source_document: Pine Labs.docx
  source_section: Core OMS and order data
  evidence_type: docx_section
  source_lines: L14-L19
  summary: '| System | Data types configured |

    |--------|-----------------------|

    | Woohoo | OMS, OMS rectified (corrections), Adhoc |

    | Pinelab (Amazon) | Amazon OMS via Pinelabs POS integration |

    | Amazon Seller Flex | Fulfilment data (seller-managed logistics via Amazon) |'
  raw_lines:
  - '| System | Data types configured |'
  - '|--------|-----------------------|'
  - '| Woohoo | OMS, OMS rectified (corrections), Adhoc |'
  - '| Pinelab (Amazon) | Amazon OMS via Pinelabs POS integration |'
  - '| Amazon Seller Flex | Fulfilment data (seller-managed logistics via Amazon) |'
  row_count: 3
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  source_document: Pine Labs.docx
  source_section: Core OMS and order data
  evidence_type: configured_source_row
  source_line: L17
  row_key: Woohoo
  columns:
    system: Woohoo
    data_types_configured: OMS, OMS rectified (corrections), Adhoc
  raw_text: '| Woohoo | OMS, OMS rectified (corrections), Adhoc |'
  summary: 'Woohoo: system=Woohoo; data_types_configured=OMS, OMS rectified (corrections), Adhoc'
  confidence: high
- id: ev.pine_labs.docx.row.02_core_oms_and_order_data.02_pinelab_amazon
  source_document: Pine Labs.docx
  source_section: Core OMS and order data
  evidence_type: configured_source_row
  source_line: L18
  row_key: Pinelab (Amazon)
  columns:
    system: Pinelab (Amazon)
    data_types_configured: Amazon OMS via Pinelabs POS integration
  raw_text: '| Pinelab (Amazon) | Amazon OMS via Pinelabs POS integration |'
  summary: 'Pinelab (Amazon): system=Pinelab (Amazon); data_types_configured=Amazon OMS via Pinelabs POS integration'
  confidence: high
- id: ev.pine_labs.docx.row.02_core_oms_and_order_data.03_amazon_seller_flex
  source_document: Pine Labs.docx
  source_section: Core OMS and order data
  evidence_type: configured_source_row
  source_line: L19
  row_key: Amazon Seller Flex
  columns:
    system: Amazon Seller Flex
    data_types_configured: Fulfilment data (seller-managed logistics via Amazon)
  raw_text: '| Amazon Seller Flex | Fulfilment data (seller-managed logistics via Amazon) |'
  summary: 'Amazon Seller Flex: system=Amazon Seller Flex; data_types_configured=Fulfilment data (seller-managed logistics
    via Amazon)'
  confidence: high
- id: ev.pine_labs.docx.section.03_distribution_channel_settlements_marketplace_platform_partners
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: docx_section
  source_lines: L21-L29
  summary: '| Channel / Partner | Data types configured | Notes |

    |-------------------|-----------------------|-------|

    | Amazon India      | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper | NAB = Non-Amazon
    Business gift cards; SVC = Stored Value Card transactions |

    | Flipkart          | Settlement, Adhoc (Ads/TDS/Rebates/VAS) | Standard marketplace settlement |

    | Paytm             | Gift card settlement, Pay-in (multi-sheet) | Separate pipelines for GC orders vs payment gateway
    |

    | PhonePe           | Settlement report, Mapper | Mapper = PhonePe product/SKU reference table |

    | Nearby            | Settlement → nearby_marketplace |       |

    | Woohoo Adhoc      | Adhoc adjustments → woohoo_oms_adhoc |       |'
  raw_lines:
  - '| Channel / Partner | Data types configured | Notes |'
  - '|-------------------|-----------------------|-------|'
  - '| Amazon India      | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper | NAB =
    Non-Amazon Business gift cards; SVC = Stored Value Card transactions |'
  - '| Flipkart          | Settlement, Adhoc (Ads/TDS/Rebates/VAS) | Standard marketplace settlement |'
  - '| Paytm             | Gift card settlement, Pay-in (multi-sheet) | Separate pipelines for GC orders vs payment gateway
    |'
  - '| PhonePe           | Settlement report, Mapper | Mapper = PhonePe product/SKU reference table |'
  - '| Nearby            | Settlement → nearby_marketplace |       |'
  - '| Woohoo Adhoc      | Adhoc adjustments → woohoo_oms_adhoc |       |'
  row_count: 7
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.01_channel_partner
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L22
  row_key: Channel / Partner
  columns:
    col_1: Channel / Partner
    col_2: Data types configured
    col_3: Notes
  raw_text: '| Channel / Partner | Data types configured | Notes |'
  summary: 'Channel / Partner: col_1=Channel / Partner; col_2=Data types configured; col_3=Notes'
  confidence: high
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L24
  row_key: Amazon India
  columns:
    col_1: Amazon India
    col_2: GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper
    col_3: NAB = Non-Amazon Business gift cards; SVC = Stored Value Card transactions
  raw_text: '| Amazon India      | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper
    | NAB = Non-Amazon Business gift cards; SVC = Stored Value Card transactions |'
  summary: 'Amazon India: col_1=Amazon India; col_2=GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions,
    mapper; col_3=NAB = Non-Amazon Business gift cards; SVC = Stored Value Card transactions'
  confidence: high
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L25
  row_key: Flipkart
  columns:
    col_1: Flipkart
    col_2: Settlement, Adhoc (Ads/TDS/Rebates/VAS)
    col_3: Standard marketplace settlement
  raw_text: '| Flipkart          | Settlement, Adhoc (Ads/TDS/Rebates/VAS) | Standard marketplace settlement |'
  summary: 'Flipkart: col_1=Flipkart; col_2=Settlement, Adhoc (Ads/TDS/Rebates/VAS); col_3=Standard marketplace settlement'
  confidence: high
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L26
  row_key: Paytm
  columns:
    col_1: Paytm
    col_2: Gift card settlement, Pay-in (multi-sheet)
    col_3: Separate pipelines for GC orders vs payment gateway
  raw_text: '| Paytm             | Gift card settlement, Pay-in (multi-sheet) | Separate pipelines for GC orders vs payment
    gateway |'
  summary: 'Paytm: col_1=Paytm; col_2=Gift card settlement, Pay-in (multi-sheet); col_3=Separate pipelines for GC orders vs
    payment gateway'
  confidence: high
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L27
  row_key: PhonePe
  columns:
    col_1: PhonePe
    col_2: Settlement report, Mapper
    col_3: Mapper = PhonePe product/SKU reference table
  raw_text: '| PhonePe           | Settlement report, Mapper | Mapper = PhonePe product/SKU reference table |'
  summary: 'PhonePe: col_1=PhonePe; col_2=Settlement report, Mapper; col_3=Mapper = PhonePe product/SKU reference table'
  confidence: high
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.06_nearby
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L28
  row_key: Nearby
  columns:
    col_1: Nearby
    col_2: Settlement → nearby_marketplace
    col_3: ''
  raw_text: '| Nearby            | Settlement → nearby_marketplace |       |'
  summary: 'Nearby: col_1=Nearby; col_2=Settlement → nearby_marketplace; col_3='
  confidence: high
- id: ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.07_woohoo_adhoc
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners
  evidence_type: configured_source_row
  source_line: L29
  row_key: Woohoo Adhoc
  columns:
    col_1: Woohoo Adhoc
    col_2: Adhoc adjustments → woohoo_oms_adhoc
    col_3: ''
  raw_text: '| Woohoo Adhoc      | Adhoc adjustments → woohoo_oms_adhoc |       |'
  summary: 'Woohoo Adhoc: col_1=Woohoo Adhoc; col_2=Adhoc adjustments → woohoo_oms_adhoc; col_3='
  confidence: high
- id: ev.pine_labs.docx.section.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: docx_section
  source_lines: L30-L40
  summary: '| Partner | Pipeline target |

    |---------|-----------------|

    | Maximize Pay | maximize_settlement (multi-sheet) |

    | Navi    | navi_settlement (multi-sheet) |

    | DreamPlug | dreamplug_settlement |

    | Tata Digital | tata_digital_settlement |

    | Amica Technologies | amica_technologies_settlement |

    | First Pay | first_pay_settlement |

    | Red Giraffe | red_giraffe_settlement |

    | Gullak Technologies | gullak_technologies_settlement |'
  raw_lines:
  - '| Partner | Pipeline target |'
  - '|---------|-----------------|'
  - '| Maximize Pay | maximize_settlement (multi-sheet) |'
  - '| Navi    | navi_settlement (multi-sheet) |'
  - '| DreamPlug | dreamplug_settlement |'
  - '| Tata Digital | tata_digital_settlement |'
  - '| Amica Technologies | amica_technologies_settlement |'
  - '| First Pay | first_pay_settlement |'
  - '| Red Giraffe | red_giraffe_settlement |'
  - '| Gullak Technologies | gullak_technologies_settlement |'
  row_count: 8
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.01_maximize_pay
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L33
  row_key: Maximize Pay
  columns:
    partner: Maximize Pay
    pipeline_target: maximize_settlement (multi-sheet)
  raw_text: '| Maximize Pay | maximize_settlement (multi-sheet) |'
  summary: 'Maximize Pay: partner=Maximize Pay; pipeline_target=maximize_settlement (multi-sheet)'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.02_navi
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L34
  row_key: Navi
  columns:
    partner: Navi
    pipeline_target: navi_settlement (multi-sheet)
  raw_text: '| Navi    | navi_settlement (multi-sheet) |'
  summary: 'Navi: partner=Navi; pipeline_target=navi_settlement (multi-sheet)'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.03_dreamplug
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L35
  row_key: DreamPlug
  columns:
    partner: DreamPlug
    pipeline_target: dreamplug_settlement
  raw_text: '| DreamPlug | dreamplug_settlement |'
  summary: 'DreamPlug: partner=DreamPlug; pipeline_target=dreamplug_settlement'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.04_tata_digital
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L36
  row_key: Tata Digital
  columns:
    partner: Tata Digital
    pipeline_target: tata_digital_settlement
  raw_text: '| Tata Digital | tata_digital_settlement |'
  summary: 'Tata Digital: partner=Tata Digital; pipeline_target=tata_digital_settlement'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.05_amica_technologies
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L37
  row_key: Amica Technologies
  columns:
    partner: Amica Technologies
    pipeline_target: amica_technologies_settlement
  raw_text: '| Amica Technologies | amica_technologies_settlement |'
  summary: 'Amica Technologies: partner=Amica Technologies; pipeline_target=amica_technologies_settlement'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.06_first_pay
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L38
  row_key: First Pay
  columns:
    partner: First Pay
    pipeline_target: first_pay_settlement
  raw_text: '| First Pay | first_pay_settlement |'
  summary: 'First Pay: partner=First Pay; pipeline_target=first_pay_settlement'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.07_red_giraffe
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L39
  row_key: Red Giraffe
  columns:
    partner: Red Giraffe
    pipeline_target: red_giraffe_settlement
  raw_text: '| Red Giraffe | red_giraffe_settlement |'
  summary: 'Red Giraffe: partner=Red Giraffe; pipeline_target=red_giraffe_settlement'
  confidence: high
- id: ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.08_gullak_technologies
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / Fintech / BNPL / wallet platform settlements
  evidence_type: configured_source_row
  source_line: L40
  row_key: Gullak Technologies
  columns:
    partner: Gullak Technologies
    pipeline_target: gullak_technologies_settlement
  raw_text: '| Gullak Technologies | gullak_technologies_settlement |'
  summary: 'Gullak Technologies: partner=Gullak Technologies; pipeline_target=gullak_technologies_settlement'
  confidence: high
- id: ev.pine_labs.docx.section.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / POS / in-store (Pinelabs)
  evidence_type: docx_section
  source_lines: L41-L48
  summary: '| File | Pipeline target |

    |------|-----------------|

    | Pinelabs commission invoice | pinelabs_commission_invoice |

    | Pinelabs tally | pinelabs_tally  |

    | Pinelabs SOA | pinelabs_soa    |

    | Pinelabs adhoc amount | pinelab_adhoc_amount |

    | Pine PG | pine_payments   |'
  raw_lines:
  - '| File | Pipeline target |'
  - '|------|-----------------|'
  - '| Pinelabs commission invoice | pinelabs_commission_invoice |'
  - '| Pinelabs tally | pinelabs_tally  |'
  - '| Pinelabs SOA | pinelabs_soa    |'
  - '| Pinelabs adhoc amount | pinelab_adhoc_amount |'
  - '| Pine PG | pine_payments   |'
  row_count: 5
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / POS / in-store (Pinelabs)
  evidence_type: configured_source_row
  source_line: L44
  row_key: Pinelabs commission invoice
  columns:
    file: Pinelabs commission invoice
    pipeline_target: pinelabs_commission_invoice
  raw_text: '| Pinelabs commission invoice | pinelabs_commission_invoice |'
  summary: 'Pinelabs commission invoice: file=Pinelabs commission invoice; pipeline_target=pinelabs_commission_invoice'
  confidence: high
- id: ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.02_pinelabs_tally
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / POS / in-store (Pinelabs)
  evidence_type: configured_source_row
  source_line: L45
  row_key: Pinelabs tally
  columns:
    file: Pinelabs tally
    pipeline_target: pinelabs_tally
  raw_text: '| Pinelabs tally | pinelabs_tally  |'
  summary: 'Pinelabs tally: file=Pinelabs tally; pipeline_target=pinelabs_tally'
  confidence: high
- id: ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.03_pinelabs_soa
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / POS / in-store (Pinelabs)
  evidence_type: configured_source_row
  source_line: L46
  row_key: Pinelabs SOA
  columns:
    file: Pinelabs SOA
    pipeline_target: pinelabs_soa
  raw_text: '| Pinelabs SOA | pinelabs_soa    |'
  summary: 'Pinelabs SOA: file=Pinelabs SOA; pipeline_target=pinelabs_soa'
  confidence: high
- id: ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / POS / in-store (Pinelabs)
  evidence_type: configured_source_row
  source_line: L47
  row_key: Pinelabs adhoc amount
  columns:
    file: Pinelabs adhoc amount
    pipeline_target: pinelab_adhoc_amount
  raw_text: '| Pinelabs adhoc amount | pinelab_adhoc_amount |'
  summary: 'Pinelabs adhoc amount: file=Pinelabs adhoc amount; pipeline_target=pinelab_adhoc_amount'
  confidence: high
- id: ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  source_document: Pine Labs.docx
  source_section: Distribution channel settlements / Marketplace / platform partners / POS / in-store (Pinelabs)
  evidence_type: configured_source_row
  source_line: L48
  row_key: Pine PG
  columns:
    file: Pine PG
    pipeline_target: pine_payments
  raw_text: '| Pine PG | pine_payments   |'
  summary: 'Pine PG: file=Pine PG; pipeline_target=pine_payments'
  confidence: high
- id: ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  source_document: Pine Labs.docx
  source_section: Payment gateway reconciliation
  evidence_type: docx_section
  source_lines: L49-L55
  summary: '| Gateway | Pipeline target |

    |---------|-----------------|

    | Cashfree | cashfree_payin  |

    | PayU    | payu_settlement |

    | Paytm   | paytm_payin (multi-sheet) |

    | PhonePe | phonepe_settlement |'
  raw_lines:
  - '| Gateway | Pipeline target |'
  - '|---------|-----------------|'
  - '| Cashfree | cashfree_payin  |'
  - '| PayU    | payu_settlement |'
  - '| Paytm   | paytm_payin (multi-sheet) |'
  - '| PhonePe | phonepe_settlement |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.06_payment_gateway_reconciliation.01_cashfree
  source_document: Pine Labs.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L52
  row_key: Cashfree
  columns:
    gateway: Cashfree
    pipeline_target: cashfree_payin
  raw_text: '| Cashfree | cashfree_payin  |'
  summary: 'Cashfree: gateway=Cashfree; pipeline_target=cashfree_payin'
  confidence: high
- id: ev.pine_labs.docx.row.06_payment_gateway_reconciliation.02_payu
  source_document: Pine Labs.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L53
  row_key: PayU
  columns:
    gateway: PayU
    pipeline_target: payu_settlement
  raw_text: '| PayU    | payu_settlement |'
  summary: 'PayU: gateway=PayU; pipeline_target=payu_settlement'
  confidence: high
- id: ev.pine_labs.docx.row.06_payment_gateway_reconciliation.03_paytm
  source_document: Pine Labs.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L54
  row_key: Paytm
  columns:
    gateway: Paytm
    pipeline_target: paytm_payin (multi-sheet)
  raw_text: '| Paytm   | paytm_payin (multi-sheet) |'
  summary: 'Paytm: gateway=Paytm; pipeline_target=paytm_payin (multi-sheet)'
  confidence: high
- id: ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  source_document: Pine Labs.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L55
  row_key: PhonePe
  columns:
    gateway: PhonePe
    pipeline_target: phonepe_settlement
  raw_text: '| PhonePe | phonepe_settlement |'
  summary: 'PhonePe: gateway=PhonePe; pipeline_target=phonepe_settlement'
  confidence: high
- id: ev.pine_labs.docx.section.07_bank_statement
  source_document: Pine Labs.docx
  source_section: Bank Statement
  evidence_type: docx_section
  source_lines: L56-L59
  summary: '| Bank | Files configured |

    |------|------------------|

    | IndusInd Bank | Bank statement + correction variant (both → indusind_bank_statement) |'
  raw_lines:
  - '| Bank | Files configured |'
  - '|------|------------------|'
  - '| IndusInd Bank | Bank statement + correction variant (both → indusind_bank_statement) |'
  row_count: 1
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.07_bank_statement.01_indusind_bank
  source_document: Pine Labs.docx
  source_section: Bank Statement
  evidence_type: configured_source_row
  source_line: L59
  row_key: IndusInd Bank
  columns:
    bank: IndusInd Bank
    files_configured: Bank statement + correction variant (both → indusind_bank_statement)
  raw_text: '| IndusInd Bank | Bank statement + correction variant (both → indusind_bank_statement) |'
  summary: 'IndusInd Bank: bank=IndusInd Bank; files_configured=Bank statement + correction variant (both → indusind_bank_statement)'
  confidence: high
- id: ev.pine_labs.docx.section.08_gift_card_specific_reports
  source_document: Pine Labs.docx
  source_section: Gift card specific reports
  evidence_type: docx_section
  source_lines: L60-L64
  summary: '| Report | Pipeline target | Purpose |

    |--------|-----------------|---------|

    | [Amazon.in](http://Amazon.in) mapper | amazon_in_mapper | Amazon product/GC SKU reference |

    | PhonePe mapper | phonepe_mapper  | PhonePe SKU/product reference |'
  raw_lines:
  - '| Report | Pipeline target | Purpose |'
  - '|--------|-----------------|---------|'
  - '| [Amazon.in](http://Amazon.in) mapper | amazon_in_mapper | Amazon product/GC SKU reference |'
  - '| PhonePe mapper | phonepe_mapper  | PhonePe SKU/product reference |'
  row_count: 2
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.08_gift_card_specific_reports.01_amazon_in_http_amazon_in_mapper
  source_document: Pine Labs.docx
  source_section: Gift card specific reports
  evidence_type: configured_source_row
  source_line: L63
  row_key: '[Amazon.in](http://Amazon.in) mapper'
  columns:
    report: '[Amazon.in](http://Amazon.in) mapper'
    pipeline_target: amazon_in_mapper
    purpose: Amazon product/GC SKU reference
  raw_text: '| [Amazon.in](http://Amazon.in) mapper | amazon_in_mapper | Amazon product/GC SKU reference |'
  summary: '[Amazon.in](http://Amazon.in) mapper: report=[Amazon.in](http://Amazon.in) mapper; pipeline_target=amazon_in_mapper;
    purpose=Amazon product/GC SKU reference'
  confidence: high
- id: ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  source_document: Pine Labs.docx
  source_section: Gift card specific reports
  evidence_type: configured_source_row
  source_line: L64
  row_key: PhonePe mapper
  columns:
    report: PhonePe mapper
    pipeline_target: phonepe_mapper
    purpose: PhonePe SKU/product reference
  raw_text: '| PhonePe mapper | phonepe_mapper  | PhonePe SKU/product reference |'
  summary: 'PhonePe mapper: report=PhonePe mapper; pipeline_target=phonepe_mapper; purpose=PhonePe SKU/product reference'
  confidence: high
- id: ev.pine_labs.docx.section.09_escrow_treasury_specific_reports
  source_document: Pine Labs.docx
  source_section: Escrow Treasury Specific reports
  evidence_type: docx_section
  source_lines: L65-L72
  summary: '| Report | Pipeline target | Purpose |

    |--------|-----------------|---------|

    | Revalidation report | revalidation_report | GC expiry extensions |

    | SCLP billing report | sclp_billing_report (DaywiseLiability sheet) | Day-wise stored card liability |

    | Credit limit report | credit_limit_report | Credit-based GC program limits |

    | Ignore card number report | ignore_card_number_report | Cards excluded from reconciliation |

    | Master merchant report | merchant_interest_sheet | Merchant-level interest/liability summary |'
  raw_lines:
  - '| Report | Pipeline target | Purpose |'
  - '|--------|-----------------|---------|'
  - '| Revalidation report | revalidation_report | GC expiry extensions |'
  - '| SCLP billing report | sclp_billing_report (DaywiseLiability sheet) | Day-wise stored card liability |'
  - '| Credit limit report | credit_limit_report | Credit-based GC program limits |'
  - '| Ignore card number report | ignore_card_number_report | Cards excluded from reconciliation |'
  - '| Master merchant report | merchant_interest_sheet | Merchant-level interest/liability summary |'
  row_count: 5
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  source_document: Pine Labs.docx
  source_section: Escrow Treasury Specific reports
  evidence_type: configured_source_row
  source_line: L68
  row_key: Revalidation report
  columns:
    report: Revalidation report
    pipeline_target: revalidation_report
    purpose: GC expiry extensions
  raw_text: '| Revalidation report | revalidation_report | GC expiry extensions |'
  summary: 'Revalidation report: report=Revalidation report; pipeline_target=revalidation_report; purpose=GC expiry extensions'
  confidence: high
- id: ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  source_document: Pine Labs.docx
  source_section: Escrow Treasury Specific reports
  evidence_type: configured_source_row
  source_line: L69
  row_key: SCLP billing report
  columns:
    report: SCLP billing report
    pipeline_target: sclp_billing_report (DaywiseLiability sheet)
    purpose: Day-wise stored card liability
  raw_text: '| SCLP billing report | sclp_billing_report (DaywiseLiability sheet) | Day-wise stored card liability |'
  summary: 'SCLP billing report: report=SCLP billing report; pipeline_target=sclp_billing_report (DaywiseLiability sheet);
    purpose=Day-wise stored card liability'
  confidence: high
- id: ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  source_document: Pine Labs.docx
  source_section: Escrow Treasury Specific reports
  evidence_type: configured_source_row
  source_line: L70
  row_key: Credit limit report
  columns:
    report: Credit limit report
    pipeline_target: credit_limit_report
    purpose: Credit-based GC program limits
  raw_text: '| Credit limit report | credit_limit_report | Credit-based GC program limits |'
  summary: 'Credit limit report: report=Credit limit report; pipeline_target=credit_limit_report; purpose=Credit-based GC
    program limits'
  confidence: high
- id: ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.04_ignore_card_number_report
  source_document: Pine Labs.docx
  source_section: Escrow Treasury Specific reports
  evidence_type: configured_source_row
  source_line: L71
  row_key: Ignore card number report
  columns:
    report: Ignore card number report
    pipeline_target: ignore_card_number_report
    purpose: Cards excluded from reconciliation
  raw_text: '| Ignore card number report | ignore_card_number_report | Cards excluded from reconciliation |'
  summary: 'Ignore card number report: report=Ignore card number report; pipeline_target=ignore_card_number_report; purpose=Cards
    excluded from reconciliation'
  confidence: high
- id: ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.05_master_merchant_report
  source_document: Pine Labs.docx
  source_section: Escrow Treasury Specific reports
  evidence_type: configured_source_row
  source_line: L72
  row_key: Master merchant report
  columns:
    report: Master merchant report
    pipeline_target: merchant_interest_sheet
    purpose: Merchant-level interest/liability summary
  raw_text: '| Master merchant report | merchant_interest_sheet | Merchant-level interest/liability summary |'
  summary: 'Master merchant report: report=Master merchant report; pipeline_target=merchant_interest_sheet; purpose=Merchant-level
    interest/liability summary'
  confidence: high
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.pine_labs
  canonical_id: tenant.pine_labs
  name: Pine Labs
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  description: Gift card / stored value card issuer and distributor using ZenStatement for gift-card issuance, distribution,
    redemption, breakage, liability, payment, bank, and settlement reconciliation.
  fields:
    tenant_name: Pine Labs
    tenant_code: PINE_LABS
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.pine_labs.pine_labs_private_limited
  canonical_id: group.pine_labs.pine_labs_private_limited
  name: Pine Labs Private Limited
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  fields:
    tenant_id: tenant.pine_labs
    group_name: Pine Labs Private Limited
    group_code: PINE_LABS_PRIVATE_LIMITED
    group_type: legal_entity
    business_meaning: Pine Labs Private Limited gift-card operating group. Source client profile uses GROUP ID 44 and GROUP
      LEVEL ID 168; client-table architecture notes also mention Qwikcilver/Pine Labs group_id 391 and group_level_id 65352,
      preserved as a review item.
    country_or_region: India
    default_currency: INR
    source_scope_identifiers:
      group_id: 44
      group_level_id: 168
      representation_rule: Use these values through Account Data Binding scope_keys.
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.pine_labs.woohoo.primary
  canonical_id: platform_account.pine_labs.woohoo.primary
  name: Woohoo gift-card OMS account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.07_woohoo_adhoc
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Woohoo gift-card OMS account
    account_type: giftcard_oms
    account_role: order_source
    source_account_identifier: null
    source_config_text: Woohoo | OMS, OMS rectified (corrections), Adhoc
    country_or_region: India
    declared_platform_id: platform.woohoo
    declared_platform_label: Woohoo gift-card OMS/distribution platform
    declared_platform_context_id: platform_context.woohoo.in.giftcard_oms
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.woohoo
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.woohoo.in.giftcard_oms
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.amazon_gc.primary
  canonical_id: platform_account.pine_labs.amazon_gc.primary
  name: Amazon India gift-card distribution account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.01_amazon_in_http_amazon_in_mapper
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.02_pinelab_amazon
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.03_amazon_seller_flex
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.amazon
    account_name: Amazon India gift-card distribution account
    account_type: marketplace_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Amazon India | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper
    country_or_region: India
    declared_platform_context_id: platform_context.amazon.in.giftcard_distribution
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.amazon.in.giftcard_distribution
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.flipkart_distribution.primary
  canonical_id: platform_account.pine_labs.flipkart_distribution.primary
  name: Flipkart gift-card distribution account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Flipkart gift-card distribution account
    account_type: marketplace_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Flipkart | Settlement, Adhoc (Ads/TDS/Rebates/VAS)
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.flipkart
        source_documents:
        - flipkart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.flipkart.in
        source_documents:
        - flipkart_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.paytm_giftcard.primary
  canonical_id: platform_account.pine_labs.paytm_giftcard.primary
  name: Paytm gift-card distribution account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.03_paytm
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.01_maximize_pay
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.paytm
    account_name: Paytm gift-card distribution account
    account_type: marketplace_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Paytm | Gift card settlement, Pay-in (multi-sheet)
    country_or_region: India
    declared_platform_context_id: platform_context.paytm.in.giftcard_distribution
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.paytm.in.giftcard_distribution
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.phonepe_giftcard.primary
  canonical_id: platform_account.pine_labs.phonepe_giftcard.primary
  name: PhonePe gift-card distribution account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.phonepe
    account_name: PhonePe gift-card distribution account
    account_type: marketplace_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: PhonePe | Settlement report, Mapper
    country_or_region: India
    declared_platform_context_id: platform_context.phonepe.in.giftcard_distribution
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.phonepe
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.phonepe.in.giftcard_distribution
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.pine_labs.nearby.primary
  canonical_id: platform_account.pine_labs.nearby.primary
  name: Nearby marketplace distribution account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.06_nearby
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Nearby marketplace distribution account
    account_type: marketplace_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Nearby | Settlement to nearby_marketplace
    country_or_region: India
    declared_platform_id: platform.nearby_marketplace
    declared_platform_label: platform.nearby_marketplace
    declared_platform_context_id: platform_context.nearby_marketplace.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.nearby_marketplace
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.nearby_marketplace.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.navi.primary
  canonical_id: platform_account.pine_labs.navi.primary
  name: Navi gift-card settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.02_navi
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.navi
    platform_context_id: platform_context.navi.in
    account_name: Navi gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Navi | navi_settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.navi
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.navi.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.tata_digital.primary
  canonical_id: platform_account.pine_labs.tata_digital.primary
  name: Tata Digital gift-card settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.04_tata_digital
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.tata_digital
    platform_context_id: platform_context.tata_digital.in
    account_name: Tata Digital gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Tata Digital | tata_digital_settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.tata_digital
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.tata_digital.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.amica_technologies.primary
  canonical_id: platform_account.pine_labs.amica_technologies.primary
  name: Amica Technologies gift-card settlement account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.05_amica_technologies
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.08_gullak_technologies
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Amica Technologies gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Amica Technologies | amica_technologies_settlement
    country_or_region: India
    declared_platform_id: platform.amica_technologies
    declared_platform_label: platform.amica_technologies
    declared_platform_context_id: platform_context.amica_technologies.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.amica_technologies
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.amica_technologies.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.first_pay.primary
  canonical_id: platform_account.pine_labs.first_pay.primary
  name: First Pay gift-card settlement account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.06_first_pay
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: First Pay gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: First Pay | first_pay_settlement
    country_or_region: India
    declared_platform_id: platform.first_pay
    declared_platform_label: platform.first_pay
    declared_platform_context_id: platform_context.first_pay.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.first_pay
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.first_pay.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.red_giraffe.primary
  canonical_id: platform_account.pine_labs.red_giraffe.primary
  name: Red Giraffe gift-card settlement account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.07_red_giraffe
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Red Giraffe gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Red Giraffe | red_giraffe_settlement
    country_or_region: India
    declared_platform_id: platform.red_giraffe
    declared_platform_label: platform.red_giraffe
    declared_platform_context_id: platform_context.red_giraffe.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.red_giraffe
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.red_giraffe.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.gullak.primary
  canonical_id: platform_account.pine_labs.gullak.primary
  name: Gullak Technologies gift-card settlement account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.08_gullak_technologies
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.05_amica_technologies
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Gullak Technologies gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Gullak Technologies | gullak_technologies_settlement
    country_or_region: India
    declared_platform_id: platform.gullak_technologies
    declared_platform_label: platform.gullak_technologies
    declared_platform_context_id: platform_context.gullak_technologies.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.gullak_technologies
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.gullak_technologies.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.maximize_pay.primary
  canonical_id: platform_account.pine_labs.maximize_pay.primary
  name: Maximize Pay gift-card settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.01_maximize_pay
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Maximize Pay gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: Maximize Pay | maximize_settlement
    country_or_region: India
    declared_platform_id: platform.maximize_pay
    declared_platform_label: platform.maximize_pay
    declared_platform_context_id: platform_context.maximize_pay.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.maximize_pay
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.maximize_pay.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.pine_labs.dreamplug.primary
  canonical_id: platform_account.pine_labs.dreamplug.primary
  name: DreamPlug gift-card settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.03_dreamplug
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: DreamPlug gift-card settlement account
    account_type: fintech_distribution
    account_role: giftcard_distribution_settlement
    source_account_identifier: null
    source_config_text: DreamPlug | dreamplug_settlement
    country_or_region: India
    declared_platform_id: platform.dreamplug
    declared_platform_label: platform.dreamplug
    declared_platform_context_id: platform_context.dreamplug.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.dreamplug
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.dreamplug.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.pine_labs.pinelabs_pos.primary
  canonical_id: platform_account.pine_labs.pinelabs_pos.primary
  name: Pinelabs POS and SOA account
  status: active
  active: true
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.02_pinelabs_tally
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Pinelabs POS and SOA account
    account_type: pos_and_ar
    account_role: pos_soa_ar
    source_account_identifier: null
    source_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
    country_or_region: India
    declared_platform_id: platform.pinelabs_pos
    declared_platform_label: Pine Labs POS / SOA source
    declared_platform_context_id: platform_context.pinelabs_pos.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.pinelabs_pos
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.pinelabs_pos.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.cashfree_in.primary
  canonical_id: platform_account.pine_labs.cashfree_in.primary
  name: Cashfree payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.01_cashfree
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: Cashfree payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Cashfree | cashfree_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.payu_in.primary
  canonical_id: platform_account.pine_labs.payu_in.primary
  name: PayU payment gateway account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.02_payu
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: PayU payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: PayU | payu_settlement
    country_or_region: India
    declared_platform_id: platform.payu
    declared_platform_label: PayU payment gateway
    declared_platform_context_id: platform_context.payu.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.payu
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.payu.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.pine_labs.paytm_in.primary
  canonical_id: platform_account.pine_labs.paytm_in.primary
  name: Paytm payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.03_paytm
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.paytm
    platform_context_id: platform_context.paytm.in
    account_name: Paytm payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Paytm | paytm_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.paytm.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.phonepe_in.primary
  canonical_id: platform_account.pine_labs.phonepe_in.primary
  name: PhonePe payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    platform_id: platform.phonepe
    platform_context_id: platform_context.phonepe.in
    account_name: PhonePe payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: PhonePe | phonepe_settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.phonepe
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.phonepe.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.pine_labs.indusind_bank.primary
  canonical_id: platform_account.pine_labs.indusind_bank.primary
  name: IndusInd Bank settlement bank account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.07_bank_statement.01_indusind_bank
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: IndusInd Bank settlement bank account
    account_type: bank_account
    account_role: bank_statement_destination
    source_account_identifier: null
    source_config_text: IndusInd Bank | Bank statement + correction variant
    country_or_region: India
    declared_platform_id: platform.indusind_bank
    declared_platform_label: IndusInd Bank statement source
    declared_platform_context_id: platform_context.indusind_bank.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.indusind_bank
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.indusind_bank.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  canonical_id: platform_account.pine_labs.giftcard_reference_reports.primary
  name: Gift-card reference reports account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Gift-card reference reports account
    account_type: reference_data
    account_role: giftcard_reference_mapping
    source_account_identifier: null
    source_config_text: Amazon.in mapper; PhonePe mapper
    country_or_region: India
    declared_platform_id: platform.giftcard_reference_reports
    declared_platform_label: platform.giftcard_reference_reports
    declared_platform_context_id: platform_context.giftcard_reference_reports.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.giftcard_reference_reports
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.giftcard_reference_reports.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.pine_labs.escrow_treasury.primary
  canonical_id: platform_account.pine_labs.escrow_treasury.primary
  name: Escrow treasury reports account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.04_ignore_card_number_report
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    account_name: Escrow treasury reports account
    account_type: treasury_reports
    account_role: giftcard_liability_treasury
    source_account_identifier: null
    source_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
    country_or_region: India
    declared_platform_id: platform.escrow_treasury
    declared_platform_label: platform.escrow_treasury
    declared_platform_context_id: platform_context.escrow_treasury.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.escrow_treasury
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.escrow_treasury.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
  canonical_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
  name: account data binding / pine labs / woohoo / primary / woohoo oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.07_woohoo_adhoc
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  fields:
    platform_account_id: platform_account.pine_labs.woohoo.primary
    table_id: table.zs_observe.woohoo_oms
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Woohoo | OMS, OMS rectified (corrections), Adhoc
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.woohoo_oms
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.woohoo.primary to table.zs_observe.woohoo_oms using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
  canonical_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
  name: account data binding / pine labs / amazon gc / primary / amazon seller flex
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.01_amazon_in_http_amazon_in_mapper
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.02_pinelab_amazon
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.03_amazon_seller_flex
  fields:
    platform_account_id: platform_account.pine_labs.amazon_gc.primary
    table_id: table.zs_observe.amazon_seller_flex
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_seller_flex
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.amazon_gc.primary to table.zs_observe.amazon_seller_flex using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
  canonical_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
  name: account data binding / pine labs / amazon gc / primary / amazon gc settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.01_amazon_in_http_amazon_in_mapper
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.02_pinelab_amazon
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.03_amazon_seller_flex
  fields:
    platform_account_id: platform_account.pine_labs.amazon_gc.primary
    table_id: table.zs_observe.amazon_gc_settlement
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_gc_settlement
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.amazon_gc.primary to table.zs_observe.amazon_gc_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.flipkart_distribution.primary.settlement
  canonical_id: account_data_binding.pine_labs.flipkart_distribution.primary.settlement
  name: account data binding / pine labs / flipkart distribution / primary / settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  fields:
    platform_account_id: platform_account.pine_labs.flipkart_distribution.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | Settlement, Adhoc (Ads/TDS/Rebates/VAS)
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.settlement
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.flipkart_distribution.primary to table.flipkart.settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
  canonical_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
  name: account data binding / pine labs / paytm giftcard / primary / paytm giftcard settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.03_paytm
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.01_maximize_pay
  fields:
    platform_account_id: platform_account.pine_labs.paytm_giftcard.primary
    table_id: table.zs_observe.paytm_giftcard_settlement
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Paytm | Gift card settlement, Pay-in (multi-sheet)
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_giftcard_settlement
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.paytm_giftcard.primary to table.zs_observe.paytm_giftcard_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
  canonical_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
  name: account data binding / pine labs / nearby / primary / nearby marketplace
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.06_nearby
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.03_flipkart
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  fields:
    platform_account_id: platform_account.pine_labs.nearby.primary
    table_id: table.zs_observe.nearby_marketplace
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nearby | Settlement to nearby_marketplace
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nearby_marketplace
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.nearby.primary to table.zs_observe.nearby_marketplace using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.navi.primary.navi_settlement
  canonical_id: account_data_binding.pine_labs.navi.primary.navi_settlement
  name: account data binding / pine labs / navi / primary / navi settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.02_navi
  fields:
    platform_account_id: platform_account.pine_labs.navi.primary
    table_id: table.zs_observe.navi_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Navi | navi_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.navi_settlement
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.navi.primary to table.zs_observe.navi_settlement using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.amica_technologies.primary.amica_technologies_settlement
  canonical_id: account_data_binding.pine_labs.amica_technologies.primary.amica_technologies_settlement
  name: account data binding / pine labs / amica technologies / primary / amica technologies settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.05_amica_technologies
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.08_gullak_technologies
  fields:
    platform_account_id: platform_account.pine_labs.amica_technologies.primary
    table_id: table.zs_observe.amica_technologies_settlement
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amica Technologies | amica_technologies_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amica_technologies_settlement
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.amica_technologies.primary to table.zs_observe.amica_technologies_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
  canonical_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
  name: account data binding / pine labs / first pay / primary / first pay settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.06_first_pay
  fields:
    platform_account_id: platform_account.pine_labs.first_pay.primary
    table_id: table.zs_observe.first_pay_settlement
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: First Pay | first_pay_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.first_pay_settlement
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.first_pay.primary to table.zs_observe.first_pay_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
  canonical_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
  name: account data binding / pine labs / red giraffe / primary / red giraffe settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.07_red_giraffe
  fields:
    platform_account_id: platform_account.pine_labs.red_giraffe.primary
    table_id: table.zs_observe.red_giraffe_settlement
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Red Giraffe | red_giraffe_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.red_giraffe_settlement
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.red_giraffe.primary to table.zs_observe.red_giraffe_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
  canonical_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
  name: account data binding / pine labs / gullak / primary / gullak technologies settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.08_gullak_technologies
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.05_amica_technologies
  fields:
    platform_account_id: platform_account.pine_labs.gullak.primary
    table_id: table.zs_observe.gullak_technologies_settlement
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Gullak Technologies | gullak_technologies_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.gullak_technologies_settlement
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.gullak.primary to table.zs_observe.gullak_technologies_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
  canonical_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
  name: account data binding / pine labs / pinelabs pos / primary / pinelabs soa
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.03_pinelabs_soa
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  fields:
    platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
    table_id: table.zs_observe.pinelabs_soa
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.pinelabs_soa
      source_documents:
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: Client Tables - Shopify.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.pine_labs.pinelabs_pos.primary to table.zs_observe.pinelabs_soa using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.cashfree_in.primary.cashfree_payin
  canonical_id: account_data_binding.pine_labs.cashfree_in.primary.cashfree_payin
  name: account data binding / pine labs / cashfree in / primary / cashfree payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.01_cashfree
  fields:
    platform_account_id: platform_account.pine_labs.cashfree_in.primary
    table_id: table.zs_observe.cashfree_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cashfree | cashfree_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.cashfree_in.primary to table.zs_observe.cashfree_payin using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.paytm_in.primary.paytm_payin
  canonical_id: account_data_binding.pine_labs.paytm_in.primary.paytm_payin
  name: account data binding / pine labs / paytm in / primary / paytm payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.03_paytm
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.04_paytm
  fields:
    platform_account_id: platform_account.pine_labs.paytm_in.primary
    table_id: table.zs_observe.paytm_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Paytm | paytm_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.paytm_in.primary to table.zs_observe.paytm_payin using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_payin
  canonical_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_payin
  name: account data binding / pine labs / phonepe in / primary / phonepe payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  fields:
    platform_account_id: platform_account.pine_labs.phonepe_in.primary
    table_id: table.zs_observe.phonepe_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: PhonePe | phonepe_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.phonepe_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.phonepe_in.primary to table.zs_observe.phonepe_payin using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
  canonical_id: account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
  name: account data binding / pine labs / phonepe giftcard / primary / phonepe settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  fields:
    platform_account_id: platform_account.pine_labs.phonepe_giftcard.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: PhonePe | Settlement report, Mapper
    declared_table_id: table.zs_observe.phonepe_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.phonepe_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.phonepe_giftcard.primary to table.zs_observe.phonepe_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
  canonical_id: account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
  name: account data binding / pine labs / maximize pay / primary / maximize settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.01_maximize_pay
  fields:
    platform_account_id: platform_account.pine_labs.maximize_pay.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Maximize Pay | maximize_settlement
    declared_table_id: table.zs_observe.maximize_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.maximize_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.maximize_pay.primary to table.zs_observe.maximize_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
  canonical_id: account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
  name: account data binding / pine labs / dreamplug / primary / dreamplug settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.03_dreamplug
  fields:
    platform_account_id: platform_account.pine_labs.dreamplug.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: DreamPlug | dreamplug_settlement
    declared_table_id: table.zs_observe.dreamplug_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.dreamplug_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.dreamplug.primary to table.zs_observe.dreamplug_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.tata_digital.primary.tata_digital_settlement
  canonical_id: account_data_binding.pine_labs.tata_digital.primary.tata_digital_settlement
  name: account data binding / pine labs / tata digital / primary / tata digital settlement
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.row.04_distribution_channel_settlements_marketplace_platform_partners_fintech_bnpl_wallet_platform_settlements.04_tata_digital
  fields:
    platform_account_id: platform_account.pine_labs.tata_digital.primary
    table_id: table.zs_observe.tata_digital_settlement
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Tata Digital | tata_digital_settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tata_digital_settlement
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.tata_digital.primary to table.zs_observe.tata_digital_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  canonical_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  name: account data binding / pine labs / pinelabs pos / primary / pinelabs commission invoice
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.02_pinelabs_tally
  fields:
    platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
    declared_table_id: table.zs_observe.pinelabs_commission_invoice
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.pinelabs_commission_invoice
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.pinelabs_pos.primary to table.zs_observe.pinelabs_commission_invoice using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  canonical_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  name: account data binding / pine labs / pinelabs pos / primary / pinelabs tally
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.02_pinelabs_tally
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  fields:
    platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
    declared_table_id: table.zs_observe.pinelabs_tally
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.pinelabs_tally
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.pinelabs_pos.primary to table.zs_observe.pinelabs_tally using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  canonical_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  name: account data binding / pine labs / pinelabs pos / primary / pinelab adhoc amount
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.02_pinelabs_tally
  fields:
    platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
    declared_table_id: table.zs_observe.pinelab_adhoc_amount
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.pinelab_adhoc_amount
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.pinelabs_pos.primary to table.zs_observe.pinelab_adhoc_amount using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  canonical_id: account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  name: account data binding / pine labs / pinelabs pos / primary / pine payments
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.05_pine_pg
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.01_pinelabs_commission_invoice
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.04_pinelabs_adhoc_amount
  - ev.pine_labs.docx.row.05_distribution_channel_settlements_marketplace_platform_partners_pos_in_store_pinelabs.02_pinelabs_tally
  fields:
    platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
    declared_table_id: table.zs_observe.pine_payments
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.pine_payments
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.pinelabs_pos.primary to table.zs_observe.pine_payments using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.payu_in.primary.payu_settlement
  canonical_id: account_data_binding.pine_labs.payu_in.primary.payu_settlement
  name: account data binding / pine labs / payu in / primary / payu settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.02_payu
  fields:
    platform_account_id: platform_account.pine_labs.payu_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: PayU | payu_settlement
    declared_table_id: table.zs_observe.payu_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.payu_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.payu_in.primary to table.zs_observe.payu_settlement using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  canonical_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  name: account data binding / pine labs / phonepe in / primary / phonepe settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  fields:
    platform_account_id: platform_account.pine_labs.phonepe_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: PhonePe | phonepe_settlement
    declared_table_id: table.zs_observe.phonepe_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.phonepe_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.phonepe_in.primary to table.zs_observe.phonepe_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  canonical_id: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  name: account data binding / pine labs / indusind bank / primary / indusind bank statement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.07_bank_statement.01_indusind_bank
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  fields:
    platform_account_id: platform_account.pine_labs.indusind_bank.primary
    table_support_level: source_configured_requires_bank_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: IndusInd Bank | Bank statement + correction variant
    declared_table_id: table.zs_ingest.indusind_bank_statement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_ingest.indusind_bank_statement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.indusind_bank.primary to table.zs_ingest.indusind_bank_statement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
  canonical_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
  name: account data binding / pine labs / giftcard reference reports / primary / amazon in mapper
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.01_amazon_in_http_amazon_in_mapper
  fields:
    platform_account_id: platform_account.pine_labs.giftcard_reference_reports.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon.in mapper; PhonePe mapper
    declared_table_id: table.zs_observe.amazon_in_mapper
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.amazon_in_mapper
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.giftcard_reference_reports.primary to table.zs_observe.amazon_in_mapper using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
  canonical_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
  name: account data binding / pine labs / giftcard reference reports / primary / phonepe mapper
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.06_payment_gateway_reconciliation
  - ev.pine_labs.docx.row.08_gift_card_specific_reports.02_phonepe_mapper
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.05_phonepe
  - ev.pine_labs.docx.row.06_payment_gateway_reconciliation.04_phonepe
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  fields:
    platform_account_id: platform_account.pine_labs.giftcard_reference_reports.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon.in mapper; PhonePe mapper
    declared_table_id: table.zs_observe.phonepe_mapper
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.phonepe_mapper
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.giftcard_reference_reports.primary to table.zs_observe.phonepe_mapper using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
  canonical_id: account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
  name: account data binding / pine labs / escrow treasury / primary / revalidation report
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.04_ignore_card_number_report
  fields:
    platform_account_id: platform_account.pine_labs.escrow_treasury.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
    declared_table_id: table.zs_observe.revalidation_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.revalidation_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.escrow_treasury.primary to table.zs_observe.revalidation_report using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
  canonical_id: account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
  name: account data binding / pine labs / escrow treasury / primary / sclp billing report
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.04_ignore_card_number_report
  fields:
    platform_account_id: platform_account.pine_labs.escrow_treasury.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
    declared_table_id: table.zs_observe.sclp_billing_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.sclp_billing_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.escrow_treasury.primary to table.zs_observe.sclp_billing_report using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
  canonical_id: account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
  name: account data binding / pine labs / escrow treasury / primary / credit limit report
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.04_ignore_card_number_report
  fields:
    platform_account_id: platform_account.pine_labs.escrow_treasury.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
    declared_table_id: table.zs_observe.credit_limit_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.credit_limit_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.escrow_treasury.primary to table.zs_observe.credit_limit_report using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
  canonical_id: account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
  name: account data binding / pine labs / escrow treasury / primary / ignore card number report
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.04_ignore_card_number_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  fields:
    platform_account_id: platform_account.pine_labs.escrow_treasury.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
    declared_table_id: table.zs_observe.ignore_card_number_report
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.ignore_card_number_report
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.escrow_treasury.primary to table.zs_observe.ignore_card_number_report using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
  canonical_id: account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
  name: account data binding / pine labs / escrow treasury / primary / merchant interest sheet
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.01_revalidation_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.05_master_merchant_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.02_sclp_billing_report
  - ev.pine_labs.docx.row.09_escrow_treasury_specific_reports.03_credit_limit_report
  fields:
    platform_account_id: platform_account.pine_labs.escrow_treasury.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 44
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 168
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
    declared_table_id: table.zs_observe.merchant_interest_sheet
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.merchant_interest_sheet
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.pine_labs.escrow_treasury.primary to table.zs_observe.merchant_interest_sheet using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.pine_labs.giftcard_core
  canonical_id: business_scope_set.pine_labs.giftcard_core
  name: Pine gift-card core OMS and activation scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.03_amazon_seller_flex
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.02_pinelab_amazon
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  description: Woohoo OMS, Amazon Seller Flex, and Amazon GC settlement scope for gift-card issuance and settlement.
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    scope_name: Pine gift-card core OMS and activation scope
    scope_type: giftcard_order_to_activation
    platform_account_ids:
    - platform_account.pine_labs.woohoo.primary
    - platform_account.pine_labs.amazon_gc.primary
    platform_ids:
    - platform.amazon
    platform_context_ids: []
    declared_unresolved_platform_ids:
    - platform.woohoo
    declared_unresolved_platform_context_ids:
    - platform_context.woohoo.in.giftcard_oms
    - platform_context.amazon.in.giftcard_distribution
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.pine_labs.distribution_settlements
  canonical_id: business_scope_set.pine_labs.distribution_settlements
  name: Pine distribution partner settlements
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  description: Gift-card distributor and fintech settlement accounts.
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    scope_name: Pine distribution partner settlements
    scope_type: giftcard_distribution_settlements
    platform_account_ids:
    - platform_account.pine_labs.amazon_gc.primary
    - platform_account.pine_labs.flipkart_distribution.primary
    - platform_account.pine_labs.paytm_giftcard.primary
    - platform_account.pine_labs.phonepe_giftcard.primary
    - platform_account.pine_labs.nearby.primary
    - platform_account.pine_labs.navi.primary
    - platform_account.pine_labs.tata_digital.primary
    - platform_account.pine_labs.amica_technologies.primary
    - platform_account.pine_labs.first_pay.primary
    - platform_account.pine_labs.red_giraffe.primary
    - platform_account.pine_labs.gullak.primary
    - platform_account.pine_labs.maximize_pay.primary
    - platform_account.pine_labs.dreamplug.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.paytm
    - platform.phonepe
    - platform.navi
    - platform.tata_digital
    platform_context_ids:
    - platform_context.flipkart.in
    - platform_context.navi.in
    - platform_context.tata_digital.in
    declared_unresolved_platform_ids:
    - platform.nearby_marketplace
    - platform.amica_technologies
    - platform.first_pay
    - platform.red_giraffe
    - platform.gullak_technologies
    - platform.maximize_pay
    - platform.dreamplug
    declared_unresolved_platform_context_ids:
    - platform_context.amazon.in.giftcard_distribution
    - platform_context.paytm.in.giftcard_distribution
    - platform_context.phonepe.in.giftcard_distribution
    - platform_context.nearby_marketplace.in
    - platform_context.amica_technologies.in
    - platform_context.first_pay.in
    - platform_context.red_giraffe.in
    - platform_context.gullak_technologies.in
    - platform_context.maximize_pay.in
    - platform_context.dreamplug.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.pine_labs.payment_gateways
  canonical_id: business_scope_set.pine_labs.payment_gateways
  name: Pine payment gateway scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  description: Payment gateway collection scope for Pine Labs.
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    scope_name: Pine payment gateway scope
    scope_type: payment_gateway_collection
    platform_account_ids:
    - platform_account.pine_labs.cashfree_in.primary
    - platform_account.pine_labs.payu_in.primary
    - platform_account.pine_labs.paytm_in.primary
    - platform_account.pine_labs.phonepe_in.primary
    platform_ids:
    - platform.cashfree
    - platform.paytm
    - platform.phonepe
    platform_context_ids:
    - platform_context.cashfree.in
    - platform_context.paytm.in
    - platform_context.phonepe.in
    declared_unresolved_platform_ids:
    - platform.payu
    declared_unresolved_platform_context_ids:
    - platform_context.payu.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.pine_labs.bank_and_treasury
  canonical_id: business_scope_set.pine_labs.bank_and_treasury
  name: Pine bank and treasury review scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  description: Bank, treasury, SOA, and reference-report scope.
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    scope_name: Pine bank and treasury review scope
    scope_type: bank_treasury
    platform_account_ids:
    - platform_account.pine_labs.indusind_bank.primary
    - platform_account.pine_labs.escrow_treasury.primary
    - platform_account.pine_labs.giftcard_reference_reports.primary
    - platform_account.pine_labs.pinelabs_pos.primary
    platform_ids: []
    platform_context_ids: []
    declared_unresolved_platform_ids:
    - platform.indusind_bank
    - platform.escrow_treasury
    - platform.giftcard_reference_reports
    - platform.pinelabs_pos
    declared_unresolved_platform_context_ids:
    - platform_context.indusind_bank.in
    - platform_context.escrow_treasury.in
    - platform_context.giftcard_reference_reports.in
    - platform_context.pinelabs_pos.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  canonical_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  name: Pine Woohoo activation to Amazon GC settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.01_woohoo
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.02_pinelab_amazon
  - ev.pine_labs.docx.row.02_core_oms_and_order_data.03_amazon_seller_flex
  - ev.pine_labs.docx.row.03_distribution_channel_settlements_marketplace_platform_partners.02_amazon_india
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    binding_name: Pine Woohoo activation to Amazon GC settlement
    binding_type: giftcard_oms_to_marketplace_settlement
    business_scope_set_id: business_scope_set.pine_labs.giftcard_core
    money_flow_paths:
    - Woohoo gift-card order -> Amazon Seller Flex activation -> Amazon GC settlement
    participating_accounts:
    - platform_account_id: platform_account.pine_labs.woohoo.primary
      role: giftcard_oms
      required: true
    - platform_account_id: platform_account.pine_labs.amazon_gc.primary
      role: activation_and_settlement_evidence
      required: true
    account_data_binding_ids:
    - account_data_binding.pine_labs.woohoo.primary.woohoo_oms
    - account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
    - account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
    evidence_table_ids:
    - table.zs_observe.woohoo_oms
    - table.zs_observe.amazon_seller_flex
    - table.zs_observe.amazon_gc_settlement
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids:
    - business_process.giftcard_activation_to_settlement
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids:
    - reconciliation_profile.giftcard_activation_to_settlement
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Use order_id for Woohoo/Amazon settlement activation matching where available.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  canonical_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  name: Pine distribution settlements to IndusInd bank
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.row.07_bank_statement.01_indusind_bank
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    binding_name: Pine distribution settlements to IndusInd bank
    binding_type: settlement_to_bank
    business_scope_set_id: business_scope_set.pine_labs.distribution_settlements
    money_flow_paths:
    - Distributor settlement -> UTR/settlement reference -> IndusInd bank credit
    participating_accounts:
    - platform_account_id: platform_account.pine_labs.amazon_gc.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.pine_labs.paytm_giftcard.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.pine_labs.gullak.primary
      role: settlement_source
      required: false
    - platform_account_id: platform_account.pine_labs.indusind_bank.primary
      role: bank_destination
      required: true
    account_data_binding_ids:
    - account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
    - account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
    - account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
    - account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
    - account_data_binding.pine_labs.nearby.primary.nearby_marketplace
    - account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
    - account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
    - account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
    evidence_table_ids:
    - table.zs_observe.amazon_gc_settlement
    - table.zs_observe.paytm_giftcard_settlement
    conditions: []
    declared_unresolved_evidence_table_ids:
    - table.zs_ingest.indusind_bank_statement
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bank statement destination is source-confirmed but current bank table binding requires review because source scope identifiers
      conflict.
    original_bad_state_status:
      status: review_required
      active: false
- card_type: business_flow_binding
  card_id: business_flow_binding.pine_labs.payment_gateway_collection
  canonical_id: business_flow_binding.pine_labs.payment_gateway_collection
  name: Pine payment gateway collection
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - payment_gateway.md
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    binding_name: Pine payment gateway collection
    binding_type: payment_gateway_payin
    business_scope_set_id: business_scope_set.pine_labs.payment_gateways
    money_flow_paths:
    - Payment gateway pay-in -> settlement/ref reference -> bank credit
    participating_accounts:
    - platform_account_id: platform_account.pine_labs.cashfree_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.pine_labs.paytm_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.pine_labs.phonepe_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.pine_labs.payu_in.primary
      role: pg_collection_review
      required: false
    account_data_binding_ids:
    - account_data_binding.pine_labs.cashfree_in.primary.cashfree_payin
    - account_data_binding.pine_labs.paytm_in.primary.paytm_payin
    - account_data_binding.pine_labs.phonepe_in.primary.phonepe_payin
    - account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
    - account_data_binding.pine_labs.payu_in.primary.payu_settlement
    evidence_table_ids:
    - table.zs_observe.cashfree_payin
    - table.zs_observe.paytm_payin
    - table.zs_observe.phonepe_payin
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - PayU remains review_required until canonical PayU context is added.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  canonical_id: business_flow_binding.pine_labs.soa_ar_collection_review
  name: Pine SOA AR invoice collection to bank
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Pine Labs.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.pine_labs.docx.section.01_identity
  fields:
    tenant_id: tenant.pine_labs
    group_id: group.pine_labs.pine_labs_private_limited
    binding_name: Pine SOA AR invoice collection to bank
    binding_type: accounts_receivable_to_bank
    business_scope_set_id: business_scope_set.pine_labs.bank_and_treasury
    money_flow_paths:
    - Pine SOA invoice/payment rows -> UTR/mode_of_payment -> bank credit
    participating_accounts:
    - platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
      role: soa_ar_source
      required: true
    - platform_account_id: platform_account.pine_labs.indusind_bank.primary
      role: bank_destination
      required: true
    account_data_binding_ids:
    - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
    - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
    - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
    - account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
    - account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
    - account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
    evidence_table_ids:
    - table.zs_observe.pinelabs_soa
    conditions: []
    declared_unresolved_evidence_table_ids:
    - table.zs_ingest.indusind_bank_statement
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - SOA source table is active from client-table evidence; bank landing is review_required until IndusInd binding and Pine
      scope conflict are resolved.
    original_bad_state_status:
      status: review_required
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- platform_account_id: platform_account.pine_labs.woohoo.primary
  client_config_text: Woohoo | OMS, OMS rectified (corrections), Adhoc
  canonical_or_supported_tables_now:
  - table.zs_observe.woohoo_oms
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.woohoo_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.amazon_gc.primary
  client_config_text: Amazon India | GC settlement (new + old formats), NAB settlement, NAB promo, SVC transactions, mapper
  canonical_or_supported_tables_now:
  - table.zs_observe.amazon_seller_flex
  - table.zs_observe.amazon_gc_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_seller_flex
  - table.zs_observe.amazon_gc_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.flipkart_distribution.primary
  client_config_text: Flipkart | Settlement, Adhoc (Ads/TDS/Rebates/VAS)
  canonical_or_supported_tables_now:
  - table.flipkart.settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.flipkart.settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.paytm_giftcard.primary
  client_config_text: Paytm | Gift card settlement, Pay-in (multi-sheet)
  canonical_or_supported_tables_now:
  - table.zs_observe.paytm_giftcard_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.paytm_giftcard_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.nearby.primary
  client_config_text: Nearby | Settlement to nearby_marketplace
  canonical_or_supported_tables_now:
  - table.zs_observe.nearby_marketplace
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.nearby_marketplace
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.navi.primary
  client_config_text: Navi | navi_settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.navi_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.navi_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.amica_technologies.primary
  client_config_text: Amica Technologies | amica_technologies_settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.amica_technologies_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amica_technologies_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.first_pay.primary
  client_config_text: First Pay | first_pay_settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.first_pay_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.first_pay_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.red_giraffe.primary
  client_config_text: Red Giraffe | red_giraffe_settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.red_giraffe_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.red_giraffe_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.gullak.primary
  client_config_text: Gullak Technologies | gullak_technologies_settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.gullak_technologies_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.gullak_technologies_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
  client_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
  canonical_or_supported_tables_now:
  - table.zs_observe.pinelabs_soa
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.pinelabs_soa
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.cashfree_in.primary
  client_config_text: Cashfree | cashfree_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.cashfree_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.cashfree_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.paytm_in.primary
  client_config_text: Paytm | paytm_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.paytm_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.paytm_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.phonepe_in.primary
  client_config_text: PhonePe | phonepe_settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.phonepe_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.phonepe_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.phonepe_giftcard.primary
  client_config_text: PhonePe | Settlement report, Mapper
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - PhonePe gift-card settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.maximize_pay.primary
  client_config_text: Maximize Pay | maximize_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Maximize Pay settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.dreamplug.primary
  client_config_text: DreamPlug | dreamplug_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - DreamPlug settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.tata_digital.primary
  client_config_text: Tata Digital | tata_digital_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Tata Digital settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.tata_digital_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.pinelabs_pos.primary
  client_config_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Pinelabs POS/Tally/Pine PG context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.pinelabs_soa
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.payu_in.primary
  client_config_text: PayU | payu_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - PayU settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.phonepe_in.primary
  client_config_text: PhonePe | phonepe_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - PhonePe settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.phonepe_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.indusind_bank.primary
  client_config_text: IndusInd Bank | Bank statement + correction variant
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - IndusInd bank statement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.giftcard_reference_reports.primary
  client_config_text: Amazon.in mapper; PhonePe mapper
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Gift-card mapper context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.pine_labs.escrow_treasury.primary
  client_config_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Escrow treasury and liability context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.pine_labs.has_group.3c291b1b5e5d
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.pine_labs
  target_card_id: group.pine_labs.pine_labs_private_limited
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_GROUP
- edge_id: edge.pine_labs.has_platform_account.c28686d2187a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.woohoo.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.e480dd9d42c1
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.amazon_gc.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.69e8d1ad82d3
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.amazon_gc.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.has_platform_account.83f937e18cfe
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.flipkart_distribution.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.10ca6cd0a1a0
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.flipkart_distribution.primary
  target_card_id: platform.flipkart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.uses_platform_context.61cd3a0b413c
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.pine_labs.flipkart_distribution.primary
  target_card_id: platform_context.flipkart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.pine_labs.has_platform_account.7124a358de29
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.paytm_giftcard.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.c9d4e7be6351
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.paytm_giftcard.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.has_platform_account.0346a1d2aa6a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.phonepe_giftcard.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.79c730c06493
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.phonepe_giftcard.primary
  target_card_id: platform.phonepe
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.has_platform_account.be77db72e848
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.nearby.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.7eb99a0f3cd3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.navi.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.40bed386fd06
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.navi.primary
  target_card_id: platform.navi
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.uses_platform_context.6edc0d1667e4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.pine_labs.navi.primary
  target_card_id: platform_context.navi.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.pine_labs.has_platform_account.2f227ed3f66d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.tata_digital.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.f865127deb06
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.tata_digital.primary
  target_card_id: platform.tata_digital
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.uses_platform_context.fc60b8668fbd
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.pine_labs.tata_digital.primary
  target_card_id: platform_context.tata_digital.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.pine_labs.has_platform_account.0dbd39a9d0f0
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.amica_technologies.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.17d7bac3c7d7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.first_pay.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.8780df961a0f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.red_giraffe.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.650aee4487d8
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.gullak.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.0b7bf9b92a63
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.maximize_pay.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.2cff0425af0c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.dreamplug.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.50743781d51a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.pinelabs_pos.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.25bfd19b102b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.cashfree_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.89fd73db4920
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.cashfree_in.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.uses_platform_context.4a52112eadd1
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.pine_labs.cashfree_in.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.pine_labs.has_platform_account.d75950aa7309
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.payu_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.b5ae29ffb41d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.paytm_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.99be2c58c11c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.paytm_in.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.uses_platform_context.af0a869827b8
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.pine_labs.paytm_in.primary
  target_card_id: platform_context.paytm.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.pine_labs.has_platform_account.a8a92fe63fd7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.phonepe_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.uses_platform.46ed1dac27e5
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.pine_labs.phonepe_in.primary
  target_card_id: platform.phonepe
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.pine_labs.uses_platform_context.3477086ae576
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.pine_labs.phonepe_in.primary
  target_card_id: platform_context.phonepe.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.pine_labs.has_platform_account.af3d24720f3c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.indusind_bank.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.53db9c30357a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_platform_account.5971545cecbf
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: platform_account.pine_labs.escrow_treasury.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_account_data_binding.0ee2d483bc9b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.woohoo.primary
  target_card_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.eb08dce54e21
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
  target_card_id: table.zs_observe.woohoo_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.4851d67566e2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.amazon_gc.primary
  target_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.d40634fc004c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
  target_card_id: table.zs_observe.amazon_seller_flex
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.818d3c886e52
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.amazon_gc.primary
  target_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.b9ff49259cbc
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
  target_card_id: table.zs_observe.amazon_gc_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.41218c829875
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.flipkart_distribution.primary
  target_card_id: account_data_binding.pine_labs.flipkart_distribution.primary.settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.04e2945b5c59
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.flipkart_distribution.primary.settlement
  target_card_id: table.flipkart.settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.6e55e5d4b721
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.paytm_giftcard.primary
  target_card_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.6b0ea78a8956
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
  target_card_id: table.zs_observe.paytm_giftcard_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.026f5d29b3a1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.nearby.primary
  target_card_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.ea149d08e5fe
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
  target_card_id: table.zs_observe.nearby_marketplace
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.e837c5572a51
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.navi.primary
  target_card_id: account_data_binding.pine_labs.navi.primary.navi_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.e9cae1d6d354
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.navi.primary.navi_settlement
  target_card_id: table.zs_observe.navi_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.cc72b0fc42fe
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.amica_technologies.primary
  target_card_id: account_data_binding.pine_labs.amica_technologies.primary.amica_technologies_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.b09cb5303f75
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.amica_technologies.primary.amica_technologies_settlement
  target_card_id: table.zs_observe.amica_technologies_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.efddaabc407e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.first_pay.primary
  target_card_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.a601d83db83c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
  target_card_id: table.zs_observe.first_pay_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.8aa6353565ee
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.red_giraffe.primary
  target_card_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.2825a19d3eaf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
  target_card_id: table.zs_observe.red_giraffe_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.fad27175aca8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.gullak.primary
  target_card_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.9a64f98e7fd6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
  target_card_id: table.zs_observe.gullak_technologies_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.4a25d731f57e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.1b0cd52f20bc
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
  target_card_id: table.zs_observe.pinelabs_soa
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.8f18491fc5f7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.cashfree_in.primary
  target_card_id: account_data_binding.pine_labs.cashfree_in.primary.cashfree_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.af219ee5f2b6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.cashfree_in.primary.cashfree_payin
  target_card_id: table.zs_observe.cashfree_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.000cbb025d94
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.paytm_in.primary
  target_card_id: account_data_binding.pine_labs.paytm_in.primary.paytm_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.10e3ce835d09
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.paytm_in.primary.paytm_payin
  target_card_id: table.zs_observe.paytm_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.f3699b5a864b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.phonepe_in.primary
  target_card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.ff7abac190fe
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_payin
  target_card_id: table.zs_observe.phonepe_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.a9aa79c0a5c2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.phonepe_giftcard.primary
  target_card_id: account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.c5138f8ed56d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.maximize_pay.primary
  target_card_id: account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.4800d4d79022
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.dreamplug.primary
  target_card_id: account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.24a50da69552
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.tata_digital.primary
  target_card_id: account_data_binding.pine_labs.tata_digital.primary.tata_digital_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.binds_to_table.6fc493382c9c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.pine_labs.tata_digital.primary.tata_digital_settlement
  target_card_id: table.zs_observe.tata_digital_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.pine_labs.has_account_data_binding.5fca6e8f1d3b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.79c83952c6c3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.2c30c240a923
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.11bc951ae8c7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.0bc8db72c4ae
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.payu_in.primary
  target_card_id: account_data_binding.pine_labs.payu_in.primary.payu_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.820169da82a6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.phonepe_in.primary
  target_card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.8e30a874e921
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.indusind_bank.primary
  target_card_id: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.d1a2ece87ddb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  target_card_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.b105e723cb58
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  target_card_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.1bd139ce509e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.escrow_treasury.primary
  target_card_id: account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.883e7deaed31
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.escrow_treasury.primary
  target_card_id: account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.fbe15b56d814
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.escrow_treasury.primary
  target_card_id: account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.b9502a9b5236
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.escrow_treasury.primary
  target_card_id: account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_account_data_binding.be9ec898e7d9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.pine_labs.escrow_treasury.primary
  target_card_id: account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.has_business_scope_set.218fcbaf9cdd
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_scope_set.pine_labs.giftcard_core
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.includes_platform_account.916b37dbfe84
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.giftcard_core
  target_card_id: platform_account.pine_labs.woohoo.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.68ce618d5eb6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.giftcard_core
  target_card_id: platform_account.pine_labs.amazon_gc.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_business_scope_set.ea5c764dcf0c
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_scope_set.pine_labs.distribution_settlements
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.includes_platform_account.81c14f0c745b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.amazon_gc.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.b4f6e77d85c5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.flipkart_distribution.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.f5ef7fc6d3ee
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.paytm_giftcard.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.67b9869c1b1e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.phonepe_giftcard.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.272331560d67
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.nearby.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.f00ea1fb7961
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.navi.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.58367400310e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.tata_digital.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.29437767923d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.amica_technologies.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.7a1f03b64411
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.first_pay.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.6c38dc24bfe1
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.red_giraffe.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.19438de848f4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.gullak.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.7095adf58308
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.maximize_pay.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.02eafd1e9363
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.distribution_settlements
  target_card_id: platform_account.pine_labs.dreamplug.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_business_scope_set.0f47d4f5a324
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_scope_set.pine_labs.payment_gateways
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.includes_platform_account.a2f7a6e1ce3f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.payment_gateways
  target_card_id: platform_account.pine_labs.cashfree_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.6d0171de431d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.payment_gateways
  target_card_id: platform_account.pine_labs.payu_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.e47fd894eb6c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.payment_gateways
  target_card_id: platform_account.pine_labs.paytm_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.f30ff39533bd
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.payment_gateways
  target_card_id: platform_account.pine_labs.phonepe_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_business_scope_set.c7099eb964d1
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_scope_set.pine_labs.bank_and_treasury
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.includes_platform_account.a25772cc148c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.bank_and_treasury
  target_card_id: platform_account.pine_labs.indusind_bank.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.9beddad7f21e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.bank_and_treasury
  target_card_id: platform_account.pine_labs.escrow_treasury.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.8f93df4b92c5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.bank_and_treasury
  target_card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.includes_platform_account.be3a746302f3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.pine_labs.bank_and_treasury
  target_card_id: platform_account.pine_labs.pinelabs_pos.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.pine_labs.has_business_flow_binding.cc7efe772bbc
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.pine_labs.uses_business_scope_set.5b5b7dd3c470
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: business_scope_set.pine_labs.giftcard_core
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.participates_with_account.6247aeae617f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: platform_account.pine_labs.woohoo.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.002f2bc42a82
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: platform_account.pine_labs.amazon_gc.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.uses_account_data_binding.df9f5f2355b7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.3ba3dc86e943
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.7ebdd14cecfa
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_evidence_table.d35e1a2248ef
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: table.zs_observe.woohoo_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.uses_evidence_table.d80faae6e1b3
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: table.zs_observe.amazon_seller_flex
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.uses_evidence_table.9bcd09355234
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  target_card_id: table.zs_observe.amazon_gc_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.has_business_flow_binding.f4ad42fc94e3
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.pine_labs.uses_business_scope_set.43f07b4f0f43
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: business_scope_set.pine_labs.distribution_settlements
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.participates_with_account.e12f08ce5ac1
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: platform_account.pine_labs.amazon_gc.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.97b025ccc5fe
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: platform_account.pine_labs.paytm_giftcard.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.bb196f5193dc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: platform_account.pine_labs.gullak.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.bd6ede7f491e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: platform_account.pine_labs.indusind_bank.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.uses_account_data_binding.e1ff38d134d6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.1370a6099fef
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.6206e09b4c20
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.0783b9076466
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.e019a2598bb9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.119da2869168
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.966b5b7eb808
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.7817320766eb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_evidence_table.b19ca36fd3e2
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: table.zs_observe.amazon_gc_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.uses_evidence_table.66f2656bd2b7
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  target_card_id: table.zs_observe.paytm_giftcard_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.has_business_flow_binding.39397c688e9f
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.pine_labs.uses_business_scope_set.608a18cd2a55
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: business_scope_set.pine_labs.payment_gateways
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.participates_with_account.abff339b5862
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: platform_account.pine_labs.cashfree_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.7abb8d9639ca
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: platform_account.pine_labs.paytm_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.9a8a8c1cbf39
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: platform_account.pine_labs.phonepe_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.e1c93746a909
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: platform_account.pine_labs.payu_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.uses_account_data_binding.e55a5a6de30a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: account_data_binding.pine_labs.cashfree_in.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.35402e5778e1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: account_data_binding.pine_labs.paytm_in.primary.paytm_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.b832c79f90f7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.48ae19aaee6a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.77ac00c5e68e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: account_data_binding.pine_labs.payu_in.primary.payu_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_evidence_table.b56ad6126b3b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: table.zs_observe.cashfree_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.uses_evidence_table.3cd1b1ea79e3
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: table.zs_observe.paytm_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.uses_evidence_table.3b88e084665a
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.payment_gateway_collection
  target_card_id: table.zs_observe.phonepe_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.pine_labs.has_business_flow_binding.724805efddc5
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.pine_labs.pine_labs_private_limited
  target_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.pine_labs.uses_business_scope_set.115a8c5629d2
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: business_scope_set.pine_labs.bank_and_treasury
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.pine_labs.participates_with_account.e71441586825
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: platform_account.pine_labs.pinelabs_pos.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.participates_with_account.043fccbe8529
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: platform_account.pine_labs.indusind_bank.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.pine_labs.uses_account_data_binding.1e860cf4f99d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.ae817e5726eb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.5bf3b31d2c2c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.ffcd993fa87b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.c1239900c8eb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_account_data_binding.6ff48c006287
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.pine_labs.uses_evidence_table.57338ce75f68
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  target_card_id: table.zs_observe.pinelabs_soa
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: platform_account.pine_labs.woohoo.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.woohoo
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.woohoo
  original_edge:
    source: platform_account.pine_labs.woohoo.primary
    edge: USES_PLATFORM
    target: platform.woohoo
- source_card_id: platform_account.pine_labs.woohoo.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.woohoo.in.giftcard_oms
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.woohoo.in.giftcard_oms
  original_edge:
    source: platform_account.pine_labs.woohoo.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.woohoo.in.giftcard_oms
- source_card_id: platform_account.pine_labs.amazon_gc.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.amazon.in.giftcard_distribution
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.amazon.in.giftcard_distribution
  original_edge:
    source: platform_account.pine_labs.amazon_gc.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.amazon.in.giftcard_distribution
- source_card_id: platform_account.pine_labs.paytm_giftcard.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.paytm.in.giftcard_distribution
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.paytm.in.giftcard_distribution
  original_edge:
    source: platform_account.pine_labs.paytm_giftcard.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.paytm.in.giftcard_distribution
- source_card_id: platform_account.pine_labs.phonepe_giftcard.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.phonepe.in.giftcard_distribution
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.phonepe.in.giftcard_distribution
  original_edge:
    source: platform_account.pine_labs.phonepe_giftcard.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.phonepe.in.giftcard_distribution
- source_card_id: platform_account.pine_labs.nearby.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.nearby_marketplace
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.nearby_marketplace
  original_edge:
    source: platform_account.pine_labs.nearby.primary
    edge: USES_PLATFORM
    target: platform.nearby_marketplace
- source_card_id: platform_account.pine_labs.nearby.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.nearby_marketplace.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.nearby_marketplace.in
  original_edge:
    source: platform_account.pine_labs.nearby.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.nearby_marketplace.in
- source_card_id: platform_account.pine_labs.amica_technologies.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.amica_technologies
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.amica_technologies
  original_edge:
    source: platform_account.pine_labs.amica_technologies.primary
    edge: USES_PLATFORM
    target: platform.amica_technologies
- source_card_id: platform_account.pine_labs.amica_technologies.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.amica_technologies.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.amica_technologies.in
  original_edge:
    source: platform_account.pine_labs.amica_technologies.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.amica_technologies.in
- source_card_id: platform_account.pine_labs.first_pay.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.first_pay
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.first_pay
  original_edge:
    source: platform_account.pine_labs.first_pay.primary
    edge: USES_PLATFORM
    target: platform.first_pay
- source_card_id: platform_account.pine_labs.first_pay.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.first_pay.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.first_pay.in
  original_edge:
    source: platform_account.pine_labs.first_pay.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.first_pay.in
- source_card_id: platform_account.pine_labs.red_giraffe.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.red_giraffe
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.red_giraffe
  original_edge:
    source: platform_account.pine_labs.red_giraffe.primary
    edge: USES_PLATFORM
    target: platform.red_giraffe
- source_card_id: platform_account.pine_labs.red_giraffe.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.red_giraffe.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.red_giraffe.in
  original_edge:
    source: platform_account.pine_labs.red_giraffe.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.red_giraffe.in
- source_card_id: platform_account.pine_labs.gullak.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.gullak_technologies
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.gullak_technologies
  original_edge:
    source: platform_account.pine_labs.gullak.primary
    edge: USES_PLATFORM
    target: platform.gullak_technologies
- source_card_id: platform_account.pine_labs.gullak.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.gullak_technologies.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.gullak_technologies.in
  original_edge:
    source: platform_account.pine_labs.gullak.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.gullak_technologies.in
- source_card_id: platform_account.pine_labs.maximize_pay.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.maximize_pay
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.maximize_pay
  original_edge:
    source: platform_account.pine_labs.maximize_pay.primary
    edge: USES_PLATFORM
    target: platform.maximize_pay
- source_card_id: platform_account.pine_labs.maximize_pay.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.maximize_pay.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.maximize_pay.in
  original_edge:
    source: platform_account.pine_labs.maximize_pay.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.maximize_pay.in
- source_card_id: platform_account.pine_labs.dreamplug.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.dreamplug
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.dreamplug
  original_edge:
    source: platform_account.pine_labs.dreamplug.primary
    edge: USES_PLATFORM
    target: platform.dreamplug
- source_card_id: platform_account.pine_labs.dreamplug.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.dreamplug.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.dreamplug.in
  original_edge:
    source: platform_account.pine_labs.dreamplug.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.dreamplug.in
- source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.pinelabs_pos
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.pinelabs_pos
  original_edge:
    source: platform_account.pine_labs.pinelabs_pos.primary
    edge: USES_PLATFORM
    target: platform.pinelabs_pos
- source_card_id: platform_account.pine_labs.pinelabs_pos.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.pinelabs_pos.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.pinelabs_pos.in
  original_edge:
    source: platform_account.pine_labs.pinelabs_pos.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.pinelabs_pos.in
- source_card_id: platform_account.pine_labs.payu_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.payu
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.payu
  original_edge:
    source: platform_account.pine_labs.payu_in.primary
    edge: USES_PLATFORM
    target: platform.payu
- source_card_id: platform_account.pine_labs.payu_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.payu.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.payu.in
  original_edge:
    source: platform_account.pine_labs.payu_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.payu.in
- source_card_id: platform_account.pine_labs.indusind_bank.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.indusind_bank
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.indusind_bank
  original_edge:
    source: platform_account.pine_labs.indusind_bank.primary
    edge: USES_PLATFORM
    target: platform.indusind_bank
- source_card_id: platform_account.pine_labs.indusind_bank.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.indusind_bank.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.indusind_bank.in
  original_edge:
    source: platform_account.pine_labs.indusind_bank.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.indusind_bank.in
- source_card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.giftcard_reference_reports
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.giftcard_reference_reports
  original_edge:
    source: platform_account.pine_labs.giftcard_reference_reports.primary
    edge: USES_PLATFORM
    target: platform.giftcard_reference_reports
- source_card_id: platform_account.pine_labs.giftcard_reference_reports.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.giftcard_reference_reports.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.giftcard_reference_reports.in
  original_edge:
    source: platform_account.pine_labs.giftcard_reference_reports.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.giftcard_reference_reports.in
- source_card_id: platform_account.pine_labs.escrow_treasury.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.escrow_treasury
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.escrow_treasury
  original_edge:
    source: platform_account.pine_labs.escrow_treasury.primary
    edge: USES_PLATFORM
    target: platform.escrow_treasury
- source_card_id: platform_account.pine_labs.escrow_treasury.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.escrow_treasury.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.escrow_treasury.in
  original_edge:
    source: platform_account.pine_labs.escrow_treasury.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.escrow_treasury.in
- source_card_id: account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.phonepe_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.phonepe_settlement
  original_edge:
    source: account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.phonepe_settlement
- source_card_id: account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.maximize_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.maximize_settlement
  original_edge:
    source: account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.maximize_settlement
- source_card_id: account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.dreamplug_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.dreamplug_settlement
  original_edge:
    source: account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.dreamplug_settlement
- source_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.pinelabs_commission_invoice
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.pinelabs_commission_invoice
  original_edge:
    source: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
    edge: BINDS_TO_TABLE
    target: table.zs_observe.pinelabs_commission_invoice
- source_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.pinelabs_tally
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.pinelabs_tally
  original_edge:
    source: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
    edge: BINDS_TO_TABLE
    target: table.zs_observe.pinelabs_tally
- source_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.pinelab_adhoc_amount
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.pinelab_adhoc_amount
  original_edge:
    source: account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
    edge: BINDS_TO_TABLE
    target: table.zs_observe.pinelab_adhoc_amount
- source_card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.pine_payments
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.pine_payments
  original_edge:
    source: account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
    edge: BINDS_TO_TABLE
    target: table.zs_observe.pine_payments
- source_card_id: account_data_binding.pine_labs.payu_in.primary.payu_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.payu_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.payu_settlement
  original_edge:
    source: account_data_binding.pine_labs.payu_in.primary.payu_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.payu_settlement
- source_card_id: account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.phonepe_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.phonepe_settlement
  original_edge:
    source: account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.phonepe_settlement
- source_card_id: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_ingest.indusind_bank_statement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_ingest.indusind_bank_statement
  original_edge:
    source: account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
    edge: BINDS_TO_TABLE
    target: table.zs_ingest.indusind_bank_statement
- source_card_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.amazon_in_mapper
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.amazon_in_mapper
  original_edge:
    source: account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
    edge: BINDS_TO_TABLE
    target: table.zs_observe.amazon_in_mapper
- source_card_id: account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.phonepe_mapper
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.phonepe_mapper
  original_edge:
    source: account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
    edge: BINDS_TO_TABLE
    target: table.zs_observe.phonepe_mapper
- source_card_id: account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.revalidation_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.revalidation_report
  original_edge:
    source: account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.revalidation_report
- source_card_id: account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.sclp_billing_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.sclp_billing_report
  original_edge:
    source: account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.sclp_billing_report
- source_card_id: account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.credit_limit_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.credit_limit_report
  original_edge:
    source: account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.credit_limit_report
- source_card_id: account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.ignore_card_number_report
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.ignore_card_number_report
  original_edge:
    source: account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
    edge: BINDS_TO_TABLE
    target: table.zs_observe.ignore_card_number_report
- source_card_id: account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.merchant_interest_sheet
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.merchant_interest_sheet
  original_edge:
    source: account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
    edge: BINDS_TO_TABLE
    target: table.zs_observe.merchant_interest_sheet
- source_card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_ingest.indusind_bank_statement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_ingest.indusind_bank_statement
  original_edge:
    source: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
    edge: USES_EVIDENCE_TABLE
    target: table.zs_ingest.indusind_bank_statement
- source_card_id: business_flow_binding.pine_labs.soa_ar_collection_review
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_ingest.indusind_bank_statement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_ingest.indusind_bank_statement
  original_edge:
    source: business_flow_binding.pine_labs.soa_ar_collection_review
    edge: USES_EVIDENCE_TABLE
    target: table.zs_ingest.indusind_bank_statement
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: phonepe_giftcard
  artifacts:
  - phonepe_settlement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: PhonePe | Settlement report, Mapper
  recommended_next_context: Add canonical PhonePe gift-card settlement context markdown/table cards.
- platform_or_area: maximize_pay
  artifacts:
  - maximize_settlement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: Maximize Pay | maximize_settlement
  recommended_next_context: Add canonical Maximize Pay settlement context markdown/table cards.
- platform_or_area: dreamplug
  artifacts:
  - dreamplug_settlement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: DreamPlug | dreamplug_settlement
  recommended_next_context: Add canonical DreamPlug settlement context markdown/table cards.
- platform_or_area: tata_digital
  artifacts:
  - tata_digital_settlement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: Tata Digital | tata_digital_settlement
  recommended_next_context: Add canonical Tata Digital settlement context markdown/table cards.
- platform_or_area: pinelabs_pos
  artifacts:
  - pinelabs_commission_invoice
  - pinelabs_tally
  - pinelab_adhoc_amount
  - pine_payments
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: Pinelabs commission invoice, tally, SOA, adhoc amount, Pine PG
  recommended_next_context: Add canonical Pinelabs POS/Tally/Pine PG context markdown/table cards.
- platform_or_area: payu_in
  artifacts:
  - payu_settlement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: PayU | payu_settlement
  recommended_next_context: Add canonical PayU settlement context markdown/table cards.
- platform_or_area: phonepe_in
  artifacts:
  - phonepe_settlement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: PhonePe | phonepe_settlement
  recommended_next_context: Add canonical PhonePe settlement context markdown/table cards.
- platform_or_area: indusind_bank
  artifacts:
  - indusind_bank_statement
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: IndusInd Bank | Bank statement + correction variant
  recommended_next_context: Add canonical IndusInd bank statement context markdown/table cards.
- platform_or_area: giftcard_reference_reports
  artifacts:
  - amazon_in_mapper
  - phonepe_mapper
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: Amazon.in mapper; PhonePe mapper
  recommended_next_context: Add canonical Gift-card mapper context markdown/table cards.
- platform_or_area: escrow_treasury
  artifacts:
  - revalidation_report
  - sclp_billing_report
  - credit_limit_report
  - ignore_card_number_report
  - merchant_interest_sheet
  impact: Configured in Pine source but not active-queryable from current platform context.
  source_text: Revalidation report, SCLP billing, credit limit, ignore card number, merchant interest sheet
  recommended_next_context: Add canonical Escrow treasury and liability context markdown/table cards.
- platform_or_area: Amazon gift-card extended reports
  artifacts:
  - NAB settlement
  - NAB promo
  - SVC transactions
  - Amazon.in mapper
  impact: Source confirms Amazon gift-card artifacts beyond active amazon_gc_settlement and seller_flex.
  source_text: Amazon India | GC settlement, NAB settlement, NAB promo, SVC transactions, mapper
  recommended_next_context: Add Pine/Amazon gift-card platform-context cards.
- platform_or_area: Woohoo corrections and adhoc
  artifacts:
  - Woohoo OMS rectified
  - Woohoo adhoc
  impact: Source confirms correction/adhoc variants beyond active woohoo_oms.
  source_text: Woohoo | OMS, OMS rectified, Adhoc
  recommended_next_context: Add Woohoo correction and adhoc table cards.
- platform_or_area: table.zs_ingest.indusind_bank_statement
  missing_artifacts:
  - table.zs_ingest.indusind_bank_statement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  - business_flow_binding.pine_labs.soa_ar_collection_review
  generated_by_refactor: true
- platform_or_area: platform_context.amazon.in.giftcard_distribution
  missing_artifacts:
  - platform_context.amazon.in.giftcard_distribution
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.amazon_gc.primary
  generated_by_refactor: true
- platform_or_area: platform_context.amica_technologies.in
  missing_artifacts:
  - platform_context.amica_technologies.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.amica_technologies.primary
  generated_by_refactor: true
- platform_or_area: platform_context.dreamplug.in
  missing_artifacts:
  - platform_context.dreamplug.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.dreamplug.primary
  generated_by_refactor: true
- platform_or_area: platform_context.escrow_treasury.in
  missing_artifacts:
  - platform_context.escrow_treasury.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.escrow_treasury.primary
  generated_by_refactor: true
- platform_or_area: platform_context.first_pay.in
  missing_artifacts:
  - platform_context.first_pay.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.first_pay.primary
  generated_by_refactor: true
- platform_or_area: platform_context.giftcard_reference_reports.in
  missing_artifacts:
  - platform_context.giftcard_reference_reports.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.giftcard_reference_reports.primary
  generated_by_refactor: true
- platform_or_area: platform_context.gullak_technologies.in
  missing_artifacts:
  - platform_context.gullak_technologies.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.gullak.primary
  generated_by_refactor: true
- platform_or_area: platform_context.indusind_bank.in
  missing_artifacts:
  - platform_context.indusind_bank.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.indusind_bank.primary
  generated_by_refactor: true
- platform_or_area: platform_context.maximize_pay.in
  missing_artifacts:
  - platform_context.maximize_pay.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.maximize_pay.primary
  generated_by_refactor: true
- platform_or_area: platform_context.nearby_marketplace.in
  missing_artifacts:
  - platform_context.nearby_marketplace.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.nearby.primary
  generated_by_refactor: true
- platform_or_area: platform_context.paytm.in.giftcard_distribution
  missing_artifacts:
  - platform_context.paytm.in.giftcard_distribution
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.paytm_giftcard.primary
  generated_by_refactor: true
- platform_or_area: platform_context.payu.in
  missing_artifacts:
  - platform_context.payu.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.payu_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.phonepe.in.giftcard_distribution
  missing_artifacts:
  - platform_context.phonepe.in.giftcard_distribution
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.phonepe_giftcard.primary
  generated_by_refactor: true
- platform_or_area: platform_context.pinelabs_pos.in
  missing_artifacts:
  - platform_context.pinelabs_pos.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.pinelabs_pos.primary
  generated_by_refactor: true
- platform_or_area: platform_context.red_giraffe.in
  missing_artifacts:
  - platform_context.red_giraffe.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.red_giraffe.primary
  generated_by_refactor: true
- platform_or_area: platform_context.woohoo.in.giftcard_oms
  missing_artifacts:
  - platform_context.woohoo.in.giftcard_oms
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.woohoo.primary
  generated_by_refactor: true
- platform_or_area: platform.amica_technologies
  missing_artifacts:
  - platform.amica_technologies
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.amica_technologies.primary
  generated_by_refactor: true
- platform_or_area: platform.dreamplug
  missing_artifacts:
  - platform.dreamplug
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.dreamplug.primary
  generated_by_refactor: true
- platform_or_area: platform.escrow_treasury
  missing_artifacts:
  - platform.escrow_treasury
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.escrow_treasury.primary
  generated_by_refactor: true
- platform_or_area: platform.first_pay
  missing_artifacts:
  - platform.first_pay
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.first_pay.primary
  generated_by_refactor: true
- platform_or_area: platform.giftcard_reference_reports
  missing_artifacts:
  - platform.giftcard_reference_reports
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.giftcard_reference_reports.primary
  generated_by_refactor: true
- platform_or_area: platform.gullak_technologies
  missing_artifacts:
  - platform.gullak_technologies
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.gullak.primary
  generated_by_refactor: true
- platform_or_area: platform.indusind_bank
  missing_artifacts:
  - platform.indusind_bank
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.indusind_bank.primary
  generated_by_refactor: true
- platform_or_area: platform.maximize_pay
  missing_artifacts:
  - platform.maximize_pay
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.maximize_pay.primary
  generated_by_refactor: true
- platform_or_area: platform.nearby_marketplace
  missing_artifacts:
  - platform.nearby_marketplace
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.nearby.primary
  generated_by_refactor: true
- platform_or_area: platform.payu
  missing_artifacts:
  - platform.payu
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.payu_in.primary
  generated_by_refactor: true
- platform_or_area: platform.pinelabs_pos
  missing_artifacts:
  - platform.pinelabs_pos
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.pinelabs_pos.primary
  generated_by_refactor: true
- platform_or_area: platform.red_giraffe
  missing_artifacts:
  - platform.red_giraffe
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.red_giraffe.primary
  generated_by_refactor: true
- platform_or_area: platform.woohoo
  missing_artifacts:
  - platform.woohoo
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.pine_labs.woohoo.primary
  generated_by_refactor: true
- platform_or_area: table.zs_observe.amazon_in_mapper
  missing_artifacts:
  - table.zs_observe.amazon_in_mapper
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
  generated_by_refactor: true
- platform_or_area: table.zs_observe.credit_limit_report
  missing_artifacts:
  - table.zs_observe.credit_limit_report
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
  generated_by_refactor: true
- platform_or_area: table.zs_observe.dreamplug_settlement
  missing_artifacts:
  - table.zs_observe.dreamplug_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.ignore_card_number_report
  missing_artifacts:
  - table.zs_observe.ignore_card_number_report
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
  generated_by_refactor: true
- platform_or_area: table.zs_observe.maximize_settlement
  missing_artifacts:
  - table.zs_observe.maximize_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.merchant_interest_sheet
  missing_artifacts:
  - table.zs_observe.merchant_interest_sheet
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
  generated_by_refactor: true
- platform_or_area: table.zs_observe.payu_settlement
  missing_artifacts:
  - table.zs_observe.payu_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.payu_in.primary.payu_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.phonepe_mapper
  missing_artifacts:
  - table.zs_observe.phonepe_mapper
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
  generated_by_refactor: true
- platform_or_area: table.zs_observe.phonepe_settlement
  missing_artifacts:
  - table.zs_observe.phonepe_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
  - account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.pine_payments
  missing_artifacts:
  - table.zs_observe.pine_payments
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  generated_by_refactor: true
- platform_or_area: table.zs_observe.pinelab_adhoc_amount
  missing_artifacts:
  - table.zs_observe.pinelab_adhoc_amount
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  generated_by_refactor: true
- platform_or_area: table.zs_observe.pinelabs_commission_invoice
  missing_artifacts:
  - table.zs_observe.pinelabs_commission_invoice
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  generated_by_refactor: true
- platform_or_area: table.zs_observe.pinelabs_tally
  missing_artifacts:
  - table.zs_observe.pinelabs_tally
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  generated_by_refactor: true
- platform_or_area: table.zs_observe.revalidation_report
  missing_artifacts:
  - table.zs_observe.revalidation_report
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
  generated_by_refactor: true
- platform_or_area: table.zs_observe.sclp_billing_report
  missing_artifacts:
  - table.zs_observe.sclp_billing_report
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- item: group.pine_labs.pine_labs_private_limited
  issue: 'Scope identifier conflict: Pine Labs client profile states group_id 44 and group_level_id 168, while the client-table
    architecture note lists Qwikcilver / Pine Labs as group_id 391 and group_level_id 65352. Current pack follows the client
    profile and preserves the conflict for production review.'
  severity: high
  review_resolution_status: open
- item: tenant.pine_labs
  issue: Client is a gift-card/SVC issuer and distributor, not a standard product/goods seller. Do not apply regular marketplace
    product-seller flows without checking gift-card process context.
  severity: high
  review_resolution_status: open
- item: table.zs_ingest.indusind_bank_statement
  issue: Referenced as evidence_table_ids by 2 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
  - business_flow_binding.pine_labs.soa_ar_collection_review
  generated_by_refactor: true
- item: platform_context.amazon.in.giftcard_distribution
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.amazon_gc.primary
  generated_by_refactor: true
- item: platform_context.amica_technologies.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.amica_technologies.primary
  generated_by_refactor: true
- item: platform_context.dreamplug.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.dreamplug.primary
  generated_by_refactor: true
- item: platform_context.escrow_treasury.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.escrow_treasury.primary
  generated_by_refactor: true
- item: platform_context.first_pay.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.first_pay.primary
  generated_by_refactor: true
- item: platform_context.giftcard_reference_reports.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.giftcard_reference_reports.primary
  generated_by_refactor: true
- item: platform_context.gullak_technologies.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.gullak.primary
  generated_by_refactor: true
- item: platform_context.indusind_bank.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.indusind_bank.primary
  generated_by_refactor: true
- item: platform_context.maximize_pay.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.maximize_pay.primary
  generated_by_refactor: true
- item: platform_context.nearby_marketplace.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.nearby.primary
  generated_by_refactor: true
- item: platform_context.paytm.in.giftcard_distribution
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.paytm_giftcard.primary
  generated_by_refactor: true
- item: platform_context.payu.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.payu_in.primary
  generated_by_refactor: true
- item: platform_context.phonepe.in.giftcard_distribution
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.phonepe_giftcard.primary
  generated_by_refactor: true
- item: platform_context.pinelabs_pos.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.pinelabs_pos.primary
  generated_by_refactor: true
- item: platform_context.red_giraffe.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.red_giraffe.primary
  generated_by_refactor: true
- item: platform_context.woohoo.in.giftcard_oms
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.woohoo.primary
  generated_by_refactor: true
- item: platform_context.amazon.in.giftcard_distribution
  issue: Referenced as platform_context_ids by 2 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  - business_scope_set.pine_labs.giftcard_core
  generated_by_refactor: true
- item: platform_context.amica_technologies.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.dreamplug.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.escrow_treasury.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform_context.first_pay.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.giftcard_reference_reports.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform_context.gullak_technologies.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.indusind_bank.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform_context.maximize_pay.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.nearby_marketplace.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.paytm.in.giftcard_distribution
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.payu.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.payment_gateways
  generated_by_refactor: true
- item: platform_context.phonepe.in.giftcard_distribution
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.pinelabs_pos.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform_context.red_giraffe.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform_context.woohoo.in.giftcard_oms
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.giftcard_core
  generated_by_refactor: true
- item: platform.amica_technologies
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.amica_technologies.primary
  generated_by_refactor: true
- item: platform.dreamplug
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.dreamplug.primary
  generated_by_refactor: true
- item: platform.escrow_treasury
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.escrow_treasury.primary
  generated_by_refactor: true
- item: platform.first_pay
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.first_pay.primary
  generated_by_refactor: true
- item: platform.giftcard_reference_reports
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.giftcard_reference_reports.primary
  generated_by_refactor: true
- item: platform.gullak_technologies
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.gullak.primary
  generated_by_refactor: true
- item: platform.indusind_bank
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.indusind_bank.primary
  generated_by_refactor: true
- item: platform.maximize_pay
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.maximize_pay.primary
  generated_by_refactor: true
- item: platform.nearby_marketplace
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.nearby.primary
  generated_by_refactor: true
- item: platform.payu
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.payu_in.primary
  generated_by_refactor: true
- item: platform.pinelabs_pos
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.pinelabs_pos.primary
  generated_by_refactor: true
- item: platform.red_giraffe
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.red_giraffe.primary
  generated_by_refactor: true
- item: platform.woohoo
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.pine_labs.woohoo.primary
  generated_by_refactor: true
- item: platform.amica_technologies
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.dreamplug
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.escrow_treasury
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform.first_pay
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.giftcard_reference_reports
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform.gullak_technologies
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.indusind_bank
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform.maximize_pay
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.nearby_marketplace
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.payu
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.payment_gateways
  generated_by_refactor: true
- item: platform.pinelabs_pos
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.bank_and_treasury
  generated_by_refactor: true
- item: platform.red_giraffe
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.distribution_settlements
  generated_by_refactor: true
- item: platform.woohoo
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.pine_labs.giftcard_core
  generated_by_refactor: true
- item: table.zs_ingest.indusind_bank_statement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.indusind_bank.primary.indusind_bank_statement
  generated_by_refactor: true
- item: table.zs_observe.amazon_in_mapper
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.giftcard_reference_reports.primary.amazon_in_mapper
  generated_by_refactor: true
- item: table.zs_observe.credit_limit_report
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.credit_limit_report
  generated_by_refactor: true
- item: table.zs_observe.dreamplug_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.dreamplug.primary.dreamplug_settlement
  generated_by_refactor: true
- item: table.zs_observe.ignore_card_number_report
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.ignore_card_number_report
  generated_by_refactor: true
- item: table.zs_observe.maximize_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.maximize_pay.primary.maximize_settlement
  generated_by_refactor: true
- item: table.zs_observe.merchant_interest_sheet
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.merchant_interest_sheet
  generated_by_refactor: true
- item: table.zs_observe.payu_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.payu_in.primary.payu_settlement
  generated_by_refactor: true
- item: table.zs_observe.phonepe_mapper
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.giftcard_reference_reports.primary.phonepe_mapper
  generated_by_refactor: true
- item: table.zs_observe.phonepe_settlement
  issue: Referenced as table_id by 2 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.phonepe_giftcard.primary.phonepe_settlement
  - account_data_binding.pine_labs.phonepe_in.primary.phonepe_settlement
  generated_by_refactor: true
- item: table.zs_observe.pine_payments
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pine_payments
  generated_by_refactor: true
- item: table.zs_observe.pinelab_adhoc_amount
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pinelab_adhoc_amount
  generated_by_refactor: true
- item: table.zs_observe.pinelabs_commission_invoice
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_commission_invoice
  generated_by_refactor: true
- item: table.zs_observe.pinelabs_tally
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_tally
  generated_by_refactor: true
- item: table.zs_observe.revalidation_report
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.revalidation_report
  generated_by_refactor: true
- item: table.zs_observe.sclp_billing_report
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.pine_labs.escrow_treasury.primary.sclp_billing_report
  generated_by_refactor: true
resolved_review_items: []
non_blocking_declared_semantic_reference_gaps:
- reference_id: business_process.giftcard_activation_to_settlement
  reference_type: business_process_ids
  affected_client_cards:
  - business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
- reference_id: reconciliation_profile.giftcard_activation_to_settlement
  reference_type: reconciliation_profile_ids
  affected_client_cards:
  - business_flow_binding.pine_labs.giftcard_activation_to_amazon_settlement
  handling: retained in declared_unresolved_* field; no edge emitted; not treated as production routing blocker
  severity: advisory
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 65
  refactored_card_count: 65
  original_edge_count: 213
  refactored_edge_count: 165
  blocked_edge_count: 48
  source_evidence_count: 44
  source_row_evidence_count: 35
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 22
    account_data_binding: 33
    business_scope_set: 4
    business_flow_binding: 4
  status_counts:
    active: 41
    review_required: 24
  review_status_counts:
    accepted: 32
    review_required: 33
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 80
  canonical_resolution_gap_type_counts:
    platform_id: 13
    platform_context_id: 16
    table_id: 17
    platform_ids: 13
    platform_context_ids: 17
    business_process_ids: 1
    reconciliation_profile_ids: 1
    evidence_table_ids: 2
  status_correction_count: 10
  status_changes:
  - card_id: platform_account.pine_labs.phonepe_giftcard.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.maximize_pay.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.dreamplug.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.payu_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.indusind_bank.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.giftcard_reference_reports.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.pine_labs.escrow_treasury.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.pine_labs.tata_digital.primary.tata_digital_settlement
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: business_flow_binding.pine_labs.distribution_partner_settlement_to_bank_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  - card_id: business_flow_binding.pine_labs.soa_ar_collection_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  id_or_source_replacement_count: 10
  id_or_source_replacements:
  - card_id: account_data_binding.pine_labs.woohoo.primary.woohoo_oms
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_seller_flex
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.amazon_gc.primary.amazon_gc_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.paytm_giftcard.primary.paytm_giftcard_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.nearby.primary.nearby_marketplace
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.amica_technologies.primary.amica_technologies_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.first_pay.primary.first_pay_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.red_giraffe.primary.red_giraffe_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.gullak.primary.gullak_technologies_settlement
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.pine_labs.pinelabs_pos.primary.pinelabs_soa
    kind: source_document_text
    from: Client Tables - Shopify.md
    to: shopify_d2c_oms_v2.md
  resolved_prior_review_count: 0
  open_review_count: 77
  future_context_gap_count: 57
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 2
  non_blocking_declared_semantic_reference_gap_type_counts:
    business_process_ids: 1
    reconciliation_profile_ids: 1
  edge_status_counts:
    emitted: 165
    blocked_unresolved: 48
```
