# Prita Designs Private Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: prita_designs_private_limited_client_runtime_cards_v2_1_refactored
  version: v2_1_refactored
  generated_date: '2026-05-24'
  created_for: Prita Designs Private Limited
  client_slug: prita_designs_private_limited
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - amazon_marketplace.md
  - delhivery_logistics.md
  - flipkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  - xpressbees_logistics.md
  source_client_profile:
    business: Large-scale multi-channel marketplace seller — India domestic plus D2C
    geography: India primary; single Amazon India settlement; no international regions
    source_group_id: 9
    source_group_level_id: 24
    source_group_name: Mensa Brands
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: Client/runtime packs contain tenant, group, platform_account, account_data_binding, business_scope_set, and
    business_flow_binding cards. Active Account Data Bindings are emitted only when currently available canonical platform
    context, client-table evidence, or explicit client table registry evidence supports the table. Configured artifacts without
    table support are preserved as future_context_gaps and review_required bindings instead of invented active mappings.
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  source_json_bad_state: prita_designs_private_limited_runtime_cards_v1_0.json
  source_docx: Prita Designs Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.global_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.international_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.increff.in.wms_operations: platform_context.increff.in
      platform_context.shiprocket.in.oms_order_source: platform_context.shiprocket.in
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: prita_designs_private_limited_runtime_cards_v1_0.json
  source_docx: Prita Designs Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Remapped role-specific Shopify/Increff/Shiprocket/Amazon/Paytm/PhonePe context aliases to uploaded broader canonical contexts
    while preserving the role in account fields.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: platform_account.prita_designs_private_limited.increff_wms.primary
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  - card_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  status_changes:
  - card_id: platform_account.prita_designs_private_limited.cred_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.klip_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.blitz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_oms
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_settlement
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_returns
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: platform_account.prita_designs_private_limited.smartr_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  blocked_edge_count: 24
  canonical_resolution_gap_count: 28
  resolved_prior_review_count: 0
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.prita_designs_private_limited.docx.section.01_identity
  source_document: Prita Designs Private Limited.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L11
  summary: '* Business: Large-scale multi-channel marketplace seller — India domestic + D2C

    * Geography: India (primary), single Amazon India settlement (no international regions)

    * OMS/WMS: Increff (warehouse/fulfilment), Shiprocket (order source), Shopify (D2C)

    * Logistics: Delhivery, Xpressbees, Smartr (settlement only)

    * Payment gateways: Razorpay, Paytm, Cashfree, Easebuzz

    * GROUP LEVEL ID :  24

    * GROUP ID :  9

    * GROUP NAME : Mensa Brands

    * CLIENT NAME : P**rita Designs Private Limited**'
  raw_lines:
  - '* Business: Large-scale multi-channel marketplace seller — India domestic + D2C'
  - '* Geography: India (primary), single Amazon India settlement (no international regions)'
  - '* OMS/WMS: Increff (warehouse/fulfilment), Shiprocket (order source), Shopify (D2C)'
  - '* Logistics: Delhivery, Xpressbees, Smartr (settlement only)'
  - '* Payment gateways: Razorpay, Paytm, Cashfree, Easebuzz'
  - '* GROUP LEVEL ID :  24'
  - '* GROUP ID :  9'
  - '* GROUP NAME : Mensa Brands'
  - '* CLIENT NAME : P**rita Designs Private Limited**'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: docx_section
  source_lines: L13-L26
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions |

    | Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |

    | Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT +
    PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |

    | Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |

    | Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 storefronts, Popup settlement new
    format, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions |

    | JioMart | OMS, Settlement, Returns, Transactions |

    | Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |

    | Tata Cliq | OMS, Settlement, Transactions |

    | Cred    | Sales, Settlement, Returns, Transactions |

    | Snapmint | Settlement only       |

    | Klip · Blitz | Settlement only       |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |'
  - '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT
    + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |'
  - '| Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |'
  - '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 storefronts, Popup settlement
    new format, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  - '| JioMart | OMS, Settlement, Returns, Transactions |'
  - '| Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |'
  - '| Tata Cliq | OMS, Settlement, Transactions |'
  - '| Cred    | Sales, Settlement, Returns, Transactions |'
  - '| Snapmint | Settlement only       |'
  - '| Klip · Blitz | Settlement only       |'
  row_count: 11
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L16
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions |'
  summary: 'Amazon India: channel=Amazon India; data_types_configured=OMS (B2C + B2B), Settlement, Disbursement, Fee preview,
    Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L17
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |'
  summary: 'Flipkart: channel=Flipkart; data_types_configured=OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google
    Ads), Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L18
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
      (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions
  raw_text: '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
    (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |'
  summary: 'Myntra: channel=Myntra; data_types_configured=OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement
    (JIT + PPMP), Non-order settlement (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS +
    VFS expenses, Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L19
  row_key: Meesho
  columns:
    channel: Meesho
    data_types_configured: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
      Transactions
  raw_text: '| Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
    Transactions |'
  summary: 'Meesho: channel=Meesho; data_types_configured=Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other
    charges, Adjustment, Brand mapping, Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L20
  row_key: Nykaa
  columns:
    channel: Nykaa
    data_types_configured: OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 storefronts, Popup settlement
      new format, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions
  raw_text: '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 storefronts, Popup settlement
    new format, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  summary: 'Nykaa: channel=Nykaa; data_types_configured=OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement
    x4 storefronts, Popup settlement new format, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L21
  row_key: JioMart
  columns:
    channel: JioMart
    data_types_configured: OMS, Settlement, Returns, Transactions
  raw_text: '| JioMart | OMS, Settlement, Returns, Transactions |'
  summary: 'JioMart: channel=JioMart; data_types_configured=OMS, Settlement, Returns, Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L22
  row_key: Snapdeal
  columns:
    channel: Snapdeal
    data_types_configured: OMS, Settlement, Commission file (5-sheet), Transactions
  raw_text: '| Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |'
  summary: 'Snapdeal: channel=Snapdeal; data_types_configured=OMS, Settlement, Commission file (5-sheet), Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.08_tata_cliq
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L23
  row_key: Tata Cliq
  columns:
    channel: Tata Cliq
    data_types_configured: OMS, Settlement, Transactions
  raw_text: '| Tata Cliq | OMS, Settlement, Transactions |'
  summary: 'Tata Cliq: channel=Tata Cliq; data_types_configured=OMS, Settlement, Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L24
  row_key: Cred
  columns:
    channel: Cred
    data_types_configured: Sales, Settlement, Returns, Transactions
  raw_text: '| Cred    | Sales, Settlement, Returns, Transactions |'
  summary: 'Cred: channel=Cred; data_types_configured=Sales, Settlement, Returns, Transactions'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L25
  row_key: Snapmint
  columns:
    channel: Snapmint
    data_types_configured: Settlement only
  raw_text: '| Snapmint | Settlement only       |'
  summary: 'Snapmint: channel=Snapmint; data_types_configured=Settlement only'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces
  evidence_type: configured_source_row
  source_line: L26
  row_key: Klip · Blitz
  columns:
    channel: Klip · Blitz
    data_types_configured: Settlement only
  raw_text: '| Klip · Blitz | Settlement only       |'
  summary: 'Klip · Blitz: channel=Klip · Blitz; data_types_configured=Settlement only'
  confidence: high
- id: ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces / D2C / other order sources
  evidence_type: docx_section
  source_lines: L27-L31
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Shopify | D2C OMS               |

    | Shiprocket | Sales / OMS           |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Shopify | D2C OMS               |'
  - '| Shiprocket | Sales / OMS           |'
  row_count: 2
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.01_shopify
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces / D2C / other order sources
  evidence_type: configured_source_row
  source_line: L30
  row_key: Shopify
  columns:
    channel: Shopify
    data_types_configured: D2C OMS
  raw_text: '| Shopify | D2C OMS               |'
  summary: 'Shopify: channel=Shopify; data_types_configured=D2C OMS'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.02_shiprocket
  source_document: Prita Designs Private Limited.docx
  source_section: Active sales channels / Domestic marketplaces / D2C / other order sources
  evidence_type: configured_source_row
  source_line: L31
  row_key: Shiprocket
  columns:
    channel: Shiprocket
    data_types_configured: Sales / OMS
  raw_text: '| Shiprocket | Sales / OMS           |'
  summary: 'Shiprocket: channel=Shiprocket; data_types_configured=Sales / OMS'
  confidence: high
- id: ev.prita_designs_private_limited.docx.section.04_wms_fulfilment_layer
  source_document: Prita Designs Private Limited.docx
  source_section: WMS / fulfilment layer
  evidence_type: docx_section
  source_lines: L32-L35
  summary: '| System | Files configured |

    |--------|------------------|

    | Increff | Sales, Returns, Returns processed |'
  raw_lines:
  - '| System | Files configured |'
  - '|--------|------------------|'
  - '| Increff | Sales, Returns, Returns processed |'
  row_count: 1
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  source_document: Prita Designs Private Limited.docx
  source_section: WMS / fulfilment layer
  evidence_type: configured_source_row
  source_line: L35
  row_key: Increff
  columns:
    system: Increff
    files_configured: Sales, Returns, Returns processed
  raw_text: '| Increff | Sales, Returns, Returns processed |'
  summary: 'Increff: system=Increff; files_configured=Sales, Returns, Returns processed'
  confidence: high
- id: ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  source_document: Prita Designs Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: docx_section
  source_lines: L36-L41
  summary: '| Courier | Files configured |

    |---------|------------------|

    | Delhivery | Settlement       |

    | Xpressbees | Settlement       |

    | Smartr  | Settlement       |'
  raw_lines:
  - '| Courier | Files configured |'
  - '|---------|------------------|'
  - '| Delhivery | Settlement       |'
  - '| Xpressbees | Settlement       |'
  - '| Smartr  | Settlement       |'
  row_count: 3
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.01_delhivery
  source_document: Prita Designs Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L39
  row_key: Delhivery
  columns:
    courier: Delhivery
    files_configured: Settlement
  raw_text: '| Delhivery | Settlement       |'
  summary: 'Delhivery: courier=Delhivery; files_configured=Settlement'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.02_xpressbees
  source_document: Prita Designs Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L40
  row_key: Xpressbees
  columns:
    courier: Xpressbees
    files_configured: Settlement
  raw_text: '| Xpressbees | Settlement       |'
  summary: 'Xpressbees: courier=Xpressbees; files_configured=Settlement'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.03_smartr
  source_document: Prita Designs Private Limited.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L41
  row_key: Smartr
  columns:
    courier: Smartr
    files_configured: Settlement
  raw_text: '| Smartr  | Settlement       |'
  summary: 'Smartr: courier=Smartr; files_configured=Settlement'
  confidence: high
- id: ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  source_document: Prita Designs Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: docx_section
  source_lines: L42-L48
  summary: '| Gateway | Pipeline target | Notes |

    |---------|-----------------|-------|

    | Razorpay | razorpay_payin  |       |

    | Paytm   | paytm_payin     | Single-sheet variant |

    | Cashfree | cashfree_payin  | Settlement Txns sheet |

    | Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) — appears twice in config, verify deduplication |'
  raw_lines:
  - '| Gateway | Pipeline target | Notes |'
  - '|---------|-----------------|-------|'
  - '| Razorpay | razorpay_payin  |       |'
  - '| Paytm   | paytm_payin     | Single-sheet variant |'
  - '| Cashfree | cashfree_payin  | Settlement Txns sheet |'
  - '| Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) — appears twice in config, verify deduplication |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.01_razorpay
  source_document: Prita Designs Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L45
  row_key: Razorpay
  columns:
    gateway: Razorpay
    pipeline_target: razorpay_payin
    notes: ''
  raw_text: '| Razorpay | razorpay_payin  |       |'
  summary: 'Razorpay: gateway=Razorpay; pipeline_target=razorpay_payin; notes='
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.02_paytm
  source_document: Prita Designs Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L46
  row_key: Paytm
  columns:
    gateway: Paytm
    pipeline_target: paytm_payin
    notes: Single-sheet variant
  raw_text: '| Paytm   | paytm_payin     | Single-sheet variant |'
  summary: 'Paytm: gateway=Paytm; pipeline_target=paytm_payin; notes=Single-sheet variant'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.03_cashfree
  source_document: Prita Designs Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L47
  row_key: Cashfree
  columns:
    gateway: Cashfree
    pipeline_target: cashfree_payin
    notes: Settlement Txns sheet
  raw_text: '| Cashfree | cashfree_payin  | Settlement Txns sheet |'
  summary: 'Cashfree: gateway=Cashfree; pipeline_target=cashfree_payin; notes=Settlement Txns sheet'
  confidence: high
- id: ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.04_easebuzz
  source_document: Prita Designs Private Limited.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L48
  row_key: Easebuzz
  columns:
    gateway: Easebuzz
    pipeline_target: easebuzz_settlement
    notes: Two-sheet (header_1 + header_2) — appears twice in config, verify deduplication
  raw_text: '| Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) — appears twice in config, verify deduplication
    |'
  summary: 'Easebuzz: gateway=Easebuzz; pipeline_target=easebuzz_settlement; notes=Two-sheet (header_1 + header_2) — appears
    twice in config, verify deduplication'
  confidence: high
- id: ev.prita_designs_private_limited.docx.section.07_marketplace_transactions_layer
  source_document: Prita Designs Private Limited.docx
  source_section: Marketplace transactions layer
  evidence_type: docx_section
  source_lines: L49-L50
  summary: 'The following channels have a dedicated `marketplace_transactions` feed in addition to their settlement files
    — these are bank-side transaction records used for payment matching: Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart,
    Snapdeal, Tata Cliq, Cred'
  raw_lines:
  - 'The following channels have a dedicated `marketplace_transactions` feed in addition to their settlement files — these
    are bank-side transaction records used for payment matching: Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart, Snapdeal,
    Tata Cliq, Cred'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.prita_designs_private_limited
  canonical_id: tenant.prita_designs_private_limited
  name: Prita Designs Private Limited
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.01_identity
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.01_shopify
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  description: India domestic and D2C multi-channel marketplace seller using ZenStatement for marketplace, Shopify, Shiprocket,
    Increff, logistics, payment gateway, and settlement reconciliation.
  fields:
    tenant_name: Prita Designs Private Limited
    tenant_code: PRITA_DESIGNS
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.prita_designs_private_limited.mensa_brands
  canonical_id: group.prita_designs_private_limited.mensa_brands
  name: Mensa Brands
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_name: Mensa Brands
    group_code: MENSA_BRANDS
    group_type: operational_unit
    business_meaning: Mensa Brands operating group for Prita Designs India domestic marketplace and D2C flows.
    country_or_region: India
    default_currency: INR
    source_scope_identifiers:
      group_id: 9
      group_level_id: 24
      representation_rule: Use these values through Account Data Binding scope_keys.
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  canonical_id: platform_account.prita_designs_private_limited.amazon_in.primary
  name: Amazon India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Amazon India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.in
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  canonical_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  name: Flipkart India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Flipkart India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.flipkart
        source_documents:
        - flipkart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.flipkart.in
        source_documents:
        - flipkart_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  canonical_id: platform_account.prita_designs_private_limited.myntra_in.primary
  name: Myntra India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: Myntra India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return, VHS + VFS expenses, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.myntra
        source_documents:
        - myntra_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.myntra.in
        source_documents:
        - myntra_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  canonical_id: platform_account.prita_designs_private_limited.meesho_in.primary
  name: Meesho India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.meesho
    platform_context_id: platform_context.meesho.in
    account_name: Meesho India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.meesho
        source_documents:
        - meesho_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.meesho.in
        source_documents:
        - meesho_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  canonical_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  name: Nykaa India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.nykaa
    platform_context_id: platform_context.nykaa_fashion.in
    account_name: Nykaa India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.nykaa
        source_documents:
        - nykaa_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.nykaa_fashion.in
        source_documents:
        - nykaa_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.nykaa.in
      to: platform_context.nykaa_fashion.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  canonical_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  name: JioMart India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.jiomart
    platform_context_id: platform_context.jiomart.in
    account_name: JioMart India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.jiomart
        source_documents:
        - jiomart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.jiomart.in
        source_documents:
        - jiomart_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  canonical_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  name: Snapdeal India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.snapdeal
    platform_context_id: platform_context.snapdeal.in
    account_name: Snapdeal India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.snapdeal
        source_documents:
        - snapdeal_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.snapdeal.in
        source_documents:
        - snapdeal_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  canonical_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  name: Tata Cliq India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.08_tata_cliq
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.tatacliq
    platform_context_id: platform_context.tatacliq.in
    account_name: Tata Cliq India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Tata Cliq | OMS, Settlement, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.tatacliq
        source_documents:
        - tatacliq_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.tatacliq.in
        source_documents:
        - tatacliq_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.cred_in.primary
  canonical_id: platform_account.prita_designs_private_limited.cred_in.primary
  name: Cred India marketplace account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Cred India marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    country_or_region: India
    declared_platform_id: platform.cred
    declared_platform_label: CRED marketplace/channel
    declared_platform_context_id: platform_context.cred.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.cred
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.cred.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.klip_in.primary
  canonical_id: platform_account.prita_designs_private_limited.klip_in.primary
  name: Klip India settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Klip India settlement account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Klip | Settlement only
    country_or_region: India
    declared_platform_id: platform.klip
    declared_platform_label: Klip channel
    declared_platform_context_id: platform_context.klip.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.klip
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.klip.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.blitz_in.primary
  canonical_id: platform_account.prita_designs_private_limited.blitz_in.primary
  name: Blitz India settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Blitz India settlement account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Blitz | Settlement only
    country_or_region: India
    declared_platform_id: platform.blitz
    declared_platform_label: Blitz channel
    declared_platform_context_id: platform_context.blitz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.blitz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.blitz.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  canonical_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  name: Snapmint India settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Snapmint India settlement account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Snapmint | Settlement only
    country_or_region: India
    declared_platform_id: platform.snapmint
    declared_platform_label: Snapmint BNPL/settlement channel
    declared_platform_context_id: platform_context.snapmint.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.snapmint
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.snapmint.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  canonical_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  name: Shopify D2C primary account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.01_shopify
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Shopify D2C primary account
    account_type: d2c_oms
    account_role: direct_to_consumer_order_source
    source_account_identifier: null
    source_config_text: Shopify | D2C OMS
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shopify
        source_documents:
        - shopify_d2c_oms_v2.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shopify.in_and_global.d2c_oms_client_config
        source_documents:
        - shopify_d2c_oms_v2.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in.d2c_oms
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  canonical_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  name: Shiprocket order-source account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.shiprocket
    platform_context_id: platform_context.shiprocket.in
    account_name: Shiprocket order-source account
    account_type: oms_order_source
    account_role: d2c_order_source
    source_account_identifier: null
    source_config_text: Shiprocket | Sales / OMS
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shiprocket
        source_documents:
        - shiprocket_logistics.md
        - shiprocket_logistics_aggregator.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shiprocket.in
        source_documents:
        - shiprocket_logistics.md
        - shiprocket_logistics_aggregator.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shiprocket.in.oms_order_source
      to: platform_context.shiprocket.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  canonical_id: platform_account.prita_designs_private_limited.increff_wms.primary
  name: Increff WMS/fulfilment account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.increff
    platform_context_id: platform_context.increff.in
    account_name: Increff WMS/fulfilment account
    account_type: wms_operations
    account_role: fulfilment_operations
    source_account_identifier: null
    source_config_text: Increff | Sales, Returns, Returns processed
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.increff
        source_documents:
        - increff_operations.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.increff.in
        source_documents:
        - increff_operations.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.increff.in.wms_operations
      to: platform_context.increff.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  canonical_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  name: Delhivery settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.01_delhivery
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.delhivery
    platform_context_id: platform_context.delhivery.in
    account_name: Delhivery settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Delhivery | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.delhivery
        source_documents:
        - delhivery_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.delhivery.in
        source_documents:
        - delhivery_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  canonical_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  name: Xpressbees settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.02_xpressbees
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.xpressbees
    platform_context_id: platform_context.xpressbees.in
    account_name: Xpressbees settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Xpressbees | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.xpressbees
        source_documents:
        - xpressbees_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.xpressbees.in
        source_documents:
        - xpressbees_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  canonical_id: platform_account.prita_designs_private_limited.smartr_in.primary
  name: Smartr settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.03_smartr
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Smartr settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Smartr | Settlement
    country_or_region: India
    declared_platform_id: platform.smartr
    declared_platform_label: Smartr logistics
    declared_platform_context_id: platform_context.smartr.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.smartr
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.smartr.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  canonical_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  name: Razorpay payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.01_razorpay
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: Razorpay payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Razorpay | razorpay_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.razorpay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.razorpay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  canonical_id: platform_account.prita_designs_private_limited.paytm_in.primary
  name: Paytm payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.02_paytm
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.paytm
    platform_context_id: platform_context.paytm.in
    account_name: Paytm payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Paytm | paytm_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.paytm.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  canonical_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  name: Cashfree payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.03_cashfree
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: Cashfree payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Cashfree | cashfree_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  canonical_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  name: Easebuzz payment gateway account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.04_easebuzz
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Easebuzz payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Easebuzz | easebuzz_settlement
    country_or_region: India
    declared_platform_id: platform.easebuzz
    declared_platform_label: Easebuzz payment gateway
    declared_platform_context_id: platform_context.easebuzz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.easebuzz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.easebuzz.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  canonical_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  name: Marketplace transactions feed
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    account_name: Marketplace transactions feed
    account_type: client_feed
    account_role: bank_side_or_transaction_matching_feed
    source_account_identifier: null
    source_config_text: marketplace_transactions feed
    country_or_region: India
    declared_platform_id: platform.marketplace_transactions
    declared_platform_label: platform.marketplace_transactions
    declared_platform_context_id: platform_context.marketplace_transactions.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.marketplace_transactions
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.marketplace_transactions.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_oms
  canonical_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_oms
  name: account data binding / prita designs private limited / amazon in / primary / amazon oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_oms
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.amazon_in.primary to table.zs_observe.amazon_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_settlement
  name: account data binding / prita designs private limited / amazon in / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.amazon_in.primary to table.zs_observe.amazon_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_disbursment
  canonical_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_disbursment
  name: account data binding / prita designs private limited / amazon in / primary / amazon disbursment
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_disbursment
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.amazon_in.primary to table.zs_observe.amazon_disbursment using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    registry_notes:
    - Canonical source uses the spelling disbursment.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_fee_preview
  canonical_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_fee_preview
  name: account data binding / prita designs private limited / amazon in / primary / amazon fee preview
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_fee_preview
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_fee_preview
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.amazon_in.primary to table.zs_observe.amazon_fee_preview using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.oms
  canonical_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.oms
  name: account data binding / prita designs private limited / flipkart in / primary / oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
    table_id: table.flipkart.oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.oms
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.flipkart_in.primary to table.flipkart.oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.cashback
  canonical_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.cashback
  name: account data binding / prita designs private limited / flipkart in / primary / cashback
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
    table_id: table.flipkart.cashback
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.cashback
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.flipkart_in.primary to table.flipkart.cashback using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.settlement
  canonical_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.settlement
  name: account data binding / prita designs private limited / flipkart in / primary / settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.settlement
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.flipkart_in.primary to table.flipkart.settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.commission
  canonical_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.commission
  name: account data binding / prita designs private limited / flipkart in / primary / commission
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
    table_id: table.flipkart.commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.commission
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.flipkart_in.primary to table.flipkart.commission using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms
  canonical_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms
  name: account data binding / prita designs private limited / myntra in / primary / myntra oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_oms
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_settlement
  name: account data binding / prita designs private limited / myntra in / primary / myntra settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_reverse
  canonical_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_reverse
  name: account data binding / prita designs private limited / myntra in / primary / myntra reverse
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_reverse
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_non_order_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_non_order_settlement
  name: account data binding / prita designs private limited / myntra in / primary / myntra non order settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_non_order_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms_settlement
  name: account data binding / prita designs private limited / myntra in / primary / myntra oms settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_oms_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_sales
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_sales
  name: account data binding / prita designs private limited / meesho in / primary / meesho sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_sales
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_settlement
  name: account data binding / prita designs private limited / meesho in / primary / meesho settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_settlement
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_returns
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_returns
  name: account data binding / prita designs private limited / meesho in / primary / meesho returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_returns
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse
  name: account data binding / prita designs private limited / meesho in / primary / meesho reverse
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_reverse
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_reverse using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_forward_expenses
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_forward_expenses
  name: account data binding / prita designs private limited / meesho in / primary / meesho forward expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_forward_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_forward_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_forward_expenses using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse_expenses
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse_expenses
  name: account data binding / prita designs private limited / meesho in / primary / meesho reverse expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_reverse_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_reverse_expenses using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_other_charges_expenses
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_other_charges_expenses
  name: account data binding / prita designs private limited / meesho in / primary / meesho other charges expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_other_charges_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_other_charges_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_other_charges_expenses
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_brand_mapping
  canonical_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_brand_mapping
  name: account data binding / prita designs private limited / meesho in / primary / meesho brand mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_brand_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_brand_mapping
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.meesho_in.primary to table.zs_observe.meesho_brand_mapping using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_oms
  canonical_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_oms
  name: account data binding / prita designs private limited / nykaa in / primary / nykaa oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_oms
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.nykaa_in.primary to table.zs_observe.nykaa_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_settlement
  name: account data binding / prita designs private limited / nykaa in / primary / nykaa settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_settlement
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.nykaa_in.primary to table.zs_observe.nykaa_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_addition_charge
  canonical_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_addition_charge
  name: account data binding / prita designs private limited / nykaa in / primary / nykaa addition charge
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_addition_charge
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_addition_charge
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.nykaa_in.primary to table.zs_observe.nykaa_addition_charge using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapper_gst
  canonical_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapper_gst
  name: account data binding / prita designs private limited / nykaa in / primary / nykaa mapper gst
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapper_gst
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_mapper_gst
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.nykaa_in.primary to table.zs_observe.nykaa_mapper_gst using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapping
  canonical_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapping
  name: account data binding / prita designs private limited / nykaa in / primary / nykaa mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.05_nykaa
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_mapping
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.nykaa_in.primary to table.zs_observe.nykaa_mapping using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_oms
  canonical_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_oms
  name: account data binding / prita designs private limited / jiomart in / primary / jiomart oms
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.jiomart_in.primary
    table_id: table.zs_observe.jiomart_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_oms
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client profile confirms JioMart, but current canonical JioMart source does not confirm this group_level_id. Keep inactive
      until entity scope is verified.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_settlement
  name: account data binding / prita designs private limited / jiomart in / primary / jiomart settlement
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.jiomart_in.primary
    table_id: table.zs_observe.jiomart_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_settlement
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client profile confirms JioMart, but current canonical JioMart source does not confirm this group_level_id. Keep inactive
      until entity scope is verified.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_returns
  canonical_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_returns
  name: account data binding / prita designs private limited / jiomart in / primary / jiomart returns
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.jiomart_in.primary
    table_id: table.zs_observe.jiomart_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_returns
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client profile confirms JioMart, but current canonical JioMart source does not confirm this group_level_id. Keep inactive
      until entity scope is verified.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: binding_table_now_resolves_to_uploaded_canonical_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_oms
  canonical_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_oms
  name: account data binding / prita designs private limited / snapdeal in / primary / snapdeal oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_oms
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_settlement
  name: account data binding / prita designs private limited / snapdeal in / primary / snapdeal settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_settlement
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_commission
  canonical_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_commission
  name: account data binding / prita designs private limited / snapdeal in / primary / snapdeal commission
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_commission
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_commission using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_sales_return
  canonical_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_sales_return
  name: account data binding / prita designs private limited / snapdeal in / primary / snapdeal sales return
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_sales_return
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_sales_return
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_sales_return using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_payments
  canonical_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_payments
  name: account data binding / prita designs private limited / snapdeal in / primary / snapdeal payments
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_payments
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_payments
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_payments using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_non_order
  canonical_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_non_order
  name: account data binding / prita designs private limited / snapdeal in / primary / snapdeal non order
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.07_snapdeal
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_non_order
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_non_order
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_non_order using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_oms
  canonical_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_oms
  name: account data binding / prita designs private limited / tatacliq in / primary / tatacliq oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.08_tata_cliq
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Tata Cliq | OMS, Settlement, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tatacliq_oms
      source_documents:
      - tatacliq_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.tatacliq_in.primary to table.zs_observe.tatacliq_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_settlement
  name: account data binding / prita designs private limited / tatacliq in / primary / tatacliq settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.08_tata_cliq
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Tata Cliq | OMS, Settlement, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tatacliq_settlement
      source_documents:
      - tatacliq_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.tatacliq_in.primary to table.zs_observe.tatacliq_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
  canonical_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
  name: account data binding / prita designs private limited / cred in / primary / cred sales
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.cred_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.cred_sales
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cred_sales
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.cred_in.primary to table.zs_observe.cred_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
  name: account data binding / prita designs private limited / cred in / primary / cred settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.cred_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.cred_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cred_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.cred_in.primary to table.zs_observe.cred_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
  canonical_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
  name: account data binding / prita designs private limited / cred in / primary / cred returns
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.cred_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.cred_returns
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cred_returns
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.cred_in.primary to table.zs_observe.cred_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
  name: account data binding / prita designs private limited / klip in / primary / klip settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.klip_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Klip | Settlement only
    declared_table_id: table.zs_observe.klip_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.klip_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.klip_in.primary to table.zs_observe.klip_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
  name: account data binding / prita designs private limited / blitz in / primary / blitz settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.blitz_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Blitz | Settlement only
    declared_table_id: table.zs_observe.blitz_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.blitz_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.blitz_in.primary to table.zs_observe.blitz_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
  name: account data binding / prita designs private limited / snapmint in / primary / snapmint settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.10_snapmint
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.11_klip_blitz
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.snapmint_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapmint | Settlement only
    declared_table_id: table.zs_observe.snapmint_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.snapmint_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.snapmint_in.primary to table.zs_observe.snapmint_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
  canonical_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
  name: account data binding / prita designs private limited / shopify d2c / primary / shopify oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.01_shopify
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Shopify | D2C OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_oms
      source_documents:
      - logistics_domain.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.prita_designs_private_limited.shopify_d2c.primary to table.zs_observe.shopify_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
  canonical_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
  name: account data binding / prita designs private limited / shiprocket order source / primary / shiprocket oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - shiprocket_logistics.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
    table_id: table.zs_observe.shiprocket_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Shiprocket | Sales / OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shiprocket_oms
      source_documents:
      - shiprocket_logistics.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.prita_designs_private_limited.shiprocket_order_source.primary to table.zs_observe.shiprocket_oms
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
  canonical_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
  name: account data binding / prita designs private limited / increff wms / primary / increff sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.increff_wms.primary
    table_id: table.zs_observe.increff_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Increff | Sales, Returns, Returns processed
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.increff_sales
      source_documents:
      - increff_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.increff_wms.primary to table.zs_observe.increff_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
  canonical_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
  name: account data binding / prita designs private limited / increff wms / primary / increff returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.04_meesho
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.09_cred
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.increff_wms.primary
    table_id: table.zs_observe.increff_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Increff | Sales, Returns, Returns processed
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.increff_returns
      source_documents:
      - increff_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.increff_wms.primary to table.zs_observe.increff_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.delhivery_in.primary.delhivery_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.delhivery_in.primary.delhivery_settlement
  name: account data binding / prita designs private limited / delhivery in / primary / delhivery settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.01_delhivery
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.delhivery_in.primary
    table_id: table.zs_observe.delhivery_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Delhivery | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.delhivery_settlement
      source_documents:
      - delhivery_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.delhivery_in.primary to table.zs_observe.delhivery_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.xpressbees_in.primary.xpressbees_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.xpressbees_in.primary.xpressbees_settlement
  name: account data binding / prita designs private limited / xpressbees in / primary / xpressbees settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.02_xpressbees
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
    table_id: table.zs_observe.xpressbees_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Xpressbees | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.xpressbees_settlement
      source_documents:
      - xpressbees_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.xpressbees_in.primary to table.zs_observe.xpressbees_settlement
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  name: account data binding / prita designs private limited / smartr in / primary / smartr settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.03_smartr
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.01_amazon_india
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.02_flipkart
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.smartr_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Smartr | Settlement
    declared_table_id: table.zs_observe.smartr_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.smartr_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.smartr_in.primary to table.zs_observe.smartr_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.razorpay_in.primary.razorpay_payin
  canonical_id: account_data_binding.prita_designs_private_limited.razorpay_in.primary.razorpay_payin
  name: account data binding / prita designs private limited / razorpay in / primary / razorpay payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.01_razorpay
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.razorpay_in.primary
    table_id: table.zs_observe.razorpay_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Razorpay | razorpay_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.razorpay_in.primary to table.zs_observe.razorpay_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.paytm_in.primary.paytm_payin
  canonical_id: account_data_binding.prita_designs_private_limited.paytm_in.primary.paytm_payin
  name: account data binding / prita designs private limited / paytm in / primary / paytm payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.02_paytm
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.paytm_in.primary
    table_id: table.zs_observe.paytm_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Paytm | paytm_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.paytm_in.primary to table.zs_observe.paytm_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.cashfree_in.primary.cashfree_payin
  canonical_id: account_data_binding.prita_designs_private_limited.cashfree_in.primary.cashfree_payin
  name: account data binding / prita designs private limited / cashfree in / primary / cashfree payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.03_cashfree
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.cashfree_in.primary
    table_id: table.zs_observe.cashfree_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cashfree | cashfree_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.cashfree_in.primary to table.zs_observe.cashfree_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  canonical_id: account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  name: account data binding / prita designs private limited / easebuzz in / primary / easebuzz settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.06_payment_gateway_reconciliation
  - ev.prita_designs_private_limited.docx.row.06_payment_gateway_reconciliation.04_easebuzz
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Easebuzz | easebuzz_settlement
    declared_table_id: table.zs_observe.easebuzz_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.easebuzz_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.easebuzz_in.primary to table.zs_observe.easebuzz_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
  canonical_id: account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
  name: account data binding / prita designs private limited / marketplace transactions / primary / marketplace transactions
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.01_identity
  fields:
    platform_account_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 24
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Dedicated marketplace_transactions feed active in the client profile
    declared_table_id: table.zs_observe.marketplace_transactions
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.marketplace_transactions
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.prita_designs_private_limited.marketplace_transactions.primary to table.zs_observe.marketplace_transactions
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  canonical_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  name: Prita active canonical domestic marketplaces
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.row.02_active_sales_channels_domestic_marketplaces.06_jiomart
  description: Canonical-mapped active domestic marketplaces for Prita. JioMart and newer/fintech marketplaces are handled
    separately where context is incomplete.
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    scope_name: Prita active canonical domestic marketplaces
    scope_type: marketplace_seller_scope
    platform_account_ids:
    - platform_account.prita_designs_private_limited.amazon_in.primary
    - platform_account.prita_designs_private_limited.flipkart_in.primary
    - platform_account.prita_designs_private_limited.myntra_in.primary
    - platform_account.prita_designs_private_limited.meesho_in.primary
    - platform_account.prita_designs_private_limited.nykaa_in.primary
    - platform_account.prita_designs_private_limited.snapdeal_in.primary
    - platform_account.prita_designs_private_limited.tatacliq_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    - platform.meesho
    - platform.nykaa
    - platform.snapdeal
    - platform.tatacliq
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    - platform_context.meesho.in
    - platform_context.nykaa_fashion.in
    - platform_context.snapdeal.in
    - platform_context.tatacliq.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.nykaa.in
      to: platform_context.nykaa_fashion.in
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  canonical_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  name: Prita Shopify, Shiprocket, and Increff operations
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - increff_operations.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.01_shopify
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  description: D2C order source, Shiprocket order-source feed, and Increff WMS fulfilment scope.
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    scope_name: Prita Shopify, Shiprocket, and Increff operations
    scope_type: d2c_wms_scope
    platform_account_ids:
    - platform_account.prita_designs_private_limited.shopify_d2c.primary
    - platform_account.prita_designs_private_limited.shiprocket_order_source.primary
    - platform_account.prita_designs_private_limited.increff_wms.primary
    platform_ids:
    - platform.shopify
    - platform.shiprocket
    - platform.increff
    platform_context_ids:
    - platform_context.shopify.in_and_global.d2c_oms_client_config
    - platform_context.shiprocket.in
    - platform_context.increff.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in.d2c_oms
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    - kind: canonical_id
      from: platform_context.shiprocket.in.oms_order_source
      to: platform_context.shiprocket.in
    - kind: canonical_id
      from: platform_context.increff.in.wms_operations
      to: platform_context.increff.in
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  canonical_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  name: Prita logistics settlement scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - delhivery_logistics.md
  - xpressbees_logistics.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.05_logistics_courier_reconciliation.03_smartr
  description: Courier settlement scope. Smartr requires added context before active use.
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    scope_name: Prita logistics settlement scope
    scope_type: logistics_settlement_scope
    platform_account_ids:
    - platform_account.prita_designs_private_limited.delhivery_in.primary
    - platform_account.prita_designs_private_limited.xpressbees_in.primary
    - platform_account.prita_designs_private_limited.smartr_in.primary
    platform_ids:
    - platform.delhivery
    - platform.xpressbees
    platform_context_ids:
    - platform_context.delhivery.in
    - platform_context.xpressbees.in
    declared_unresolved_platform_ids:
    - platform.smartr
    declared_unresolved_platform_context_ids:
    - platform_context.smartr.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  canonical_id: business_scope_set.prita_designs_private_limited.payment_gateways
  name: Prita payment gateway scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - payment_gateway.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.01_identity
  description: Payment gateway pay-in scope for D2C and other payment matching.
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    scope_name: Prita payment gateway scope
    scope_type: payment_gateway_scope
    platform_account_ids:
    - platform_account.prita_designs_private_limited.razorpay_in.primary
    - platform_account.prita_designs_private_limited.paytm_in.primary
    - platform_account.prita_designs_private_limited.cashfree_in.primary
    - platform_account.prita_designs_private_limited.easebuzz_in.primary
    platform_ids:
    - platform.razorpay
    - platform.paytm
    - platform.cashfree
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.paytm.in
    - platform_context.cashfree.in
    declared_unresolved_platform_ids:
    - platform.easebuzz
    declared_unresolved_platform_context_ids:
    - platform_context.easebuzz.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  canonical_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  name: Prita marketplace orders to Increff operations
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - increff_operations.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    binding_name: Prita marketplace orders to Increff operations
    binding_type: marketplace_to_wms_operations
    business_scope_set_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
    money_flow_paths:
    - Marketplace order/settlement evidence -> Increff sales/returns fulfilment evidence
    participating_accounts:
    - platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.increff_wms.primary
      role: wms_operations
      required: true
    account_data_binding_ids:
    - account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_oms
    - account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_settlement
    - account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_disbursment
    - account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_fee_preview
    - account_data_binding.prita_designs_private_limited.flipkart_in.primary.oms
    - account_data_binding.prita_designs_private_limited.flipkart_in.primary.cashback
    - account_data_binding.prita_designs_private_limited.flipkart_in.primary.settlement
    - account_data_binding.prita_designs_private_limited.flipkart_in.primary.commission
    - account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms
    - account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_settlement
    - account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_reverse
    - account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_sales
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_settlement
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_returns
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_forward_expenses
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse_expenses
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_other_charges_expenses
    - account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_brand_mapping
    - account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_oms
    - account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_settlement
    - account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_addition_charge
    - account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapper_gst
    - account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapping
    - account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_oms
    - account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_settlement
    - account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_commission
    - account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_sales_return
    - account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_payments
    - account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_non_order
    - account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_oms
    - account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_settlement
    - account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
    - account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
    evidence_table_ids:
    - table.zs_observe.increff_sales
    - table.zs_observe.increff_returns
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  canonical_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  name: Prita Shopify D2C prepaid to payment gateways
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - logistics_domain.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.01_shopify
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    binding_name: Prita Shopify D2C prepaid to payment gateways
    binding_type: d2c_oms_to_payment_gateway
    business_scope_set_id: business_scope_set.prita_designs_private_limited.payment_gateways
    money_flow_paths:
    - Shopify D2C order -> payment gateway pay-in -> bank review
    participating_accounts:
    - platform_account_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
      role: d2c_oms
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.razorpay_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.cashfree_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.paytm_in.primary
      role: pg_collection
      required: false
    - platform_account_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
      role: pg_collection_review
      required: false
    account_data_binding_ids:
    - account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
    - account_data_binding.prita_designs_private_limited.razorpay_in.primary.razorpay_payin
    - account_data_binding.prita_designs_private_limited.cashfree_in.primary.cashfree_payin
    - account_data_binding.prita_designs_private_limited.paytm_in.primary.paytm_payin
    - account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.razorpay_payin
    - table.zs_observe.cashfree_payin
    - table.zs_observe.paytm_payin
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  canonical_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  name: Prita Shiprocket order source to Increff operations
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - increff_operations.md
  - shiprocket_logistics.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.02_active_sales_channels_domestic_marketplaces
  - ev.prita_designs_private_limited.docx.section.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  - ev.prita_designs_private_limited.docx.row.03_active_sales_channels_domestic_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.prita_designs_private_limited.docx.row.04_wms_fulfilment_layer.01_increff
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    binding_name: Prita Shiprocket order source to Increff operations
    binding_type: order_source_to_wms_operations
    business_scope_set_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    money_flow_paths:
    - Shiprocket sales/OMS -> Increff sales/returns operational evidence
    participating_accounts:
    - platform_account_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.increff_wms.primary
      role: wms_operations
      required: true
    account_data_binding_ids:
    - account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
    - account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
    - account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
    evidence_table_ids:
    - table.zs_observe.shiprocket_oms
    - table.zs_observe.increff_sales
    - table.zs_observe.increff_returns
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  canonical_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  name: Prita courier settlement reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  - delhivery_logistics.md
  - logistics_reconciliation_patterns.md
  - xpressbees_logistics.md
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.05_logistics_courier_reconciliation
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    binding_name: Prita courier settlement reconciliation
    binding_type: logistics_settlement_reconciliation
    business_scope_set_id: business_scope_set.prita_designs_private_limited.logistics_settlement
    money_flow_paths:
    - Courier settlement -> batch/amount/reference reconciliation -> bank review
    participating_accounts:
    - platform_account_id: platform_account.prita_designs_private_limited.delhivery_in.primary
      role: courier_settlement
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
      role: courier_settlement
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.smartr_in.primary
      role: courier_settlement_review
      required: false
    account_data_binding_ids:
    - account_data_binding.prita_designs_private_limited.delhivery_in.primary.delhivery_settlement
    - account_data_binding.prita_designs_private_limited.xpressbees_in.primary.xpressbees_settlement
    - account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
    evidence_table_ids:
    - table.zs_observe.delhivery_settlement
    - table.zs_observe.xpressbees_settlement
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids:
    - reconciliation_profile.courier_batch_to_bank_credit
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bank account is not supplied for Prita, so bank landing remains outside this active flow.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  canonical_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  name: Prita marketplace transactions matching scope
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx
  evidence_refs:
  - ev.prita_designs_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.prita_designs_private_limited
    group_id: group.prita_designs_private_limited.mensa_brands
    binding_name: Prita marketplace transactions matching scope
    binding_type: marketplace_transaction_matching
    business_scope_set_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
    money_flow_paths:
    - Marketplace settlement -> marketplace_transactions feed -> bank/payment matching
    participating_accounts:
    - platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
      role: transaction_feed_review
      required: true
    account_data_binding_ids:
    - account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
    evidence_table_ids: []
    conditions: []
    declared_unresolved_evidence_table_ids:
    - table.zs_observe.marketplace_transactions
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Generic marketplace_transactions feed is source-confirmed but requires platform-context semantics before active reconciliation.
    original_bad_state_status:
      status: review_required
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- platform_account_id: platform_account.prita_designs_private_limited.amazon_in.primary
  client_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  - table.zs_observe.amazon_fee_preview
  future_context_gaps:
  - Transactions feed is represented through marketplace_transactions until platform-specific transaction-table context is
    added.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  client_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
  canonical_or_supported_tables_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  future_context_gaps:
  - Flipkart adhoc Ads/TDS/Rebates/VAS/Google Ads and transactions need additional platform context.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.myntra_in.primary
  client_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
    Returns/RTO, JIT GSTR return, VHS + VFS expenses, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  future_context_gaps:
  - Seller reports Fwd/Rev
  - JIT GSTR return
  - VHS + VFS expenses
  - Non-order expenses
  - Transactions
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.meesho_in.primary
  client_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
    mapping, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.meesho_sales
  - table.zs_observe.meesho_settlement
  - table.zs_observe.meesho_returns
  - table.zs_observe.meesho_reverse
  - table.zs_observe.meesho_forward_expenses
  - table.zs_observe.meesho_reverse_expenses
  - table.zs_observe.meesho_other_charges_expenses
  - table.zs_observe.meesho_brand_mapping
  future_context_gaps:
  - Meesho transactions feed needs additional platform context.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.meesho_sales
  - table.zs_observe.meesho_settlement
  - table.zs_observe.meesho_returns
  - table.zs_observe.meesho_reverse
  - table.zs_observe.meesho_forward_expenses
  - table.zs_observe.meesho_reverse_expenses
  - table.zs_observe.meesho_other_charges_expenses
  - table.zs_observe.meesho_brand_mapping
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  client_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
    Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.nykaa_oms
  - table.zs_observe.nykaa_settlement
  - table.zs_observe.nykaa_addition_charge
  - table.zs_observe.nykaa_mapper_gst
  - table.zs_observe.nykaa_mapping
  future_context_gaps:
  - Nykaa payout summary and marketplace_transactions feed require additional context if queried as separate tables.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.nykaa_oms
  - table.zs_observe.nykaa_settlement
  - table.zs_observe.nykaa_addition_charge
  - table.zs_observe.nykaa_mapper_gst
  - table.zs_observe.nykaa_mapping
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  client_config_text: JioMart | OMS, Settlement, Returns, Transactions
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - JioMart group_level_id/entity confirmation for this client
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.jiomart_oms
  - table.zs_observe.jiomart_settlement
  - table.zs_observe.jiomart_returns
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  client_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.snapdeal_oms
  - table.zs_observe.snapdeal_settlement
  - table.zs_observe.snapdeal_commission
  - table.zs_observe.snapdeal_sales_return
  - table.zs_observe.snapdeal_payments
  - table.zs_observe.snapdeal_non_order
  future_context_gaps:
  - Snapdeal transactions feed needs additional platform context if separate from settlement/payments.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.snapdeal_oms
  - table.zs_observe.snapdeal_settlement
  - table.zs_observe.snapdeal_commission
  - table.zs_observe.snapdeal_sales_return
  - table.zs_observe.snapdeal_payments
  - table.zs_observe.snapdeal_non_order
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  client_config_text: Tata Cliq | OMS, Settlement, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  future_context_gaps:
  - Tata Cliq transactions feed needs additional platform context.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.cred_in.primary
  client_config_text: Cred | Sales, Settlement, Returns, Transactions
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Cred platform context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.klip_in.primary
  client_config_text: Klip | Settlement only
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Klip settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.blitz_in.primary
  client_config_text: Blitz | Settlement only
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Blitz settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  client_config_text: Snapmint | Settlement only
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Snapmint settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  client_config_text: Shopify | D2C OMS
  canonical_or_supported_tables_now:
  - table.zs_observe.shopify_oms
  future_context_gaps:
  - Shopify returns are not listed in this client profile but table support exists if returns are later configured.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.shopify_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  client_config_text: Shiprocket | Sales / OMS
  canonical_or_supported_tables_now:
  - table.zs_observe.shiprocket_oms
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.shiprocket_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.increff_wms.primary
  client_config_text: Increff | Sales, Returns, Returns processed
  canonical_or_supported_tables_now:
  - table.zs_observe.increff_sales
  - table.zs_observe.increff_returns
  future_context_gaps:
  - Increff returns processed requires explicit table context if separate from current returns table.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.increff_sales
  - table.zs_observe.increff_returns
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  client_config_text: Delhivery | Settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.delhivery_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.delhivery_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  client_config_text: Xpressbees | Settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.xpressbees_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.xpressbees_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.smartr_in.primary
  client_config_text: Smartr | Settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Smartr settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  client_config_text: Razorpay | razorpay_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.razorpay_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.razorpay_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.paytm_in.primary
  client_config_text: Paytm | paytm_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.paytm_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.paytm_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  client_config_text: Cashfree | cashfree_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.cashfree_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.cashfree_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  client_config_text: Easebuzz | easebuzz_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Easebuzz settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  client_config_text: Dedicated marketplace_transactions feed active in the client profile
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Generic marketplace_transactions table semantics
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.prita_designs_private_limited.has_group.c80bba008578
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.prita_designs_private_limited
  target_card_id: group.prita_designs_private_limited.mensa_brands
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_GROUP
- edge_id: edge.prita_designs_private_limited.has_platform_account.6cf818622957
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.7db6b7973358
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.2a2b10cc9440
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  target_card_id: platform_context.amazon.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.527b2559ed61
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.6472e009f74a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  target_card_id: platform.flipkart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.31e07dc48463
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  target_card_id: platform_context.flipkart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.7bb6717dc001
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.9c6340423dc3
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: platform.myntra
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.cff379b029d9
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: platform_context.myntra.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.ac310796f4b3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.5ff68855bf45
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: platform.meesho
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.4bd590e6954d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: platform_context.meesho.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.618528310f59
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.dafd39fb1183
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: platform.nykaa
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.eb66b5f7dc2e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: platform_context.nykaa_fashion.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.b22e427b0bf0
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.d96bc6698959
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  target_card_id: platform.jiomart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.37e7a6757739
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  target_card_id: platform_context.jiomart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.ff7c4d6610c3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.06316fe368a7
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: platform.snapdeal
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.1a9319bf8e66
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: platform_context.snapdeal.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.2f62f9a1f562
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.160198f55c61
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  target_card_id: platform.tatacliq
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.31d3fdd9e888
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  target_card_id: platform_context.tatacliq.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.016d8dcd6a17
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.cred_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_platform_account.98a94a053018
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.klip_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_platform_account.e43cf23adfe5
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.blitz_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_platform_account.8c8d9782d996
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.d74aa0188538
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.ec64c1dfe50d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_oms
  target_card_id: table.zs_observe.amazon_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.c4bc33c98f44
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.43af874a6e18
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.4edc89d66fb5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_disbursment
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.64002f8bba1b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_disbursment
  target_card_id: table.zs_observe.amazon_disbursment
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.6e40e1950ed4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_fee_preview
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.2e5b8e194311
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_fee_preview
  target_card_id: table.zs_observe.amazon_fee_preview
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.817e3e88026b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.628e50b0a365
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.oms
  target_card_id: table.flipkart.oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.4750aacb9aff
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.cashback
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.cec906b70fed
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.cashback
  target_card_id: table.flipkart.cashback
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.da7e5cdd6874
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.30d04bf1b64a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.settlement
  target_card_id: table.flipkart.settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.beae61e47997
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.commission
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.9fb5762f8d5d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.commission
  target_card_id: table.flipkart.commission
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.a37256313a1a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.2c04c7654d18
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms
  target_card_id: table.zs_observe.myntra_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.2cf1b0755468
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.3881e41facb2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_settlement
  target_card_id: table.zs_observe.myntra_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.ba3663b99b5b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_reverse
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.49ac783d3076
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_reverse
  target_card_id: table.zs_observe.myntra_reverse
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.7cbe9866e609
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_non_order_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.6844b4035c35
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_non_order_settlement
  target_card_id: table.zs_observe.myntra_non_order_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.f14f215a986d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.aa63d44a2f51
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms_settlement
  target_card_id: table.zs_observe.myntra_oms_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.baf388090c03
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.cef773b12232
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_sales
  target_card_id: table.zs_observe.meesho_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.995ff661e819
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.c3e0f7366a4d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_settlement
  target_card_id: table.zs_observe.meesho_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.11c501c70813
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.1b51c3ec6278
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_returns
  target_card_id: table.zs_observe.meesho_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.944b781e89eb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.b9952bd3ecb8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse
  target_card_id: table.zs_observe.meesho_reverse
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.0f11bdef72ac
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_forward_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.cefd521ec0b5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_forward_expenses
  target_card_id: table.zs_observe.meesho_forward_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.640938b23e26
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.ac12ccb7a435
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse_expenses
  target_card_id: table.zs_observe.meesho_reverse_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.9021e9fe91cd
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_other_charges_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.c8aba3646d2e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_other_charges_expenses
  target_card_id: table.zs_observe.meesho_other_charges_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.a85008ce326f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_brand_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.bcd7b2215f80
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_brand_mapping
  target_card_id: table.zs_observe.meesho_brand_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.e5944d5918c7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.5538099c221b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_oms
  target_card_id: table.zs_observe.nykaa_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.fb7a436a9c92
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.5883045bbc41
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_settlement
  target_card_id: table.zs_observe.nykaa_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.6286d2a854b2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_addition_charge
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.5a834a284458
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_addition_charge
  target_card_id: table.zs_observe.nykaa_addition_charge
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.1990148ca326
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapper_gst
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.f642c2abff3c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapper_gst
  target_card_id: table.zs_observe.nykaa_mapper_gst
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.0ceaa2eea130
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.49c64862d1ac
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapping
  target_card_id: table.zs_observe.nykaa_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.ae708a05e331
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.6b9f4b526c72
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_oms
  target_card_id: table.zs_observe.jiomart_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.d06744adac44
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.1ee7cff77a11
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_settlement
  target_card_id: table.zs_observe.jiomart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.673333c76210
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.jiomart_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.e90017b673e7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_returns
  target_card_id: table.zs_observe.jiomart_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.822d1c713142
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.c759a0fedf51
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_oms
  target_card_id: table.zs_observe.snapdeal_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.bd36fa8b1cf8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.3b7279d4a39d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_settlement
  target_card_id: table.zs_observe.snapdeal_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.902de0a8d86c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_commission
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.1d2726e63323
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_commission
  target_card_id: table.zs_observe.snapdeal_commission
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.5a78c1685bce
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_sales_return
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.a0ebc28a84e4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_sales_return
  target_card_id: table.zs_observe.snapdeal_sales_return
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.63a911af3183
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_payments
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.18ed1660bfd4
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_payments
  target_card_id: table.zs_observe.snapdeal_payments
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.00a9edcf06cb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_non_order
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.e4cec48e0f51
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_non_order
  target_card_id: table.zs_observe.snapdeal_non_order
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.8cea891ea48d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.7f090985c8e8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_oms
  target_card_id: table.zs_observe.tatacliq_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.9f278d61dabd
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.33aec18070c8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_settlement
  target_card_id: table.zs_observe.tatacliq_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.650471ca6ee2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.cred_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.1ccaaec1678d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.cred_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.edf4b20846f4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.cred_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.d882d1b5b338
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.klip_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.7ff425e23206
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.blitz_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.f646878f07b3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_platform_account.e1c439e9393a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.dd796a42916c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  target_card_id: platform.shopify
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.f26ca9fb0b18
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  target_card_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.6460da41d828
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.95f123638fa8
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  target_card_id: platform.shiprocket
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.d3a6d8f736a3
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  target_card_id: platform_context.shiprocket.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_platform_account.b6e412b6573b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.50c283eef920
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  target_card_id: platform.increff
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.2d325758255e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  target_card_id: platform_context.increff.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.98f33710f2d8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  target_card_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.0cb58d6f980d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
  target_card_id: table.zs_observe.shopify_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.9bad0c1b9fa4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  target_card_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.72f2cda486d6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
  target_card_id: table.zs_observe.shiprocket_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.3e82944840f7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  target_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.5eecd8ec9d48
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
  target_card_id: table.zs_observe.increff_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.765e73f1d302
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  target_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.34f27179b6cb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
  target_card_id: table.zs_observe.increff_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_platform_account.afd178da0185
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.364d9602d468
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  target_card_id: platform.delhivery
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.e6ceaccbdaae
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  target_card_id: platform_context.delhivery.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.8bfe65d647b9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.delhivery_in.primary.delhivery_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.9cd40485fd00
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.delhivery_in.primary.delhivery_settlement
  target_card_id: table.zs_observe.delhivery_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_platform_account.ab959c98a1e0
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.b471926d191e
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  target_card_id: platform.xpressbees
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.94b7cf5a6ec2
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  target_card_id: platform_context.xpressbees.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.0a3e2a19c295
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.xpressbees_in.primary.xpressbees_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.eef906e93d61
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.xpressbees_in.primary.xpressbees_settlement
  target_card_id: table.zs_observe.xpressbees_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_platform_account.223948fd0fe8
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.c93dfbcc6298
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_platform_account.9242174a05ac
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.c91ffabf499a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  target_card_id: platform.razorpay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.f1e5932383d0
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  target_card_id: platform_context.razorpay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.7e49a261f6dd
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.razorpay_in.primary.razorpay_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.c4301db14ea2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.razorpay_in.primary.razorpay_payin
  target_card_id: table.zs_observe.razorpay_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_platform_account.b3eb78844dce
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.d00e949cc14c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.872c23fbc7c6
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  target_card_id: platform_context.paytm.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.f14681ffa3fa
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.paytm_in.primary.paytm_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.14fec45f16e6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.paytm_in.primary.paytm_payin
  target_card_id: table.zs_observe.paytm_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_platform_account.e5294eab52e0
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_platform.a692803c2d76
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.prita_designs_private_limited.uses_platform_context.3811d5f25199
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.45f6e03085b4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.cashfree_in.primary.cashfree_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.binds_to_table.7d9ed47db445
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.prita_designs_private_limited.cashfree_in.primary.cashfree_payin
  target_card_id: table.zs_observe.cashfree_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.prita_designs_private_limited.has_platform_account.df47b4253c07
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.13506a6e2afe
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  target_card_id: account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_platform_account.b097b9f4cec3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_account_data_binding.220eeebef0ef
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  target_card_id: account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.has_business_scope_set.1a6cc942ca97
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.includes_platform_account.86925f4eeabd
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.c1230ad18d43
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.38e15f7781f3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.b5043b33006e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.2b4e766f6ba5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.854e1713a978
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.6c6f255878cc
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  target_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_business_scope_set.9d4b05669eac
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.includes_platform_account.f83e9f180b1d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  target_card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.6e795b42595a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  target_card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.40e6295d23ab
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  target_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_business_scope_set.11c4794ec9ff
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.includes_platform_account.3a0f3cf7d2b3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  target_card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.1b67569b5de0
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  target_card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.505d71f2f761
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  target_card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_business_scope_set.87faef3d22a2
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.includes_platform_account.d5f16b2cccb7
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  target_card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.dd72ce01bcb9
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  target_card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.183e7fb4bbdc
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  target_card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.includes_platform_account.f6de0d3b5208
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  target_card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.prita_designs_private_limited.has_business_flow_binding.dcdc845d00a3
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.prita_designs_private_limited.uses_business_scope_set.00b8514fa98b
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.participates_with_account.481a85dd8f9a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.d5c3b0089cee
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.6996d7e054fc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.ada4625bf02f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.26c9c3a97027
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.1cd21d4c2e1e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.d24ec5ee1dee
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.f59767ac8d47
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.3cf216de7941
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.aea1014d9374
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.42e89d589116
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_disbursment
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.4bb29eb1272c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.amazon_in.primary.amazon_fee_preview
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.749ecd1915a9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.eea7704bc1ad
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.cashback
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.5dacfc94b6f3
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.b8844d58da17
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.flipkart_in.primary.commission
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.9c7706b5a83e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.eb9d60557347
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.58f597852b9c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_reverse
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.79721bddf6b9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_non_order_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.9d879dbb84e9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.myntra_in.primary.myntra_oms_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.f69050f9a7c2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.85e2ac5476b4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.f38f966bf1da
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.3696236c05f9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.e06ef47ca9d2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_forward_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.a86ac3426dd0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_reverse_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.958a0e0d9a4d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_other_charges_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.44124bff6558
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.meesho_in.primary.meesho_brand_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.f9db112a3c7a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.0078f02c3d00
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.d1a4545f2632
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_addition_charge
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.edb3620b0743
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapper_gst
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.e3429da55992
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.nykaa_in.primary.nykaa_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.0b9c27ea80f5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.eac242de3480
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.71c5d5296796
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_commission
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.35263486949b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_sales_return
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.bad3b72f93b4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_payments
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.2facdb22a5ec
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.snapdeal_in.primary.snapdeal_non_order
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.ff351302ec7b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.5ac67abe5d38
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.tatacliq_in.primary.tatacliq_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.717804262744
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.81d37c0ad120
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.8c94ccf1ba2e
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: table.zs_observe.increff_sales
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.d04c708d4ca7
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_to_increff_operations
  target_card_id: table.zs_observe.increff_returns
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.has_business_flow_binding.ce69b03e9ecf
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.prita_designs_private_limited.uses_business_scope_set.dfbbbcf5e26c
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: business_scope_set.prita_designs_private_limited.payment_gateways
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.participates_with_account.d87efb417383
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.598f9589d641
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.prita_designs_private_limited.razorpay_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.1ae305902465
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.prita_designs_private_limited.cashfree_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.759ff7e29b70
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.prita_designs_private_limited.paytm_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.50029178367c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.cb17ba06df50
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.b77c4bd41883
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.prita_designs_private_limited.razorpay_in.primary.razorpay_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.eeec68e54331
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.prita_designs_private_limited.cashfree_in.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.a030b8526513
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.prita_designs_private_limited.paytm_in.primary.paytm_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.0f33e97b3b53
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.1bfd6863b273
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.shopify_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.21de6f4b844b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.razorpay_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.6d6646787ef3
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.cashfree_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.337c628a7b00
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.paytm_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.has_business_flow_binding.4e8455f76d8b
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.prita_designs_private_limited.uses_business_scope_set.6457ff095b5d
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.participates_with_account.94891f8e483a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.f93bf42d7602
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: platform_account.prita_designs_private_limited.increff_wms.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.ba1b6f805214
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.f11d3375da74
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.cd43b4984d8f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: account_data_binding.prita_designs_private_limited.increff_wms.primary.increff_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.0b82f3477a17
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: table.zs_observe.shiprocket_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.2c67c0fdcc1d
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: table.zs_observe.increff_sales
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.2080083c8e6d
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.shiprocket_order_source_to_increff
  target_card_id: table.zs_observe.increff_returns
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.has_business_flow_binding.e130704c50bd
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.prita_designs_private_limited.uses_business_scope_set.d402eaaac923
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: business_scope_set.prita_designs_private_limited.logistics_settlement
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.participates_with_account.cffc9091cab0
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.prita_designs_private_limited.delhivery_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.5da760bd84ce
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.prita_designs_private_limited.xpressbees_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.eb25c4f70b4b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.3097afaffe82
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.prita_designs_private_limited.delhivery_in.primary.delhivery_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.c49f7ec53150
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.prita_designs_private_limited.xpressbees_in.primary.xpressbees_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.59608402e160
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.af969bd5a59b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: table.zs_observe.delhivery_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.uses_evidence_table.bb490326835f
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.prita_designs_private_limited.logistics_settlement_reconciliation
  target_card_id: table.zs_observe.xpressbees_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.prita_designs_private_limited.has_business_flow_binding.4e28410b8b77
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.prita_designs_private_limited.mensa_brands
  target_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.prita_designs_private_limited.uses_business_scope_set.43879dcd6f0f
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.prita_designs_private_limited.participates_with_account.376cec1a8fba
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.amazon_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.007e03275259
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.flipkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.c37851b07928
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.myntra_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.f652c2ec08e0
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.meesho_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.64cb65cd6bca
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.d32a2f719d94
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.snapdeal_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.d323608e5565
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.tatacliq_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.participates_with_account.fa5f6ec35298
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.prita_designs_private_limited.uses_account_data_binding.7c31f8ca1468
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  target_card_id: account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: platform_account.prita_designs_private_limited.cred_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.cred
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.cred
  original_edge:
    source: platform_account.prita_designs_private_limited.cred_in.primary
    edge: USES_PLATFORM
    target: platform.cred
- source_card_id: platform_account.prita_designs_private_limited.cred_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.cred.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.cred.in
  original_edge:
    source: platform_account.prita_designs_private_limited.cred_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.cred.in
- source_card_id: platform_account.prita_designs_private_limited.klip_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.klip
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.klip
  original_edge:
    source: platform_account.prita_designs_private_limited.klip_in.primary
    edge: USES_PLATFORM
    target: platform.klip
- source_card_id: platform_account.prita_designs_private_limited.klip_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.klip.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.klip.in
  original_edge:
    source: platform_account.prita_designs_private_limited.klip_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.klip.in
- source_card_id: platform_account.prita_designs_private_limited.blitz_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.blitz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.blitz
  original_edge:
    source: platform_account.prita_designs_private_limited.blitz_in.primary
    edge: USES_PLATFORM
    target: platform.blitz
- source_card_id: platform_account.prita_designs_private_limited.blitz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.blitz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.blitz.in
  original_edge:
    source: platform_account.prita_designs_private_limited.blitz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.blitz.in
- source_card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.snapmint
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.snapmint
  original_edge:
    source: platform_account.prita_designs_private_limited.snapmint_in.primary
    edge: USES_PLATFORM
    target: platform.snapmint
- source_card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.snapmint.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.snapmint.in
  original_edge:
    source: platform_account.prita_designs_private_limited.snapmint_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.snapmint.in
- source_card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cred_sales
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cred_sales
  original_edge:
    source: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cred_sales
- source_card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cred_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cred_settlement
  original_edge:
    source: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cred_settlement
- source_card_id: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cred_returns
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cred_returns
  original_edge:
    source: account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cred_returns
- source_card_id: account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.klip_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.klip_settlement
  original_edge:
    source: account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.klip_settlement
- source_card_id: account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.blitz_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.blitz_settlement
  original_edge:
    source: account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.blitz_settlement
- source_card_id: account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.snapmint_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.snapmint_settlement
  original_edge:
    source: account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.snapmint_settlement
- source_card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.smartr
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.smartr
  original_edge:
    source: platform_account.prita_designs_private_limited.smartr_in.primary
    edge: USES_PLATFORM
    target: platform.smartr
- source_card_id: platform_account.prita_designs_private_limited.smartr_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.smartr.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.smartr.in
  original_edge:
    source: platform_account.prita_designs_private_limited.smartr_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.smartr.in
- source_card_id: account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.smartr_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.smartr_settlement
  original_edge:
    source: account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.smartr_settlement
- source_card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.easebuzz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.easebuzz
  original_edge:
    source: platform_account.prita_designs_private_limited.easebuzz_in.primary
    edge: USES_PLATFORM
    target: platform.easebuzz
- source_card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.easebuzz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.easebuzz.in
  original_edge:
    source: platform_account.prita_designs_private_limited.easebuzz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.easebuzz.in
- source_card_id: account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.easebuzz_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.easebuzz_settlement
  original_edge:
    source: account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.easebuzz_settlement
- source_card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.marketplace_transactions
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.marketplace_transactions
  original_edge:
    source: platform_account.prita_designs_private_limited.marketplace_transactions.primary
    edge: USES_PLATFORM
    target: platform.marketplace_transactions
- source_card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.marketplace_transactions.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.marketplace_transactions.in
  original_edge:
    source: platform_account.prita_designs_private_limited.marketplace_transactions.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.marketplace_transactions.in
- source_card_id: account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.marketplace_transactions
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.marketplace_transactions
  original_edge:
    source: account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
    edge: BINDS_TO_TABLE
    target: table.zs_observe.marketplace_transactions
- source_card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.marketplace_transactions
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.marketplace_transactions
  original_edge:
    source: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.marketplace_transactions
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: cred_in
  artifacts:
  - cred_sales
  - cred_settlement
  - cred_returns
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Cred | Sales, Settlement, Returns, Transactions
  recommended_next_context: Add canonical Cred platform context markdown/table cards.
- platform_or_area: klip_in
  artifacts:
  - klip_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Klip | Settlement only
  recommended_next_context: Add canonical Klip settlement context markdown/table cards.
- platform_or_area: blitz_in
  artifacts:
  - blitz_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Blitz | Settlement only
  recommended_next_context: Add canonical Blitz settlement context markdown/table cards.
- platform_or_area: snapmint_in
  artifacts:
  - snapmint_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Snapmint | Settlement only
  recommended_next_context: Add canonical Snapmint settlement context markdown/table cards.
- platform_or_area: smartr
  artifacts:
  - smartr_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Smartr | Settlement
  recommended_next_context: Add canonical Smartr logistics settlement markdown/table cards.
- platform_or_area: easebuzz
  artifacts:
  - easebuzz_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Easebuzz | easebuzz_settlement
  recommended_next_context: Add canonical Easebuzz payment-gateway markdown/table cards.
- platform_or_area: marketplace_transactions
  artifacts:
  - marketplace_transactions
  impact: Client profile confirms a dedicated transactions feed, but platform-specific semantics are not available in current
    context.
  source_text: Dedicated marketplace_transactions feed
  recommended_next_context: Add platform-context table cards for marketplace_transactions and channel-specific matching rules.
- platform_or_area: bank_account
  artifacts:
  - bank statement destination
  impact: No bank account or bank statement binding supplied in Prita profile.
  source_text: No bank section provided in client profile.
  recommended_next_context: Add Prita bank account and Account Data Binding cards before activating bank-crossing flows.
- platform_or_area: table.zs_observe.marketplace_transactions
  missing_artifacts:
  - table.zs_observe.marketplace_transactions
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  generated_by_refactor: true
- platform_or_area: platform_context.blitz.in
  missing_artifacts:
  - platform_context.blitz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.blitz_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.cred.in
  missing_artifacts:
  - platform_context.cred.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.cred_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.easebuzz.in
  missing_artifacts:
  - platform_context.easebuzz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.klip.in
  missing_artifacts:
  - platform_context.klip.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.klip_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.marketplace_transactions.in
  missing_artifacts:
  - platform_context.marketplace_transactions.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- platform_or_area: platform_context.smartr.in
  missing_artifacts:
  - platform_context.smartr.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.smartr_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.snapmint.in
  missing_artifacts:
  - platform_context.snapmint.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.snapmint_in.primary
  generated_by_refactor: true
- platform_or_area: platform.blitz
  missing_artifacts:
  - platform.blitz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.blitz_in.primary
  generated_by_refactor: true
- platform_or_area: platform.cred
  missing_artifacts:
  - platform.cred
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.cred_in.primary
  generated_by_refactor: true
- platform_or_area: platform.easebuzz
  missing_artifacts:
  - platform.easebuzz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- platform_or_area: platform.klip
  missing_artifacts:
  - platform.klip
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.klip_in.primary
  generated_by_refactor: true
- platform_or_area: platform.marketplace_transactions
  missing_artifacts:
  - platform.marketplace_transactions
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- platform_or_area: platform.smartr
  missing_artifacts:
  - platform.smartr
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.smartr_in.primary
  generated_by_refactor: true
- platform_or_area: platform.snapmint
  missing_artifacts:
  - platform.snapmint
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.prita_designs_private_limited.snapmint_in.primary
  generated_by_refactor: true
- platform_or_area: table.zs_observe.blitz_settlement
  missing_artifacts:
  - table.zs_observe.blitz_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.cred_returns
  missing_artifacts:
  - table.zs_observe.cred_returns
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
  generated_by_refactor: true
- platform_or_area: table.zs_observe.cred_sales
  missing_artifacts:
  - table.zs_observe.cred_sales
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
  generated_by_refactor: true
- platform_or_area: table.zs_observe.cred_settlement
  missing_artifacts:
  - table.zs_observe.cred_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.easebuzz_settlement
  missing_artifacts:
  - table.zs_observe.easebuzz_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.klip_settlement
  missing_artifacts:
  - table.zs_observe.klip_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.smartr_settlement
  missing_artifacts:
  - table.zs_observe.smartr_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.snapmint_settlement
  missing_artifacts:
  - table.zs_observe.snapmint_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- item: platform_account.prita_designs_private_limited.jiomart_in.primary
  issue: Client profile says JioMart OMS, settlement, returns, and transactions are configured, but current JioMart canonical
    evidence is explicitly scoped to Tanvi group_level_id 26 for OMS/returns/settlement and Ardeur group_level_id 221 for
    shipment. Prita JioMart is therefore emitted as review_required.
  severity: high
  review_resolution_status: open
- item: platform_account.prita_designs_private_limited.easebuzz_in.primary
  issue: Easebuzz is configured and appears twice in source config; no active canonical Easebuzz settlement context is available
    in the current platform library.
  severity: medium
  review_resolution_status: open
- item: table.zs_observe.marketplace_transactions
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
  generated_by_refactor: true
- item: platform_context.blitz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.blitz_in.primary
  generated_by_refactor: true
- item: platform_context.cred.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.cred_in.primary
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- item: platform_context.klip.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.klip_in.primary
  generated_by_refactor: true
- item: platform_context.marketplace_transactions.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- item: platform_context.smartr.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.smartr_in.primary
  generated_by_refactor: true
- item: platform_context.snapmint.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.snapmint_in.primary
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.prita_designs_private_limited.payment_gateways
  generated_by_refactor: true
- item: platform_context.smartr.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.prita_designs_private_limited.logistics_settlement
  generated_by_refactor: true
- item: platform.blitz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.blitz_in.primary
  generated_by_refactor: true
- item: platform.cred
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.cred_in.primary
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- item: platform.klip
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.klip_in.primary
  generated_by_refactor: true
- item: platform.marketplace_transactions
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- item: platform.smartr
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.smartr_in.primary
  generated_by_refactor: true
- item: platform.snapmint
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.prita_designs_private_limited.snapmint_in.primary
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.prita_designs_private_limited.payment_gateways
  generated_by_refactor: true
- item: platform.smartr
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.prita_designs_private_limited.logistics_settlement
  generated_by_refactor: true
- item: table.zs_observe.blitz_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.blitz_in.primary.blitz_settlement
  generated_by_refactor: true
- item: table.zs_observe.cred_returns
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.cred_in.primary.cred_returns
  generated_by_refactor: true
- item: table.zs_observe.cred_sales
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.cred_in.primary.cred_sales
  generated_by_refactor: true
- item: table.zs_observe.cred_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.cred_in.primary.cred_settlement
  generated_by_refactor: true
- item: table.zs_observe.easebuzz_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.easebuzz_in.primary.easebuzz_settlement
  generated_by_refactor: true
- item: table.zs_observe.klip_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.klip_in.primary.klip_settlement
  generated_by_refactor: true
- item: table.zs_observe.marketplace_transactions
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.marketplace_transactions.primary.marketplace_transactions
  generated_by_refactor: true
- item: table.zs_observe.smartr_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.smartr_in.primary.smartr_settlement
  generated_by_refactor: true
- item: table.zs_observe.snapmint_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.prita_designs_private_limited.snapmint_in.primary.snapmint_settlement
  generated_by_refactor: true
resolved_review_items: []
non_blocking_declared_semantic_reference_gaps: []
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 89
  refactored_card_count: 89
  original_edge_count: 297
  refactored_edge_count: 273
  blocked_edge_count: 24
  source_evidence_count: 28
  source_row_evidence_count: 21
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 23
    account_data_binding: 55
    business_scope_set: 4
    business_flow_binding: 5
  status_counts:
    active: 73
    review_required: 16
  review_status_counts:
    accepted: 73
    review_required: 16
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 28
  canonical_resolution_gap_type_counts:
    platform_id: 7
    platform_context_id: 7
    table_id: 9
    platform_ids: 2
    platform_context_ids: 2
    evidence_table_ids: 1
  status_correction_count: 11
  status_changes:
  - card_id: platform_account.prita_designs_private_limited.cred_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.klip_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.blitz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.snapmint_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_oms
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_settlement
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: account_data_binding.prita_designs_private_limited.jiomart_in.primary.jiomart_returns
    card_type: account_data_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: binding_table_now_resolves_to_uploaded_canonical_card
  - card_id: platform_account.prita_designs_private_limited.smartr_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.easebuzz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.prita_designs_private_limited.marketplace_transactions.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: business_flow_binding.prita_designs_private_limited.marketplace_transactions_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  id_or_source_replacement_count: 10
  id_or_source_replacements:
  - card_id: platform_account.prita_designs_private_limited.nykaa_in.primary
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: platform_account.prita_designs_private_limited.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.prita_designs_private_limited.shiprocket_order_source.primary
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: platform_account.prita_designs_private_limited.increff_wms.primary
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  - card_id: account_data_binding.prita_designs_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.prita_designs_private_limited.shiprocket_order_source.primary.shiprocket_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_scope_set.prita_designs_private_limited.domestic_marketplaces_active
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: business_scope_set.prita_designs_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  resolved_prior_review_count: 0
  open_review_count: 30
  future_context_gap_count: 31
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 0
  non_blocking_declared_semantic_reference_gap_type_counts: {}
  edge_status_counts:
    emitted: 273
    blocked_unresolved: 24
```
