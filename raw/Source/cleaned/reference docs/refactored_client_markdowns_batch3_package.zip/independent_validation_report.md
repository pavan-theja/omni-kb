# Independent Validation Report — Client Runtime Refactor Batch 3

This report was generated after the markdown files were produced. It re-parsed the emitted markdowns independently, loaded the current canonical markdown registry from `/mnt/data`, and checked emitted graph references.

```yaml
validation_checks:
  yaml_parse_errors: 0
  emitted_edge_reference_errors: 0
  forbidden_client_layer_card_types: 0
  active_bindings_to_missing_table_cards: 0
  status_active_conflicts: 0
  old_shopify_source_documents_in_candidate_cards: 0
active_shopify_canonical: shopify_d2c_oms_v2.md
client_runtime_allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
```
