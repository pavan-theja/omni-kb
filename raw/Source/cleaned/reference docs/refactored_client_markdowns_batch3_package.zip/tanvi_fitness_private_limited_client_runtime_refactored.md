# Tanvi Fitness Private Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the uploaded bad-state client JSON into client/runtime binding cards, uses the uploaded canonical platform/domain markdowns for reference resolution, and preserves DOCX-backed evidence without creating canonical platform/table/domain cards inside the client layer.

```yaml
document_metadata:
  package_id: tanvi_fitness_private_limited_client_runtime_cards_v2_1_refactored
  version: v2_1_refactored
  generated_date: '2026-05-24'
  created_for: Tanvi Fitness Private Limited
  client_slug: tanvi_fitness_private_limited
  status: parser_ready_with_explicit_registry_gaps
  source_documents:
  - Cognee KB Design v4.md
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  - xpressbees_logistics.md
  source_client_profile:
    business: Health, wellness, and personal care brand across health-specific marketplaces, general marketplaces, and D2C
    geography: India only
    source_group_id: 9
    source_group_level_id: 26
    source_group_name: Mensa Brands
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: Client/runtime packs contain tenant, group, platform_account, account_data_binding, business_scope_set, and
    business_flow_binding cards. Active Account Data Bindings are emitted only when currently available canonical platform
    context, client-table evidence, or explicit client table registry evidence supports the table. Configured artifacts without
    table support are preserved as future_context_gaps and review_required bindings instead of invented active mappings.
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  source_json_bad_state: tanvi_fitness_private_limited_runtime_cards_v1_0.json
  source_docx: Tanvi Fitness.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  canonical_markdowns_loaded:
  - ajio_marketplace.md
  - amazon_marketplace.md
  - bank_statement.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ecom_express.md
  - ekart_logistics.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - logistics_domain.md
  - logistics_reconciliation_patterns.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shadowfax_logistics.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - target_plus.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - unicommerce_operations.md
  - walmart_marketplace.md
  - xpressbees_logistics.md
  active_shopify_canonical: shopify_d2c_oms_v2.md
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  boundary_policy:
    client_runtime_cards_allowed:
    - tenant
    - group
    - platform_account
    - account_data_binding
    - business_scope_set
    - business_flow_binding
    do_not_create_in_client_runtime_pack:
    - platform
    - platform_context
    - domain
    - table
    - column
    - metric
    - business_process
    - workflow_step
    - reconciliation_profile
    - matching_logic
    - bank_account
    - payment_gateway_account
    - logistics_account
    - erp_accounting_mapping
    - statutory_tax_filing
    - connector
    dangling_reference_policy: No candidate_edge is emitted unless both source and target resolve to a client card in this
      file or an uploaded canonical card.
    scope_key_policy: group_id/group_level_id/currency/country filters stay in account_data_binding.scope_keys, not in reusable
      platform/domain/table cards.
    missing_account_identifier_policy: A missing seller/merchant/store/account identifier is not by itself a blocker when
      the client DOCX confirms the account and table-level scope keys are present.
```

## 0. Parser Instructions and Refactor Manifest

```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  - connector
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM / USES_PLATFORM_CONTEXT / BINDS_TO_TABLE if the canonical target card is absent.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.in_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.global_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.international_d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.shopify.us_d2c: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.increff.in.wms_operations: platform_context.increff.in
      platform_context.shiprocket.in.oms_order_source: platform_context.shiprocket.in
      platform_context.amazon.us: platform_context.amazon.international
      platform_context.amazon.ca: platform_context.amazon.international
      platform_context.amazon.uk: platform_context.amazon.international
      platform_context.amazon.mx: platform_context.amazon.international
      platform_context.nykaa.in: platform_context.nykaa_fashion.in
      platform_context.rbl_bank.in_payin: platform_context.rbl_bank.in
      platform.idfc_bank: platform.idfc_first_bank
      platform_context.idfc_bank.in: platform_context.idfc_first_bank.in
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
      table.zs_observe.idfc_bank: table.zs_ingest.idfc_bank
      table.zs_observe.idfc_bank_inr: table.zs_ingest.idfc_bank_inr
      table.zs_observe.yesbank_oms_payout: table.zs_ingest.yesbank_oms_payout
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
  status_policy:
    active: source-confirmed and routable against at least the available canonical/client table context
    review_required: source-confirmed but missing a required canonical platform/context/table card for production routing
    draft: intentionally inactive pending bank binding, external account binding, or future platform-context authoring
clean_refactor_manifest:
  source_json: tanvi_fitness_private_limited_runtime_cards_v1_0.json
  source_docx: Tanvi Fitness.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  corrections_applied:
  - Replaced old Shopify references with shopify_d2c_oms_v2 canonical context.
  - Collapsed Amazon US/CA/UK/MX aliases to uploaded platform_context.amazon.international while preserving country/currency
    guards on account bindings.
  - Remapped Nykaa India alias to Nykaa Fashion canonical context.
  - Remapped IDFC Bank alias to IDFC First Bank canonical bank-statement context where present.
  - Remapped role-specific Shopify/Increff/Shiprocket/Amazon/Paytm/PhonePe context aliases to uploaded broader canonical contexts
    while preserving the role in account fields.
  - Blocked unresolved platform/context/table edges rather than emitting dangling references.
  - Normalized status/active conflicts from the bad-state JSON.
  - Added DOCX section and row-level evidence references for configured sources.
  id_replacement_hits:
  - card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  - card_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  status_changes:
  - card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  blocked_edge_count: 30
  canonical_resolution_gap_count: 36
  resolved_prior_review_count: 0
```

## 1. Source Intake and Evidence Registry

```yaml
source_evidence:
- id: ev.tanvi_fitness_private_limited.docx.section.01_identity
  source_document: Tanvi Fitness.docx
  source_section: Identity
  evidence_type: docx_section
  source_lines: L2-L12
  summary: '* Business: Health, wellness & personal care brand — selling across health-specific marketplaces + general fashion/lifestyle
    marketplaces + D2C

    * Geography: India only

    * OMS/WMS: Increff (fulfilment/WMS), Shiprocket (order source), Shopify (D2C)

    * Logistics: Delhivery, Ekart, DTDC, Xpressbees, Shadowfax

    * Payment gateways: Razorpay, Paytm, Cashfree, Easebuzz

    * GROUP LEVEL ID : 26

    * GROUP ID :  9

    * CLIENT NAME  :  T**anvi Fitness Private Limited**

    * GROUP NAME :  Mensa Brands

    > The presence of OneMg, Healthkart, and GetSupp alongside standard fashion marketplaces (Myntra, Nykaa, Flipkart) indicates
    a health/wellness or personal care product brand with dual distribution — health-platform and general lifestyle channels
    managed in parallel.'
  raw_lines:
  - '* Business: Health, wellness & personal care brand — selling across health-specific marketplaces + general fashion/lifestyle
    marketplaces + D2C'
  - '* Geography: India only'
  - '* OMS/WMS: Increff (fulfilment/WMS), Shiprocket (order source), Shopify (D2C)'
  - '* Logistics: Delhivery, Ekart, DTDC, Xpressbees, Shadowfax'
  - '* Payment gateways: Razorpay, Paytm, Cashfree, Easebuzz'
  - '* GROUP LEVEL ID : 26'
  - '* GROUP ID :  9'
  - '* CLIENT NAME  :  T**anvi Fitness Private Limited**'
  - '* GROUP NAME :  Mensa Brands'
  - '> The presence of OneMg, Healthkart, and GetSupp alongside standard fashion marketplaces (Myntra, Nykaa, Flipkart) indicates
    a health/wellness or personal care product brand with dual distribution — health-platform and general lifestyle channels
    managed in parallel.'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces
  evidence_type: docx_section
  source_lines: L14-L19
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | OneMg   | Sales, Settlement, Returns, Transactions |

    | Healthkart | OMS, Settlement, Returns, Transactions |

    | GetSupp | OMS Settlement (combined), Transactions |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| OneMg   | Sales, Settlement, Returns, Transactions |'
  - '| Healthkart | OMS, Settlement, Returns, Transactions |'
  - '| GetSupp | OMS Settlement (combined), Transactions |'
  row_count: 3
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces
  evidence_type: configured_source_row
  source_line: L17
  row_key: OneMg
  columns:
    channel: OneMg
    data_types_configured: Sales, Settlement, Returns, Transactions
  raw_text: '| OneMg   | Sales, Settlement, Returns, Transactions |'
  summary: 'OneMg: channel=OneMg; data_types_configured=Sales, Settlement, Returns, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces
  evidence_type: configured_source_row
  source_line: L18
  row_key: Healthkart
  columns:
    channel: Healthkart
    data_types_configured: OMS, Settlement, Returns, Transactions
  raw_text: '| Healthkart | OMS, Settlement, Returns, Transactions |'
  summary: 'Healthkart: channel=Healthkart; data_types_configured=OMS, Settlement, Returns, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces
  evidence_type: configured_source_row
  source_line: L19
  row_key: GetSupp
  columns:
    channel: GetSupp
    data_types_configured: OMS Settlement (combined), Transactions
  raw_text: '| GetSupp | OMS Settlement (combined), Transactions |'
  summary: 'GetSupp: channel=GetSupp; data_types_configured=OMS Settlement (combined), Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.section.03_active_sales_channels_health_specific_marketplaces_general_marketplaces
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: docx_section
  source_lines: L20-L32
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions |

    | Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |

    | Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT +
    PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |

    | Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |

    | Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format, Payout summary,
    TDS, Additional shipping, MBTPT/GST mapper, Transactions |

    | JioMart | OMS, Settlement, Returns, Transactions |

    | Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |

    | Tata Cliq | OMS, Settlement, Transactions |

    | Cred    | Sales, Settlement, Returns, Transactions |

    | Klip · Blitz · Snapmint | Settlement only       |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |'
  - '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT
    + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |'
  - '| Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |'
  - '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format, Payout summary,
    TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  - '| JioMart | OMS, Settlement, Returns, Transactions |'
  - '| Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |'
  - '| Tata Cliq | OMS, Settlement, Transactions |'
  - '| Cred    | Sales, Settlement, Returns, Transactions |'
  - '| Klip · Blitz · Snapmint | Settlement only       |'
  row_count: 10
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L23
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions |'
  summary: 'Amazon India: channel=Amazon India; data_types_configured=OMS (B2C + B2B), Settlement, Disbursement, Fee preview,
    Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L24
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |'
  summary: 'Flipkart: channel=Flipkart; data_types_configured=OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google
    Ads), Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L25
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
      (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions
  raw_text: '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
    (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |'
  summary: 'Myntra: channel=Myntra; data_types_configured=OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement
    (JIT + PPMP), Non-order settlement (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS +
    VFS expenses, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L26
  row_key: Meesho
  columns:
    channel: Meesho
    data_types_configured: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
      Transactions
  raw_text: '| Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
    Transactions |'
  summary: 'Meesho: channel=Meesho; data_types_configured=Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other
    charges, Adjustment, Brand mapping, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L27
  row_key: Nykaa
  columns:
    channel: Nykaa
    data_types_configured: OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format,
      Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions
  raw_text: '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format, Payout
    summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  summary: 'Nykaa: channel=Nykaa; data_types_configured=OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement
    x4 + Popup new format, Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.06_jiomart
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L28
  row_key: JioMart
  columns:
    channel: JioMart
    data_types_configured: OMS, Settlement, Returns, Transactions
  raw_text: '| JioMart | OMS, Settlement, Returns, Transactions |'
  summary: 'JioMart: channel=JioMart; data_types_configured=OMS, Settlement, Returns, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L29
  row_key: Snapdeal
  columns:
    channel: Snapdeal
    data_types_configured: OMS, Settlement, Commission file (5-sheet), Transactions
  raw_text: '| Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |'
  summary: 'Snapdeal: channel=Snapdeal; data_types_configured=OMS, Settlement, Commission file (5-sheet), Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.08_tata_cliq
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L30
  row_key: Tata Cliq
  columns:
    channel: Tata Cliq
    data_types_configured: OMS, Settlement, Transactions
  raw_text: '| Tata Cliq | OMS, Settlement, Transactions |'
  summary: 'Tata Cliq: channel=Tata Cliq; data_types_configured=OMS, Settlement, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L31
  row_key: Cred
  columns:
    channel: Cred
    data_types_configured: Sales, Settlement, Returns, Transactions
  raw_text: '| Cred    | Sales, Settlement, Returns, Transactions |'
  summary: 'Cred: channel=Cred; data_types_configured=Sales, Settlement, Returns, Transactions'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / General marketplaces
  evidence_type: configured_source_row
  source_line: L32
  row_key: Klip · Blitz · Snapmint
  columns:
    channel: Klip · Blitz · Snapmint
    data_types_configured: Settlement only
  raw_text: '| Klip · Blitz · Snapmint | Settlement only       |'
  summary: 'Klip · Blitz · Snapmint: channel=Klip · Blitz · Snapmint; data_types_configured=Settlement only'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / D2C / other order sources
  evidence_type: docx_section
  source_lines: L33-L37
  summary: '| Channel | Data types configured |

    |---------|-----------------------|

    | Shopify | D2C OMS               |

    | Shiprocket | Sales / OMS           |'
  raw_lines:
  - '| Channel | Data types configured |'
  - '|---------|-----------------------|'
  - '| Shopify | D2C OMS               |'
  - '| Shiprocket | Sales / OMS           |'
  row_count: 2
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.01_shopify
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / D2C / other order sources
  evidence_type: configured_source_row
  source_line: L36
  row_key: Shopify
  columns:
    channel: Shopify
    data_types_configured: D2C OMS
  raw_text: '| Shopify | D2C OMS               |'
  summary: 'Shopify: channel=Shopify; data_types_configured=D2C OMS'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.02_shiprocket
  source_document: Tanvi Fitness.docx
  source_section: Active sales channels / Health-specific marketplaces / D2C / other order sources
  evidence_type: configured_source_row
  source_line: L37
  row_key: Shiprocket
  columns:
    channel: Shiprocket
    data_types_configured: Sales / OMS
  raw_text: '| Shiprocket | Sales / OMS           |'
  summary: 'Shiprocket: channel=Shiprocket; data_types_configured=Sales / OMS'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.section.05_wms_fulfilment_layer
  source_document: Tanvi Fitness.docx
  source_section: WMS / fulfilment layer
  evidence_type: docx_section
  source_lines: L38-L41
  summary: '| System | Files configured |

    |--------|------------------|

    | Increff | Sales, Returns, Returns processed |'
  raw_lines:
  - '| System | Files configured |'
  - '|--------|------------------|'
  - '| Increff | Sales, Returns, Returns processed |'
  row_count: 1
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  source_document: Tanvi Fitness.docx
  source_section: WMS / fulfilment layer
  evidence_type: configured_source_row
  source_line: L41
  row_key: Increff
  columns:
    system: Increff
    files_configured: Sales, Returns, Returns processed
  raw_text: '| Increff | Sales, Returns, Returns processed |'
  summary: 'Increff: system=Increff; files_configured=Sales, Returns, Returns processed'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  source_document: Tanvi Fitness.docx
  source_section: Logistics — courier reconciliation
  evidence_type: docx_section
  source_lines: L42-L49
  summary: '| Courier | Files configured |

    |---------|------------------|

    | Delhivery | Settlement       |

    | Ekart   | Settlement       |

    | DTDC    | Settlement       |

    | Xpressbees | Settlement       |

    | Shadowfax | Settlement       |'
  raw_lines:
  - '| Courier | Files configured |'
  - '|---------|------------------|'
  - '| Delhivery | Settlement       |'
  - '| Ekart   | Settlement       |'
  - '| DTDC    | Settlement       |'
  - '| Xpressbees | Settlement       |'
  - '| Shadowfax | Settlement       |'
  row_count: 5
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.01_delhivery
  source_document: Tanvi Fitness.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L45
  row_key: Delhivery
  columns:
    courier: Delhivery
    files_configured: Settlement
  raw_text: '| Delhivery | Settlement       |'
  summary: 'Delhivery: courier=Delhivery; files_configured=Settlement'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.02_ekart
  source_document: Tanvi Fitness.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L46
  row_key: Ekart
  columns:
    courier: Ekart
    files_configured: Settlement
  raw_text: '| Ekart   | Settlement       |'
  summary: 'Ekart: courier=Ekart; files_configured=Settlement'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.03_dtdc
  source_document: Tanvi Fitness.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L47
  row_key: DTDC
  columns:
    courier: DTDC
    files_configured: Settlement
  raw_text: '| DTDC    | Settlement       |'
  summary: 'DTDC: courier=DTDC; files_configured=Settlement'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.04_xpressbees
  source_document: Tanvi Fitness.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L48
  row_key: Xpressbees
  columns:
    courier: Xpressbees
    files_configured: Settlement
  raw_text: '| Xpressbees | Settlement       |'
  summary: 'Xpressbees: courier=Xpressbees; files_configured=Settlement'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.05_shadowfax
  source_document: Tanvi Fitness.docx
  source_section: Logistics — courier reconciliation
  evidence_type: configured_source_row
  source_line: L49
  row_key: Shadowfax
  columns:
    courier: Shadowfax
    files_configured: Settlement
  raw_text: '| Shadowfax | Settlement       |'
  summary: 'Shadowfax: courier=Shadowfax; files_configured=Settlement'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  source_document: Tanvi Fitness.docx
  source_section: Payment gateway reconciliation
  evidence_type: docx_section
  source_lines: L50-L56
  summary: '| Gateway | Pipeline target | Notes |

    |---------|-----------------|-------|

    | Razorpay | razorpay_payin  |       |

    | Paytm   | paytm_payin     |       |

    | Cashfree | cashfree_payin  | Settlement Txns sheet — see warning below |

    | Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) — see warning below |'
  raw_lines:
  - '| Gateway | Pipeline target | Notes |'
  - '|---------|-----------------|-------|'
  - '| Razorpay | razorpay_payin  |       |'
  - '| Paytm   | paytm_payin     |       |'
  - '| Cashfree | cashfree_payin  | Settlement Txns sheet — see warning below |'
  - '| Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) — see warning below |'
  row_count: 4
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
- id: ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.01_razorpay
  source_document: Tanvi Fitness.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L53
  row_key: Razorpay
  columns:
    gateway: Razorpay
    pipeline_target: razorpay_payin
    notes: ''
  raw_text: '| Razorpay | razorpay_payin  |       |'
  summary: 'Razorpay: gateway=Razorpay; pipeline_target=razorpay_payin; notes='
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.02_paytm
  source_document: Tanvi Fitness.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L54
  row_key: Paytm
  columns:
    gateway: Paytm
    pipeline_target: paytm_payin
    notes: ''
  raw_text: '| Paytm   | paytm_payin     |       |'
  summary: 'Paytm: gateway=Paytm; pipeline_target=paytm_payin; notes='
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.03_cashfree
  source_document: Tanvi Fitness.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L55
  row_key: Cashfree
  columns:
    gateway: Cashfree
    pipeline_target: cashfree_payin
    notes: Settlement Txns sheet — see warning below
  raw_text: '| Cashfree | cashfree_payin  | Settlement Txns sheet — see warning below |'
  summary: 'Cashfree: gateway=Cashfree; pipeline_target=cashfree_payin; notes=Settlement Txns sheet — see warning below'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.04_easebuzz
  source_document: Tanvi Fitness.docx
  source_section: Payment gateway reconciliation
  evidence_type: configured_source_row
  source_line: L56
  row_key: Easebuzz
  columns:
    gateway: Easebuzz
    pipeline_target: easebuzz_settlement
    notes: Two-sheet (header_1 + header_2) — see warning below
  raw_text: '| Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) — see warning below |'
  summary: 'Easebuzz: gateway=Easebuzz; pipeline_target=easebuzz_settlement; notes=Two-sheet (header_1 + header_2) — see warning
    below'
  confidence: high
- id: ev.tanvi_fitness_private_limited.docx.section.08_marketplace_transactions_layer
  source_document: Tanvi Fitness.docx
  source_section: Marketplace transactions layer
  evidence_type: docx_section
  source_lines: L57-L58
  summary: 'Dedicated `marketplace_transactions` feed active for: Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart, Snapdeal,
    Tata Cliq, Cred, OneMg, Healthkart, GetSupp.'
  raw_lines:
  - 'Dedicated `marketplace_transactions` feed active for: Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart, Snapdeal, Tata
    Cliq, Cred, OneMg, Healthkart, GetSupp.'
  row_count: 0
  confidence: high
  preservation: source_docx_text_extracted_for_runtime_binding_refactor
```

## 2. Candidate Cards

### 2.1 tenant

```yaml
candidate_cards:
- card_type: tenant
  card_id: tenant.tanvi_fitness_private_limited
  canonical_id: tenant.tanvi_fitness_private_limited
  name: Tanvi Fitness Private Limited
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.01_shopify
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  description: India health, wellness, and personal-care brand selling across health-specific marketplaces, general marketplaces,
    Shopify D2C, Shiprocket, Increff, logistics, and payment gateway flows.
  fields:
    tenant_name: Tanvi Fitness Private Limited
    tenant_code: TANVI_FITNESS
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    original_bad_state_status:
      status: active
      active: true
```

### 2.2 group

```yaml
candidate_cards:
- card_type: group
  card_id: group.tanvi_fitness_private_limited.mensa_brands
  canonical_id: group.tanvi_fitness_private_limited.mensa_brands
  name: Mensa Brands
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_name: Mensa Brands
    group_code: MENSA_BRANDS
    group_type: operational_unit
    business_meaning: Mensa Brands operating group for Tanvi Fitness / MYFITNESS India health and marketplace flows.
    country_or_region: India
    default_currency: INR
    source_scope_identifiers:
      group_id: 9
      group_level_id: 26
      representation_rule: Use these values through Account Data Binding scope_keys.
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
```

### 2.3 platform_account

```yaml
candidate_cards:
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  name: Amazon India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Amazon India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.amazon
        source_documents:
        - amazon_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.amazon.in
        source_documents:
        - amazon_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  name: Flipkart India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Flipkart India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.flipkart
        source_documents:
        - flipkart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.flipkart.in
        source_documents:
        - flipkart_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  name: Myntra India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: Myntra India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return, VHS + VFS expenses, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.myntra
        source_documents:
        - myntra_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.myntra.in
        source_documents:
        - myntra_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  name: Meesho India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.meesho
    platform_context_id: platform_context.meesho.in
    account_name: Meesho India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.meesho
        source_documents:
        - meesho_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.meesho.in
        source_documents:
        - meesho_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  name: Nykaa India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.nykaa
    platform_context_id: platform_context.nykaa_fashion.in
    account_name: Nykaa India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.nykaa
        source_documents:
        - nykaa_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.nykaa_fashion.in
        source_documents:
        - nykaa_marketplace.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.nykaa.in
      to: platform_context.nykaa_fashion.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  name: JioMart India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.06_jiomart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.jiomart
    platform_context_id: platform_context.jiomart.in
    account_name: JioMart India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.jiomart
        source_documents:
        - jiomart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.jiomart.in
        source_documents:
        - jiomart_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  name: Snapdeal India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.snapdeal
    platform_context_id: platform_context.snapdeal.in
    account_name: Snapdeal India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.snapdeal
        source_documents:
        - snapdeal_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.snapdeal.in
        source_documents:
        - snapdeal_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  name: Tata Cliq India primary marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.08_tata_cliq
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.tatacliq
    platform_context_id: platform_context.tatacliq.in
    account_name: Tata Cliq India primary marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Tata Cliq | OMS, Settlement, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.tatacliq
        source_documents:
        - tatacliq_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.tatacliq.in
        source_documents:
        - tatacliq_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  name: Cred India marketplace account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: Cred India marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    country_or_region: India
    declared_platform_id: platform.cred
    declared_platform_label: CRED marketplace/channel
    declared_platform_context_id: platform_context.cred.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.cred
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.cred.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  name: Klip India settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: Klip India settlement account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Klip | Settlement only
    country_or_region: India
    declared_platform_id: platform.klip
    declared_platform_label: Klip channel
    declared_platform_context_id: platform_context.klip.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.klip
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.klip.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  name: Blitz India settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: Blitz India settlement account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Blitz | Settlement only
    country_or_region: India
    declared_platform_id: platform.blitz
    declared_platform_label: Blitz channel
    declared_platform_context_id: platform_context.blitz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.blitz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.blitz.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  name: Snapmint India settlement account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: Snapmint India settlement account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Snapmint | Settlement only
    country_or_region: India
    declared_platform_id: platform.snapmint
    declared_platform_label: Snapmint BNPL/settlement channel
    declared_platform_context_id: platform_context.snapmint.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.snapmint
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.snapmint.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  name: HealthKart India marketplace account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - healthkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.healthkart
    platform_context_id: platform_context.healthkart.in
    account_name: HealthKart India marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: Healthkart | OMS, Settlement, Returns, Transactions
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.healthkart
        source_documents:
        - healthkart_marketplace.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.healthkart.in
        source_documents:
        - healthkart_marketplace.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  name: OneMg marketplace account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: OneMg marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: OneMg | Sales, Settlement, Returns, Transactions
    country_or_region: India
    declared_platform_id: platform.onemg
    declared_platform_label: 1mg / OneMg health marketplace
    declared_platform_context_id: platform_context.onemg.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.onemg
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.onemg.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  name: GetSupp marketplace account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: GetSupp marketplace account
    account_type: marketplace
    account_role: sales_channel
    source_account_identifier: null
    source_config_text: GetSupp | OMS Settlement (combined), Transactions
    country_or_region: India
    declared_platform_id: platform.getsupp
    declared_platform_label: GetSupp health marketplace
    declared_platform_context_id: platform_context.getsupp.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.getsupp
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.getsupp.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  name: Shopify D2C primary account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.01_shopify
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Shopify D2C primary account
    account_type: d2c_oms
    account_role: direct_to_consumer_order_source
    source_account_identifier: null
    source_config_text: Shopify | D2C OMS
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shopify
        source_documents:
        - shopify_d2c_oms_v2.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shopify.in_and_global.d2c_oms_client_config
        source_documents:
        - shopify_d2c_oms_v2.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in.d2c_oms
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  name: Shiprocket order-source account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.shiprocket
    platform_context_id: platform_context.shiprocket.in
    account_name: Shiprocket order-source account
    account_type: oms_order_source
    account_role: d2c_order_source
    source_account_identifier: null
    source_config_text: Shiprocket | Sales / OMS
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shiprocket
        source_documents:
        - shiprocket_logistics.md
        - shiprocket_logistics_aggregator.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shiprocket.in
        source_documents:
        - shiprocket_logistics.md
        - shiprocket_logistics_aggregator.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shiprocket.in.oms_order_source
      to: platform_context.shiprocket.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  name: Increff WMS/fulfilment account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - increff_operations.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.increff
    platform_context_id: platform_context.increff.in
    account_name: Increff WMS/fulfilment account
    account_type: wms_operations
    account_role: fulfilment_operations
    source_account_identifier: null
    source_config_text: Increff | Sales, Returns, Returns processed
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.increff
        source_documents:
        - increff_operations.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.increff.in
        source_documents:
        - increff_operations.md
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.increff.in.wms_operations
      to: platform_context.increff.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  name: Delhivery settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.01_delhivery
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.delhivery
    platform_context_id: platform_context.delhivery.in
    account_name: Delhivery settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Delhivery | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.delhivery
        source_documents:
        - delhivery_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.delhivery.in
        source_documents:
        - delhivery_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  name: Ekart settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.02_ekart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.ekart
    platform_context_id: platform_context.ekart.in
    account_name: Ekart settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Ekart | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.ekart
        source_documents:
        - ekart_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.ekart.in
        source_documents:
        - ekart_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  name: DTDC settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.03_dtdc
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.dtdc
    platform_context_id: platform_context.dtdc.in
    account_name: DTDC settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: DTDC | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.dtdc
        source_documents:
        - dtdc_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.dtdc.in
        source_documents:
        - dtdc_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  name: Xpressbees settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.04_xpressbees
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.xpressbees
    platform_context_id: platform_context.xpressbees.in
    account_name: Xpressbees settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Xpressbees | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.xpressbees
        source_documents:
        - xpressbees_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.xpressbees.in
        source_documents:
        - xpressbees_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  name: Shadowfax settlement account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - shadowfax_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.05_shadowfax
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.shadowfax
    platform_context_id: platform_context.shadowfax.in
    account_name: Shadowfax settlement account
    account_type: logistics
    account_role: courier_settlement
    source_account_identifier: null
    source_config_text: Shadowfax | Settlement
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.shadowfax
        source_documents:
        - shadowfax_logistics.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.shadowfax.in
        source_documents:
        - shadowfax_logistics.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  name: Razorpay payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.01_razorpay
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: Razorpay payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Razorpay | razorpay_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.razorpay
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.razorpay.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  name: Paytm payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.02_paytm
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.paytm
    platform_context_id: platform_context.paytm.in
    account_name: Paytm payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Paytm | paytm_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.paytm
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.paytm.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  name: Cashfree payment gateway account
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.03_cashfree
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: Cashfree payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Cashfree | cashfree_payin
    country_or_region: India
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: resolved
        resolved_id: platform.cashfree
        source_documents:
        - payment_gateway.md
      platform_context_id:
        status: resolved
        resolved_id: platform_context.cashfree.in
        source_documents:
        - payment_gateway.md
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  name: Easebuzz payment gateway account
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.04_easebuzz
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: Easebuzz payment gateway account
    account_type: payment_gateway
    account_role: payment_collection
    source_account_identifier: null
    source_config_text: Easebuzz | easebuzz_settlement
    country_or_region: India
    declared_platform_id: platform.easebuzz
    declared_platform_label: Easebuzz payment gateway
    declared_platform_context_id: platform_context.easebuzz.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.easebuzz
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.easebuzz.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
- card_type: platform_account
  card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  canonical_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  name: Marketplace transactions feed
  status: review_required
  active: false
  confidence: curated
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    account_name: Marketplace transactions feed
    account_type: client_feed
    account_role: bank_side_or_transaction_matching_feed
    source_account_identifier: null
    source_config_text: marketplace_transactions feed
    country_or_region: India
    declared_platform_id: platform.marketplace_transactions
    declared_platform_label: platform.marketplace_transactions
    declared_platform_context_id: platform_context.marketplace_transactions.in
    source_account_identifier_status: not_provided_in_client_docx_not_a_runtime_blocker_when_scope_keys_exist
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    canonical_reference_resolution:
      platform_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform.marketplace_transactions
      platform_context_id:
        status: missing_from_uploaded_canonical_markdowns
        declared_id: platform_context.marketplace_transactions.in
    notes:
    - Client document confirms this platform/system is configured. Exact external account identifier was not supplied.
    original_bad_state_status:
      status: active
      active: true
    status_correction_reason: platform_or_context_missing_and_no_resolved_account_data_binding
```

### 2.4 account_data_binding

```yaml
candidate_cards:
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_oms
  name: account data binding / tanvi fitness private limited / amazon in / primary / amazon oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_oms
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.amazon_in.primary to table.zs_observe.amazon_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_settlement
  name: account data binding / tanvi fitness private limited / amazon in / primary / amazon settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_settlement
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.amazon_in.primary to table.zs_observe.amazon_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_disbursment
  canonical_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_disbursment
  name: account data binding / tanvi fitness private limited / amazon in / primary / amazon disbursment
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_disbursment
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.amazon_in.primary to table.zs_observe.amazon_disbursment using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    registry_notes:
    - Canonical source uses the spelling disbursment.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_fee_preview
  canonical_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_fee_preview
  name: account data binding / tanvi fitness private limited / amazon in / primary / amazon fee preview
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
    table_id: table.zs_observe.amazon_fee_preview
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.amazon_fee_preview
      source_documents:
      - amazon_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.amazon_in.primary to table.zs_observe.amazon_fee_preview using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.oms
  name: account data binding / tanvi fitness private limited / flipkart in / primary / oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
    table_id: table.flipkart.oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.oms
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.flipkart_in.primary to table.flipkart.oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.cashback
  canonical_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.cashback
  name: account data binding / tanvi fitness private limited / flipkart in / primary / cashback
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
    table_id: table.flipkart.cashback
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.cashback
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.flipkart_in.primary to table.flipkart.cashback using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.settlement
  name: account data binding / tanvi fitness private limited / flipkart in / primary / settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.settlement
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.flipkart_in.primary to table.flipkart.settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.commission
  canonical_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.commission
  name: account data binding / tanvi fitness private limited / flipkart in / primary / commission
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - flipkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
    table_id: table.flipkart.commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.flipkart.commission
      source_documents:
      - flipkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.flipkart_in.primary to table.flipkart.commission using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms
  name: account data binding / tanvi fitness private limited / myntra in / primary / myntra oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_oms
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_settlement
  name: account data binding / tanvi fitness private limited / myntra in / primary / myntra settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_reverse
  canonical_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_reverse
  name: account data binding / tanvi fitness private limited / myntra in / primary / myntra reverse
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_reverse
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_non_order_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_non_order_settlement
  name: account data binding / tanvi fitness private limited / myntra in / primary / myntra non order settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_non_order_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms_settlement
  name: account data binding / tanvi fitness private limited / myntra in / primary / myntra oms settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - myntra_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Returns/RTO,
      GSTR, expenses, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.myntra_oms_settlement
      source_documents:
      - myntra_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - 'Mapped only to current canonical Myntra semantic coverage: OMS, settlement, reverse/returns, non-order settlement,
      and OMS-settlement helper. Seller reports, GSTR, VHS/VFS, non-order expenses, and transactions remain outside active
      table bindings until added to platform context.'
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_sales
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_sales
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_sales
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_settlement
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_settlement
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_returns
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_returns
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_returns
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho reverse
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_reverse
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_reverse using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_forward_expenses
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_forward_expenses
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho forward expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_forward_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_forward_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_forward_expenses using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse_expenses
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse_expenses
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho reverse expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_reverse_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_reverse_expenses using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_other_charges_expenses
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_other_charges_expenses
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho other charges expenses
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_other_charges_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_other_charges_expenses
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_other_charges_expenses
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_brand_mapping
  canonical_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_brand_mapping
  name: account data binding / tanvi fitness private limited / meesho in / primary / meesho brand mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - meesho_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
    table_id: table.zs_observe.meesho_brand_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.meesho_brand_mapping
      source_documents:
      - meesho_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.meesho_in.primary to table.zs_observe.meesho_brand_mapping using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_oms
  name: account data binding / tanvi fitness private limited / nykaa in / primary / nykaa oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_oms
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.nykaa_in.primary to table.zs_observe.nykaa_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_settlement
  name: account data binding / tanvi fitness private limited / nykaa in / primary / nykaa settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_settlement
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.nykaa_in.primary to table.zs_observe.nykaa_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_addition_charge
  canonical_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_addition_charge
  name: account data binding / tanvi fitness private limited / nykaa in / primary / nykaa addition charge
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_addition_charge
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_addition_charge
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.nykaa_in.primary to table.zs_observe.nykaa_addition_charge using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapper_gst
  canonical_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapper_gst
  name: account data binding / tanvi fitness private limited / nykaa in / primary / nykaa mapper gst
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapper_gst
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_mapper_gst
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.nykaa_in.primary to table.zs_observe.nykaa_mapper_gst using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapping
  canonical_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapping
  name: account data binding / tanvi fitness private limited / nykaa in / primary / nykaa mapping
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - nykaa_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.05_nykaa
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
      Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.nykaa_mapping
      source_documents:
      - nykaa_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.nykaa_in.primary to table.zs_observe.nykaa_mapping using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_oms
  name: account data binding / tanvi fitness private limited / jiomart in / primary / jiomart oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.06_jiomart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
    table_id: table.zs_observe.jiomart_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_oms
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - JioMart binding uses current canonical tables. Canonical JioMart source has client-specific scope caveats; verify entity
      coverage for this client before production use.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_settlement
  name: account data binding / tanvi fitness private limited / jiomart in / primary / jiomart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.06_jiomart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
    table_id: table.zs_observe.jiomart_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_settlement
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - JioMart binding uses current canonical tables. Canonical JioMart source has client-specific scope caveats; verify entity
      coverage for this client before production use.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_returns
  canonical_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_returns
  name: account data binding / tanvi fitness private limited / jiomart in / primary / jiomart returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - jiomart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.06_jiomart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
    table_id: table.zs_observe.jiomart_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: JioMart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.jiomart_returns
      source_documents:
      - jiomart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - JioMart binding uses current canonical tables. Canonical JioMart source has client-specific scope caveats; verify entity
      coverage for this client before production use.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_oms
  name: account data binding / tanvi fitness private limited / snapdeal in / primary / snapdeal oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_oms
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_settlement
  name: account data binding / tanvi fitness private limited / snapdeal in / primary / snapdeal settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_settlement
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_commission
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_commission
  name: account data binding / tanvi fitness private limited / snapdeal in / primary / snapdeal commission
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_commission
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_commission using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_sales_return
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_sales_return
  name: account data binding / tanvi fitness private limited / snapdeal in / primary / snapdeal sales return
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_sales_return
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_sales_return
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_sales_return using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_payments
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_payments
  name: account data binding / tanvi fitness private limited / snapdeal in / primary / snapdeal payments
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_payments
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_payments
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_payments using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_non_order
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_non_order
  name: account data binding / tanvi fitness private limited / snapdeal in / primary / snapdeal non order
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - snapdeal_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.07_snapdeal
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.02_flipkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_non_order
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.snapdeal_non_order
      source_documents:
      - snapdeal_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapdeal_in.primary to table.zs_observe.snapdeal_non_order using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_oms
  name: account data binding / tanvi fitness private limited / tatacliq in / primary / tatacliq oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.08_tata_cliq
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Tata Cliq | OMS, Settlement, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tatacliq_oms
      source_documents:
      - tatacliq_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.tatacliq_in.primary to table.zs_observe.tatacliq_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_settlement
  name: account data binding / tanvi fitness private limited / tatacliq in / primary / tatacliq settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.08_tata_cliq
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Tata Cliq | OMS, Settlement, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.tatacliq_settlement
      source_documents:
      - tatacliq_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.tatacliq_in.primary to table.zs_observe.tatacliq_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
  canonical_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
  name: account data binding / tanvi fitness private limited / cred in / primary / cred sales
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.cred_sales
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cred_sales
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.cred_in.primary to table.zs_observe.cred_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
  name: account data binding / tanvi fitness private limited / cred in / primary / cred settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.cred_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cred_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.cred_in.primary to table.zs_observe.cred_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
  canonical_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
  name: account data binding / tanvi fitness private limited / cred in / primary / cred returns
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cred | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.cred_returns
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.cred_returns
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.cred_in.primary to table.zs_observe.cred_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
  name: account data binding / tanvi fitness private limited / klip in / primary / klip settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Klip | Settlement only
    declared_table_id: table.zs_observe.klip_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.klip_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.klip_in.primary to table.zs_observe.klip_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
  name: account data binding / tanvi fitness private limited / blitz in / primary / blitz settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Blitz | Settlement only
    declared_table_id: table.zs_observe.blitz_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.blitz_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.blitz_in.primary to table.zs_observe.blitz_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
  name: account data binding / tanvi fitness private limited / snapmint in / primary / snapmint settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.10_klip_blitz_snapmint
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Snapmint | Settlement only
    declared_table_id: table.zs_observe.snapmint_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.snapmint_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.snapmint_in.primary to table.zs_observe.snapmint_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
  name: account data binding / tanvi fitness private limited / healthkart in / primary / healthkart oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - healthkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
    table_id: table.zs_observe.healthkart_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Healthkart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.healthkart_oms
      source_documents:
      - healthkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.healthkart_in.primary to table.zs_observe.healthkart_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
  name: account data binding / tanvi fitness private limited / healthkart in / primary / healthkart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - healthkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
    table_id: table.zs_observe.healthkart_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Healthkart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.healthkart_settlement
      source_documents:
      - healthkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.healthkart_in.primary to table.zs_observe.healthkart_settlement
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
  canonical_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
  name: account data binding / tanvi fitness private limited / healthkart in / primary / healthkart return
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - healthkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.03_myntra
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
    table_id: table.zs_observe.healthkart_return
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Healthkart | OMS, Settlement, Returns, Transactions
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.healthkart_return
      source_documents:
      - healthkart_marketplace.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.healthkart_in.primary to table.zs_observe.healthkart_return using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  canonical_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  name: account data binding / tanvi fitness private limited / onemg in / primary / onemg sales
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: OneMg | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.onemg_sales
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.onemg_sales
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.onemg_in.primary to table.zs_observe.onemg_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  name: account data binding / tanvi fitness private limited / onemg in / primary / onemg settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: OneMg | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.onemg_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.onemg_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.onemg_in.primary to table.zs_observe.onemg_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  canonical_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  name: account data binding / tanvi fitness private limited / onemg in / primary / onemg returns
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: OneMg | Sales, Settlement, Returns, Transactions
    declared_table_id: table.zs_observe.onemg_returns
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.onemg_returns
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.onemg_in.primary to table.zs_observe.onemg_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  name: account data binding / tanvi fitness private limited / getsupp in / primary / getsupp oms settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.01_amazon_india
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: GetSupp | OMS Settlement (combined), Transactions
    declared_table_id: table.zs_observe.getsupp_oms_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.getsupp_oms_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.getsupp_in.primary to table.zs_observe.getsupp_oms_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
  name: account data binding / tanvi fitness private limited / shopify d2c / primary / shopify oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - logistics_domain.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.01_shopify
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Shopify | D2C OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shopify_oms
      source_documents:
      - logistics_domain.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.shopify_d2c.primary to table.zs_observe.shopify_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
  canonical_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
  name: account data binding / tanvi fitness private limited / shiprocket order source / primary / shiprocket oms
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - shiprocket_logistics.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
    table_id: table.zs_observe.shiprocket_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Shiprocket | Sales / OMS
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.shiprocket_oms
      source_documents:
      - shiprocket_logistics.md
      - shopify_d2c_oms_v2.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: source_document_text
      from: shopify_d2c_oms.md
      to: shopify_d2c_oms_v2.md
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary to table.zs_observe.shiprocket_oms
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
  canonical_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
  name: account data binding / tanvi fitness private limited / increff wms / primary / increff sales
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - increff_operations.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
    table_id: table.zs_observe.increff_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Increff | Sales, Returns, Returns processed
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.increff_sales
      source_documents:
      - increff_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.increff_wms.primary to table.zs_observe.increff_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
  canonical_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
  name: account data binding / tanvi fitness private limited / increff wms / primary / increff returns
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - increff_operations.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.04_meesho
  - ev.tanvi_fitness_private_limited.docx.row.03_active_sales_channels_health_specific_marketplaces_general_marketplaces.09_cred
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
    table_id: table.zs_observe.increff_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Increff | Sales, Returns, Returns processed
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.increff_returns
      source_documents:
      - increff_operations.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.increff_wms.primary to table.zs_observe.increff_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.delhivery_in.primary.delhivery_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.delhivery_in.primary.delhivery_settlement
  name: account data binding / tanvi fitness private limited / delhivery in / primary / delhivery settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - delhivery_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.01_delhivery
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
    table_id: table.zs_observe.delhivery_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Delhivery | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.delhivery_settlement
      source_documents:
      - delhivery_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.delhivery_in.primary to table.zs_observe.delhivery_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.ekart_in.primary.ekart_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.ekart_in.primary.ekart_settlement
  name: account data binding / tanvi fitness private limited / ekart in / primary / ekart settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - ekart_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.02_ekart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
    table_id: table.zs_observe.ekart_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Ekart | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.ekart_settlement
      source_documents:
      - ekart_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.ekart_in.primary to table.zs_observe.ekart_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.dtdc_in.primary.dtdc_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.dtdc_in.primary.dtdc_settlement
  name: account data binding / tanvi fitness private limited / dtdc in / primary / dtdc settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - dtdc_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.03_dtdc
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
    table_id: table.zs_observe.dtdc_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: DTDC | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.dtdc_settlement
      source_documents:
      - dtdc_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.dtdc_in.primary to table.zs_observe.dtdc_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.xpressbees_in.primary.xpressbees_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.xpressbees_in.primary.xpressbees_settlement
  name: account data binding / tanvi fitness private limited / xpressbees in / primary / xpressbees settlement
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - xpressbees_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.04_xpressbees
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
    table_id: table.zs_observe.xpressbees_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Xpressbees | Settlement
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.xpressbees_settlement
      source_documents:
      - xpressbees_logistics.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.xpressbees_in.primary to table.zs_observe.xpressbees_settlement
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  name: account data binding / tanvi fitness private limited / shadowfax in / primary / shadowfax settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.05_shadowfax
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Shadowfax | Settlement
    declared_table_id: table.zs_observe.shadowfax_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.shadowfax_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.shadowfax_in.primary to table.zs_observe.shadowfax_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.razorpay_in.primary.razorpay_payin
  canonical_id: account_data_binding.tanvi_fitness_private_limited.razorpay_in.primary.razorpay_payin
  name: account data binding / tanvi fitness private limited / razorpay in / primary / razorpay payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.01_razorpay
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
    table_id: table.zs_observe.razorpay_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Razorpay | razorpay_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.razorpay_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.razorpay_in.primary to table.zs_observe.razorpay_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.paytm_in.primary.paytm_payin
  canonical_id: account_data_binding.tanvi_fitness_private_limited.paytm_in.primary.paytm_payin
  name: account data binding / tanvi fitness private limited / paytm in / primary / paytm payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.02_paytm
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
    table_id: table.zs_observe.paytm_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Paytm | paytm_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.paytm_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.paytm_in.primary to table.zs_observe.paytm_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.cashfree_in.primary.cashfree_payin
  canonical_id: account_data_binding.tanvi_fitness_private_limited.cashfree_in.primary.cashfree_payin
  name: account data binding / tanvi fitness private limited / cashfree in / primary / cashfree payin
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.03_cashfree
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
    table_id: table.zs_observe.cashfree_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Cashfree | cashfree_payin
    canonical_table_resolution:
      status: resolved
      resolved_id: table.zs_observe.cashfree_payin
      source_documents:
      - payment_gateway.md
    routing_status: routable_when_scope_keys_are_available
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.cashfree_in.primary to table.zs_observe.cashfree_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: active
      active: true
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  canonical_id: account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  name: account data binding / tanvi fitness private limited / easebuzz in / primary / easebuzz settlement
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.07_payment_gateway_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.07_payment_gateway_reconciliation.04_easebuzz
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Easebuzz | easebuzz_settlement
    declared_table_id: table.zs_observe.easebuzz_settlement
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.easebuzz_settlement
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.easebuzz_in.primary to table.zs_observe.easebuzz_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
- card_type: account_data_binding
  card_id: account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
  canonical_id: account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
  name: account data binding / tanvi fitness private limited / marketplace transactions / primary / marketplace transactions
  status: review_required
  active: false
  confidence: source_configured
  review_status: review_required
  create_action: upsert
  source_documents:
  - Prita Designs Private Limited.docx / Tanvi Fitness.docx
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  fields:
    platform_account_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
    table_support_level: source_configured_requires_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 26
      data_type: integer
    runtime_qualifiers: []
    source_config_text: Dedicated marketplace_transactions feed active in the client profile
    declared_table_id: table.zs_observe.marketplace_transactions
    canonical_table_resolution:
      status: missing_from_uploaded_canonical_markdowns
      declared_id: table.zs_observe.marketplace_transactions
    routing_status: blocked_until_table_card_exists
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bind platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary to table.zs_observe.marketplace_transactions
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    original_bad_state_status:
      status: review_required
      active: false
    status_correction_reason: table_binding_missing_canonical_table_card
```

### 2.5 business_scope_set

```yaml
candidate_cards:
- card_type: business_scope_set
  card_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  canonical_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  name: Tanvi health-specific marketplace scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - healthkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.01_onemg
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.02_healthkart
  - ev.tanvi_fitness_private_limited.docx.row.02_active_sales_channels_health_specific_marketplaces.03_getsupp
  description: Health-specific marketplaces for Tanvi / MYFITNESS. HealthKart is active from canonical context; OneMg and
    GetSupp require added context.
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    scope_name: Tanvi health-specific marketplace scope
    scope_type: health_marketplace_scope
    platform_account_ids:
    - platform_account.tanvi_fitness_private_limited.healthkart_in.primary
    - platform_account.tanvi_fitness_private_limited.onemg_in.primary
    - platform_account.tanvi_fitness_private_limited.getsupp_in.primary
    platform_ids:
    - platform.healthkart
    platform_context_ids:
    - platform_context.healthkart.in
    declared_unresolved_platform_ids:
    - platform.onemg
    - platform.getsupp
    declared_unresolved_platform_context_ids:
    - platform_context.onemg.in
    - platform_context.getsupp.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  canonical_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  name: Tanvi active canonical general marketplaces
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - healthkart_marketplace.md
  - jiomart_marketplace.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  description: Canonical-mapped marketplace accounts for Tanvi across general and health channels.
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    scope_name: Tanvi active canonical general marketplaces
    scope_type: marketplace_seller_scope
    platform_account_ids:
    - platform_account.tanvi_fitness_private_limited.amazon_in.primary
    - platform_account.tanvi_fitness_private_limited.flipkart_in.primary
    - platform_account.tanvi_fitness_private_limited.myntra_in.primary
    - platform_account.tanvi_fitness_private_limited.meesho_in.primary
    - platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    - platform_account.tanvi_fitness_private_limited.jiomart_in.primary
    - platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
    - platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
    - platform_account.tanvi_fitness_private_limited.healthkart_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    - platform.meesho
    - platform.nykaa
    - platform.jiomart
    - platform.snapdeal
    - platform.tatacliq
    - platform.healthkart
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    - platform_context.meesho.in
    - platform_context.nykaa_fashion.in
    - platform_context.jiomart.in
    - platform_context.snapdeal.in
    - platform_context.tatacliq.in
    - platform_context.healthkart.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.nykaa.in
      to: platform_context.nykaa_fashion.in
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  canonical_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  name: Tanvi Shopify, Shiprocket, and Increff operations
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - increff_operations.md
  - shiprocket_logistics.md
  - shiprocket_logistics_aggregator.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.01_shopify
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  description: D2C order source, Shiprocket order-source feed, and Increff WMS fulfilment scope.
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    scope_name: Tanvi Shopify, Shiprocket, and Increff operations
    scope_type: d2c_wms_scope
    platform_account_ids:
    - platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
    - platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
    - platform_account.tanvi_fitness_private_limited.increff_wms.primary
    platform_ids:
    - platform.shopify
    - platform.shiprocket
    - platform.increff
    platform_context_ids:
    - platform_context.shopify.in_and_global.d2c_oms_client_config
    - platform_context.shiprocket.in
    - platform_context.increff.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    refactor_replacements_applied:
    - kind: canonical_id
      from: platform_context.shopify.in.d2c_oms
      to: platform_context.shopify.in_and_global.d2c_oms_client_config
    - kind: canonical_id
      from: platform_context.shiprocket.in.oms_order_source
      to: platform_context.shiprocket.in
    - kind: canonical_id
      from: platform_context.increff.in.wms_operations
      to: platform_context.increff.in
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  canonical_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  name: Tanvi logistics settlement scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - shadowfax_logistics.md
  - xpressbees_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.06_logistics_courier_reconciliation.05_shadowfax
  description: Courier settlement scope. Shadowfax requires added context before active use.
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    scope_name: Tanvi logistics settlement scope
    scope_type: logistics_settlement_scope
    platform_account_ids:
    - platform_account.tanvi_fitness_private_limited.delhivery_in.primary
    - platform_account.tanvi_fitness_private_limited.ekart_in.primary
    - platform_account.tanvi_fitness_private_limited.dtdc_in.primary
    - platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
    - platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
    platform_ids:
    - platform.delhivery
    - platform.ekart
    - platform.dtdc
    - platform.xpressbees
    - platform.shadowfax
    platform_context_ids:
    - platform_context.delhivery.in
    - platform_context.ekart.in
    - platform_context.dtdc.in
    - platform_context.xpressbees.in
    - platform_context.shadowfax.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
- card_type: business_scope_set
  card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  canonical_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  name: Tanvi payment gateway scope
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - payment_gateway.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  description: Payment gateway pay-in scope for D2C and other payment matching.
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    scope_name: Tanvi payment gateway scope
    scope_type: payment_gateway_scope
    platform_account_ids:
    - platform_account.tanvi_fitness_private_limited.razorpay_in.primary
    - platform_account.tanvi_fitness_private_limited.paytm_in.primary
    - platform_account.tanvi_fitness_private_limited.cashfree_in.primary
    - platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
    platform_ids:
    - platform.razorpay
    - platform.paytm
    - platform.cashfree
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.paytm.in
    - platform_context.cashfree.in
    declared_unresolved_platform_ids:
    - platform.easebuzz
    declared_unresolved_platform_context_ids:
    - platform_context.easebuzz.in
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes: []
    original_bad_state_status:
      status: active
      active: true
```

### 2.6 business_flow_binding

```yaml
candidate_cards:
- card_type: business_flow_binding
  card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  canonical_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  name: Tanvi health-marketplace reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - healthkart_marketplace.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    binding_name: Tanvi health-marketplace reconciliation
    binding_type: health_marketplace_reconciliation
    business_scope_set_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
    money_flow_paths:
    - Health marketplace OMS/sales -> settlement -> returns -> transactions review
    participating_accounts:
    - platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
      role: health_marketplace_oms_settlement_returns
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
      role: health_marketplace_review
      required: false
    - platform_account_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
      role: health_marketplace_review
      required: false
    account_data_binding_ids:
    - account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
    - account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
    - account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
    - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
    - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
    - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
    - account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
    evidence_table_ids:
    - table.zs_observe.healthkart_oms
    - table.zs_observe.healthkart_settlement
    - table.zs_observe.healthkart_return
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - HealthKart is active. OneMg and GetSupp are source-confirmed but require platform context before active use.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  canonical_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  name: Tanvi marketplace orders to Increff operations
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - increff_operations.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    binding_name: Tanvi marketplace orders to Increff operations
    binding_type: marketplace_to_wms_operations
    business_scope_set_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
    money_flow_paths:
    - Marketplace order/settlement evidence -> Increff sales/returns fulfilment evidence
    participating_accounts:
    - platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
      role: marketplace_order_or_settlement_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
      role: wms_operations
      required: true
    account_data_binding_ids:
    - account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_oms
    - account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_settlement
    - account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_disbursment
    - account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_fee_preview
    - account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.oms
    - account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.cashback
    - account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.settlement
    - account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.commission
    - account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms
    - account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_settlement
    - account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_reverse
    - account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_sales
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_settlement
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_returns
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_forward_expenses
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse_expenses
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_other_charges_expenses
    - account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_brand_mapping
    - account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_oms
    - account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_settlement
    - account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_addition_charge
    - account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapper_gst
    - account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapping
    - account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_oms
    - account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_settlement
    - account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_returns
    - account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_oms
    - account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_settlement
    - account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_commission
    - account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_sales_return
    - account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_payments
    - account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_non_order
    - account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_oms
    - account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_settlement
    - account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
    - account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
    - account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
    - account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
    - account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
    evidence_table_ids:
    - table.zs_observe.increff_sales
    - table.zs_observe.increff_returns
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  canonical_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  name: Tanvi Shopify D2C prepaid to payment gateways
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - logistics_domain.md
  - payment_gateway.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.01_shopify
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    binding_name: Tanvi Shopify D2C prepaid to payment gateways
    binding_type: d2c_oms_to_payment_gateway
    business_scope_set_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
    money_flow_paths:
    - Shopify D2C order -> payment gateway pay-in -> bank review
    participating_accounts:
    - platform_account_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
      role: d2c_oms
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
      role: pg_collection
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
      role: pg_collection
      required: false
    - platform_account_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
      role: pg_collection_review
      required: false
    account_data_binding_ids:
    - account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
    - account_data_binding.tanvi_fitness_private_limited.razorpay_in.primary.razorpay_payin
    - account_data_binding.tanvi_fitness_private_limited.cashfree_in.primary.cashfree_payin
    - account_data_binding.tanvi_fitness_private_limited.paytm_in.primary.paytm_payin
    - account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.razorpay_payin
    - table.zs_observe.cashfree_payin
    - table.zs_observe.paytm_payin
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  canonical_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  name: Tanvi Shiprocket order source to Increff operations
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - increff_operations.md
  - shiprocket_logistics.md
  - shopify_d2c_oms_v2.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.02_active_sales_channels_health_specific_marketplaces
  - ev.tanvi_fitness_private_limited.docx.section.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  - ev.tanvi_fitness_private_limited.docx.row.04_active_sales_channels_health_specific_marketplaces_d2c_other_order_sources.02_shiprocket
  - ev.tanvi_fitness_private_limited.docx.row.05_wms_fulfilment_layer.01_increff
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    binding_name: Tanvi Shiprocket order source to Increff operations
    binding_type: order_source_to_wms_operations
    business_scope_set_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    money_flow_paths:
    - Shiprocket sales/OMS -> Increff sales/returns operational evidence
    participating_accounts:
    - platform_account_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
      role: wms_operations
      required: true
    account_data_binding_ids:
    - account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
    - account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
    - account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
    evidence_table_ids:
    - table.zs_observe.shiprocket_oms
    - table.zs_observe.increff_sales
    - table.zs_observe.increff_returns
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  canonical_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  name: Tanvi courier settlement reconciliation
  status: active
  active: true
  confidence: curated
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - logistics_reconciliation_patterns.md
  - xpressbees_logistics.md
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.06_logistics_courier_reconciliation
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    binding_name: Tanvi courier settlement reconciliation
    binding_type: logistics_settlement_reconciliation
    business_scope_set_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
    money_flow_paths:
    - Courier settlement -> batch/amount/reference reconciliation -> bank review
    participating_accounts:
    - platform_account_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
      role: courier_settlement
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
      role: courier_settlement
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
      role: courier_settlement
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
      role: courier_settlement
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
      role: courier_settlement_review
      required: false
    account_data_binding_ids:
    - account_data_binding.tanvi_fitness_private_limited.delhivery_in.primary.delhivery_settlement
    - account_data_binding.tanvi_fitness_private_limited.ekart_in.primary.ekart_settlement
    - account_data_binding.tanvi_fitness_private_limited.dtdc_in.primary.dtdc_settlement
    - account_data_binding.tanvi_fitness_private_limited.xpressbees_in.primary.xpressbees_settlement
    - account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
    evidence_table_ids:
    - table.zs_observe.delhivery_settlement
    - table.zs_observe.ekart_settlement
    - table.zs_observe.dtdc_settlement
    - table.zs_observe.xpressbees_settlement
    conditions: []
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids:
    - reconciliation_profile.courier_batch_to_bank_credit
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Bank account is not supplied for Tanvi, so bank landing remains outside this active flow.
    original_bad_state_status:
      status: active
      active: true
- card_type: business_flow_binding
  card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  canonical_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  name: Tanvi marketplace transactions matching scope
  status: active
  active: true
  confidence: source_configured
  review_status: accepted
  create_action: upsert
  source_documents:
  - Cognee KB Design v4.md
  - Tanvi Fitness.docx
  evidence_refs:
  - ev.tanvi_fitness_private_limited.docx.section.01_identity
  fields:
    tenant_id: tenant.tanvi_fitness_private_limited
    group_id: group.tanvi_fitness_private_limited.mensa_brands
    binding_name: Tanvi marketplace transactions matching scope
    binding_type: marketplace_transaction_matching
    business_scope_set_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
    money_flow_paths:
    - Marketplace settlement -> marketplace_transactions feed -> bank/payment matching
    participating_accounts:
    - platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
      role: marketplace_channel
      required: true
    - platform_account_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
      role: transaction_feed_review
      required: true
    account_data_binding_ids:
    - account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
    evidence_table_ids: []
    conditions: []
    declared_unresolved_evidence_table_ids:
    - table.zs_observe.marketplace_transactions
    resolved_business_process_ids: []
    declared_unresolved_business_process_ids: []
    resolved_reconciliation_profile_ids: []
    declared_unresolved_reconciliation_profile_ids: []
    runtime_layer_policy: client_scope_and_account_binding_only_no_canonical_semantics_created_here
    notes:
    - Generic marketplace_transactions feed is source-confirmed but requires platform-context semantics before active reconciliation.
    original_bad_state_status:
      status: review_required
      active: false
```

## 3. Semantic Mapping Decisions

```yaml
semantic_mappings:
- platform_account_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  client_config_text: Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  - table.zs_observe.amazon_fee_preview
  future_context_gaps:
  - Transactions feed is represented through marketplace_transactions until platform-specific transaction-table context is
    added.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  - table.zs_observe.amazon_fee_preview
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  client_config_text: Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
  canonical_or_supported_tables_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  future_context_gaps:
  - Flipkart adhoc Ads/TDS/Rebates/VAS/Google Ads and transactions need additional platform context.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  client_config_text: Myntra | OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
    Returns/RTO, JIT GSTR return, VHS + VFS expenses, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  future_context_gaps:
  - Seller reports Fwd/Rev
  - JIT GSTR return
  - VHS + VFS expenses
  - Non-order expenses
  - Transactions
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  client_config_text: Meesho | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
    mapping, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.meesho_sales
  - table.zs_observe.meesho_settlement
  - table.zs_observe.meesho_returns
  - table.zs_observe.meesho_reverse
  - table.zs_observe.meesho_forward_expenses
  - table.zs_observe.meesho_reverse_expenses
  - table.zs_observe.meesho_other_charges_expenses
  - table.zs_observe.meesho_brand_mapping
  future_context_gaps:
  - Meesho transactions feed needs additional platform context.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.meesho_sales
  - table.zs_observe.meesho_settlement
  - table.zs_observe.meesho_returns
  - table.zs_observe.meesho_reverse
  - table.zs_observe.meesho_forward_expenses
  - table.zs_observe.meesho_reverse_expenses
  - table.zs_observe.meesho_other_charges_expenses
  - table.zs_observe.meesho_brand_mapping
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  client_config_text: Nykaa | OMS x4 storefronts, Settlement x4, payout summary, TDS, Additional shipping, MBTPT/GST mapper,
    Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.nykaa_oms
  - table.zs_observe.nykaa_settlement
  - table.zs_observe.nykaa_addition_charge
  - table.zs_observe.nykaa_mapper_gst
  - table.zs_observe.nykaa_mapping
  future_context_gaps:
  - Nykaa payout summary and marketplace_transactions feed require additional context if queried as separate tables.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.nykaa_oms
  - table.zs_observe.nykaa_settlement
  - table.zs_observe.nykaa_addition_charge
  - table.zs_observe.nykaa_mapper_gst
  - table.zs_observe.nykaa_mapping
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  client_config_text: JioMart | OMS, Settlement, Returns, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.jiomart_oms
  - table.zs_observe.jiomart_settlement
  - table.zs_observe.jiomart_returns
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.jiomart_oms
  - table.zs_observe.jiomart_settlement
  - table.zs_observe.jiomart_returns
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  client_config_text: Snapdeal | OMS, Settlement, Commission file, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.snapdeal_oms
  - table.zs_observe.snapdeal_settlement
  - table.zs_observe.snapdeal_commission
  - table.zs_observe.snapdeal_sales_return
  - table.zs_observe.snapdeal_payments
  - table.zs_observe.snapdeal_non_order
  future_context_gaps:
  - Snapdeal transactions feed needs additional platform context if separate from settlement/payments.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.snapdeal_oms
  - table.zs_observe.snapdeal_settlement
  - table.zs_observe.snapdeal_commission
  - table.zs_observe.snapdeal_sales_return
  - table.zs_observe.snapdeal_payments
  - table.zs_observe.snapdeal_non_order
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  client_config_text: Tata Cliq | OMS, Settlement, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  future_context_gaps:
  - Tata Cliq transactions feed needs additional platform context.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  client_config_text: Cred | Sales, Settlement, Returns, Transactions
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Cred platform context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  client_config_text: Klip | Settlement only
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Klip settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  client_config_text: Blitz | Settlement only
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Blitz settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  client_config_text: Snapmint | Settlement only
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Snapmint settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  client_config_text: Healthkart | OMS, Settlement, Returns, Transactions
  canonical_or_supported_tables_now:
  - table.zs_observe.healthkart_oms
  - table.zs_observe.healthkart_settlement
  - table.zs_observe.healthkart_return
  future_context_gaps:
  - HealthKart transactions feed if required separately.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.healthkart_oms
  - table.zs_observe.healthkart_settlement
  - table.zs_observe.healthkart_return
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  client_config_text: OneMg | Sales, Settlement, Returns, Transactions
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - OneMg platform context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  client_config_text: GetSupp | OMS Settlement (combined), Transactions
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - GetSupp platform context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  client_config_text: Shopify | D2C OMS
  canonical_or_supported_tables_now:
  - table.zs_observe.shopify_oms
  future_context_gaps:
  - Shopify returns are not listed in this client profile but table support exists if returns are later configured.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.shopify_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  client_config_text: Shiprocket | Sales / OMS
  canonical_or_supported_tables_now:
  - table.zs_observe.shiprocket_oms
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.shiprocket_oms
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  client_config_text: Increff | Sales, Returns, Returns processed
  canonical_or_supported_tables_now:
  - table.zs_observe.increff_sales
  - table.zs_observe.increff_returns
  future_context_gaps:
  - Increff returns processed requires explicit table context if separate from current returns table.
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.increff_sales
  - table.zs_observe.increff_returns
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  client_config_text: Delhivery | Settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.delhivery_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.delhivery_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  client_config_text: Ekart | Settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.ekart_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.ekart_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  client_config_text: DTDC | Settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.dtdc_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.dtdc_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  client_config_text: Xpressbees | Settlement
  canonical_or_supported_tables_now:
  - table.zs_observe.xpressbees_settlement
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.xpressbees_settlement
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  client_config_text: Shadowfax | Settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Shadowfax settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  client_config_text: Razorpay | razorpay_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.razorpay_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.razorpay_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  client_config_text: Paytm | paytm_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.paytm_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.paytm_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  client_config_text: Cashfree | cashfree_payin
  canonical_or_supported_tables_now:
  - table.zs_observe.cashfree_payin
  future_context_gaps: []
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now:
  - table.zs_observe.cashfree_payin
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  client_config_text: Easebuzz | easebuzz_settlement
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Easebuzz settlement context
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
- platform_account_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  client_config_text: Dedicated marketplace_transactions feed active in the client profile
  canonical_or_supported_tables_now: []
  future_context_gaps:
  - Generic marketplace_transactions table semantics
  mapping_policy: Map only to current supported table coverage. Preserve configured artifacts without table support as future_context_gaps.
  notes: []
  resolved_canonical_mapped_now: []
  unresolved_canonical_requested: []
  source_confirmed_requires_context: []
```

## 4. Candidate Edges

```yaml
candidate_edges:
- edge_id: edge.tanvi_fitness_private_limited.has_group.0ff348446239
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_card_id: tenant.tanvi_fitness_private_limited
  target_card_id: group.tanvi_fitness_private_limited.mensa_brands
  source_type: tenant
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_GROUP
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.d9e9f3ba7e36
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.6743ea801db0
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  target_card_id: platform.amazon
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.c9bf43196dc0
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  target_card_id: platform_context.amazon.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.cc3a5395ae34
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.d8efd2e11e36
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  target_card_id: platform.flipkart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.4273a303328e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  target_card_id: platform_context.flipkart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.2dc5abb44bb1
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.2aa7e302e0af
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: platform.myntra
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.8386a4155322
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: platform_context.myntra.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.1f9d515918af
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.bacfcfd44109
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: platform.meesho
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.36ab8370cdc4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: platform_context.meesho.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.a8fb92c7fcd9
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.3984f9bc4cc9
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: platform.nykaa
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.68a720cfc791
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: platform_context.nykaa_fashion.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.a70444cfbc2e
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.df8d0a1765df
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  target_card_id: platform.jiomart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.f2ce495b29e1
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  target_card_id: platform_context.jiomart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.9024cab3b6a8
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.b23e699dc323
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: platform.snapdeal
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.280e28c41bee
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: platform_context.snapdeal.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.c68154b8e287
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.8af8cd9561fe
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  target_card_id: platform.tatacliq
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.98b3f98950b1
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  target_card_id: platform_context.tatacliq.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.222394638bd4
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.d1f979280b6f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.5d94d92fa9b6
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.eb27290e31dd
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.3719e92f51a2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.5414ee741507
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_oms
  target_card_id: table.zs_observe.amazon_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.46485fc4180d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.a49fcf03dd4a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_settlement
  target_card_id: table.zs_observe.amazon_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.c5672af549e5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_disbursment
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.772da3aa21ac
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_disbursment
  target_card_id: table.zs_observe.amazon_disbursment
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.09f5a55c82af
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_fee_preview
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.feb1516d4d77
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_fee_preview
  target_card_id: table.zs_observe.amazon_fee_preview
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.61aa359a673f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.ce1f06f9edc5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.oms
  target_card_id: table.flipkart.oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.2a97660d9c2b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.cashback
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.dc80a57471cf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.cashback
  target_card_id: table.flipkart.cashback
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.f292762e461f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.ec07785fc21b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.settlement
  target_card_id: table.flipkart.settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.08cdb7afe282
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.commission
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.cd28f648e89b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.commission
  target_card_id: table.flipkart.commission
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.a1ac01f2d6db
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.196b882b9974
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms
  target_card_id: table.zs_observe.myntra_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.4a8b0b8bf415
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.5831b936fe92
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_settlement
  target_card_id: table.zs_observe.myntra_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.e327c4f818c6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_reverse
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.02f0882a05d7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_reverse
  target_card_id: table.zs_observe.myntra_reverse
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.86c67b7ee8b8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_non_order_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.84277b591d5b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_non_order_settlement
  target_card_id: table.zs_observe.myntra_non_order_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.099292fb4c88
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.19ffe6ae2b5a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms_settlement
  target_card_id: table.zs_observe.myntra_oms_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.cc88e746305f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.68a7a7438f73
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_sales
  target_card_id: table.zs_observe.meesho_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.d3e35502ba8f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.7291cfb44dad
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_settlement
  target_card_id: table.zs_observe.meesho_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.0eef67b43708
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.9319b30020bf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_returns
  target_card_id: table.zs_observe.meesho_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.83717586c6a8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.fd5580775dea
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse
  target_card_id: table.zs_observe.meesho_reverse
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.e0b18b07c082
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_forward_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.925b03b849cc
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_forward_expenses
  target_card_id: table.zs_observe.meesho_forward_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.d724e59d7524
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.f732661786c9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse_expenses
  target_card_id: table.zs_observe.meesho_reverse_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.cdf665958207
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_other_charges_expenses
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.2d9c8937bcff
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_other_charges_expenses
  target_card_id: table.zs_observe.meesho_other_charges_expenses
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.416b6628c765
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_brand_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.65341eeb29d7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_brand_mapping
  target_card_id: table.zs_observe.meesho_brand_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.52ab5df43e48
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.50b68d38d746
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_oms
  target_card_id: table.zs_observe.nykaa_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.6993c15fa261
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.a1673e40b7ff
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_settlement
  target_card_id: table.zs_observe.nykaa_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.8a9ee4186bab
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_addition_charge
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.c63381fc9ccf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_addition_charge
  target_card_id: table.zs_observe.nykaa_addition_charge
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.aae40bc9313e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapper_gst
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.55b43530c41a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapper_gst
  target_card_id: table.zs_observe.nykaa_mapper_gst
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.5a9634313f5b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapping
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.18fc8fae6c2e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapping
  target_card_id: table.zs_observe.nykaa_mapping
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.7b70c3cfb91a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.0f7a6d1f90fe
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_oms
  target_card_id: table.zs_observe.jiomart_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.28fc36555e5a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.ab469cdb7df9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_settlement
  target_card_id: table.zs_observe.jiomart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.02a82374c9bf
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.0f970305440d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_returns
  target_card_id: table.zs_observe.jiomart_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.7043a3217f65
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.b85081aa9eef
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_oms
  target_card_id: table.zs_observe.snapdeal_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.2ad3ebd811d0
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.ddd83c57b372
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_settlement
  target_card_id: table.zs_observe.snapdeal_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.6f574ea78bd6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_commission
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.4dacdad4e566
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_commission
  target_card_id: table.zs_observe.snapdeal_commission
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.50fb7fb6b7e9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_sales_return
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.25e5e7ffe806
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_sales_return
  target_card_id: table.zs_observe.snapdeal_sales_return
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.8b325163f2a8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_payments
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.9b27782a2e72
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_payments
  target_card_id: table.zs_observe.snapdeal_payments
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.1b574757078c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_non_order
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.1b5f00f36a02
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_non_order
  target_card_id: table.zs_observe.snapdeal_non_order
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.53569f5a1624
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.3772527d4a5b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_oms
  target_card_id: table.zs_observe.tatacliq_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.fc32f6ba7ac7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.5f4e63141d8b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_settlement
  target_card_id: table.zs_observe.tatacliq_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.c84051e1d319
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.33886707c78b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.7260d3c21d2a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.27eb2307352a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.c0ebd066a7ff
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.101aa61b8c94
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.6b3665e1e352
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.b4a852e870c8
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  target_card_id: platform.healthkart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.c94dd1987003
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  target_card_id: platform_context.healthkart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.b2f30d624bd7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.ae76b1c1ae6a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
  target_card_id: table.zs_observe.healthkart_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.11e4b1b8bf56
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.e649168952e5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
  target_card_id: table.zs_observe.healthkart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.12cf6a71af2b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.d3530fc6d46b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
  target_card_id: table.zs_observe.healthkart_return
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.e1c29fa70907
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.ff05cafd2734
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.2fe4a6d328d9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.36c10ac22b66
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.dc4dd4e4b844
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.74d429f3eaee
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.fc523bc945d3
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.fa4dc43922c2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  target_card_id: platform.shopify
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.bf6439fb9112
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  target_card_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.888c163ec380
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.511bc308bf23
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  target_card_id: platform.shiprocket
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.18703d3cf47e
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  target_card_id: platform_context.shiprocket.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.618ecc8f9b89
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.26dce750b917
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  target_card_id: platform.increff
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.5a71e9e29d48
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  target_card_id: platform_context.increff.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.1d5f6fc3bb6f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.1e0c4515c690
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
  target_card_id: table.zs_observe.shopify_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.25527cc22891
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.c1b6305c715f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
  target_card_id: table.zs_observe.shiprocket_oms
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.5daf61d83058
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.ac5577994c81
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
  target_card_id: table.zs_observe.increff_sales
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.d8574cf56039
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.b1dc3e4ebbe9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
  target_card_id: table.zs_observe.increff_returns
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.9061b979044a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.d59a724f5e40
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  target_card_id: platform.delhivery
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.26bb986311ac
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  target_card_id: platform_context.delhivery.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.9240a6fd1c7b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.delhivery_in.primary.delhivery_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.01da165cbda5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.delhivery_in.primary.delhivery_settlement
  target_card_id: table.zs_observe.delhivery_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.2f84c302e5ba
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.5b5d61fb87c6
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  target_card_id: platform.ekart
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.6b843008f4b0
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  target_card_id: platform_context.ekart.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.051ea1d304f6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.ekart_in.primary.ekart_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.d03ccf095327
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.ekart_in.primary.ekart_settlement
  target_card_id: table.zs_observe.ekart_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.16fa5a83a686
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.a8066effde3a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  target_card_id: platform.dtdc
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.46d6b2af0eaf
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  target_card_id: platform_context.dtdc.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.2d570aee0e11
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.dtdc_in.primary.dtdc_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.7d68cf4d3838
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.dtdc_in.primary.dtdc_settlement
  target_card_id: table.zs_observe.dtdc_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.4bca10ffb304
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.7881130478f2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  target_card_id: platform.xpressbees
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.124112c8f468
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  target_card_id: platform_context.xpressbees.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.cc9573e10dc1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.xpressbees_in.primary.xpressbees_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.9d37e5134261
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.xpressbees_in.primary.xpressbees_settlement
  target_card_id: table.zs_observe.xpressbees_settlement
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.58b7a27fad78
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.99cbf753c89f
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  target_card_id: platform.shadowfax
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.24ff6775125f
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  target_card_id: platform_context.shadowfax.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.c7a9e7d7aa2d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.65a2922d7399
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.0dcbbc13ba19
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  target_card_id: platform.razorpay
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.d50a50922454
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  target_card_id: platform_context.razorpay.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.d7b4d943bba6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.razorpay_in.primary.razorpay_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.d1689a5c30d8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.razorpay_in.primary.razorpay_payin
  target_card_id: table.zs_observe.razorpay_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.d3135a695572
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.3bdcf6733d95
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  target_card_id: platform.paytm
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.b2740857418d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  target_card_id: platform_context.paytm.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.c6f95df66db7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.paytm_in.primary.paytm_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.4e94bbc78fde
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.paytm_in.primary.paytm_payin
  target_card_id: table.zs_observe.paytm_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.62d8fae9e363
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_platform.4579ceee29ee
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  target_card_id: platform.cashfree
  source_type: platform_account
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM
- edge_id: edge.tanvi_fitness_private_limited.uses_platform_context.8f1c402d38f4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  target_card_id: platform_context.cashfree.in
  source_type: platform_account
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_PLATFORM_CONTEXT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.deec5cc55f78
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.cashfree_in.primary.cashfree_payin
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.binds_to_table.eb8fe7f9719e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_card_id: account_data_binding.tanvi_fitness_private_limited.cashfree_in.primary.cashfree_payin
  target_card_id: table.zs_observe.cashfree_payin
  source_type: account_data_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: BINDS_TO_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.a04adc89ea33
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.45f0d74f91d5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_platform_account.bc0fa005b836
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  source_type: group
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_account_data_binding.4fcbc4a9f446
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  target_card_id: account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
  source_type: platform_account
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.has_business_scope_set.96a3c3507631
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.91597ed4b1ef
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  target_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.70bd914bb11b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  target_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.f1324c10bc26
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  target_card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_business_scope_set.43c6233fc01b
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.b899b98a1234
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.be35a2c0bb8e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.db596c182a57
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.d5cfdaaa0037
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.4264bf3d2692
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.b0618b10b6aa
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.55dd0a3f33ae
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.97ca9d882405
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.0df8c92b4427
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  target_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_business_scope_set.ab6a66350dbf
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.c5f5fdf61481
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.12fdcfbdb053
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.71602a0cab17
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_business_scope_set.f67feac5aeb0
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.d458bc68a248
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  target_card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.668f86b3923b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  target_card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.4136eb6a564c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  target_card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.773424f8aa26
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  target_card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.9386d36e229e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  target_card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_business_scope_set.4778683969fd
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  source_type: group
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.1ec2b2b7a438
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  target_card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.63e73aed86f0
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  target_card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.cdc6c3080f31
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  target_card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.includes_platform_account.8d0d46279e96
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  target_card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  source_type: business_scope_set
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: INCLUDES_PLATFORM_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.has_business_flow_binding.bed2918d8057
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_business_scope_set.e7906cbf7ca8
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.c0226ce744f7
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.199071fb0d4f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.af60efd601b9
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.063bf9f30976
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.edc69434850e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.24204ca603b6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.012ccaec5d66
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.04ed2c95980b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.46206bfa6170
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.7740d44c53f5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.175f881ea498
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: table.zs_observe.healthkart_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.52aad19079c5
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: table.zs_observe.healthkart_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.e9432ce620c5
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.health_marketplace_reconciliation
  target_card_id: table.zs_observe.healthkart_return
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_business_flow_binding.0478e3271140
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_business_scope_set.86b0890a9534
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.37f060151b8f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.888268c2d0e1
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.bd8377bc4f7f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.49165f0d2351
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.d4a8b4325877
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.9fbde720314c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.3580f9a82ca2
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.a8f35d5e70ec
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.71680f5be61b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.23334ba5d2c8
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.f25b118d4bf4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.5feff0b9a4b2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.90c44a42792f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_disbursment
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.0aee1416473d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.amazon_in.primary.amazon_fee_preview
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.c068abd41607
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.a7366d760830
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.cashback
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.6f57a5d3d2f3
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.bc21b80ad678
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.flipkart_in.primary.commission
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.5f68984bf926
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.81049a8af017
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.025e62e8928a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_reverse
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.af5eff071fa6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_non_order_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.6c78fc4f5719
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.myntra_in.primary.myntra_oms_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.0cdb517cccfe
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.dd3d9bde10fc
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.91cafb75529c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.0b701ecb4599
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.255c4631a012
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_forward_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.ea0d70380d0d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_reverse_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.6088860aa25a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_other_charges_expenses
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.d86b62a86e1e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.meesho_in.primary.meesho_brand_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.ec9b19608454
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.db455d9df4e7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.eb24430f7184
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_addition_charge
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.ca779998a25f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapper_gst
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.1b0109eaa329
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.nykaa_in.primary.nykaa_mapping
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.32e29aa907c1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.b431cf4ddda9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.e2627d369fa9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.jiomart_in.primary.jiomart_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.f1492f492bfd
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.e63e82aa7178
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.893beba4119c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_commission
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.089d3101928b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_sales_return
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.5c5a8c30e752
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_payments
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.ca7b5887ee5d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.snapdeal_in.primary.snapdeal_non_order
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.f568ccd27649
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.8ce47e5a46fb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.tatacliq_in.primary.tatacliq_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.332d2134edf4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.274723b8204e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.f0b5ef32ac1e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.healthkart_in.primary.healthkart_return
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.762902538a0a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.7d371daee77f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.28b54007c873
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: table.zs_observe.increff_sales
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.32fcd91cd850
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_to_increff_operations
  target_card_id: table.zs_observe.increff_returns
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_business_flow_binding.6de587ac0531
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_business_scope_set.3348c2db8954
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: business_scope_set.tanvi_fitness_private_limited.payment_gateways
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.254f8e44320d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.de0cdff374c0
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.tanvi_fitness_private_limited.razorpay_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.0a884152b15f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.tanvi_fitness_private_limited.cashfree_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.6c33f8ec5e96
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.tanvi_fitness_private_limited.paytm_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.e7d5db4cfa97
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.d9fd0d6be6f1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.468779536011
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.tanvi_fitness_private_limited.razorpay_in.primary.razorpay_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.f8acd37d1177
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.tanvi_fitness_private_limited.cashfree_in.primary.cashfree_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.e941517ddd90
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.tanvi_fitness_private_limited.paytm_in.primary.paytm_payin
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.73fd02ffcdcb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.da744bee06fc
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.shopify_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.39afa4445480
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.razorpay_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.3c5288409158
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.cashfree_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.4bdfb3716291
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shopify_d2c_prepaid_to_pg
  target_card_id: table.zs_observe.paytm_payin
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_business_flow_binding.17395ea316ba
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_business_scope_set.c96b3e5bb91e
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.54880e139595
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.03f34aab260e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.6287e4b6f1cf
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.7ab0ca144e3f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_sales
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.9e1dc197c124
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: account_data_binding.tanvi_fitness_private_limited.increff_wms.primary.increff_returns
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.64e4b9c84c35
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: table.zs_observe.shiprocket_oms
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.2b2e6612b011
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: table.zs_observe.increff_sales
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.3e8043745d1b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.shiprocket_order_source_to_increff
  target_card_id: table.zs_observe.increff_returns
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_business_flow_binding.2b5fc529d2f8
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_business_scope_set.0d4e27588a89
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: business_scope_set.tanvi_fitness_private_limited.logistics_settlement
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.43a09d2a7f53
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.delhivery_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.062956157a17
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.ekart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.fa3ee5d6ed1a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.dtdc_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.e6de1c23cb47
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.xpressbees_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.5a5fe4af8b40
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: platform_account.tanvi_fitness_private_limited.shadowfax_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.6ba2cba4f4c3
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.delhivery_in.primary.delhivery_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.d18b07becaf7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.ekart_in.primary.ekart_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.693dc7a54bc2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.dtdc_in.primary.dtdc_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.73c528e590d9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.xpressbees_in.primary.xpressbees_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.0d1e1bfd470c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.96a41ffe9c0f
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: table.zs_observe.delhivery_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.b46a7a7febcf
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: table.zs_observe.ekart_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.362c915235f9
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: table.zs_observe.dtdc_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.uses_evidence_table.15703935dbe7
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.logistics_settlement_reconciliation
  target_card_id: table.zs_observe.xpressbees_settlement
  source_type: business_flow_binding
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_EVIDENCE_TABLE
- edge_id: edge.tanvi_fitness_private_limited.has_business_flow_binding.8f4bdf718668
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_card_id: group.tanvi_fitness_private_limited.mensa_brands
  target_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  source_type: group
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: HAS_BUSINESS_FLOW_BINDING
- edge_id: edge.tanvi_fitness_private_limited.uses_business_scope_set.479de02e82cb
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
  source_type: business_flow_binding
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_BUSINESS_SCOPE_SET
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.1411f50ff86b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.amazon_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.e8b9bc0d2eac
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.flipkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.655172c6b606
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.myntra_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.1119b7bd4747
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.meesho_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.7b429f7f4998
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.271ead6ce555
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.jiomart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.5dcb8e99b45e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.snapdeal_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.b4e46fb34dbc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.tatacliq_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.59b70beca0ef
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.participates_with_account.47f826581857
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  source_type: business_flow_binding
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: PARTICIPATES_WITH_ACCOUNT
- edge_id: edge.tanvi_fitness_private_limited.uses_account_data_binding.2d0c81742060
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  target_card_id: account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
  source_type: business_flow_binding
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  edge_properties:
    emitted_by: client_runtime_refactor_batch3
    source_json_edge_type: USES_ACCOUNT_DATA_BINDING
```

## 5. Blocked / Non-Materialized Edges

These edges were present or implied in the bad-state JSON but are intentionally not emitted because the referenced target/source is not available in the uploaded canonical registry after the approved remaps.

```yaml
blocked_edges:
- source_card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.cred
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.cred
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.cred_in.primary
    edge: USES_PLATFORM
    target: platform.cred
- source_card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.cred.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.cred.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.cred_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.cred.in
- source_card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.klip
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.klip
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.klip_in.primary
    edge: USES_PLATFORM
    target: platform.klip
- source_card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.klip.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.klip.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.klip_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.klip.in
- source_card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.blitz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.blitz
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.blitz_in.primary
    edge: USES_PLATFORM
    target: platform.blitz
- source_card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.blitz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.blitz.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.blitz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.blitz.in
- source_card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.snapmint
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.snapmint
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
    edge: USES_PLATFORM
    target: platform.snapmint
- source_card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.snapmint.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.snapmint.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.snapmint.in
- source_card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cred_sales
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cred_sales
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cred_sales
- source_card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cred_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cred_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cred_settlement
- source_card_id: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.cred_returns
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.cred_returns
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
    edge: BINDS_TO_TABLE
    target: table.zs_observe.cred_returns
- source_card_id: account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.klip_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.klip_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.klip_settlement
- source_card_id: account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.blitz_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.blitz_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.blitz_settlement
- source_card_id: account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.snapmint_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.snapmint_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.snapmint_settlement
- source_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.onemg
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.onemg
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    edge: USES_PLATFORM
    target: platform.onemg
- source_card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.onemg.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.onemg.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.onemg.in
- source_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.onemg_sales
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.onemg_sales
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
    edge: BINDS_TO_TABLE
    target: table.zs_observe.onemg_sales
- source_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.onemg_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.onemg_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.onemg_settlement
- source_card_id: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.onemg_returns
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.onemg_returns
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
    edge: BINDS_TO_TABLE
    target: table.zs_observe.onemg_returns
- source_card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.getsupp
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.getsupp
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
    edge: USES_PLATFORM
    target: platform.getsupp
- source_card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.getsupp.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.getsupp.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.getsupp.in
- source_card_id: account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.getsupp_oms_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.getsupp_oms_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.getsupp_oms_settlement
- source_card_id: account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.shadowfax_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.shadowfax_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.shadowfax_settlement
- source_card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.easebuzz
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.easebuzz
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
    edge: USES_PLATFORM
    target: platform.easebuzz
- source_card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.easebuzz.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.easebuzz.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.easebuzz.in
- source_card_id: account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.easebuzz_settlement
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.easebuzz_settlement
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
    edge: BINDS_TO_TABLE
    target: table.zs_observe.easebuzz_settlement
- source_card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  edge_type: USES_PLATFORM
  target_card_id: platform.marketplace_transactions
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform.marketplace_transactions
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
    edge: USES_PLATFORM
    target: platform.marketplace_transactions
- source_card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_card_id: platform_context.marketplace_transactions.in
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: platform_context.marketplace_transactions.in
  original_edge:
    source: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.marketplace_transactions.in
- source_card_id: account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
  edge_type: BINDS_TO_TABLE
  target_card_id: table.zs_observe.marketplace_transactions
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.marketplace_transactions
  original_edge:
    source: account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
    edge: BINDS_TO_TABLE
    target: table.zs_observe.marketplace_transactions
- source_card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  edge_type: USES_EVIDENCE_TABLE
  target_card_id: table.zs_observe.marketplace_transactions
  blocked_reason: unresolved_source_or_target_after_refactor
  missing_refs:
  - position: target
    id: table.zs_observe.marketplace_transactions
  original_edge:
    source: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
    edge: USES_EVIDENCE_TABLE
    target: table.zs_observe.marketplace_transactions
```

## 6. Future Context Gaps

```yaml
future_context_gaps:
- platform_or_area: cred_in
  artifacts:
  - cred_sales
  - cred_settlement
  - cred_returns
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Cred | Sales, Settlement, Returns, Transactions
  recommended_next_context: Add canonical Cred platform context markdown/table cards.
- platform_or_area: klip_in
  artifacts:
  - klip_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Klip | Settlement only
  recommended_next_context: Add canonical Klip settlement context markdown/table cards.
- platform_or_area: blitz_in
  artifacts:
  - blitz_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Blitz | Settlement only
  recommended_next_context: Add canonical Blitz settlement context markdown/table cards.
- platform_or_area: snapmint_in
  artifacts:
  - snapmint_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Snapmint | Settlement only
  recommended_next_context: Add canonical Snapmint settlement context markdown/table cards.
- platform_or_area: onemg_in
  artifacts:
  - onemg_sales
  - onemg_settlement
  - onemg_returns
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: OneMg | Sales, Settlement, Returns, Transactions
  recommended_next_context: Add canonical OneMg platform context markdown/table cards.
- platform_or_area: getsupp_in
  artifacts:
  - getsupp_oms_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: GetSupp | OMS Settlement (combined), Transactions
  recommended_next_context: Add canonical GetSupp platform context markdown/table cards.
- platform_or_area: shadowfax
  artifacts:
  - shadowfax_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Shadowfax | Settlement
  recommended_next_context: Add canonical Shadowfax logistics settlement markdown/table cards.
- platform_or_area: easebuzz
  artifacts:
  - easebuzz_settlement
  impact: Configured in client profile but not active-queryable from current platform context.
  source_text: Easebuzz | easebuzz_settlement
  recommended_next_context: Add canonical Easebuzz payment-gateway markdown/table cards.
- platform_or_area: marketplace_transactions
  artifacts:
  - marketplace_transactions
  impact: Client profile confirms a dedicated transactions feed, but platform-specific semantics are not available in current
    context.
  source_text: Dedicated marketplace_transactions feed
  recommended_next_context: Add platform-context table cards for marketplace_transactions and channel-specific matching rules.
- platform_or_area: bank_account
  artifacts:
  - bank statement destination
  impact: No bank account or bank statement binding supplied in Tanvi profile.
  source_text: No bank section provided in client profile.
  recommended_next_context: Add Tanvi bank account and Account Data Binding cards before activating bank-crossing flows.
- platform_or_area: table.zs_observe.marketplace_transactions
  missing_artifacts:
  - table.zs_observe.marketplace_transactions
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: medium
  affected_client_cards:
  - business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  generated_by_refactor: true
- platform_or_area: platform_context.blitz.in
  missing_artifacts:
  - platform_context.blitz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.blitz_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.cred.in
  missing_artifacts:
  - platform_context.cred.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.cred_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.easebuzz.in
  missing_artifacts:
  - platform_context.easebuzz.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.getsupp.in
  missing_artifacts:
  - platform_context.getsupp.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.klip.in
  missing_artifacts:
  - platform_context.klip.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.klip_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.marketplace_transactions.in
  missing_artifacts:
  - platform_context.marketplace_transactions.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- platform_or_area: platform_context.onemg.in
  missing_artifacts:
  - platform_context.onemg.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.onemg_in.primary
  generated_by_refactor: true
- platform_or_area: platform_context.snapmint.in
  missing_artifacts:
  - platform_context.snapmint.in
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  generated_by_refactor: true
- platform_or_area: platform.blitz
  missing_artifacts:
  - platform.blitz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.blitz_in.primary
  generated_by_refactor: true
- platform_or_area: platform.cred
  missing_artifacts:
  - platform.cred
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.cred_in.primary
  generated_by_refactor: true
- platform_or_area: platform.easebuzz
  missing_artifacts:
  - platform.easebuzz
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- platform_or_area: platform.getsupp
  missing_artifacts:
  - platform.getsupp
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  generated_by_refactor: true
- platform_or_area: platform.klip
  missing_artifacts:
  - platform.klip
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.klip_in.primary
  generated_by_refactor: true
- platform_or_area: platform.marketplace_transactions
  missing_artifacts:
  - platform.marketplace_transactions
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- platform_or_area: platform.onemg
  missing_artifacts:
  - platform.onemg
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.onemg_in.primary
  generated_by_refactor: true
- platform_or_area: platform.snapmint
  missing_artifacts:
  - platform.snapmint
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  generated_by_refactor: true
- platform_or_area: table.zs_observe.blitz_settlement
  missing_artifacts:
  - table.zs_observe.blitz_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.cred_returns
  missing_artifacts:
  - table.zs_observe.cred_returns
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
  generated_by_refactor: true
- platform_or_area: table.zs_observe.cred_sales
  missing_artifacts:
  - table.zs_observe.cred_sales
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
  generated_by_refactor: true
- platform_or_area: table.zs_observe.cred_settlement
  missing_artifacts:
  - table.zs_observe.cred_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.easebuzz_settlement
  missing_artifacts:
  - table.zs_observe.easebuzz_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.getsupp_oms_settlement
  missing_artifacts:
  - table.zs_observe.getsupp_oms_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.klip_settlement
  missing_artifacts:
  - table.zs_observe.klip_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.onemg_returns
  missing_artifacts:
  - table.zs_observe.onemg_returns
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  generated_by_refactor: true
- platform_or_area: table.zs_observe.onemg_sales
  missing_artifacts:
  - table.zs_observe.onemg_sales
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  generated_by_refactor: true
- platform_or_area: table.zs_observe.onemg_settlement
  missing_artifacts:
  - table.zs_observe.onemg_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.shadowfax_settlement
  missing_artifacts:
  - table.zs_observe.shadowfax_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  generated_by_refactor: true
- platform_or_area: table.zs_observe.snapmint_settlement
  missing_artifacts:
  - table.zs_observe.snapmint_settlement
  impact: Client source confirms usage, but a matching uploaded canonical card is unavailable after alias/remap normalization;
    production routing edges are blocked for this artifact only.
  required_action: author_or_map_canonical_platform_context_or_table_card_then_rebuild_client_runtime_pack
  severity: high
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
  generated_by_refactor: true
resolved_context_gaps: []
```

## 7. Review Items and Advisory Reference Gaps

```yaml
open_review_items:
- item: platform_account.tanvi_fitness_private_limited.healthkart_in.primary
  issue: HealthKart canonical context explicitly documents Tanvi Fitness / MYFITNESS group_level_id 26; active bindings are
    therefore allowed for HealthKart core tables.
  severity: low
  review_resolution_status: open
- item: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  issue: Easebuzz is configured in the client document, but no active canonical Easebuzz settlement context is available in
    the current platform library.
  severity: medium
  review_resolution_status: open
- item: table.zs_observe.marketplace_transactions
  issue: Referenced as evidence_table_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
  generated_by_refactor: true
- item: platform_context.blitz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.blitz_in.primary
  generated_by_refactor: true
- item: platform_context.cred.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.cred_in.primary
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- item: platform_context.getsupp.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  generated_by_refactor: true
- item: platform_context.klip.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.klip_in.primary
  generated_by_refactor: true
- item: platform_context.marketplace_transactions.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- item: platform_context.onemg.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.onemg_in.primary
  generated_by_refactor: true
- item: platform_context.snapmint.in
  issue: Referenced as platform_context_id by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  generated_by_refactor: true
- item: platform_context.easebuzz.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.tanvi_fitness_private_limited.payment_gateways
  generated_by_refactor: true
- item: platform_context.getsupp.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  generated_by_refactor: true
- item: platform_context.onemg.in
  issue: Referenced as platform_context_ids by 1 client card(s), but no matching uploaded canonical card exists after current
    remaps. It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  generated_by_refactor: true
- item: platform.blitz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.blitz_in.primary
  generated_by_refactor: true
- item: platform.cred
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.cred_in.primary
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
  generated_by_refactor: true
- item: platform.getsupp
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.getsupp_in.primary
  generated_by_refactor: true
- item: platform.klip
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.klip_in.primary
  generated_by_refactor: true
- item: platform.marketplace_transactions
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
  generated_by_refactor: true
- item: platform.onemg
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.onemg_in.primary
  generated_by_refactor: true
- item: platform.snapmint
  issue: Referenced as platform_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: false
  affected_client_cards:
  - platform_account.tanvi_fitness_private_limited.snapmint_in.primary
  generated_by_refactor: true
- item: platform.easebuzz
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.tanvi_fitness_private_limited.payment_gateways
  generated_by_refactor: true
- item: platform.getsupp
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  generated_by_refactor: true
- item: platform.onemg
  issue: Referenced as platform_ids by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: medium
  blocking_for_active_ingestion: false
  affected_client_cards:
  - business_scope_set.tanvi_fitness_private_limited.health_marketplaces
  generated_by_refactor: true
- item: table.zs_observe.blitz_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.blitz_in.primary.blitz_settlement
  generated_by_refactor: true
- item: table.zs_observe.cred_returns
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_returns
  generated_by_refactor: true
- item: table.zs_observe.cred_sales
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_sales
  generated_by_refactor: true
- item: table.zs_observe.cred_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.cred_in.primary.cred_settlement
  generated_by_refactor: true
- item: table.zs_observe.easebuzz_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.easebuzz_in.primary.easebuzz_settlement
  generated_by_refactor: true
- item: table.zs_observe.getsupp_oms_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.getsupp_in.primary.getsupp_oms_settlement
  generated_by_refactor: true
- item: table.zs_observe.klip_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.klip_in.primary.klip_settlement
  generated_by_refactor: true
- item: table.zs_observe.marketplace_transactions
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.marketplace_transactions.primary.marketplace_transactions
  generated_by_refactor: true
- item: table.zs_observe.onemg_returns
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_returns
  generated_by_refactor: true
- item: table.zs_observe.onemg_sales
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_sales
  generated_by_refactor: true
- item: table.zs_observe.onemg_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.onemg_in.primary.onemg_settlement
  generated_by_refactor: true
- item: table.zs_observe.shadowfax_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.shadowfax_in.primary.shadowfax_settlement
  generated_by_refactor: true
- item: table.zs_observe.snapmint_settlement
  issue: Referenced as table_id by 1 client card(s), but no matching uploaded canonical card exists after current remaps.
    It is retained as declared source context and no dangling edge is emitted.
  severity: high
  blocking_for_active_ingestion: true
  affected_client_cards:
  - account_data_binding.tanvi_fitness_private_limited.snapmint_in.primary.snapmint_settlement
  generated_by_refactor: true
resolved_review_items: []
non_blocking_declared_semantic_reference_gaps: []
```

## 8. Validation Summary

```yaml
validation_summary:
  result: pass
  original_card_count: 105
  refactored_card_count: 105
  original_edge_count: 369
  refactored_edge_count: 339
  blocked_edge_count: 30
  source_evidence_count: 33
  source_row_evidence_count: 25
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 28
    account_data_binding: 64
    business_scope_set: 5
    business_flow_binding: 6
  status_counts:
    active: 84
    review_required: 21
  review_status_counts:
    accepted: 84
    review_required: 21
  active_bindings_to_missing_tables: []
  edge_reference_error_count: 0
  edge_reference_errors: []
  status_active_conflicts: []
  forbidden_candidate_cards: []
  duplicate_card_id_count: 0
  old_shopify_source_docs_in_candidate_cards: []
  canonical_resolution_gap_count: 36
  canonical_resolution_gap_type_counts:
    platform_id: 8
    platform_context_id: 8
    table_id: 13
    platform_ids: 3
    platform_context_ids: 3
    evidence_table_ids: 1
  status_correction_count: 9
  status_changes:
  - card_id: platform_account.tanvi_fitness_private_limited.cred_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.klip_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.blitz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.snapmint_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.onemg_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.getsupp_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.easebuzz_in.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: platform_account.tanvi_fitness_private_limited.marketplace_transactions.primary
    card_type: platform_account
    from_status: active
    from_active: true
    to_status: review_required
    to_active: false
    reason: platform_or_context_missing_and_no_resolved_account_data_binding
  - card_id: business_flow_binding.tanvi_fitness_private_limited.marketplace_transactions_review
    card_type: business_flow_binding
    from_status: review_required
    from_active: false
    to_status: active
    to_active: true
    reason: normalized_status_active_consistency
  id_or_source_replacement_count: 10
  id_or_source_replacements:
  - card_id: platform_account.tanvi_fitness_private_limited.nykaa_in.primary
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: platform_account.tanvi_fitness_private_limited.shopify_d2c.primary
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: platform_account.tanvi_fitness_private_limited.shiprocket_order_source.primary
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: platform_account.tanvi_fitness_private_limited.increff_wms.primary
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  - card_id: account_data_binding.tanvi_fitness_private_limited.shopify_d2c.primary.shopify_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: account_data_binding.tanvi_fitness_private_limited.shiprocket_order_source.primary.shiprocket_oms
    kind: source_document_text
    from: shopify_d2c_oms.md
    to: shopify_d2c_oms_v2.md
  - card_id: business_scope_set.tanvi_fitness_private_limited.general_marketplaces_active
    kind: canonical_id
    from: platform_context.nykaa.in
    to: platform_context.nykaa_fashion.in
  - card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  - card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.shiprocket.in.oms_order_source
    to: platform_context.shiprocket.in
  - card_id: business_scope_set.tanvi_fitness_private_limited.d2c_and_operations
    kind: canonical_id
    from: platform_context.increff.in.wms_operations
    to: platform_context.increff.in
  resolved_prior_review_count: 0
  open_review_count: 38
  future_context_gap_count: 39
  resolved_context_gap_count: 0
  non_blocking_declared_semantic_reference_gap_count: 0
  non_blocking_declared_semantic_reference_gap_type_counts: {}
  edge_status_counts:
    emitted: 339
    blocked_unresolved: 30
```
