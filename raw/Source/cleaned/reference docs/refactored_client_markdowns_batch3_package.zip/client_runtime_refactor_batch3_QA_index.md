# Client Runtime Markdown Refactor — Batch 3 QA Index

This package contains parser-ready client runtime markdowns for MPL USA, Pine Labs, Prita Designs Private Limited, Rosenza International Trading L.L.C, and Tanvi Fitness Private Limited.

The refactor used the uploaded canonical marketplace/logistics/banking/payment/OMS/WMS markdowns, with `shopify_d2c_oms_v2.md` as the active Shopify source.

```yaml
batch_validation_summary:
  batch_id: client_runtime_refactor_batch3_v2_1
  generated_date: '2026-05-24'
  client_count: 5
  output_directory: /mnt/data/refactored_client_markdowns_batch3
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9918
  active_shopify_canonical: shopify_d2c_oms_v2.md
  total_cards: 312
  total_emitted_edges: 947
  total_blocked_edges: 120
  total_source_evidence: 133
  total_row_evidence: 101
  total_open_reviews: 178
  total_resolved_reviews: 0
  yaml_parse_error_count: 0
  active_bindings_to_missing_tables: 0
  edge_reference_error_count: 0
  status_active_conflict_count: 0
  forbidden_candidate_card_count: 0
  client_outputs:
  - client_slug: mpl_usa
    client_name: MPL USA
    output_markdown: mpl_usa_client_runtime_refactored.md
    cards: 16
    emitted_edges: 43
    blocked_edges: 14
    source_evidence: 8
    row_evidence: 5
    open_reviews: 24
    resolved_reviews: 0
    future_context_gaps: 14
    status_corrections: 3
    canonical_resolution_gaps: 29
    result: pass
  - client_slug: pine_labs
    client_name: Pine Labs
    output_markdown: pine_labs_client_runtime_refactored.md
    cards: 65
    emitted_edges: 165
    blocked_edges: 48
    source_evidence: 44
    row_evidence: 35
    open_reviews: 77
    resolved_reviews: 0
    future_context_gaps: 57
    status_corrections: 10
    canonical_resolution_gaps: 80
    result: pass
  - client_slug: prita_designs_private_limited
    client_name: Prita Designs Private Limited
    output_markdown: prita_designs_private_limited_client_runtime_refactored.md
    cards: 89
    emitted_edges: 273
    blocked_edges: 24
    source_evidence: 28
    row_evidence: 21
    open_reviews: 30
    resolved_reviews: 0
    future_context_gaps: 31
    status_corrections: 11
    canonical_resolution_gaps: 28
    result: pass
  - client_slug: rosenza_international_trading_llc
    client_name: Rosenza International Trading L.L.C
    output_markdown: rosenza_international_trading_llc_client_runtime_refactored.md
    cards: 37
    emitted_edges: 127
    blocked_edges: 4
    source_evidence: 20
    row_evidence: 15
    open_reviews: 9
    resolved_reviews: 0
    future_context_gaps: 4
    status_corrections: 2
    canonical_resolution_gaps: 4
    result: pass
  - client_slug: tanvi_fitness_private_limited
    client_name: Tanvi Fitness Private Limited
    output_markdown: tanvi_fitness_private_limited_client_runtime_refactored.md
    cards: 105
    emitted_edges: 339
    blocked_edges: 30
    source_evidence: 33
    row_evidence: 25
    open_reviews: 38
    resolved_reviews: 0
    future_context_gaps: 39
    status_corrections: 9
    canonical_resolution_gaps: 36
    result: pass
  yaml_parse_errors: []
```

## Output Files

- `mpl_usa_client_runtime_refactored.md` — 16 cards, 43 emitted edges, 14 blocked edges, result `pass`.
- `pine_labs_client_runtime_refactored.md` — 65 cards, 165 emitted edges, 48 blocked edges, result `pass`.
- `prita_designs_private_limited_client_runtime_refactored.md` — 89 cards, 273 emitted edges, 24 blocked edges, result `pass`.
- `rosenza_international_trading_llc_client_runtime_refactored.md` — 37 cards, 127 emitted edges, 4 blocked edges, result `pass`.
- `tanvi_fitness_private_limited_client_runtime_refactored.md` — 105 cards, 339 emitted edges, 30 blocked edges, result `pass`.
