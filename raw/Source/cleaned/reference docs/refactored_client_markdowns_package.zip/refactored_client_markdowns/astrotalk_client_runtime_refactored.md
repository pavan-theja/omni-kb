# AstroTalk — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the previously JSON-shaped client runtime pack into a card/edge/evidence registry and applies canonical-platform boundary fixes against the uploaded domain markdowns. It intentionally emits only client runtime binding cards; it does not recreate platform/domain/table/metric semantics already owned by canonical markdowns.

```yaml
document_metadata:
  package_id: astrotalk_business_hierarchy_runtime_cards_v1_0
  version: v1_0
  generated_date: '2026-05-24'
  created_for: AstroTalk
  client_slug: astrotalk
  status: ready_for_review
  source_documents:
  - AstroTalk.docx
  - shopify_d2c_oms_v2.md
  - Cognee KB Design v4.md
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - myntra_marketplace.md
  - payment_gateway.md
  - shiprocket_logistics_aggregator.md
  - unicommerce_d2c_oms.md
  source_client_profile:
    business: Diversified multi-vertical operation — e-commerce marketplaces + D2C + food/restaurant + services
    geography: India
    source_group_id: 60
    source_group_level_id: 221
    source_group_name: AstroTalk
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: 'Client/runtime packs contain business hierarchy cards: tenant, group, platform_account, account_data_binding,
    business_scope_set, and business_flow_binding. Active table bindings are emitted only when the current canonical platform
    context or explicit client-table evidence supports the table. Client-mentioned artifacts without current table support
    are preserved as future_context_gaps with source text; no table mapping is fabricated.'
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  refactor_version: client_runtime_markdown_refactor_v2_structured
  refactored_on: '2026-05-24'
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  canonical_source_policy: This client layer binds tenant/group/account/runtime scope to canonical cards from the uploaded
    platform/domain markdowns. It does not recreate platform/table/domain semantics.
  docx_source_title: AstroTalk
```

## 0. Parser Instructions and Refactor Manifest
```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM or USES_PLATFORM_CONTEXT if the target canonical platform/context card is absent.
  - Do not emit active BINDS_TO_TABLE edges for missing canonical table cards.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
```

```yaml
clean_refactor_manifest:
  source_json: astrotalk.json
  source_docx: AstroTalk.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9842
  corrections_applied:
  - Replaced Shopify OMS canonical source references with shopify_d2c_oms_v2.md per user correction.
  - 'Moved unresolved semantic mapping IDs to future gaps for platform_account.astrotalk.amazon_in.primary: [''table.zs_observe.amazon_sku_master'']'
  id_replacement_hits:
  - card_id: platform_account.astrotalk.shopify_d2c.primary
    field: platform_context_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  demoted_binding_ids:
  - account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  blocked_edge_count: 20
  canonical_resolution_gap_count: 9
```

## 1. Source Intake and Evidence Registry
```yaml
source_evidence:
  id: ev.astrotalk.docx.identity
  source_document: AstroTalk.docx
  source_section: 1. Identity
  evidence_type: docx_section
  summary: Client identity, business model, group identifiers, configured operational stack, and region/currency hints from
    the client DOCX.
  raw_lines:
  - '* Business: Diversified multi-vertical operation — e-commerce marketplaces + D2C + food/restaurant + services'
  - '* OMS/WMS: Unicommerce (marketplace order management), Shopify (D2C), Petpooja + Posist (restaurant/F&B POS)'
  - '* Logistics: Shiprocket, Shipway, Kwikship, Yolojet, Criticalog'
  - '* Payment gateways: Razorpay, GoKwik, Snapmint'
  - '* GROUP LEVEL ID : 221'
  - '* GROUP ID : 60'
  - '* CLEINT NAME : **AstroTalk**'
  - '* GROUP NAME : **AstroTalk**'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.2_active_sales_channels_e_commerce_marketplaces
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > E-commerce marketplaces
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels > E-commerce marketplaces.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, SKU master (lookup) |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads) |'
  - '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT
    + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.2_active_sales_channels_d2c
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > D2C
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels > D2C.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| Shopify | D2C OMS               |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.2_active_sales_channels_food_and_beverage_restaurant_pos
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > Food & beverage (restaurant POS)
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels > Food & beverage (restaurant POS).
  raw_lines:
  - '| System | Data types configured |'
  - '| Petpooja | OMS (order data)      |'
  - '| Posist | OMS (order data)      |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.2_active_sales_channels_services
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > Services
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels > Services.
  raw_lines:
  - '| System | Data types configured |'
  - '| Astrotalk | ODA (on-demand / order data) |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.3_oms_layer
  source_document: AstroTalk.docx
  source_section: 3. OMS layer
  evidence_type: docx_section
  summary: Client DOCX section covering 3. OMS layer.
  raw_lines:
  - '| System | Files configured |'
  - '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  - '| Amazon | SKU master (product/ASIN–SKU reference lookup) |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.4_logistics_courier_reconciliation
  source_document: AstroTalk.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: docx_section
  summary: Client DOCX section covering 4. Logistics — courier reconciliation.
  raw_lines:
  - '| Courier | Files configured |'
  - '| Shiprocket | Invoice + Settlement report |'
  - '| Shipway | Invoice + Settlement report |'
  - '| Kwikship | Invoice + Settlement |'
  - '| Yolojet | Invoice + Manual entry |'
  - '| Criticalog | Invoice only     |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.section.5_payment_gateway_reconciliation
  source_document: AstroTalk.docx
  source_section: 5. Payment gateway reconciliation
  evidence_type: docx_section
  summary: Client DOCX section covering 5. Payment gateway reconciliation.
  raw_lines:
  - '| Gateway | Pipeline target |'
  - '| Razorpay | razorpay_payin  |'
  - '| GoKwik  | gokwik_settlement |'
  - '| Snapmint | snapmint_settlement |'
  - '> GoKwik is a D2C checkout/COD verification platform — its settlement file covers COD remittance and RTO charges for
    the Shopify channel. Snapmint is a BNPL (buy-now-pay-later) provider; its settlement covers EMI disbursals.'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > E-commerce marketplaces
  evidence_type: configured_source_row
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Disbursement, SKU master (lookup)
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, SKU master (lookup) |'
  source_line_number_in_docx_text_extract: 15
  summary: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master (lookup)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > E-commerce marketplaces
  evidence_type: configured_source_row
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads) |'
  source_line_number_in_docx_text_extract: 16
  summary: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > E-commerce marketplaces
  evidence_type: configured_source_row
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
      (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses
  raw_text: '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
    (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses |'
  source_line_number_in_docx_text_extract: 17
  summary: 'Myntra: OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT
    + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > D2C
  evidence_type: configured_source_row
  row_key: Shopify
  columns:
    channel: Shopify
    data_types_configured: D2C OMS
  raw_text: '| Shopify | D2C OMS               |'
  source_line_number_in_docx_text_extract: 21
  summary: 'Shopify: D2C OMS'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > Food & beverage (restaurant POS)
  evidence_type: configured_source_row
  row_key: Petpooja
  columns:
    system: Petpooja
    data_types_configured: OMS (order data)
  raw_text: '| Petpooja | OMS (order data)      |'
  source_line_number_in_docx_text_extract: 25
  summary: 'Petpooja: OMS (order data)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > Food & beverage (restaurant POS)
  evidence_type: configured_source_row
  row_key: Posist
  columns:
    system: Posist
    data_types_configured: OMS (order data)
  raw_text: '| Posist | OMS (order data)      |'
  source_line_number_in_docx_text_extract: 26
  summary: 'Posist: OMS (order data)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  source_document: AstroTalk.docx
  source_section: 2. Active sales channels > Services
  evidence_type: configured_source_row
  row_key: Astrotalk
  columns:
    system: Astrotalk
    data_types_configured: ODA (on-demand / order data)
  raw_text: '| Astrotalk | ODA (on-demand / order data) |'
  source_line_number_in_docx_text_extract: 30
  summary: 'Astrotalk: ODA (on-demand / order data)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.3_oms_layer.unicommerce
  source_document: AstroTalk.docx
  source_section: 3. OMS layer
  evidence_type: configured_source_row
  row_key: Unicommerce
  columns:
    system: Unicommerce
    files_configured: Sales, Returns, Cancellations, Sales order report
  raw_text: '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  source_line_number_in_docx_text_extract: 34
  summary: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.3_oms_layer.amazon
  source_document: AstroTalk.docx
  source_section: 3. OMS layer
  evidence_type: configured_source_row
  row_key: Amazon
  columns:
    system: Amazon
    files_configured: SKU master (product/ASIN–SKU reference lookup)
  raw_text: '| Amazon | SKU master (product/ASIN–SKU reference lookup) |'
  source_line_number_in_docx_text_extract: 35
  summary: 'Amazon: SKU master (product/ASIN–SKU reference lookup)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  source_document: AstroTalk.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Shiprocket
  columns:
    courier: Shiprocket
    files_configured: Invoice + Settlement report
  raw_text: '| Shiprocket | Invoice + Settlement report |'
  source_line_number_in_docx_text_extract: 39
  summary: 'Shiprocket: Invoice + Settlement report'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  source_document: AstroTalk.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Shipway
  columns:
    courier: Shipway
    files_configured: Invoice + Settlement report
  raw_text: '| Shipway | Invoice + Settlement report |'
  source_line_number_in_docx_text_extract: 40
  summary: 'Shipway: Invoice + Settlement report'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  source_document: AstroTalk.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Kwikship
  columns:
    courier: Kwikship
    files_configured: Invoice + Settlement
  raw_text: '| Kwikship | Invoice + Settlement |'
  source_line_number_in_docx_text_extract: 41
  summary: 'Kwikship: Invoice + Settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  source_document: AstroTalk.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Yolojet
  columns:
    courier: Yolojet
    files_configured: Invoice + Manual entry
  raw_text: '| Yolojet | Invoice + Manual entry |'
  source_line_number_in_docx_text_extract: 42
  summary: 'Yolojet: Invoice + Manual entry'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
  source_document: AstroTalk.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Criticalog
  columns:
    courier: Criticalog
    files_configured: Invoice only
  raw_text: '| Criticalog | Invoice only     |'
  source_line_number_in_docx_text_extract: 43
  summary: 'Criticalog: Invoice only'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  source_document: AstroTalk.docx
  source_section: 5. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: Razorpay
  columns:
    gateway: Razorpay
    pipeline_target: razorpay_payin
  raw_text: '| Razorpay | razorpay_payin  |'
  source_line_number_in_docx_text_extract: 47
  summary: 'Razorpay: razorpay_payin'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  source_document: AstroTalk.docx
  source_section: 5. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: GoKwik
  columns:
    gateway: GoKwik
    pipeline_target: gokwik_settlement
  raw_text: '| GoKwik  | gokwik_settlement |'
  source_line_number_in_docx_text_extract: 48
  summary: 'GoKwik: gokwik_settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  source_document: AstroTalk.docx
  source_section: 5. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: Snapmint
  columns:
    gateway: Snapmint
    pipeline_target: snapmint_settlement
  raw_text: '| Snapmint | snapmint_settlement |'
  source_line_number_in_docx_text_extract: 49
  summary: 'Snapmint: snapmint_settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.astrotalk.docx.note.5_payment_gateway_reconciliation.001
  source_document: AstroTalk.docx
  source_section: 5. Payment gateway reconciliation
  evidence_type: source_note
  raw_text: GoKwik is a D2C checkout/COD verification platform — its settlement file covers COD remittance and RTO charges
    for the Shopify channel. Snapmint is a BNPL (buy-now-pay-later) provider; its settlement covers EMI disbursals.
  summary: GoKwik is a D2C checkout/COD verification platform — its settlement file covers COD remittance and RTO charges
    for the Shopify channel. Snapmint is a BNPL (buy-now-pay-later) provider; its settlement covers EMI disbursals.
  source_line_number_in_docx_text_extract: 50
  confidence: high
```

## 2. Client Runtime Candidate Cards
### 2.1 Tenant Cards
```yaml
candidate_card:
  card_type: tenant
  card_id: tenant.astrotalk
  name: AstroTalk
  fields:
    tenant_name: AstroTalk
    tenant_code: ASTROTALK
    description: Diversified commerce, D2C, food/POS, services, logistics, and payment gateway client using ZenStatement for
      marketplace, Shopify, Unicommerce, courier, gateway, and custom ODA reasoning.
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    evidence_refs:
    - ev.astrotalk.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.2 Group Cards
```yaml
candidate_card:
  card_type: group
  card_id: group.astrotalk.astrotalk
  name: AstroTalk
  fields:
    tenant_id: tenant.astrotalk
    group_name: AstroTalk
    group_code: ASTROTALK
    group_type: business_unit
    business_meaning: AstroTalk operating group covering marketplace, Shopify D2C, Unicommerce OMS, POS/restaurant systems,
      logistics, payment gateways, and Astrotalk ODA service evidence.
    country_or_region: India
    default_currency: INR
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    source_scope_identifiers:
      group_id: 60
      group_level_id: 221
      representation_rule: Use these only through Account Data Binding scope_keys.
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    evidence_refs:
    - ev.astrotalk.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.3 Platform Account Cards
```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.amazon_in.primary
  name: AstroTalk Amazon India Seller Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: AstroTalk Amazon India Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: amazon_marketplace.md
      platform_context_id_source_file: amazon_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.flipkart_in.primary
  name: AstroTalk Flipkart Seller Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: AstroTalk Flipkart Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: flipkart_marketplace.md
      platform_context_id_source_file: flipkart_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.myntra_in.primary
  name: AstroTalk Myntra Seller Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: AstroTalk Myntra Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
      expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: myntra_marketplace.md
      platform_context_id_source_file: myntra_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.shopify_d2c.primary
  name: AstroTalk Shopify D2C Store
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: AstroTalk Shopify D2C Store
    account_type: store_account
    account_role: d2c_order_source
    source_account_identifier: null
    source_config_text: 'Shopify: D2C OMS'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: shopify_d2c_oms_v2.md
      platform_context_id_source_file: shopify_d2c_oms_v2.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.unicommerce_oms.primary
  name: AstroTalk Unicommerce OMS Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.unicommerce
    platform_context_id: platform_context.unicommerce.in.d2c_oms
    account_name: AstroTalk Unicommerce OMS Account
    account_type: oms_account
    account_role: oms_source
    source_account_identifier: null
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: unicommerce_operations.md
      platform_context_id_source_file: unicommerce_d2c_oms.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.petpooja_pos.primary
  name: AstroTalk Petpooja POS Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.petpooja
    platform_context_id: platform_context.petpooja.in
    account_name: AstroTalk Petpooja POS Account
    account_type: pos_account
    account_role: restaurant_order_source
    source_account_identifier: null
    source_config_text: 'Petpooja: OMS order data'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.posist_pos.primary
  name: AstroTalk Posist POS Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.posist
    platform_context_id: platform_context.posist.in
    account_name: AstroTalk Posist POS Account
    account_type: pos_account
    account_role: restaurant_order_source
    source_account_identifier: null
    source_config_text: 'Posist: OMS order data'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.astrotalk_oda.primary
  name: AstroTalk ODA Service Reference Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.astrotalk_service
    platform_context_id: platform_context.astrotalk_service.in
    account_name: AstroTalk ODA Service Reference Account
    account_type: service_reference_account
    account_role: oda_lookup_source
    source_account_identifier: null
    source_config_text: 'Astrotalk: ODA on-demand/order data; Client Tables document defines astrotalk_oda logistics lookup.'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.shiprocket_in.primary
  name: AstroTalk Shiprocket Logistics Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.shiprocket
    platform_context_id: platform_context.shiprocket.in
    account_name: AstroTalk Shiprocket Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Shiprocket: Invoice + Settlement report'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: shiprocket_logistics_aggregator.md
      platform_context_id_source_file: shiprocket_logistics_aggregator.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.shipway_in.primary
  name: AstroTalk Shipway Logistics Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.shipway
    platform_context_id: platform_context.shipway.in
    account_name: AstroTalk Shipway Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Shipway: Invoice + Settlement report'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.kwikship_in.primary
  name: AstroTalk Kwikship Logistics Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.kwikship
    platform_context_id: platform_context.kwikship.in
    account_name: AstroTalk Kwikship Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Kwikship: Invoice + Settlement'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.yolojet_in.primary
  name: AstroTalk Yolojet Logistics Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.yolojet
    platform_context_id: platform_context.yolojet.in
    account_name: AstroTalk Yolojet Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Yolojet: Invoice + Manual entry; ODA lookup exists separately'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.criticalog_in.primary
  name: AstroTalk Criticalog Logistics Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.criticalog
    platform_context_id: platform_context.criticalog.in
    account_name: AstroTalk Criticalog Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Criticalog: Invoice only'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.razorpay_in.primary
  name: AstroTalk Razorpay Gateway Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: AstroTalk Razorpay Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'Razorpay: razorpay_payin'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: payment_gateway.md
      platform_context_id_source_file: payment_gateway.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.gokwik_in.primary
  name: AstroTalk GoKwik Gateway Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.gokwik
    platform_context_id: platform_context.gokwik.in
    account_name: AstroTalk GoKwik Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'GoKwik: gokwik_settlement; D2C checkout/COD verification; covers COD remittance and RTO charges'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.astrotalk.snapmint_in.primary
  name: AstroTalk Snapmint BNPL Account
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    platform_id: platform.snapmint
    platform_context_id: platform_context.snapmint.in
    account_name: AstroTalk Snapmint BNPL Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'Snapmint: snapmint_settlement; BNPL EMI disbursals'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

### 2.4 Account Data Binding Cards
```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.amazon_in.primary.amazon_oms
  name: account_data_binding.astrotalk.amazon_in.primary.amazon_oms
  fields:
    platform_account_id: platform_account.astrotalk.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
    notes:
    - Bind platform_account.astrotalk.amazon_in.primary to table.zs_observe.amazon_oms using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.amazon_in.primary.amazon_settlement
  name: account_data_binding.astrotalk.amazon_in.primary.amazon_settlement
  fields:
    platform_account_id: platform_account.astrotalk.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
    notes:
    - Bind platform_account.astrotalk.amazon_in.primary to table.zs_observe.amazon_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.amazon_in.primary.amazon_disbursment
  name: account_data_binding.astrotalk.amazon_in.primary.amazon_disbursment
  fields:
    platform_account_id: platform_account.astrotalk.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
    notes:
    - Bind platform_account.astrotalk.amazon_in.primary to table.zs_observe.amazon_disbursment using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - amazon_marketplace.md
    registry_notes:
    - Canonical source uses the spelling disbursment.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  name: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  fields:
    platform_account_id: platform_account.astrotalk.amazon_in.primary
    table_id: table.zs_observe.amazon_sku_master
    table_support_level: missing_uploaded_canonical_table_card
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
    notes:
    - Bind platform_account.astrotalk.amazon_in.primary to table.zs_observe.amazon_sku_master using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    - 'Demoted during refactor: table_id is not present as a candidate table card in the uploaded canonical markdown set,
      so this binding must not be used in active flow routing yet.'
    active: false
    status: draft
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
    canonical_table_resolution:
      table_id_status: missing_uploaded_canonical_table_card
      table_source_file: null
    blocked_from_active_binding: true
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.flipkart_in.primary.oms
  name: account_data_binding.astrotalk.flipkart_in.primary.oms
  fields:
    platform_account_id: platform_account.astrotalk.flipkart_in.primary
    table_id: table.flipkart.oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.astrotalk.flipkart_in.primary to table.flipkart.oms using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.flipkart_in.primary.cashback
  name: account_data_binding.astrotalk.flipkart_in.primary.cashback
  fields:
    platform_account_id: platform_account.astrotalk.flipkart_in.primary
    table_id: table.flipkart.cashback
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.astrotalk.flipkart_in.primary to table.flipkart.cashback using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.flipkart_in.primary.settlement
  name: account_data_binding.astrotalk.flipkart_in.primary.settlement
  fields:
    platform_account_id: platform_account.astrotalk.flipkart_in.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.astrotalk.flipkart_in.primary to table.flipkart.settlement using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.flipkart_in.primary.commission
  name: account_data_binding.astrotalk.flipkart_in.primary.commission
  fields:
    platform_account_id: platform_account.astrotalk.flipkart_in.primary
    table_id: table.flipkart.commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.astrotalk.flipkart_in.primary to table.flipkart.commission using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms
  name: account_data_binding.astrotalk.myntra_in.primary.myntra_oms
  fields:
    platform_account_id: platform_account.astrotalk.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
      expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
    notes:
    - Bind platform_account.astrotalk.myntra_in.primary to table.zs_observe.myntra_oms using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.myntra_in.primary.myntra_settlement
  name: account_data_binding.astrotalk.myntra_in.primary.myntra_settlement
  fields:
    platform_account_id: platform_account.astrotalk.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
      expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
    notes:
    - Bind platform_account.astrotalk.myntra_in.primary to table.zs_observe.myntra_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.myntra_in.primary.myntra_reverse
  name: account_data_binding.astrotalk.myntra_in.primary.myntra_reverse
  fields:
    platform_account_id: platform_account.astrotalk.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
      expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
    notes:
    - Bind platform_account.astrotalk.myntra_in.primary to table.zs_observe.myntra_reverse using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.myntra_in.primary.myntra_non_order_settlement
  name: account_data_binding.astrotalk.myntra_in.primary.myntra_non_order_settlement
  fields:
    platform_account_id: platform_account.astrotalk.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
      expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
    notes:
    - Bind platform_account.astrotalk.myntra_in.primary to table.zs_observe.myntra_non_order_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms_settlement
  name: account_data_binding.astrotalk.myntra_in.primary.myntra_oms_settlement
  fields:
    platform_account_id: platform_account.astrotalk.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
      expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
    notes:
    - Bind platform_account.astrotalk.myntra_in.primary to table.zs_observe.myntra_oms_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - myntra_marketplace.md
    registry_notes:
    - Partial reconciliation-helper table; bind only when explicit OMS-settlement diagnostics are needed.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
  name: account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
  fields:
    platform_account_id: platform_account.astrotalk.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Shopify: D2C OMS'
    notes:
    - Bind platform_account.astrotalk.shopify_d2c.primary to table.zs_observe.shopify_oms using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - shopify_d2c_oms_v2.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce
  name: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce
  fields:
    platform_account_id: platform_account.astrotalk.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    notes:
    - Bind platform_account.astrotalk.unicommerce_oms.primary to table.zs_observe.unicommerce using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.astrotalk.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce_order_sales_report
  name: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce_order_sales_report
  fields:
    platform_account_id: platform_account.astrotalk.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce_order_sales_report
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    notes:
    - Bind platform_account.astrotalk.unicommerce_oms.primary to table.zs_observe.unicommerce_order_sales_report using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.astrotalk.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.astrotalk_oda.primary.astrotalk_oda
  name: account_data_binding.astrotalk.astrotalk_oda.primary.astrotalk_oda
  fields:
    platform_account_id: platform_account.astrotalk.astrotalk_oda.primary
    table_id: table.zs_observe.astrotalk_oda
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: Astrotalk ODA service lookup from Client Tables - Shopify.md
    notes:
    - Bind platform_account.astrotalk.astrotalk_oda.primary to table.zs_observe.astrotalk_oda using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - shopify_d2c_oms_v2.md
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_invoice
  name: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_invoice
  fields:
    platform_account_id: platform_account.astrotalk.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_invoice
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Shiprocket: Invoice + Settlement report'
    notes:
    - Bind platform_account.astrotalk.shiprocket_in.primary to table.zs_observe.shiprocket_invoice using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - shiprocket_logistics_aggregator.md
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shiprocket_logistics_aggregator.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_settlement_report
  name: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_settlement_report
  fields:
    platform_account_id: platform_account.astrotalk.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_settlement_report
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Shiprocket: Invoice + Settlement report'
    notes:
    - Bind platform_account.astrotalk.shiprocket_in.primary to table.zs_observe.shiprocket_settlement_report using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - shiprocket_logistics_aggregator.md
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shiprocket_logistics_aggregator.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.astrotalk.razorpay_in.primary.razorpay_payin
  name: account_data_binding.astrotalk.razorpay_in.primary.razorpay_payin
  fields:
    platform_account_id: platform_account.astrotalk.razorpay_in.primary
    table_id: table.zs_observe.razorpay_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 60
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Razorpay: razorpay_payin'
    notes:
    - Bind platform_account.astrotalk.razorpay_in.primary to table.zs_observe.razorpay_payin using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - AstroTalk.docx
    - payment_gateway.md
    evidence_refs:
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: payment_gateway.md
```

### 2.5 Business Scope Set Cards
```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.astrotalk.ecommerce_marketplaces
  name: AstroTalk E-commerce Marketplace Accounts
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    scope_name: AstroTalk E-commerce Marketplace Accounts
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.astrotalk.amazon_in.primary
    - platform_account.astrotalk.flipkart_in.primary
    - platform_account.astrotalk.myntra_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    description: Marketplace accounts configured for Amazon, Flipkart, and Myntra.
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.astrotalk.shopify_d2c
  name: AstroTalk Shopify D2C
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    scope_name: AstroTalk Shopify D2C
    scope_type: single_account
    platform_account_ids:
    - platform_account.astrotalk.shopify_d2c.primary
    platform_ids:
    - platform.shopify
    platform_context_ids:
    - platform_context.shopify.in_and_global.d2c_oms_client_config
    description: Shopify D2C order source.
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.astrotalk.unicommerce_oms
  name: AstroTalk Unicommerce OMS
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    scope_name: AstroTalk Unicommerce OMS
    scope_type: single_account
    platform_account_ids:
    - platform_account.astrotalk.unicommerce_oms.primary
    platform_ids:
    - platform.unicommerce
    platform_context_ids:
    - platform_context.unicommerce.in.d2c_oms
    description: Unicommerce OMS/order/shipment reporting scope.
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.astrotalk.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.astrotalk.logistics_reconciliation
  name: AstroTalk Logistics Reconciliation Scope
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    scope_name: AstroTalk Logistics Reconciliation Scope
    scope_type: logistics_scope
    platform_account_ids:
    - platform_account.astrotalk.shiprocket_in.primary
    - platform_account.astrotalk.shipway_in.primary
    - platform_account.astrotalk.kwikship_in.primary
    - platform_account.astrotalk.yolojet_in.primary
    - platform_account.astrotalk.criticalog_in.primary
    platform_ids:
    - platform.shiprocket
    - platform.shipway
    - platform.kwikship
    - platform.yolojet
    - platform.criticalog
    platform_context_ids:
    - platform_context.shiprocket.in
    - platform_context.shipway.in
    - platform_context.kwikship.in
    - platform_context.yolojet.in
    - platform_context.criticalog.in
    description: Courier sources including Shiprocket plus platform-context gaps for Shipway/Kwikship/Yolojet/Criticalog.
    active: true
    status: draft
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.astrotalk.payment_gateways
  name: AstroTalk Payment Gateway Scope
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    scope_name: AstroTalk Payment Gateway Scope
    scope_type: payment_gateway_scope
    platform_account_ids:
    - platform_account.astrotalk.razorpay_in.primary
    - platform_account.astrotalk.gokwik_in.primary
    - platform_account.astrotalk.snapmint_in.primary
    platform_ids:
    - platform.razorpay
    - platform.gokwik
    - platform.snapmint
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.gokwik.in
    - platform_context.snapmint.in
    description: Payment gateway scope with active Razorpay and context gaps for GoKwik/Snapmint.
    active: true
    status: draft
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.astrotalk.pos_services_future_context
  name: AstroTalk POS and Service Future Context
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    scope_name: AstroTalk POS and Service Future Context
    scope_type: custom_source_scope
    platform_account_ids:
    - platform_account.astrotalk.petpooja_pos.primary
    - platform_account.astrotalk.posist_pos.primary
    - platform_account.astrotalk.astrotalk_oda.primary
    platform_ids:
    - platform.petpooja
    - platform.posist
    - platform.astrotalk_service
    platform_context_ids:
    - platform_context.petpooja.in
    - platform_context.posist.in
    - platform_context.astrotalk_service.in
    description: POS/restaurant and Astrotalk service data. ODA lookup is bound; POS order tables need context.
    active: true
    status: draft
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
    - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
    - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

### 2.6 Business Flow Binding Cards
```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  name: AstroTalk Marketplace to Unicommerce Operations
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    binding_name: AstroTalk Marketplace to Unicommerce Operations
    binding_type: operational_flow
    business_scope_set_id: business_scope_set.astrotalk.unicommerce_oms
    money_flow_paths:
    - marketplace_to_oms_operations
    - order_to_shipment
    participating_accounts:
    - platform_account_id: platform_account.astrotalk.amazon_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.astrotalk.flipkart_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.astrotalk.myntra_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.astrotalk.unicommerce_oms.primary
      role: oms_operations_source
      required: true
    evidence_table_ids:
    - table.zs_observe.unicommerce
    - table.zs_observe.unicommerce_order_sales_report
    account_data_binding_ids:
    - account_data_binding.astrotalk.amazon_in.primary.amazon_oms
    - account_data_binding.astrotalk.amazon_in.primary.amazon_settlement
    - account_data_binding.astrotalk.amazon_in.primary.amazon_disbursment
    - account_data_binding.astrotalk.flipkart_in.primary.oms
    - account_data_binding.astrotalk.flipkart_in.primary.cashback
    - account_data_binding.astrotalk.flipkart_in.primary.settlement
    - account_data_binding.astrotalk.flipkart_in.primary.commission
    - account_data_binding.astrotalk.myntra_in.primary.myntra_oms
    - account_data_binding.astrotalk.myntra_in.primary.myntra_settlement
    - account_data_binding.astrotalk.myntra_in.primary.myntra_reverse
    - account_data_binding.astrotalk.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.astrotalk.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce
    - account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce_order_sales_report
    business_process_ids:
    - business_process.order_to_shipment_flow
    reconciliation_profile_ids:
    - reconciliation_profile.order_to_shipment
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    - Refactor moved unsupported bindings into pending_account_data_binding_ids so active flow routing has no missing table
      dependency.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
    - ev.astrotalk.docx.row.3_oms_layer.amazon
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
    - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
    - ev.astrotalk.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    pending_account_data_binding_ids:
    - account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  name: AstroTalk Shopify D2C Prepaid to Razorpay
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    binding_name: AstroTalk Shopify D2C Prepaid to Razorpay
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.astrotalk.shopify_d2c
    money_flow_paths:
    - ecommerce_store_to_payment_gateway
    - payment_gateway_settlement
    participating_accounts:
    - platform_account_id: platform_account.astrotalk.shopify_d2c.primary
      role: store_order_source
      required: true
    - platform_account_id: platform_account.astrotalk.razorpay_in.primary
      role: payment_source
      required: true
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.razorpay_payin
    account_data_binding_ids:
    - account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
    - account_data_binding.astrotalk.razorpay_in.primary.razorpay_payin
    business_process_ids:
    - business_process.payment_capture_to_gateway_settlement
    reconciliation_profile_ids:
    - reconciliation_profile.oms_payment_to_gateway_settlement
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.astrotalk.shopify_cod_bnpl_future_context
  name: AstroTalk Shopify GoKwik/Snapmint Context Required
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    binding_name: AstroTalk Shopify GoKwik/Snapmint Context Required
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.astrotalk.payment_gateways
    money_flow_paths:
    - d2c_cod_remittance
    - bnpl_disbursal_reconciliation
    participating_accounts:
    - platform_account_id: platform_account.astrotalk.shopify_d2c.primary
      role: store_order_source
      required: true
    - platform_account_id: platform_account.astrotalk.gokwik_in.primary
      role: cod_checkout_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.snapmint_in.primary
      role: bnpl_settlement_source
      required: false
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: source_confirmed_context_missing
    active: false
    status: draft
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes:
    - GoKwik and Snapmint are configured, but canonical table cards are not available in the current platform registry.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  name: AstroTalk Shopify to Shiprocket Logistics
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    binding_name: AstroTalk Shopify to Shiprocket Logistics
    binding_type: fulfilment_flow
    business_scope_set_id: business_scope_set.astrotalk.logistics_reconciliation
    money_flow_paths:
    - order_to_shipment
    - shipment_to_freight_invoice
    participating_accounts:
    - platform_account_id: platform_account.astrotalk.shopify_d2c.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.astrotalk.shiprocket_in.primary
      role: logistics_source
      required: true
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.shiprocket_invoice
    - table.zs_observe.shiprocket_settlement_report
    account_data_binding_ids:
    - account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
    - account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_invoice
    - account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_settlement_report
    business_process_ids:
    - business_process.order_to_shipment_flow
    reconciliation_profile_ids:
    - reconciliation_profile.shipment_to_freight_invoice
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  name: AstroTalk Yolojet ODA Lookup Enrichment
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    binding_name: AstroTalk Yolojet ODA Lookup Enrichment
    binding_type: reference_enrichment_flow
    business_scope_set_id: business_scope_set.astrotalk.pos_services_future_context
    money_flow_paths:
    - logistics_oda_fee_enrichment
    participating_accounts:
    - platform_account_id: platform_account.astrotalk.astrotalk_oda.primary
      role: oda_lookup_source
      required: true
    - platform_account_id: platform_account.astrotalk.yolojet_in.primary
      role: logistics_partner_context
      required: false
    evidence_table_ids:
    - table.zs_observe.astrotalk_oda
    account_data_binding_ids:
    - account_data_binding.astrotalk.astrotalk_oda.primary.astrotalk_oda
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes:
    - ODA table is a lookup/reference asset for logistics surcharge reasoning. Yolojet invoice/manual-entry evidence remains
      unavailable for active binding.
    evidence_refs:
    - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
    - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  name: AstroTalk Bank-Crossing Flows Require Bank Binding
  fields:
    tenant_id: tenant.astrotalk
    group_id: group.astrotalk.astrotalk
    binding_name: AstroTalk Bank-Crossing Flows Require Bank Binding
    binding_type: money_flow
    business_scope_set_id: business_scope_set.astrotalk.payment_gateways
    money_flow_paths:
    - payment_gateway_to_bank
    - logistics_cod_to_bank
    participating_accounts:
    - platform_account_id: platform_account.astrotalk.razorpay_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.gokwik_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.snapmint_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.shiprocket_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.shipway_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.kwikship_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.yolojet_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.astrotalk.criticalog_in.primary
      role: settlement_or_remittance_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: inferred
    active: false
    status: draft
    source_documents:
    - AstroTalk.docx
    - Cognee KB Design v4.md
    notes:
    - No bank account or bank-statement binding was supplied.
    evidence_refs:
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
    - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
    - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

## 3. Semantic Mappings
```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.amazon_in.primary
  client_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
  canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  future_platform_context_gaps:
  - table.zs_observe.amazon_sku_master
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
  refactor_note: Unresolved canonical IDs were moved from canonical_mapped_now to future_platform_context_gaps.
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.flipkart_in.primary
  client_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  canonical_mapped_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  future_platform_context_gaps:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.myntra_in.primary
  client_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order
    expenses, Returns/RTO, JIT GSTR return, VHS + VFS expenses'
  canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  future_platform_context_gaps:
  - Myntra seller reports
  - Myntra non-order expenses detail
  - Myntra JIT GSTR return
  - Myntra VHS expenses
  - Myntra VFS expenses
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.shopify_d2c.primary
  client_config_text: 'Shopify: D2C OMS'
  canonical_mapped_now:
  - table.zs_observe.shopify_oms
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.unicommerce_oms.primary
  client_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
  canonical_mapped_now:
  - table.zs_observe.unicommerce
  - table.zs_observe.unicommerce_order_sales_report
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.petpooja_pos.primary
  client_config_text: 'Petpooja: OMS order data'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - 'Petpooja: OMS order data'
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.posist_pos.primary
  client_config_text: 'Posist: OMS order data'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - 'Posist: OMS order data'
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.astrotalk_oda.primary
  client_config_text: 'Astrotalk: ODA on-demand/order data'
  canonical_mapped_now:
  - table.zs_observe.astrotalk_oda
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.shiprocket_in.primary
  client_config_text: 'Shiprocket: Invoice + Settlement report'
  canonical_mapped_now:
  - table.zs_observe.shiprocket_invoice
  - table.zs_observe.shiprocket_settlement_report
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.shipway_in.primary
  client_config_text: 'Shipway: Invoice + Settlement report'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Shipway invoice
  - Shipway settlement report
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.kwikship_in.primary
  client_config_text: 'Kwikship: Invoice + Settlement'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Kwikship invoice
  - Kwikship settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.yolojet_in.primary
  client_config_text: 'Yolojet: Invoice + Manual entry; ODA lookup exists separately'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Yolojet invoice
  - Yolojet manual entry settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.criticalog_in.primary
  client_config_text: 'Criticalog: Invoice only'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Criticalog invoice
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.razorpay_in.primary
  client_config_text: 'Razorpay: razorpay_payin'
  canonical_mapped_now:
  - table.zs_observe.razorpay_payin
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.gokwik_in.primary
  client_config_text: 'GoKwik: gokwik_settlement; D2C checkout/COD verification; covers COD remittance and RTO charges'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - GoKwik settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.astrotalk.snapmint_in.primary
  client_config_text: 'Snapmint: snapmint_settlement; BNPL EMI disbursals'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Snapmint settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

## 4. Future Context Gaps
```yaml
future_context_gap:
  platform_or_area: AstroTalk Flipkart Seller Account
  missing_artifacts:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Myntra Seller Account
  missing_artifacts:
  - Myntra seller reports
  - Myntra non-order expenses detail
  - Myntra JIT GSTR return
  - Myntra VHS expenses
  - Myntra VFS expenses
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Myntra: OMS (JIT + PPMP), Seller reports Fwd/Rev, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
    Returns/RTO, JIT GSTR return, VHS + VFS expenses'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Petpooja POS Account
  missing_artifacts:
  - 'Petpooja: OMS order data'
  impact: Restaurant/POS OMS data cannot be actively bound until platform/table context is authored.
  source_text: 'Petpooja: OMS order data'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Posist POS Account
  missing_artifacts:
  - 'Posist: OMS order data'
  impact: Restaurant/POS OMS data cannot be actively bound until platform/table context is authored.
  source_text: 'Posist: OMS order data'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Shipway Logistics Account
  missing_artifacts:
  - Shipway invoice
  - Shipway settlement report
  impact: Courier reconciliation cannot be actively bound until platform/table context is authored.
  source_text: 'Shipway: Invoice + Settlement report'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Kwikship Logistics Account
  missing_artifacts:
  - Kwikship invoice
  - Kwikship settlement
  impact: Courier reconciliation cannot be actively bound until platform/table context is authored.
  source_text: 'Kwikship: Invoice + Settlement'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Yolojet Logistics Account
  missing_artifacts:
  - Yolojet invoice
  - Yolojet manual entry settlement
  impact: Courier reconciliation cannot be actively bound until platform/table context is authored.
  source_text: 'Yolojet: Invoice + Manual entry; ODA lookup exists separately'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Criticalog Logistics Account
  missing_artifacts:
  - Criticalog invoice
  impact: Courier reconciliation cannot be actively bound until platform/table context is authored.
  source_text: 'Criticalog: Invoice only'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk GoKwik Gateway Account
  missing_artifacts:
  - GoKwik settlement
  impact: Gateway settlement cannot be actively bound until platform/table context is authored.
  source_text: 'GoKwik: gokwik_settlement; D2C checkout/COD verification; covers COD remittance and RTO charges'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AstroTalk Snapmint BNPL Account
  missing_artifacts:
  - Snapmint settlement
  impact: Gateway settlement cannot be actively bound until platform/table context is authored.
  source_text: 'Snapmint: snapmint_settlement; BNPL EMI disbursals'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  gap_type: missing_uploaded_canonical_table_card
  platform_or_area: AstroTalk table.zs_observe.amazon_sku_master
  missing_artifacts:
  - table.zs_observe.amazon_sku_master
  impact: Client DOCX mentions this artifact, but the uploaded canonical markdown set does not currently expose the table
    as a queryable table card. Binding has been demoted to draft and excluded from active business flows.
  source_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, SKU master lookup'
  required_next_context: Author or confirm the canonical table card and source schema before creating an active Account Data
    Binding.
```

## 5. Canonical Resolution Gaps
```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.petpooja_pos.primary
  source_config_text: 'Petpooja: OMS order data'
  missing_or_unresolved_refs:
  - platform.petpooja
  - platform_context.petpooja.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.posist_pos.primary
  source_config_text: 'Posist: OMS order data'
  missing_or_unresolved_refs:
  - platform.posist
  - platform_context.posist.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.astrotalk_oda.primary
  source_config_text: 'Astrotalk: ODA on-demand/order data; Client Tables document defines astrotalk_oda logistics lookup.'
  missing_or_unresolved_refs:
  - platform.astrotalk_service
  - platform_context.astrotalk_service.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.shipway_in.primary
  source_config_text: 'Shipway: Invoice + Settlement report'
  missing_or_unresolved_refs:
  - platform.shipway
  - platform_context.shipway.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.kwikship_in.primary
  source_config_text: 'Kwikship: Invoice + Settlement'
  missing_or_unresolved_refs:
  - platform.kwikship
  - platform_context.kwikship.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.yolojet_in.primary
  source_config_text: 'Yolojet: Invoice + Manual entry; ODA lookup exists separately'
  missing_or_unresolved_refs:
  - platform.yolojet
  - platform_context.yolojet.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.criticalog_in.primary
  source_config_text: 'Criticalog: Invoice only'
  missing_or_unresolved_refs:
  - platform.criticalog
  - platform_context.criticalog.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.gokwik_in.primary
  source_config_text: 'GoKwik: gokwik_settlement; D2C checkout/COD verification; covers COD remittance and RTO charges'
  missing_or_unresolved_refs:
  - platform.gokwik
  - platform_context.gokwik.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.astrotalk.snapmint_in.primary
  source_config_text: 'Snapmint: snapmint_settlement; BNPL EMI disbursals'
  missing_or_unresolved_refs:
  - platform.snapmint
  - platform_context.snapmint.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

## 6. Candidate Edge Registry
```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0001.cae84cce12e2
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_id: tenant.astrotalk
  source_type: tenant
  target_id: group.astrotalk.astrotalk
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0002.89e0497c70b6
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0003.3dcd9f12349d
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.amazon_in.primary
  source_type: platform_account
  target_id: platform.amazon
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0004.97e52406a551
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.amazon_in.primary
  source_type: platform_account
  target_id: platform_context.amazon.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0005.888d9a1bbeaf
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0006.9792faf9fe8a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.amazon_in.primary.amazon_oms
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0007.8fbfbac6ed36
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0008.dfad8552d3d8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.amazon_in.primary.amazon_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0009.6ea9d00cca15
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0010.0599d481c52d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.amazon_in.primary.amazon_disbursment
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_disbursment
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0011.b673ca81a801
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0012.ab7dc1851b2f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0013.9d7580b1c019
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.flipkart_in.primary
  source_type: platform_account
  target_id: platform.flipkart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0014.097e58190974
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.flipkart_in.primary
  source_type: platform_account
  target_id: platform_context.flipkart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0015.e9c54631c2ee
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0016.46dacb4a87dd
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.flipkart_in.primary.oms
  source_type: account_data_binding
  target_id: table.flipkart.oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0017.6250b3cb31d1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0018.6e6cc0005f04
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.flipkart_in.primary.cashback
  source_type: account_data_binding
  target_id: table.flipkart.cashback
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0019.91deccac5ba2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0020.2675531c8996
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.flipkart_in.primary.settlement
  source_type: account_data_binding
  target_id: table.flipkart.settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0021.6b1b6a01cf54
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0022.e4300ca417b5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.flipkart_in.primary.commission
  source_type: account_data_binding
  target_id: table.flipkart.commission
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0023.e0ce3c3dd88a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0024.3cbcf629eabf
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: platform.myntra
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0025.f1e0b56a3dd2
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: platform_context.myntra.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0026.76ae7ebc6892
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0027.9ded43750586
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0028.aaa40c27d7fa
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0029.ee0d9c56aff1
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.myntra_in.primary.myntra_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0030.ef91f2221c22
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0031.c41f97e30c7b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.myntra_in.primary.myntra_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0032.26af92fc3d6c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0033.1b406b2207fd
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.myntra_in.primary.myntra_non_order_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_non_order_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0034.a15d3ce8cdb5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0035.1414fa52a953
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0036.c3ba28b34c4d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0037.9d88c15d4a60
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.shopify_d2c.primary
  source_type: platform_account
  target_id: platform.shopify
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0038.6f959e958edd
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.shopify_d2c.primary
  source_type: platform_account
  target_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0039.459485e83988
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.shopify_d2c.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0040.6dab7a212de3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
  source_type: account_data_binding
  target_id: table.zs_observe.shopify_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0041.2831293f25aa
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0042.96fcab6fa120
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform.unicommerce
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0043.50a924dee2c9
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform_context.unicommerce.in.d2c_oms
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0044.8c40b48dce42
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0045.5f1499b3b122
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0046.f05822dbed0d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0047.52ccdc1dbb51
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce_order_sales_report
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0048.424c16c98d1d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.petpooja_pos.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0049.67cc1825f48c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.posist_pos.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0050.480b5c675cf9
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.astrotalk_oda.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0051.9fb07e6b18d0
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.astrotalk_oda.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.astrotalk_oda.primary.astrotalk_oda
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0052.801a79497250
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.astrotalk_oda.primary.astrotalk_oda
  source_type: account_data_binding
  target_id: table.zs_observe.astrotalk_oda
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0053.2bf3ae2c8b0a
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0054.badde14a4443
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.shiprocket_in.primary
  source_type: platform_account
  target_id: platform.shiprocket
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0055.6e1e774a8df7
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.shiprocket_in.primary
  source_type: platform_account
  target_id: platform_context.shiprocket.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0056.9729f91ae049
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.shiprocket_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0057.67f11097970f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_invoice
  source_type: account_data_binding
  target_id: table.zs_observe.shiprocket_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0058.0dbfd58fe244
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.shiprocket_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_settlement_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0059.afd318860b8c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_settlement_report
  source_type: account_data_binding
  target_id: table.zs_observe.shiprocket_settlement_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0060.989db9549fc9
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.shipway_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0061.a270fc93a63c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.kwikship_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0062.a5989fe9c8e2
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.yolojet_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0063.558e2adeebb2
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.criticalog_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0064.20361bbaa24b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0065.ef6d7ae4e467
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.astrotalk.razorpay_in.primary
  source_type: platform_account
  target_id: platform.razorpay
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0066.25dec2c8cdd3
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.astrotalk.razorpay_in.primary
  source_type: platform_account
  target_id: platform_context.razorpay.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0067.591734536061
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.astrotalk.razorpay_in.primary
  source_type: platform_account
  target_id: account_data_binding.astrotalk.razorpay_in.primary.razorpay_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0068.b76d7e95ec22
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.astrotalk.razorpay_in.primary.razorpay_payin
  source_type: account_data_binding
  target_id: table.zs_observe.razorpay_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0069.06aed975937d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.gokwik_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0070.2c78beb1b144
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: platform_account.astrotalk.snapmint_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0071.557734c73295
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_scope_set.astrotalk.ecommerce_marketplaces
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0072.aa25d8d27051
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.ecommerce_marketplaces
  source_type: business_scope_set
  target_id: platform_account.astrotalk.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0073.21ecfc60c88b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.ecommerce_marketplaces
  source_type: business_scope_set
  target_id: platform_account.astrotalk.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0074.72931fb2582f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.ecommerce_marketplaces
  source_type: business_scope_set
  target_id: platform_account.astrotalk.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0075.9dab75843be6
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_scope_set.astrotalk.shopify_d2c
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0076.30876d843665
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.shopify_d2c
  source_type: business_scope_set
  target_id: platform_account.astrotalk.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0077.1355f8831dba
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_scope_set.astrotalk.unicommerce_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0078.4d33f68f6eec
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.unicommerce_oms
  source_type: business_scope_set
  target_id: platform_account.astrotalk.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0079.d1cc5236fe80
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_scope_set.astrotalk.logistics_reconciliation
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0080.75c9d7df16b6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.astrotalk.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0081.ca24c32c5a42
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.astrotalk.shipway_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0082.5281f3c001a0
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.astrotalk.kwikship_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0083.bea3d6e29968
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.astrotalk.yolojet_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0084.0486edcbb752
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.astrotalk.criticalog_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0085.f5f906dd61e9
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_scope_set.astrotalk.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0086.1199274fedf8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.astrotalk.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0087.046fc076a1a5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.astrotalk.gokwik_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0088.13c26c63b9f6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.astrotalk.snapmint_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0089.7d7ddfca7156
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_scope_set.astrotalk.pos_services_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0090.22f9a4768d88
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.pos_services_future_context
  source_type: business_scope_set
  target_id: platform_account.astrotalk.petpooja_pos.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0091.3afebbe5f351
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.pos_services_future_context
  source_type: business_scope_set
  target_id: platform_account.astrotalk.posist_pos.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0092.4712d56e828c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.astrotalk.pos_services_future_context
  source_type: business_scope_set
  target_id: platform_account.astrotalk.astrotalk_oda.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0093.fdeee0273725
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0094.7bd0bda6581a
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: business_scope_set.astrotalk.unicommerce_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0095.ca32ea13a27a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0096.004a36342091
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0097.94a94f98e048
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0098.90feb1da2169
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0099.1c6dcf6e4983
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0100.63b2dee7c440
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0101.b8f202251207
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0102.6670a4f2308c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0103.1ebf626c0a3b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0104.32a22de776d1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0105.67c7d3200523
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0106.e25265212782
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0107.f96f36d32e47
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0108.5ebf9664217e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0109.9e9a80f1607e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0110.19ff8ab622a9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0111.5dcdabee97b4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0112.aa2a5f84c70b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0113.ca5851ecc687
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0114.ce16dfd96c95
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.amazon_india
  - ev.astrotalk.docx.row.3_oms_layer.amazon
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.flipkart
  - ev.astrotalk.docx.row.2_active_sales_channels_e_commerce_marketplaces.myntra
  - ev.astrotalk.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0115.e0d509854226
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0116.61fdeb689da3
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: business_scope_set.astrotalk.shopify_d2c
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0117.18767c30dbbf
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0118.c63968c99138
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0119.1ce2b9bccd9c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0120.6b58bbb16943
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.razorpay_in.primary.razorpay_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0121.d0bfa0e43a37
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: table.zs_observe.shopify_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0122.ad0c3ae728e5
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.shopify_prepaid_to_razorpay
  source_type: business_flow_binding
  target_id: table.zs_observe.razorpay_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0123.983892657af7
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_flow_binding.astrotalk.shopify_cod_bnpl_future_context
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0124.9975355f2f93
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.astrotalk.shopify_cod_bnpl_future_context
  source_type: business_flow_binding
  target_id: business_scope_set.astrotalk.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0125.430eb6a02ff2
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_cod_bnpl_future_context
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0126.cdbf2b08b5cd
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_cod_bnpl_future_context
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.gokwik_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0127.b6401e575cb1
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_cod_bnpl_future_context
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.snapmint_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0128.e366f61517d3
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0129.425b347b3892
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: business_scope_set.astrotalk.logistics_reconciliation
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0130.6a3912b9def7
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0131.1cb256383bd3
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0132.5f3a8585eda3
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.shopify_d2c.primary.shopify_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0133.b6bebbc143de
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0134.6c8ac4ef9f0c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.shiprocket_in.primary.shiprocket_settlement_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0135.1a3b86f0b8d2
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.shopify_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0136.2b26545223a6
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.shiprocket_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0137.c3a9a9b130b8
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.shopify_to_shiprocket_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.shiprocket_settlement_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0138.3047bc203710
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0139.786ad4befcdc
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  source_type: business_flow_binding
  target_id: business_scope_set.astrotalk.pos_services_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0140.835dc1bc420a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.astrotalk_oda.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0141.905cff8b663d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.yolojet_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0142.8c61fdf23c16
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  source_type: business_flow_binding
  target_id: account_data_binding.astrotalk.astrotalk_oda.primary.astrotalk_oda
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0143.91b09696fe13
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.astrotalk.yolojet_oda_lookup_enrichment
  source_type: business_flow_binding
  target_id: table.zs_observe.astrotalk_oda
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
  - ev.astrotalk.docx.row.2_active_sales_channels_d2c.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0144.5ef9011df1f7
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.astrotalk.astrotalk
  source_type: group
  target_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.identity
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0145.2dbe15482476
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: business_scope_set.astrotalk.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0146.3ff82f26f658
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0147.fb0fb108fa7c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.gokwik_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0148.add271486b74
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.snapmint_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0149.49d850c0f35c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0150.d25e49bc4af4
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.shipway_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0151.c8598aac1101
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.kwikship_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0152.c40a0a3a6d63
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.yolojet_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
candidate_edge:
  edge_id: edge.client.astrotalk.0153.b64474cff6ac
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.astrotalk.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.astrotalk.criticalog_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.razorpay
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shiprocket
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

## 7. Blocked / Non-Emitted Edges
```yaml
blocked_edge:
  source_id: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  edge_type: BINDS_TO_TABLE
  target_id: table.zs_observe.amazon_sku_master
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
    edge: BINDS_TO_TABLE
    target: table.zs_observe.amazon_sku_master
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.petpooja_pos.primary
  edge_type: USES_PLATFORM
  target_id: platform.petpooja
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.petpooja_pos.primary
    edge: USES_PLATFORM
    target: platform.petpooja
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.petpooja_pos.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.petpooja.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.petpooja_pos.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.petpooja.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.posist_pos.primary
  edge_type: USES_PLATFORM
  target_id: platform.posist
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.posist_pos.primary
    edge: USES_PLATFORM
    target: platform.posist
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.posist_pos.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.posist.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.posist_pos.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.posist.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.astrotalk_oda.primary
  edge_type: USES_PLATFORM
  target_id: platform.astrotalk_service
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.astrotalk_oda.primary
    edge: USES_PLATFORM
    target: platform.astrotalk_service
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.astrotalk_oda.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.astrotalk_service.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.astrotalk_oda.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.astrotalk_service.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.shipway_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.shipway
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.shipway_in.primary
    edge: USES_PLATFORM
    target: platform.shipway
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.shipway_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.shipway.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.shipway_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.shipway.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.kwikship_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.kwikship
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.kwikship_in.primary
    edge: USES_PLATFORM
    target: platform.kwikship
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.kwikship_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.kwikship.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.kwikship_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.kwikship.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.yolojet_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.yolojet
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.yolojet_in.primary
    edge: USES_PLATFORM
    target: platform.yolojet
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.yolojet_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.yolojet.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.yolojet_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.yolojet.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.criticalog_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.criticalog
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.criticalog_in.primary
    edge: USES_PLATFORM
    target: platform.criticalog
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.criticalog_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.criticalog.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.criticalog_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.criticalog.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.gokwik_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.gokwik
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.gokwik_in.primary
    edge: USES_PLATFORM
    target: platform.gokwik
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.gokwik_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.gokwik.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.gokwik_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.gokwik.in
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.snapmint_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.snapmint
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.snapmint_in.primary
    edge: USES_PLATFORM
    target: platform.snapmint
```

```yaml
blocked_edge:
  source_id: platform_account.astrotalk.snapmint_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.snapmint.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.astrotalk.snapmint_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.snapmint.in
```

```yaml
blocked_edge:
  source_id: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
  edge_type: USES_ACCOUNT_DATA_BINDING
  target_id: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  blocked_reason: active_flow_edge_to_demoted_binding_removed
  original_edge:
    source: business_flow_binding.astrotalk.marketplace_to_unicommerce_operations
    edge: USES_ACCOUNT_DATA_BINDING
    target: account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
```

## 8. Review Items
```yaml
review_item:
  item: group.astrotalk.astrotalk
  issue: Client doc reports group_level_id 221, while the uploaded Unicommerce Operations canonical document references Astrotalk
    group_level_id 211. Use the client doc for this pack and verify before production SQL.
  severity: high
  review_item_id: review.astrotalk.001
  evidence_refs:
  - ev.astrotalk.docx.identity
```

```yaml
review_item:
  item: tenant.astrotalk
  issue: Source has the typo CLEINT NAME. Tenant name normalized to AstroTalk.
  severity: low
  review_item_id: review.astrotalk.002
  evidence_refs:
  - ev.astrotalk.docx.identity
```

```yaml
review_item:
  item: platform_account.*
  issue: Exact seller, store, gateway, POS, and courier identifiers are not supplied in the client doc.
  severity: medium
  review_item_id: review.astrotalk.003
  evidence_refs:
  - ev.astrotalk.docx.identity
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.001
  item: platform_account.astrotalk.petpooja_pos.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.petpooja
  - platform_context.petpooja.in
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.petpooja
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.002
  item: platform_account.astrotalk.posist_pos.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.posist
  - platform_context.posist.in
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_food_and_beverage_restaurant_pos.posist
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.003
  item: platform_account.astrotalk.astrotalk_oda.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.astrotalk_service
  - platform_context.astrotalk_service.in
  evidence_refs:
  - ev.astrotalk.docx.row.2_active_sales_channels_services.astrotalk
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.004
  item: platform_account.astrotalk.shipway_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.shipway
  - platform_context.shipway.in
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.shipway
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.005
  item: platform_account.astrotalk.kwikship_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.kwikship
  - platform_context.kwikship.in
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.kwikship
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.006
  item: platform_account.astrotalk.yolojet_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.yolojet
  - platform_context.yolojet.in
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.yolojet
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.007
  item: platform_account.astrotalk.criticalog_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.criticalog
  - platform_context.criticalog.in
  evidence_refs:
  - ev.astrotalk.docx.row.4_logistics_courier_reconciliation.criticalog
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.008
  item: platform_account.astrotalk.gokwik_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.gokwik
  - platform_context.gokwik.in
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.gokwik
```

```yaml
review_item:
  review_item_id: review.astrotalk.canonical_context_gap.009
  item: platform_account.astrotalk.snapmint_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.snapmint
  - platform_context.snapmint.in
  evidence_refs:
  - ev.astrotalk.docx.row.5_payment_gateway_reconciliation.snapmint
```

## 9. Refactored Validation Summary
```yaml
validation_summary:
  result: pass
  client_slug: astrotalk
  card_count: 50
  edge_count_emitted: 153
  blocked_edge_count: 20
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 16
    account_data_binding: 20
    business_scope_set: 6
    business_flow_binding: 6
  status_counts:
    active: 44
    draft: 6
  active_account_data_binding_count: 19
  draft_account_data_binding_count: 1
  demoted_account_data_binding_ids:
  - account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
  active_binding_missing_table_refs: []
  duplicate_card_ids: []
  edge_missing_refs_after_refactor: []
  canonical_resolution_gap_count: 9
  semantic_mapping_count: 16
  future_context_gap_count: 11
  review_item_count: 3
  source_evidence_count: 26
  shopify_source_policy: shopify_d2c_oms_v2.md is the active Shopify OMS canonical; shopify_d2c_oms.md is not used.
```
