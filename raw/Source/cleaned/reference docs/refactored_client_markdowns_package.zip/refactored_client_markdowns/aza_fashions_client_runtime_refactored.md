# Aza Fashions Private Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the previously JSON-shaped client runtime pack into a card/edge/evidence registry and applies canonical-platform boundary fixes against the uploaded domain markdowns. It intentionally emits only client runtime binding cards; it does not recreate platform/domain/table/metric semantics already owned by canonical markdowns.

```yaml
document_metadata:
  package_id: aza_fashions_business_hierarchy_runtime_cards_v1_0
  version: v1_0
  generated_date: '2026-05-24'
  created_for: Aza Fashions Private Limited
  client_slug: aza_fashions
  status: ready_for_review
  source_documents:
  - Aza Fashions Private Limited.docx
  - shopify_d2c_oms_v2.md
  - Cognee KB Design v4.md
  - delhivery_logistics.md
  - dtdc_logistics.md
  - ekart_logistics.md
  - payment_gateway.md
  - shiprocket_logistics_aggregator.md
  source_client_profile:
    business: D2C luxury/premium fashion — own platform, no marketplace presence configured
    geography: India domestic plus international cross-border D2C
    source_group_id: 56
    source_group_level_id: 203
    source_group_name: Aza Fashion
    default_currency: INR
    currencies_in_scope:
    - INR
    - USD
    - multi_currency
  build_policy: 'Client/runtime packs contain business hierarchy cards: tenant, group, platform_account, account_data_binding,
    business_scope_set, and business_flow_binding. Active table bindings are emitted only when the current canonical platform
    context or explicit client-table evidence supports the table. Client-mentioned artifacts without current table support
    are preserved as future_context_gaps with source text; no table mapping is fabricated.'
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  refactor_version: client_runtime_markdown_refactor_v2_structured
  refactored_on: '2026-05-24'
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  canonical_source_policy: This client layer binds tenant/group/account/runtime scope to canonical cards from the uploaded
    platform/domain markdowns. It does not recreate platform/table/domain semantics.
  docx_source_title: Aza Fashions Private Limited
```

## 0. Parser Instructions and Refactor Manifest
```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM or USES_PLATFORM_CONTEXT if the target canonical platform/context card is absent.
  - Do not emit active BINDS_TO_TABLE edges for missing canonical table cards.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
```

```yaml
clean_refactor_manifest:
  source_json: aza_fashions.json
  source_docx: Aza Fashions Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9842
  corrections_applied:
  - Replaced Shopify OMS canonical source references with shopify_d2c_oms_v2.md per user correction.
  id_replacement_hits:
  - card_id: platform_account.aza_fashions.paypal_in.primary
    field: platform_context_id
    from: platform_context.paypal.in
    to: platform_context.paypal.global
  - card_id: platform_account.aza_fashions.paypal_us.primary
    field: platform_context_id
    from: platform_context.paypal.us
    to: platform_context.paypal.global
  demoted_binding_ids: []
  blocked_edge_count: 10
  canonical_resolution_gap_count: 5
```

## 1. Source Intake and Evidence Registry
```yaml
source_evidence:
  id: ev.aza_fashions.docx.identity
  source_document: Aza Fashions Private Limited.docx
  source_section: 1. Identity
  evidence_type: docx_section
  summary: Client identity, business model, group identifiers, configured operational stack, and region/currency hints from
    the client DOCX.
  raw_lines:
  - '* Business: D2C luxury/premium fashion — own platform, no marketplace presence configured'
  - '* Brand: AZA Fashions (luxury ethnic wear retailer)'
  - '* OMS: Proprietary AZA platform (data via flat-file dumps — no Shopify/Unicommerce)'
  - '* Logistics: Delhivery, Ekart, Bluedart, DTDC, Shiprocket, iThink'
  - '* Payment gateways: Razorpay, PayU, PayPal IN, PayPal US, PayGlocal'
  - '* Geography: India (domestic) + International (cross-border D2C)'
  - '* GROUP LEVEL ID :  203'
  - '* GROUP ID : 56'
  - '* GROUP NAME: **Aza Fashion**'
  - '* CLIENT NAME : **Aza Fashions Private Limited**'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.section.2_active_sales_channels
  source_document: Aza Fashions Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| AZA (own platform) | Sales dump, Return dump, Wallet ledger |'
  - '> No marketplace OMS or settlement files (Amazon, Flipkart, Myntra, etc.) are configured. All revenue flows through AZA''s
    proprietary platform only.'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.section.3_logistics_courier_reconciliation
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: docx_section
  summary: Client DOCX section covering 3. Logistics — courier reconciliation.
  raw_lines:
  - '| Courier | Files configured |'
  - '| Delhivery | Settlement + Invoice |'
  - '| Bluedart | Settlement + Invoice |'
  - '| DTDC    | Settlement + Invoice |'
  - '| Shiprocket | Settlement + Invoice |'
  - '| iThink  | Settlement + Invoice |'
  - '| Ekart   | Invoice only (Teabox variant) |'
  - '> Ekart has only an invoice file — no settlement file. COD remittance for Ekart-shipped orders may be embedded in another
    file or handled off-platform. Confirm with ops.'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.section.4_payment_gateway_reconciliation
  source_document: Aza Fashions Private Limited.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: docx_section
  summary: Client DOCX section covering 4. Payment gateway reconciliation.
  raw_lines:
  - '| Gateway | Scope | Pipeline target |'
  - '| Razorpay | Domestic D2C | razorpay_payin  |'
  - '| PayU    | Domestic D2C | payu_settlement |'
  - '| PayPal IN | Domestic / NRI | paypal_in_settlement |'
  - '| PayPal US | International (USD) | paypal_us_settlement |'
  - '| PayGlocal | International (multi-currency) | payglocal_settlement |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  source_document: Aza Fashions Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: AZA (own platform)
  columns:
    channel: AZA (own platform)
    data_types_configured: Sales dump, Return dump, Wallet ledger
  raw_text: '| AZA (own platform) | Sales dump, Return dump, Wallet ledger |'
  source_line_number_in_docx_text_extract: 16
  summary: 'AZA (own platform): Sales dump, Return dump, Wallet ledger'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Delhivery
  columns:
    courier: Delhivery
    files_configured: Settlement + Invoice
  raw_text: '| Delhivery | Settlement + Invoice |'
  source_line_number_in_docx_text_extract: 21
  summary: 'Delhivery: Settlement + Invoice'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Bluedart
  columns:
    courier: Bluedart
    files_configured: Settlement + Invoice
  raw_text: '| Bluedart | Settlement + Invoice |'
  source_line_number_in_docx_text_extract: 22
  summary: 'Bluedart: Settlement + Invoice'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: DTDC
  columns:
    courier: DTDC
    files_configured: Settlement + Invoice
  raw_text: '| DTDC    | Settlement + Invoice |'
  source_line_number_in_docx_text_extract: 23
  summary: 'DTDC: Settlement + Invoice'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Shiprocket
  columns:
    courier: Shiprocket
    files_configured: Settlement + Invoice
  raw_text: '| Shiprocket | Settlement + Invoice |'
  source_line_number_in_docx_text_extract: 24
  summary: 'Shiprocket: Settlement + Invoice'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ithink
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: iThink
  columns:
    courier: iThink
    files_configured: Settlement + Invoice
  raw_text: '| iThink  | Settlement + Invoice |'
  source_line_number_in_docx_text_extract: 25
  summary: 'iThink: Settlement + Invoice'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Ekart
  columns:
    courier: Ekart
    files_configured: Invoice only (Teabox variant)
  raw_text: '| Ekart   | Invoice only (Teabox variant) |'
  source_line_number_in_docx_text_extract: 26
  summary: 'Ekart: Invoice only (Teabox variant)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  source_document: Aza Fashions Private Limited.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: Razorpay
  columns:
    gateway: Razorpay
    scope: Domestic D2C
    pipeline_target: razorpay_payin
  raw_text: '| Razorpay | Domestic D2C | razorpay_payin  |'
  source_line_number_in_docx_text_extract: 31
  summary: 'Razorpay: Domestic D2C | razorpay_payin'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  source_document: Aza Fashions Private Limited.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: PayU
  columns:
    gateway: PayU
    scope: Domestic D2C
    pipeline_target: payu_settlement
  raw_text: '| PayU    | Domestic D2C | payu_settlement |'
  source_line_number_in_docx_text_extract: 32
  summary: 'PayU: Domestic D2C | payu_settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  source_document: Aza Fashions Private Limited.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: PayPal IN
  columns:
    gateway: PayPal IN
    scope: Domestic / NRI
    pipeline_target: paypal_in_settlement
  raw_text: '| PayPal IN | Domestic / NRI | paypal_in_settlement |'
  source_line_number_in_docx_text_extract: 33
  summary: 'PayPal IN: Domestic / NRI | paypal_in_settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  source_document: Aza Fashions Private Limited.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: PayPal US
  columns:
    gateway: PayPal US
    scope: International (USD)
    pipeline_target: paypal_us_settlement
  raw_text: '| PayPal US | International (USD) | paypal_us_settlement |'
  source_line_number_in_docx_text_extract: 34
  summary: 'PayPal US: International (USD) | paypal_us_settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
  source_document: Aza Fashions Private Limited.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: PayGlocal
  columns:
    gateway: PayGlocal
    scope: International (multi-currency)
    pipeline_target: payglocal_settlement
  raw_text: '| PayGlocal | International (multi-currency) | payglocal_settlement |'
  source_line_number_in_docx_text_extract: 35
  summary: 'PayGlocal: International (multi-currency) | payglocal_settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.note.2_active_sales_channels.001
  source_document: Aza Fashions Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: source_note
  raw_text: No marketplace OMS or settlement files (Amazon, Flipkart, Myntra, etc.) are configured. All revenue flows through
    AZA's proprietary platform only.
  summary: No marketplace OMS or settlement files (Amazon, Flipkart, Myntra, etc.) are configured. All revenue flows through
    AZA's proprietary platform only.
  source_line_number_in_docx_text_extract: 17
  confidence: high
```

```yaml
source_evidence:
  id: ev.aza_fashions.docx.note.3_logistics_courier_reconciliation.002
  source_document: Aza Fashions Private Limited.docx
  source_section: 3. Logistics — courier reconciliation
  evidence_type: source_note
  raw_text: Ekart has only an invoice file — no settlement file. COD remittance for Ekart-shipped orders may be embedded in
    another file or handled off-platform. Confirm with ops.
  summary: Ekart has only an invoice file — no settlement file. COD remittance for Ekart-shipped orders may be embedded in
    another file or handled off-platform. Confirm with ops.
  source_line_number_in_docx_text_extract: 27
  confidence: high
```

## 2. Client Runtime Candidate Cards
### 2.1 Tenant Cards
```yaml
candidate_card:
  card_type: tenant
  card_id: tenant.aza_fashions
  name: Aza Fashions Private Limited
  fields:
    tenant_name: Aza Fashions Private Limited
    tenant_code: AZA
    description: Luxury/premium D2C fashion client with proprietary AZA platform, domestic and international orders, logistics
      reconciliation, wallet/refund reasoning, and payment gateway settlement diagnostics.
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    evidence_refs:
    - ev.aza_fashions.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.2 Group Cards
```yaml
candidate_card:
  card_type: group
  card_id: group.aza_fashions.aza_fashion
  name: Aza Fashion
  fields:
    tenant_id: tenant.aza_fashions
    group_name: Aza Fashion
    group_code: AZA_FASHION
    group_type: brand
    business_meaning: Aza Fashion brand/operating group for proprietary D2C luxury fashion sales, returns, wallet, logistics,
      and payment gateway flows.
    country_or_region: India domestic; international cross-border D2C also in scope
    default_currency: INR
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    source_scope_identifiers:
      group_id: 56
      group_level_id: 203
      representation_rule: Use these only through Account Data Binding scope_keys.
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    evidence_refs:
    - ev.aza_fashions.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.3 Platform Account Cards
```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.aza_own_platform.primary
  name: AZA Proprietary Platform Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.aza_own_platform
    platform_context_id: platform_context.aza_own_platform.global
    account_name: AZA Proprietary Platform Account
    account_type: custom_sales_platform_account
    account_role: d2c_order_source
    source_account_identifier: null
    source_config_text: 'AZA own platform: Sales dump, Return dump, Wallet ledger'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.delhivery_in.primary
  name: AZA Delhivery Logistics Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.delhivery
    platform_context_id: platform_context.delhivery.in
    account_name: AZA Delhivery Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Delhivery: Settlement + Invoice'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: delhivery_logistics.md
      platform_context_id_source_file: delhivery_logistics.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.dtdc_in.primary
  name: AZA DTDC Logistics Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.dtdc
    platform_context_id: platform_context.dtdc.in
    account_name: AZA DTDC Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'DTDC: Settlement + Invoice'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: dtdc_logistics.md
      platform_context_id_source_file: dtdc_logistics.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.shiprocket_in.primary
  name: AZA Shiprocket Logistics Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.shiprocket
    platform_context_id: platform_context.shiprocket.in
    account_name: AZA Shiprocket Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Shiprocket: Settlement + Invoice'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: shiprocket_logistics_aggregator.md
      platform_context_id_source_file: shiprocket_logistics_aggregator.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.ekart_in.primary
  name: AZA Ekart Logistics Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.ekart
    platform_context_id: platform_context.ekart.in
    account_name: AZA Ekart Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Ekart: Invoice only (Teabox variant)'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: ekart_logistics.md
      platform_context_id_source_file: ekart_logistics.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.bluedart_in.primary
  name: AZA BlueDart Logistics Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.bluedart
    platform_context_id: platform_context.bluedart.in
    account_name: AZA BlueDart Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'BlueDart: Settlement + Invoice'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.ithink_in.primary
  name: AZA iThink Logistics Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.ithink
    platform_context_id: platform_context.ithink.in
    account_name: AZA iThink Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'iThink: Settlement + Invoice'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ithink
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.razorpay_in.primary
  name: AZA Razorpay Gateway Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.razorpay
    platform_context_id: platform_context.razorpay.in
    account_name: AZA Razorpay Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'Razorpay domestic D2C: razorpay_payin'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: payment_gateway.md
      platform_context_id_source_file: payment_gateway.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.paypal_in.primary
  name: AZA PayPal IN Gateway Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.paypal
    platform_context_id: platform_context.paypal.global
    account_name: AZA PayPal IN Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'PayPal IN: paypal_in_settlement'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: payment_gateway.md
      platform_context_id_source_file: payment_gateway.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.paypal_us.primary
  name: AZA PayPal US Gateway Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.paypal
    platform_context_id: platform_context.paypal.global
    account_name: AZA PayPal US Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'PayPal US: paypal_us_settlement'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: payment_gateway.md
      platform_context_id_source_file: payment_gateway.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.payu_in.primary
  name: AZA PayU Gateway Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.payu
    platform_context_id: platform_context.payu.in
    account_name: AZA PayU Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'PayU domestic D2C: payu_settlement'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.aza_fashions.payglocal_global.primary
  name: AZA PayGlocal Gateway Account
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    platform_id: platform.payglocal
    platform_context_id: platform_context.payglocal.global
    account_name: AZA PayGlocal Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'PayGlocal international multi-currency: payglocal_settlement'
    country_or_region: India domestic; international cross-border D2C also in scope
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

### 2.4 Account Data Binding Cards
```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  name: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  fields:
    platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
    table_id: table.zs_observe.aza_sales_dump
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'AZA own platform: Sales dump, Return dump, Wallet ledger'
    notes:
    - Bind platform_account.aza_fashions.aza_own_platform.primary to table.zs_observe.aza_sales_dump using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - shopify_d2c_oms_v2.md
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  name: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  fields:
    platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
    table_id: table.zs_observe.aza_return_dump
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'AZA own platform: Sales dump, Return dump, Wallet ledger'
    notes:
    - Bind platform_account.aza_fashions.aza_own_platform.primary to table.zs_observe.aza_return_dump using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - shopify_d2c_oms_v2.md
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  name: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  fields:
    platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
    table_id: table.zs_observe.aza_wallet_ledger
    table_support_level: client_table_evidence
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'AZA own platform: Sales dump, Return dump, Wallet ledger'
    notes:
    - Bind platform_account.aza_fashions.aza_own_platform.primary to table.zs_observe.aza_wallet_ledger using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - shopify_d2c_oms_v2.md
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_settlement
  name: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_settlement
  fields:
    platform_account_id: platform_account.aza_fashions.delhivery_in.primary
    table_id: table.zs_observe.delhivery_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'Delhivery: Settlement + Invoice'
    notes:
    - Bind platform_account.aza_fashions.delhivery_in.primary to table.zs_observe.delhivery_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - delhivery_logistics.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: delhivery_logistics.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_invoice
  name: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_invoice
  fields:
    platform_account_id: platform_account.aza_fashions.delhivery_in.primary
    table_id: table.zs_observe.delhivery_invoice
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'Delhivery: Settlement + Invoice'
    notes:
    - Bind platform_account.aza_fashions.delhivery_in.primary to table.zs_observe.delhivery_invoice using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - delhivery_logistics.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: delhivery_logistics.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_settlement
  name: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_settlement
  fields:
    platform_account_id: platform_account.aza_fashions.dtdc_in.primary
    table_id: table.zs_observe.dtdc_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'DTDC: Settlement + Invoice'
    notes:
    - Bind platform_account.aza_fashions.dtdc_in.primary to table.zs_observe.dtdc_settlement using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - dtdc_logistics.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: dtdc_logistics.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_invoice
  name: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_invoice
  fields:
    platform_account_id: platform_account.aza_fashions.dtdc_in.primary
    table_id: table.zs_observe.dtdc_invoice
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'DTDC: Settlement + Invoice'
    notes:
    - Bind platform_account.aza_fashions.dtdc_in.primary to table.zs_observe.dtdc_invoice using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - dtdc_logistics.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: dtdc_logistics.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_settlement
  name: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_settlement
  fields:
    platform_account_id: platform_account.aza_fashions.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'Shiprocket: Settlement + Invoice'
    notes:
    - Bind platform_account.aza_fashions.shiprocket_in.primary to table.zs_observe.shiprocket_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - shiprocket_logistics_aggregator.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shiprocket_logistics_aggregator.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_invoice
  name: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_invoice
  fields:
    platform_account_id: platform_account.aza_fashions.shiprocket_in.primary
    table_id: table.zs_observe.shiprocket_invoice
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'Shiprocket: Settlement + Invoice'
    notes:
    - Bind platform_account.aza_fashions.shiprocket_in.primary to table.zs_observe.shiprocket_invoice using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - shiprocket_logistics_aggregator.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shiprocket_logistics_aggregator.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.ekart_in.primary.ekart_invoice
  name: account_data_binding.aza_fashions.ekart_in.primary.ekart_invoice
  fields:
    platform_account_id: platform_account.aza_fashions.ekart_in.primary
    table_id: table.zs_observe.ekart_invoice
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'Ekart: Invoice only (Teabox variant)'
    notes:
    - Bind platform_account.aza_fashions.ekart_in.primary to table.zs_observe.ekart_invoice using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - ekart_logistics.md
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ekart_logistics.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.razorpay_in.primary.razorpay_payin
  name: account_data_binding.aza_fashions.razorpay_in.primary.razorpay_payin
  fields:
    platform_account_id: platform_account.aza_fashions.razorpay_in.primary
    table_id: table.zs_observe.razorpay_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'Razorpay domestic D2C: razorpay_payin'
    notes:
    - Bind platform_account.aza_fashions.razorpay_in.primary to table.zs_observe.razorpay_payin using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Aza Fashions Private Limited.docx
    - payment_gateway.md
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: payment_gateway.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.paypal_in.primary.paypal_settlement
  name: account_data_binding.aza_fashions.paypal_in.primary.paypal_settlement
  fields:
    platform_account_id: platform_account.aza_fashions.paypal_in.primary
    table_id: table.zs_observe.paypal_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'PayPal IN: paypal_in_settlement'
    notes:
    - Generic PayPal settlement table exists in current payment gateway context, but the uploaded client evidence does not
      provide the source account/currency discriminator needed to make a region-specific binding executable.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: false
    status: draft
    confidence: inferred
    source_documents:
    - Aza Fashions Private Limited.docx
    - payment_gateway.md
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: payment_gateway.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.aza_fashions.paypal_us.primary.paypal_settlement
  name: account_data_binding.aza_fashions.paypal_us.primary.paypal_settlement
  fields:
    platform_account_id: platform_account.aza_fashions.paypal_us.primary
    table_id: table.zs_observe.paypal_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 56
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 203
      data_type: integer
    source_config_text: 'PayPal US: paypal_us_settlement'
    notes:
    - Generic PayPal settlement table exists in current payment gateway context, but the uploaded client evidence does not
      provide the source account/currency discriminator needed to make a region-specific binding executable.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: false
    status: draft
    confidence: inferred
    source_documents:
    - Aza Fashions Private Limited.docx
    - payment_gateway.md
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: payment_gateway.md
```

### 2.5 Business Scope Set Cards
```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.aza_fashions.aza_own_platform
  name: AZA Own Platform D2C
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    scope_name: AZA Own Platform D2C
    scope_type: single_account
    platform_account_ids:
    - platform_account.aza_fashions.aza_own_platform.primary
    platform_ids:
    - platform.aza_own_platform
    platform_context_ids:
    - platform_context.aza_own_platform.global
    description: AZA proprietary platform sales/returns/wallet scope from client-table evidence.
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.aza_fashions.logistics_reconciliation
  name: AZA Logistics Reconciliation
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    scope_name: AZA Logistics Reconciliation
    scope_type: logistics_scope
    platform_account_ids:
    - platform_account.aza_fashions.delhivery_in.primary
    - platform_account.aza_fashions.dtdc_in.primary
    - platform_account.aza_fashions.shiprocket_in.primary
    - platform_account.aza_fashions.ekart_in.primary
    - platform_account.aza_fashions.bluedart_in.primary
    - platform_account.aza_fashions.ithink_in.primary
    platform_ids:
    - platform.delhivery
    - platform.dtdc
    - platform.shiprocket
    - platform.ekart
    - platform.bluedart
    - platform.ithink
    platform_context_ids:
    - platform_context.delhivery.in
    - platform_context.dtdc.in
    - platform_context.shiprocket.in
    - platform_context.ekart.in
    - platform_context.bluedart.in
    - platform_context.ithink.in
    description: Courier settlement/invoice scope; BlueDart and iThink require platform context, Ekart invoice-only is intentionally
      invoice-only.
    active: true
    status: draft
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ithink
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.aza_fashions.payment_gateways
  name: AZA Payment Gateways
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    scope_name: AZA Payment Gateways
    scope_type: payment_gateway_scope
    platform_account_ids:
    - platform_account.aza_fashions.razorpay_in.primary
    - platform_account.aza_fashions.payu_in.primary
    - platform_account.aza_fashions.paypal_in.primary
    - platform_account.aza_fashions.paypal_us.primary
    - platform_account.aza_fashions.payglocal_global.primary
    platform_ids:
    - platform.razorpay
    - platform.payu
    - platform.paypal
    - platform.payglocal
    platform_context_ids:
    - platform_context.razorpay.in
    - platform_context.payu.in
    - platform_context.paypal.global
    - platform_context.paypal.global
    - platform_context.payglocal.global
    description: Domestic and international payment gateway scope; PayU/PayGlocal require context, generic PayPal settlement
      requires account/currency discriminator review.
    active: true
    status: draft
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

### 2.6 Business Flow Binding Cards
```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  name: AZA Own Platform Sales Return Wallet Flow
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    binding_name: AZA Own Platform Sales Return Wallet Flow
    binding_type: operational_reconciliation_flow
    business_scope_set_id: business_scope_set.aza_fashions.aza_own_platform
    money_flow_paths:
    - own_platform_sales_to_returns
    - return_to_wallet_refund
    participating_accounts:
    - platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
      role: order_return_wallet_source
      required: true
    evidence_table_ids:
    - table.zs_observe.aza_sales_dump
    - table.zs_observe.aza_return_dump
    - table.zs_observe.aza_wallet_ledger
    account_data_binding_ids:
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
    business_process_ids:
    - business_process.d2c_order_lifecycle
    - business_process.return_refund_lifecycle
    reconciliation_profile_ids:
    - reconciliation_profile.return_to_wallet_credit
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  name: AZA Own Platform to Active Payment Gateway Sources
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    binding_name: AZA Own Platform to Active Payment Gateway Sources
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.aza_fashions.payment_gateways
    money_flow_paths:
    - ecommerce_store_to_payment_gateway
    - payment_gateway_settlement
    participating_accounts:
    - platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.aza_fashions.razorpay_in.primary
      role: payment_source
      required: false
    - platform_account_id: platform_account.aza_fashions.paypal_in.primary
      role: payment_source
      required: false
    - platform_account_id: platform_account.aza_fashions.paypal_us.primary
      role: payment_source
      required: false
    evidence_table_ids:
    - table.zs_observe.aza_sales_dump
    - table.zs_observe.razorpay_payin
    - table.zs_observe.paypal_settlement
    account_data_binding_ids:
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
    - account_data_binding.aza_fashions.razorpay_in.primary.razorpay_payin
    - account_data_binding.aza_fashions.paypal_in.primary.paypal_settlement
    - account_data_binding.aza_fashions.paypal_us.primary.paypal_settlement
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: inferred
    active: true
    status: draft
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - Razorpay and generic PayPal settlement have current table support; PayU is source-important but not available in current
      platform context, so full AZA PG coverage remains draft-for-review.
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  name: AZA Own Platform to Supported Logistics
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    binding_name: AZA Own Platform to Supported Logistics
    binding_type: fulfilment_flow
    business_scope_set_id: business_scope_set.aza_fashions.logistics_reconciliation
    money_flow_paths:
    - order_to_shipment
    - shipment_to_freight_invoice
    - cod_delivery_to_courier_remittance
    participating_accounts:
    - platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
      role: order_source
      required: true
    - platform_account_id: platform_account.aza_fashions.delhivery_in.primary
      role: logistics_source
      required: true
    - platform_account_id: platform_account.aza_fashions.dtdc_in.primary
      role: logistics_source
      required: true
    - platform_account_id: platform_account.aza_fashions.shiprocket_in.primary
      role: logistics_source
      required: true
    - platform_account_id: platform_account.aza_fashions.ekart_in.primary
      role: logistics_source
      required: true
    evidence_table_ids:
    - table.zs_observe.aza_sales_dump
    - table.zs_observe.delhivery_settlement
    - table.zs_observe.delhivery_invoice
    - table.zs_observe.dtdc_settlement
    - table.zs_observe.dtdc_invoice
    - table.zs_observe.shiprocket_settlement
    - table.zs_observe.shiprocket_invoice
    - table.zs_observe.ekart_invoice
    account_data_binding_ids:
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
    - account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
    - account_data_binding.aza_fashions.delhivery_in.primary.delhivery_settlement
    - account_data_binding.aza_fashions.delhivery_in.primary.delhivery_invoice
    - account_data_binding.aza_fashions.dtdc_in.primary.dtdc_settlement
    - account_data_binding.aza_fashions.dtdc_in.primary.dtdc_invoice
    - account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_settlement
    - account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_invoice
    - account_data_binding.aza_fashions.ekart_in.primary.ekart_invoice
    business_process_ids:
    - business_process.order_to_shipment_flow
    reconciliation_profile_ids:
    - reconciliation_profile.shipment_to_freight_invoice
    - reconciliation_profile.cod_expected_to_courier_remittance
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  name: AZA Bank-Crossing Flows Require Bank Binding
  fields:
    tenant_id: tenant.aza_fashions
    group_id: group.aza_fashions.aza_fashion
    binding_name: AZA Bank-Crossing Flows Require Bank Binding
    binding_type: money_flow
    business_scope_set_id: business_scope_set.aza_fashions.payment_gateways
    money_flow_paths:
    - payment_gateway_to_bank
    - logistics_cod_to_bank
    - refund_to_bank
    participating_accounts:
    - platform_account_id: platform_account.aza_fashions.razorpay_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.payu_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.paypal_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.paypal_us.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.payglocal_global.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.delhivery_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.dtdc_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.shiprocket_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.ekart_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.bluedart_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.aza_fashions.ithink_in.primary
      role: settlement_or_remittance_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: inferred
    active: false
    status: draft
    source_documents:
    - Aza Fashions Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - No bank account or bank-statement binding was supplied.
    evidence_refs:
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
    - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
    - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
    - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

## 3. Semantic Mappings
```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
  client_config_text: 'AZA own platform: Sales dump, Return dump, Wallet ledger'
  canonical_mapped_now:
  - table.zs_observe.aza_sales_dump
  - table.zs_observe.aza_return_dump
  - table.zs_observe.aza_wallet_ledger
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.delhivery_in.primary
  client_config_text: 'Delhivery: Settlement + Invoice'
  canonical_mapped_now:
  - table.zs_observe.delhivery_settlement
  - table.zs_observe.delhivery_invoice
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.dtdc_in.primary
  client_config_text: 'DTDC: Settlement + Invoice'
  canonical_mapped_now:
  - table.zs_observe.dtdc_settlement
  - table.zs_observe.dtdc_invoice
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.shiprocket_in.primary
  client_config_text: 'Shiprocket: Settlement + Invoice'
  canonical_mapped_now:
  - table.zs_observe.shiprocket_settlement
  - table.zs_observe.shiprocket_invoice
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.ekart_in.primary
  client_config_text: 'Ekart: Invoice only (Teabox variant)'
  canonical_mapped_now:
  - table.zs_observe.ekart_invoice
  future_platform_context_gaps:
  - Ekart settlement for AZA, if COD remittance is separately available
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.bluedart_in.primary
  client_config_text: 'BlueDart: Settlement + Invoice'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - BlueDart settlement
  - BlueDart invoice
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.ithink_in.primary
  client_config_text: 'iThink: Settlement + Invoice'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - iThink settlement
  - iThink invoice
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.razorpay_in.primary
  client_config_text: 'Razorpay domestic D2C: razorpay_payin'
  canonical_mapped_now:
  - table.zs_observe.razorpay_payin
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.paypal_in.primary
  client_config_text: 'PayPal IN: paypal_in_settlement'
  canonical_mapped_now:
  - table.zs_observe.paypal_settlement
  future_platform_context_gaps:
  - Confirm PayPal source account identifier and currency/region discriminator before activating this binding
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.paypal_us.primary
  client_config_text: 'PayPal US: paypal_us_settlement'
  canonical_mapped_now:
  - table.zs_observe.paypal_settlement
  future_platform_context_gaps:
  - Confirm PayPal source account identifier and currency/region discriminator before activating this binding
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.payu_in.primary
  client_config_text: 'PayU domestic D2C: payu_settlement'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - PayU settlement table/context
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.aza_fashions.payglocal_global.primary
  client_config_text: 'PayGlocal international multi-currency: payglocal_settlement'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - PayGlocal settlement table/context
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

## 4. Future Context Gaps
```yaml
future_context_gap:
  platform_or_area: AZA Ekart Logistics Account
  missing_artifacts:
  - Ekart settlement for AZA, if COD remittance is separately available
  impact: Source explicitly says Ekart settlement is not configured in the uploaded client doc; do not bind it as active.
  source_text: 'Ekart: Invoice only (Teabox variant)'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AZA BlueDart Logistics Account
  missing_artifacts:
  - BlueDart settlement
  - BlueDart invoice
  impact: Courier reconciliation cannot be actively bound until platform/table context is authored.
  source_text: 'BlueDart: Settlement + Invoice'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AZA iThink Logistics Account
  missing_artifacts:
  - iThink settlement
  - iThink invoice
  impact: Courier reconciliation cannot be actively bound until platform/table context is authored.
  source_text: 'iThink: Settlement + Invoice'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AZA PayU Gateway Account
  missing_artifacts:
  - PayU settlement table/context
  impact: Gateway settlement cannot be actively bound until platform/table context is authored.
  source_text: 'PayU domestic D2C: payu_settlement'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: AZA PayGlocal Gateway Account
  missing_artifacts:
  - PayGlocal settlement table/context
  impact: Gateway settlement cannot be actively bound until platform/table context is authored.
  source_text: 'PayGlocal international multi-currency: payglocal_settlement'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

## 5. Canonical Resolution Gaps
```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.aza_fashions.aza_own_platform.primary
  source_config_text: 'AZA own platform: Sales dump, Return dump, Wallet ledger'
  missing_or_unresolved_refs:
  - platform.aza_own_platform
  - platform_context.aza_own_platform.global
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.aza_fashions.bluedart_in.primary
  source_config_text: 'BlueDart: Settlement + Invoice'
  missing_or_unresolved_refs:
  - platform.bluedart
  - platform_context.bluedart.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.aza_fashions.ithink_in.primary
  source_config_text: 'iThink: Settlement + Invoice'
  missing_or_unresolved_refs:
  - platform.ithink
  - platform_context.ithink.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.aza_fashions.payu_in.primary
  source_config_text: 'PayU domestic D2C: payu_settlement'
  missing_or_unresolved_refs:
  - platform.payu
  - platform_context.payu.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.aza_fashions.payglocal_global.primary
  source_config_text: 'PayGlocal international multi-currency: payglocal_settlement'
  missing_or_unresolved_refs:
  - platform.payglocal
  - platform_context.payglocal.global
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

## 6. Candidate Edge Registry
```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0001.965fbdbb0fa3
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_id: tenant.aza_fashions
  source_type: tenant
  target_id: group.aza_fashions.aza_fashion
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0002.19aa6f034ade
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.aza_own_platform.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0003.31b9d6ce91ca
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.aza_own_platform.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0004.a1590a3eb17f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  source_type: account_data_binding
  target_id: table.zs_observe.aza_sales_dump
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0005.997d54968384
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.aza_own_platform.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0006.891d6365d3e7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  source_type: account_data_binding
  target_id: table.zs_observe.aza_return_dump
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0007.990ee5e50f2e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.aza_own_platform.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0008.56481cb744a1
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  source_type: account_data_binding
  target_id: table.zs_observe.aza_wallet_ledger
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0009.98998fd34f20
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.delhivery_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0010.c11c9894036d
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.delhivery_in.primary
  source_type: platform_account
  target_id: platform.delhivery
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0011.24742576e1da
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.delhivery_in.primary
  source_type: platform_account
  target_id: platform_context.delhivery.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0012.0b117cc2498d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.delhivery_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0013.577c0c3fb16b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.delhivery_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0014.99a4650eec6c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.delhivery_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0015.5014f7526f1e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_invoice
  source_type: account_data_binding
  target_id: table.zs_observe.delhivery_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0016.9ac73db36654
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.dtdc_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0017.0f0f63668c4d
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.dtdc_in.primary
  source_type: platform_account
  target_id: platform.dtdc
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0018.09801a0b9c0b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.dtdc_in.primary
  source_type: platform_account
  target_id: platform_context.dtdc.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0019.ca0910e20d40
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.dtdc_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0020.50b7b57f8e50
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.dtdc_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0021.dda91aa94add
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.dtdc_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0022.aa09feca3a91
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_invoice
  source_type: account_data_binding
  target_id: table.zs_observe.dtdc_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0023.6678353284fc
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0024.c31008ec9163
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.shiprocket_in.primary
  source_type: platform_account
  target_id: platform.shiprocket
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0025.6e03dfa8dc0d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.shiprocket_in.primary
  source_type: platform_account
  target_id: platform_context.shiprocket.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0026.0e53d1fec495
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.shiprocket_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0027.95b233d51003
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.shiprocket_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0028.22c55358f8c6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.shiprocket_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0029.c3a2d9f7455c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_invoice
  source_type: account_data_binding
  target_id: table.zs_observe.shiprocket_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0030.2696a881ffc4
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.ekart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0031.009f51e4476f
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.ekart_in.primary
  source_type: platform_account
  target_id: platform.ekart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0032.201611745154
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.ekart_in.primary
  source_type: platform_account
  target_id: platform_context.ekart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0033.2d3ed68eadd1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.ekart_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.ekart_in.primary.ekart_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0034.014c83b42940
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.ekart_in.primary.ekart_invoice
  source_type: account_data_binding
  target_id: table.zs_observe.ekart_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0035.9cf07b0fa7d4
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.bluedart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0036.bcc5846878be
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.ithink_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ithink
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0037.3a7fb821ea3d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0038.91a74bbc4282
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.razorpay_in.primary
  source_type: platform_account
  target_id: platform.razorpay
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0039.ec311458f0e9
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.razorpay_in.primary
  source_type: platform_account
  target_id: platform_context.razorpay.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0040.ee48237c0ce3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.razorpay_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.razorpay_in.primary.razorpay_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0041.59801904b922
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.razorpay_in.primary.razorpay_payin
  source_type: account_data_binding
  target_id: table.zs_observe.razorpay_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0042.f691c0809f4b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.paypal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0043.8520922f0c14
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.paypal_in.primary
  source_type: platform_account
  target_id: platform.paypal
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0044.d7ac62db7256
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.paypal_in.primary
  source_type: platform_account
  target_id: platform_context.paypal.global
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0045.adc997496274
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.paypal_in.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.paypal_in.primary.paypal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0046.88b16211b716
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.paypal_in.primary.paypal_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.paypal_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0047.8e2174aed62d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.paypal_us.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0048.40da38da5d07
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.aza_fashions.paypal_us.primary
  source_type: platform_account
  target_id: platform.paypal
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0049.bd8911261f8c
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.aza_fashions.paypal_us.primary
  source_type: platform_account
  target_id: platform_context.paypal.global
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0050.a4ccdbe9994b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.aza_fashions.paypal_us.primary
  source_type: platform_account
  target_id: account_data_binding.aza_fashions.paypal_us.primary.paypal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0051.5ef667f03f5b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.aza_fashions.paypal_us.primary.paypal_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.paypal_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0052.41ea91036e27
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.payu_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0053.3c9dca41d803
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: platform_account.aza_fashions.payglocal_global.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0054.09ff5fb3e603
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_scope_set.aza_fashions.aza_own_platform
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0055.b03cecabd5a0
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.aza_own_platform
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.aza_own_platform.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0056.2074b6d55e30
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_scope_set.aza_fashions.logistics_reconciliation
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0057.6f4da036598b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.delhivery_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0058.158ea06c41d3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.dtdc_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0059.aacc6fdb563b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0060.efc369a62ad6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.ekart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0061.370cb4072b37
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.bluedart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0062.8c31a6ef5181
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.ithink_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0063.c891df2b1bb4
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_scope_set.aza_fashions.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0064.7d266d8bd752
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0065.c5badad0ed6e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.payu_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0066.bd7564f5e13f
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.paypal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0067.8b5a25fc4a21
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.paypal_us.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0068.6a04e91450e4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.aza_fashions.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.aza_fashions.payglocal_global.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0069.220c5da9351d
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0070.151491f77178
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: business_scope_set.aza_fashions.aza_own_platform
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0071.b6d55b219eec
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.aza_own_platform.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0072.d525a84192d0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0073.d65c5fed54f1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0074.aa15395d84e9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0075.1123bb15cb5a
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: table.zs_observe.aza_sales_dump
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0076.58d17f3cf62e
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: table.zs_observe.aza_return_dump
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0077.a2df496a530e
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_sales_return_wallet
  source_type: business_flow_binding
  target_id: table.zs_observe.aza_wallet_ledger
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0078.24392023a0eb
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0079.08b34e78e530
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: business_scope_set.aza_fashions.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0080.088c67b15a27
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.aza_own_platform.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0081.75cb2dbfa1ce
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0082.18f12d81ffbc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.paypal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0083.ed40cdafe022
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.paypal_us.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0084.b4d47e8c9602
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0085.646915f32d08
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0086.b25b626293be
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0087.a59ad7f7ce94
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.razorpay_in.primary.razorpay_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0088.7fa369cf63e8
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.paypal_in.primary.paypal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0089.3ea7aa15ee0a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.paypal_us.primary.paypal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0090.27865f214b90
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: table.zs_observe.aza_sales_dump
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0091.1fe17a258ca4
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: table.zs_observe.razorpay_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0092.695899768f58
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_active_payment_gateway_sources
  source_type: business_flow_binding
  target_id: table.zs_observe.paypal_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0093.98898fd11bd4
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0094.f17b5b4cb76b
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: business_scope_set.aza_fashions.logistics_reconciliation
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0095.4e74260ce683
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.aza_own_platform.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0096.a9c34f4fd60f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.delhivery_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0097.a5f909327704
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.dtdc_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0098.81cb513f9b55
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0099.18ab60f5018b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.ekart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0100.37512c65ce44
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_sales_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0101.35902ac3c3be
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_return_dump
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0102.48a536f24d20
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.aza_own_platform.primary.aza_wallet_ledger
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0103.47ca21c58017
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0104.d6e80f63c09a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.delhivery_in.primary.delhivery_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0105.4684c1ff01d4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0106.8b4f722ba518
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.dtdc_in.primary.dtdc_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0107.01f623a95708
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0108.48464cf26ad5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.shiprocket_in.primary.shiprocket_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0109.bb474a46937c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: account_data_binding.aza_fashions.ekart_in.primary.ekart_invoice
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0110.d3a35fbf309b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.aza_sales_dump
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0111.2857588883f3
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.delhivery_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0112.acdccb09bd0b
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.delhivery_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0113.8c703ade5fe8
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.dtdc_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0114.3d838fd4c467
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.dtdc_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0115.265db0ffc5f6
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.shiprocket_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0116.d7c2a5ed9526
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.shiprocket_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0117.3144e111b57c
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.aza_fashions.own_platform_to_logistics
  source_type: business_flow_binding
  target_id: table.zs_observe.ekart_invoice
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.delhivery
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.dtdc
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.shiprocket
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ekart
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0118.92a70826543d
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.aza_fashions.aza_fashion
  source_type: group
  target_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.identity
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0119.317dc9c251c4
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: business_scope_set.aza_fashions.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0120.fd147a5501a9
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.razorpay_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0121.7a64d54b21cf
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.payu_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0122.15cbe217d958
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.paypal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0123.4065e37f3beb
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.paypal_us.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0124.545b9a145bf5
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.payglocal_global.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0125.33603f9bfb41
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.delhivery_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0126.a8d45ed8042d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.dtdc_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0127.b29998b93eaf
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.shiprocket_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0128.7cc6582b6833
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.ekart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0129.823522a9dc59
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.bluedart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

```yaml
candidate_edge:
  edge_id: edge.client.aza_fashions.0130.5487b00c171d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.aza_fashions.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.aza_fashions.ithink_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.razorpay
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_in
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.paypal_us
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
```

## 7. Blocked / Non-Emitted Edges
```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.aza_own_platform.primary
  edge_type: USES_PLATFORM
  target_id: platform.aza_own_platform
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.aza_own_platform.primary
    edge: USES_PLATFORM
    target: platform.aza_own_platform
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.aza_own_platform.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.aza_own_platform.global
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.aza_own_platform.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.aza_own_platform.global
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.bluedart_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.bluedart
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.bluedart_in.primary
    edge: USES_PLATFORM
    target: platform.bluedart
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.bluedart_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.bluedart.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.bluedart_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.bluedart.in
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.ithink_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.ithink
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.ithink_in.primary
    edge: USES_PLATFORM
    target: platform.ithink
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.ithink_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.ithink.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.ithink_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.ithink.in
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.payu_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.payu
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.payu_in.primary
    edge: USES_PLATFORM
    target: platform.payu
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.payu_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.payu.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.payu_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.payu.in
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.payglocal_global.primary
  edge_type: USES_PLATFORM
  target_id: platform.payglocal
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.payglocal_global.primary
    edge: USES_PLATFORM
    target: platform.payglocal
```

```yaml
blocked_edge:
  source_id: platform_account.aza_fashions.payglocal_global.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.payglocal.global
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.aza_fashions.payglocal_global.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.payglocal.global
```

## 8. Review Items
```yaml
review_item:
  item: group.aza_fashions.aza_fashion
  issue: Client Tables document lists group_id/tenant_id 56 as AZA Fashions and 203 as alternate group; uploaded client doc
    is interpreted as group_id=56 and group_level_id=203.
  severity: medium
  review_item_id: review.aza_fashions.001
  evidence_refs:
  - ev.aza_fashions.docx.identity
```

```yaml
review_item:
  item: platform_account.aza_fashions.payu_in.primary
  issue: Client evidence says PayU is important/primary for AZA, but no current PayU canonical settlement table is available
    in the uploaded platform registry.
  severity: high
  review_item_id: review.aza_fashions.002
  evidence_refs:
  - ev.aza_fashions.docx.identity
```

```yaml
review_item:
  item: platform_account.*
  issue: Exact gateway merchant IDs, courier account IDs, and proprietary platform account identifiers are not supplied in
    the client doc.
  severity: medium
  review_item_id: review.aza_fashions.003
  evidence_refs:
  - ev.aza_fashions.docx.identity
```

```yaml
review_item:
  review_item_id: review.aza_fashions.canonical_context_gap.001
  item: platform_account.aza_fashions.aza_own_platform.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.aza_own_platform
  - platform_context.aza_own_platform.global
  evidence_refs:
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
review_item:
  review_item_id: review.aza_fashions.canonical_context_gap.002
  item: platform_account.aza_fashions.bluedart_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.bluedart
  - platform_context.bluedart.in
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.bluedart
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
review_item:
  review_item_id: review.aza_fashions.canonical_context_gap.003
  item: platform_account.aza_fashions.ithink_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.ithink
  - platform_context.ithink.in
  evidence_refs:
  - ev.aza_fashions.docx.row.3_logistics_courier_reconciliation.ithink
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
review_item:
  review_item_id: review.aza_fashions.canonical_context_gap.004
  item: platform_account.aza_fashions.payu_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.payu
  - platform_context.payu.in
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payu
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

```yaml
review_item:
  review_item_id: review.aza_fashions.canonical_context_gap.005
  item: platform_account.aza_fashions.payglocal_global.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.payglocal
  - platform_context.payglocal.global
  evidence_refs:
  - ev.aza_fashions.docx.row.4_payment_gateway_reconciliation.payglocal
  - ev.aza_fashions.docx.row.2_active_sales_channels.aza_own_platform
```

## 9. Refactored Validation Summary
```yaml
validation_summary:
  result: pass
  client_slug: aza_fashions
  card_count: 34
  edge_count_emitted: 130
  blocked_edge_count: 10
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 12
    account_data_binding: 13
    business_scope_set: 3
    business_flow_binding: 4
  status_counts:
    active: 28
    draft: 6
  active_account_data_binding_count: 11
  draft_account_data_binding_count: 2
  demoted_account_data_binding_ids: []
  active_binding_missing_table_refs: []
  duplicate_card_ids: []
  edge_missing_refs_after_refactor: []
  canonical_resolution_gap_count: 5
  semantic_mapping_count: 12
  future_context_gap_count: 5
  review_item_count: 3
  source_evidence_count: 18
  shopify_source_policy: shopify_d2c_oms_v2.md is the active Shopify OMS canonical; shopify_d2c_oms.md is not used.
```
