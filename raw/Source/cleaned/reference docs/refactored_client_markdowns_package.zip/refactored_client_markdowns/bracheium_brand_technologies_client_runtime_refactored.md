# Bracheium Brand Technologies Pvt Ltd — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the previously JSON-shaped client runtime pack into a card/edge/evidence registry and applies canonical-platform boundary fixes against the uploaded domain markdowns. It intentionally emits only client runtime binding cards; it does not recreate platform/domain/table/metric semantics already owned by canonical markdowns.

```yaml
document_metadata:
  package_id: bracheium_brand_technologies_business_hierarchy_runtime_cards_v1_0
  version: v1_0
  generated_date: '2026-05-24'
  created_for: Bracheium Brand Technologies Pvt Ltd
  client_slug: bracheium_brand_technologies
  status: ready_for_review
  source_documents:
  - Bracheium Brand Technologies Pvt Ltd.docx
  - Cognee KB Design v4.md
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - increff_operations.md
  - jiomart_marketplace.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - payment_gateway.md
  - shiprocket_logistics.md
  - shopify_d2c_oms_v2.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  - xpressbees_logistics.md
  source_client_profile:
    business: Multi-channel marketplace seller — India domestic + D2C
    geography: India only
    source_group_id: 9
    source_group_level_id: 29
    source_group_name: Mensa Brands
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: 'Client/runtime packs contain business hierarchy cards: tenant, group, platform_account, account_data_binding,
    business_scope_set, and business_flow_binding. Active table bindings are emitted only when the current canonical platform
    context or explicit client-table evidence supports the table. Client-mentioned artifacts without current table support
    are preserved as future_context_gaps with source text; no table mapping is fabricated.'
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  refactor_version: client_runtime_markdown_refactor_v2_structured
  refactored_on: '2026-05-24'
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  canonical_source_policy: This client layer binds tenant/group/account/runtime scope to canonical cards from the uploaded
    platform/domain markdowns. It does not recreate platform/table/domain semantics.
  docx_source_title: Bracheium Brand Technologies Pvt Ltd
```

## 0. Parser Instructions and Refactor Manifest
```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM or USES_PLATFORM_CONTEXT if the target canonical platform/context card is absent.
  - Do not emit active BINDS_TO_TABLE edges for missing canonical table cards.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
```

```yaml
clean_refactor_manifest:
  source_json: bracheium_brand_technologies.json
  source_docx: Bracheium Brand Technologies Pvt Ltd.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9842
  corrections_applied:
  - Replaced Shopify OMS canonical source references with shopify_d2c_oms_v2.md per user correction.
  id_replacement_hits:
  - card_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
    field: platform_context_id
    from: platform_context.shopify.in.d2c_oms
    to: platform_context.shopify.in_and_global.d2c_oms_client_config
  demoted_binding_ids: []
  blocked_edge_count: 12
  canonical_resolution_gap_count: 6
```

## 1. Source Intake and Evidence Registry
```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.identity
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 1. Identity
  evidence_type: docx_section
  summary: Client identity, business model, group identifiers, configured operational stack, and region/currency hints from
    the client DOCX.
  raw_lines:
  - '* Business: Multi-channel marketplace seller — India domestic + D2C'
  - '* Geography: India only'
  - '* OMS/WMS: Increff (fulfilment/WMS), Unicommerce (marketplace sync), Shopify (D2C), Shiprocket (order source)'
  - '* Logistics: Xpressbees (settlement + invoice)'
  - '* Payment gateways: Cashfree, PhonePe, Easebuzz'
  - '* GROUP LEVEL ID :  29'
  - '* GROUP ID :  9'
  - '* GROUP NAME : Mensa Brands'
  - '* CLIENT NAME :  B**racheium Brand Technologies Pvt Ltd**'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels > Domestic marketplaces.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, MTR report, Transactions |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |'
  - '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT
    + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |'
  - '| Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions
    |'
  - '| Nykaa   | OMS x2 storefronts (Fashion, Popup), Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
    MBTPT/GST mapper, Transactions |'
  - '| JioMart | OMS, Settlement, Returns, Transactions |'
  - '| Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |'
  - '| Tata Cliq | OMS, Settlement, Transactions |'
  - '| Cred    | Sales, Settlement, Returns, Transactions |'
  - '| FirstCry | OMS — WB, Settlement — WB, Returns — WB, RTO — WB |'
  - '| Klip · Blitz | Settlement only       |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_d2c_other_order_sources
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > D2C / other order sources
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels > D2C / other order sources.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| Shopify | D2C OMS               |'
  - '| Shiprocket | Sales / OMS           |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.section.3_wms_fulfilment_layer
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 3. WMS / fulfilment layer
  evidence_type: docx_section
  summary: Client DOCX section covering 3. WMS / fulfilment layer.
  raw_lines:
  - '| System | Files configured |'
  - '| Increff | Sales, Returns, Returns processed |'
  - '| Unicommerce | Sales, Returns, Cancellations |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.section.4_payment_gateway_reconciliation
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: docx_section
  summary: Client DOCX section covering 4. Payment gateway reconciliation.
  raw_lines:
  - '| Gateway | Pipeline target | Notes |'
  - '| Cashfree | cashfree_payin  | Settlement Txns sheet |'
  - '| PhonePe | phonepe_payin   |       |'
  - '| Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.section.5_marketplace_transactions_layer
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 5. Marketplace transactions layer
  evidence_type: docx_section
  summary: Client DOCX section covering 5. Marketplace transactions layer.
  raw_lines:
  - 'Dedicated `marketplace_transactions` feed active for: Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart, Snapdeal, Tata
    Cliq, Cred. Additionally a generic `transactions_report` file routes to `transactions_report` pipeline — confirm with
    ops which channel or gateway this covers.'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Disbursement, Fee preview, MTR report, Transactions
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement, Fee preview, MTR report, Transactions |'
  source_line_number_in_docx_text_extract: 16
  summary: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement, Fee preview, MTR report, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions |'
  source_line_number_in_docx_text_extract: 17
  summary: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads), Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
      (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions
  raw_text: '| Myntra  | OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
    (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions |'
  source_line_number_in_docx_text_extract: 18
  summary: 'Myntra: OMS (JIT + PPMP), Seller reports (Fwd + Rev), Fwd/Rev settlement (JIT + PPMP), Non-order settlement (JIT
    + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return, VHS + VFS expenses, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Meesho
  columns:
    channel: Meesho
    data_types_configured: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
      Transactions
  raw_text: '| Meesho  | Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
    Transactions |'
  source_line_number_in_docx_text_extract: 19
  summary: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Nykaa
  columns:
    channel: Nykaa
    data_types_configured: OMS x2 storefronts (Fashion, Popup), Settlement x2 + Popup new format, Payout summary, TDS, Additional
      shipping, MBTPT/GST mapper, Transactions
  raw_text: '| Nykaa   | OMS x2 storefronts (Fashion, Popup), Settlement x2 + Popup new format, Payout summary, TDS, Additional
    shipping, MBTPT/GST mapper, Transactions |'
  source_line_number_in_docx_text_extract: 20
  summary: 'Nykaa: OMS x2 storefronts (Fashion, Popup), Settlement x2 + Popup new format, Payout summary, TDS, Additional
    shipping, MBTPT/GST mapper, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: JioMart
  columns:
    channel: JioMart
    data_types_configured: OMS, Settlement, Returns, Transactions
  raw_text: '| JioMart | OMS, Settlement, Returns, Transactions |'
  source_line_number_in_docx_text_extract: 21
  summary: 'JioMart: OMS, Settlement, Returns, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Snapdeal
  columns:
    channel: Snapdeal
    data_types_configured: OMS, Settlement, Commission file (5-sheet), Transactions
  raw_text: '| Snapdeal | OMS, Settlement, Commission file (5-sheet), Transactions |'
  source_line_number_in_docx_text_extract: 22
  summary: 'Snapdeal: OMS, Settlement, Commission file (5-sheet), Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Tata Cliq
  columns:
    channel: Tata Cliq
    data_types_configured: OMS, Settlement, Transactions
  raw_text: '| Tata Cliq | OMS, Settlement, Transactions |'
  source_line_number_in_docx_text_extract: 23
  summary: 'Tata Cliq: OMS, Settlement, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Cred
  columns:
    channel: Cred
    data_types_configured: Sales, Settlement, Returns, Transactions
  raw_text: '| Cred    | Sales, Settlement, Returns, Transactions |'
  source_line_number_in_docx_text_extract: 24
  summary: 'Cred: Sales, Settlement, Returns, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: FirstCry
  columns:
    channel: FirstCry
    data_types_configured: OMS — WB, Settlement — WB, Returns — WB, RTO — WB
  raw_text: '| FirstCry | OMS — WB, Settlement — WB, Returns — WB, RTO — WB |'
  source_line_number_in_docx_text_extract: 25
  summary: 'FirstCry: OMS — WB, Settlement — WB, Returns — WB, RTO — WB'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > Domestic marketplaces
  evidence_type: configured_source_row
  row_key: Klip · Blitz
  columns:
    channel: Klip · Blitz
    data_types_configured: Settlement only
  raw_text: '| Klip · Blitz | Settlement only       |'
  source_line_number_in_docx_text_extract: 26
  summary: 'Klip · Blitz: Settlement only'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > D2C / other order sources
  evidence_type: configured_source_row
  row_key: Shopify
  columns:
    channel: Shopify
    data_types_configured: D2C OMS
  raw_text: '| Shopify | D2C OMS               |'
  source_line_number_in_docx_text_extract: 30
  summary: 'Shopify: D2C OMS'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 2. Active sales channels > D2C / other order sources
  evidence_type: configured_source_row
  row_key: Shiprocket
  columns:
    channel: Shiprocket
    data_types_configured: Sales / OMS
  raw_text: '| Shiprocket | Sales / OMS           |'
  source_line_number_in_docx_text_extract: 31
  summary: 'Shiprocket: Sales / OMS'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 3. WMS / fulfilment layer
  evidence_type: configured_source_row
  row_key: Increff
  columns:
    system: Increff
    files_configured: Sales, Returns, Returns processed
  raw_text: '| Increff | Sales, Returns, Returns processed |'
  source_line_number_in_docx_text_extract: 35
  summary: 'Increff: Sales, Returns, Returns processed'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 3. WMS / fulfilment layer
  evidence_type: configured_source_row
  row_key: Unicommerce
  columns:
    system: Unicommerce
    files_configured: Sales, Returns, Cancellations
  raw_text: '| Unicommerce | Sales, Returns, Cancellations |'
  source_line_number_in_docx_text_extract: 36
  summary: 'Unicommerce: Sales, Returns, Cancellations'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: Cashfree
  columns:
    gateway: Cashfree
    pipeline_target: cashfree_payin
    notes: Settlement Txns sheet
  raw_text: '| Cashfree | cashfree_payin  | Settlement Txns sheet |'
  source_line_number_in_docx_text_extract: 40
  summary: 'Cashfree: cashfree_payin | Settlement Txns sheet'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: PhonePe
  columns:
    gateway: PhonePe
    pipeline_target: phonepe_payin
    notes: ''
  raw_text: '| PhonePe | phonepe_payin   |       |'
  source_line_number_in_docx_text_extract: 41
  summary: 'PhonePe: phonepe_payin | '
  confidence: high
```

```yaml
source_evidence:
  id: ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
  source_document: Bracheium Brand Technologies Pvt Ltd.docx
  source_section: 4. Payment gateway reconciliation
  evidence_type: configured_source_row
  row_key: Easebuzz
  columns:
    gateway: Easebuzz
    pipeline_target: easebuzz_settlement
    notes: Two-sheet (header_1 + header_2)
  raw_text: '| Easebuzz | easebuzz_settlement | Two-sheet (header_1 + header_2) |'
  source_line_number_in_docx_text_extract: 42
  summary: 'Easebuzz: easebuzz_settlement | Two-sheet (header_1 + header_2)'
  confidence: high
```

## 2. Client Runtime Candidate Cards
### 2.1 Tenant Cards
```yaml
candidate_card:
  card_type: tenant
  card_id: tenant.bracheium_brand_technologies
  name: Bracheium Brand Technologies Pvt Ltd
  fields:
    tenant_name: Bracheium Brand Technologies Pvt Ltd
    tenant_code: BRACHEIUM
    description: India domestic plus D2C multi-channel marketplace seller using ZenStatement for marketplace settlement, Shopify/Shiprocket
      D2C, Increff/Unicommerce operations, Xpressbees logistics, and payment gateway reconciliation.
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.2 Group Cards
```yaml
candidate_card:
  card_type: group
  card_id: group.bracheium_brand_technologies.mensa_brands
  name: Mensa Brands
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_name: Mensa Brands
    group_code: MENSA_BRANDS
    group_type: operational_unit
    business_meaning: Mensa Brands operating group for Bracheium Brand Technologies marketplace, D2C, WMS/OMS, logistics,
      and payment gateway activity.
    country_or_region: India
    default_currency: INR
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    source_scope_identifiers:
      group_id: 9
      group_level_id: 29
      representation_rule: Use these only through Account Data Binding scope_keys.
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.3 Platform Account Cards
```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  name: Bracheium Amazon India Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Bracheium Amazon India Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: amazon_marketplace.md
      platform_context_id_source_file: amazon_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  name: Bracheium Flipkart Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Bracheium Flipkart Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: flipkart_marketplace.md
      platform_context_id_source_file: flipkart_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  name: Bracheium Myntra Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: Bracheium Myntra Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
      JIT GSTR return, VHS + VFS expenses, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: myntra_marketplace.md
      platform_context_id_source_file: myntra_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  name: Bracheium Meesho Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.meesho
    platform_context_id: platform_context.meesho.in
    account_name: Bracheium Meesho Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: meesho_marketplace.md
      platform_context_id_source_file: meesho_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  name: Bracheium Nykaa Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.nykaa
    platform_context_id: platform_context.nykaa_fashion.in
    account_name: Bracheium Nykaa Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: nykaa_marketplace.md
      platform_context_id_source_file: nykaa_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  name: Bracheium JioMart Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.jiomart
    platform_context_id: platform_context.jiomart.in
    account_name: Bracheium JioMart Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'JioMart: OMS, Settlement, Returns, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: jiomart_marketplace.md
      platform_context_id_source_file: jiomart_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  name: Bracheium Snapdeal Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.snapdeal
    platform_context_id: platform_context.snapdeal.in
    account_name: Bracheium Snapdeal Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file 5-sheet, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: snapdeal_marketplace.md
      platform_context_id_source_file: snapdeal_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  name: Bracheium Tata Cliq Seller Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.tatacliq
    platform_context_id: platform_context.tatacliq.in
    account_name: Bracheium Tata Cliq Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Tata Cliq: OMS, Settlement, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: tatacliq_marketplace.md
      platform_context_id_source_file: tatacliq_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.cred_in.primary
  name: Bracheium Cred Marketplace Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.cred
    platform_context_id: platform_context.cred.in
    account_name: Bracheium Cred Marketplace Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Cred: Sales, Settlement, Returns, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  name: Bracheium FirstCry Marketplace Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.firstcry
    platform_context_id: platform_context.firstcry.in
    account_name: Bracheium FirstCry Marketplace Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'FirstCry: OMS WB, Settlement WB, Returns WB, RTO WB'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.klip_in.primary
  name: Bracheium Klip Marketplace Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.klip
    platform_context_id: platform_context.klip.in
    account_name: Bracheium Klip Marketplace Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Klip: Settlement only'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  name: Bracheium Blitz Marketplace Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.blitz
    platform_context_id: platform_context.blitz.in
    account_name: Bracheium Blitz Marketplace Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Blitz: Settlement only'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  name: Bracheium Shopify D2C Store
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.shopify
    platform_context_id: platform_context.shopify.in_and_global.d2c_oms_client_config
    account_name: Bracheium Shopify D2C Store
    account_type: store_account
    account_role: d2c_order_source
    source_account_identifier: null
    source_config_text: 'Shopify: D2C OMS'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: shopify_d2c_oms_v2.md
      platform_context_id_source_file: shopify_d2c_oms_v2.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  name: Bracheium Shiprocket Order Source
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.shiprocket
    platform_context_id: platform_context.shiprocket.in
    account_name: Bracheium Shiprocket Order Source
    account_type: logistics_aggregator_order_source
    account_role: order_source
    source_account_identifier: null
    source_config_text: 'Shiprocket: Sales / OMS'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: shiprocket_logistics_aggregator.md
      platform_context_id_source_file: shiprocket_logistics_aggregator.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  name: Bracheium Increff WMS Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.increff
    platform_context_id: platform_context.increff.in
    account_name: Bracheium Increff WMS Account
    account_type: wms_account
    account_role: wms_operations_source
    source_account_identifier: null
    source_config_text: 'Increff: Sales, Returns, Returns processed'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: increff_operations.md
      platform_context_id_source_file: increff_operations.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  name: Bracheium Unicommerce OMS Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.unicommerce
    platform_context_id: platform_context.unicommerce.in.d2c_oms
    account_name: Bracheium Unicommerce OMS Account
    account_type: oms_account
    account_role: oms_source
    source_account_identifier: null
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: unicommerce_operations.md
      platform_context_id_source_file: unicommerce_d2c_oms.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  name: Bracheium Xpressbees Logistics Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.xpressbees
    platform_context_id: platform_context.xpressbees.in
    account_name: Bracheium Xpressbees Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'Xpressbees: Settlement + Invoice'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: xpressbees_logistics.md
      platform_context_id_source_file: xpressbees_logistics.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  name: Bracheium Cashfree Gateway Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.cashfree
    platform_context_id: platform_context.cashfree.in
    account_name: Bracheium Cashfree Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'Cashfree: cashfree_payin Settlement Txns sheet'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: payment_gateway.md
      platform_context_id_source_file: payment_gateway.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  name: Bracheium PhonePe Gateway Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.phonepe
    platform_context_id: platform_context.phonepe.in
    account_name: Bracheium PhonePe Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'PhonePe: phonepe_payin'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: payment_gateway.md
      platform_context_id_source_file: payment_gateway.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  name: Bracheium Easebuzz Gateway Account
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.easebuzz
    platform_context_id: platform_context.easebuzz.in
    account_name: Bracheium Easebuzz Gateway Account
    account_type: payment_gateway_account
    account_role: payment_gateway_source
    source_account_identifier: null
    source_config_text: 'Easebuzz: easebuzz_settlement two-sheet header_1 + header_2'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  name: Bracheium Marketplace Transactions Feed
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    platform_id: platform.marketplace_transactions
    platform_context_id: platform_context.marketplace_transactions.in
    account_name: Bracheium Marketplace Transactions Feed
    account_type: transaction_feed_account
    account_role: cross_marketplace_transactions_feed
    source_account_identifier: null
    source_config_text: marketplace_transactions feed active for Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart, Snapdeal,
      Tata Cliq, Cred; generic transactions_report also configured
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

### 2.4 Account Data Binding Cards
```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_oms
  name: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.amazon_in.primary to table.zs_observe.amazon_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_settlement
  name: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.amazon_in.primary to table.zs_observe.amazon_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_disbursment
  name: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_disbursment
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.amazon_in.primary to table.zs_observe.amazon_disbursment using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - amazon_marketplace.md
    registry_notes:
    - Canonical source uses the spelling disbursment.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_fee_preview
  name: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_fee_preview
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
    table_id: table.zs_observe.amazon_fee_preview
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.amazon_in.primary to table.zs_observe.amazon_fee_preview using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.oms
  name: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
    table_id: table.flipkart.oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.flipkart_in.primary to table.flipkart.oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.cashback
  name: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.cashback
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
    table_id: table.flipkart.cashback
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.flipkart_in.primary to table.flipkart.cashback using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.settlement
  name: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.flipkart_in.primary to table.flipkart.settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.commission
  name: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.commission
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
    table_id: table.flipkart.commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.flipkart_in.primary to table.flipkart.commission using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms
  name: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
      JIT GSTR return, VHS + VFS expenses, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.myntra_in.primary to table.zs_observe.myntra_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_settlement
  name: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
      JIT GSTR return, VHS + VFS expenses, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.myntra_in.primary to table.zs_observe.myntra_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_reverse
  name: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_reverse
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
      JIT GSTR return, VHS + VFS expenses, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.myntra_in.primary to table.zs_observe.myntra_reverse using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_non_order_settlement
  name: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_non_order_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
      JIT GSTR return, VHS + VFS expenses, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.myntra_in.primary to table.zs_observe.myntra_non_order_settlement
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms_settlement
  name: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
      JIT GSTR return, VHS + VFS expenses, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.myntra_in.primary to table.zs_observe.myntra_oms_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - myntra_marketplace.md
    registry_notes:
    - Partial reconciliation-helper table; bind only when explicit OMS-settlement diagnostics are needed.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_sales
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_sales
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_settlement
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_returns
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_returns
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_reverse using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_forward_expenses
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_forward_expenses
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_forward_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_forward_expenses using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse_expenses
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse_expenses
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_reverse_expenses using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_other_charges_expenses
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_other_charges_expenses
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_other_charges_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_other_charges_expenses
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_brand_mapping
  name: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_brand_mapping
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
    table_id: table.zs_observe.meesho_brand_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
      mapping, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.meesho_in.primary to table.zs_observe.meesho_brand_mapping using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_oms
  name: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
    table_id: table.zs_observe.nykaa_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.nykaa_in.primary to table.zs_observe.nykaa_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_settlement
  name: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
    table_id: table.zs_observe.nykaa_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.nykaa_in.primary to table.zs_observe.nykaa_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_addition_charge
  name: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_addition_charge
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
    table_id: table.zs_observe.nykaa_addition_charge
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.nykaa_in.primary to table.zs_observe.nykaa_addition_charge using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapper_gst
  name: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapper_gst
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapper_gst
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.nykaa_in.primary to table.zs_observe.nykaa_mapper_gst using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapping
  name: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapping
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.nykaa_in.primary to table.zs_observe.nykaa_mapping using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_oms
  name: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
    table_id: table.zs_observe.jiomart_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'JioMart: OMS, Settlement, Returns, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.jiomart_in.primary to table.zs_observe.jiomart_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_settlement
  name: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
    table_id: table.zs_observe.jiomart_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'JioMart: OMS, Settlement, Returns, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.jiomart_in.primary to table.zs_observe.jiomart_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_returns
  name: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_returns
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
    table_id: table.zs_observe.jiomart_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'JioMart: OMS, Settlement, Returns, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.jiomart_in.primary to table.zs_observe.jiomart_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_oms
  name: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file 5-sheet, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.snapdeal_in.primary to table.zs_observe.snapdeal_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - snapdeal_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: snapdeal_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_settlement
  name: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file 5-sheet, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.snapdeal_in.primary to table.zs_observe.snapdeal_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - snapdeal_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: snapdeal_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_commission
  name: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_commission
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file 5-sheet, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.snapdeal_in.primary to table.zs_observe.snapdeal_commission using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - snapdeal_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: snapdeal_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_oms
  name: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Tata Cliq: OMS, Settlement, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.tatacliq_in.primary to table.zs_observe.tatacliq_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - tatacliq_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: tatacliq_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_settlement
  name: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Tata Cliq: OMS, Settlement, Transactions'
    notes:
    - Bind platform_account.bracheium_brand_technologies.tatacliq_in.primary to table.zs_observe.tatacliq_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - tatacliq_marketplace.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: tatacliq_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
  name: account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
    table_id: table.zs_observe.shopify_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Shopify: D2C OMS'
    notes:
    - Bind platform_account.bracheium_brand_technologies.shopify_d2c.primary to table.zs_observe.shopify_oms using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - shopify_d2c_oms_v2.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.shiprocket_order_source.primary.shiprocket_oms
  name: account_data_binding.bracheium_brand_technologies.shiprocket_order_source.primary.shiprocket_oms
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
    table_id: table.zs_observe.shiprocket_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Shiprocket: Sales / OMS'
    notes:
    - Bind platform_account.bracheium_brand_technologies.shiprocket_order_source.primary to table.zs_observe.shiprocket_oms
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - shiprocket_logistics.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: shopify_d2c_oms_v2.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_sales
  name: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_sales
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.increff_wms.primary
    table_id: table.zs_observe.increff_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Increff: Sales, Returns, Returns processed'
    notes:
    - Bind platform_account.bracheium_brand_technologies.increff_wms.primary to table.zs_observe.increff_sales using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - increff_operations.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: increff_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_returns
  name: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_returns
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.increff_wms.primary
    table_id: table.zs_observe.increff_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Increff: Sales, Returns, Returns processed'
    notes:
    - Bind platform_account.bracheium_brand_technologies.increff_wms.primary to table.zs_observe.increff_returns using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - increff_operations.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: increff_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce
  name: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations'
    notes:
    - Bind platform_account.bracheium_brand_technologies.unicommerce_oms.primary to table.zs_observe.unicommerce using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce_order_sales_report
  name: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce_order_sales_report
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce_order_sales_report
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations'
    notes:
    - Bind platform_account.bracheium_brand_technologies.unicommerce_oms.primary to table.zs_observe.unicommerce_order_sales_report
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.xpressbees_in.primary.xpressbees_settlement
  name: account_data_binding.bracheium_brand_technologies.xpressbees_in.primary.xpressbees_settlement
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
    table_id: table.zs_observe.xpressbees_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Xpressbees: Settlement + Invoice'
    notes:
    - Bind platform_account.bracheium_brand_technologies.xpressbees_in.primary to table.zs_observe.xpressbees_settlement using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - xpressbees_logistics.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: xpressbees_logistics.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.cashfree_in.primary.cashfree_payin
  name: account_data_binding.bracheium_brand_technologies.cashfree_in.primary.cashfree_payin
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
    table_id: table.zs_observe.cashfree_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'Cashfree: cashfree_payin Settlement Txns sheet'
    notes:
    - Bind platform_account.bracheium_brand_technologies.cashfree_in.primary to table.zs_observe.cashfree_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - payment_gateway.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: payment_gateway.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bracheium_brand_technologies.phonepe_in.primary.phonepe_payin
  name: account_data_binding.bracheium_brand_technologies.phonepe_in.primary.phonepe_payin
  fields:
    platform_account_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
    table_id: table.zs_observe.phonepe_payin
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 9
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 29
      data_type: integer
    source_config_text: 'PhonePe: phonepe_payin'
    notes:
    - Bind platform_account.bracheium_brand_technologies.phonepe_in.primary to table.zs_observe.phonepe_payin using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - payment_gateway.md
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: payment_gateway.md
```

### 2.5 Business Scope Set Cards
```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  name: Bracheium Canonical-Mapped Marketplaces
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium Canonical-Mapped Marketplaces
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.amazon_in.primary
    - platform_account.bracheium_brand_technologies.flipkart_in.primary
    - platform_account.bracheium_brand_technologies.myntra_in.primary
    - platform_account.bracheium_brand_technologies.meesho_in.primary
    - platform_account.bracheium_brand_technologies.nykaa_in.primary
    - platform_account.bracheium_brand_technologies.jiomart_in.primary
    - platform_account.bracheium_brand_technologies.snapdeal_in.primary
    - platform_account.bracheium_brand_technologies.tatacliq_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    - platform.meesho
    - platform.nykaa
    - platform.jiomart
    - platform.snapdeal
    - platform.tatacliq
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    - platform_context.meesho.in
    - platform_context.nykaa_fashion.in
    - platform_context.jiomart.in
    - platform_context.snapdeal.in
    - platform_context.tatacliq.in
    description: Domestic marketplaces with active table bindings in current canonical coverage.
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.marketplaces_future_context
  name: Bracheium Marketplace Future Context
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium Marketplace Future Context
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.cred_in.primary
    - platform_account.bracheium_brand_technologies.firstcry_in.primary
    - platform_account.bracheium_brand_technologies.klip_in.primary
    - platform_account.bracheium_brand_technologies.blitz_in.primary
    platform_ids:
    - platform.cred
    - platform.firstcry
    - platform.klip
    - platform.blitz
    platform_context_ids:
    - platform_context.cred.in
    - platform_context.firstcry.in
    - platform_context.klip.in
    - platform_context.blitz.in
    description: Source-confirmed marketplaces requiring platform context before active binding.
    active: false
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.d2c_order_sources
  name: Bracheium D2C Order Sources
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium D2C Order Sources
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.shopify_d2c.primary
    - platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
    platform_ids:
    - platform.shopify
    - platform.shiprocket
    platform_context_ids:
    - platform_context.shopify.in_and_global.d2c_oms_client_config
    - platform_context.shiprocket.in
    description: Shopify D2C and Shiprocket order-source scope.
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.operations_wms_oms
  name: Bracheium Operations WMS/OMS
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium Operations WMS/OMS
    scope_type: operational_scope
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.increff_wms.primary
    - platform_account.bracheium_brand_technologies.unicommerce_oms.primary
    platform_ids:
    - platform.increff
    - platform.unicommerce
    platform_context_ids:
    - platform_context.increff.in
    - platform_context.unicommerce.in.d2c_oms
    description: Increff WMS plus Unicommerce OMS operational scope.
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
    - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.logistics_reconciliation
  name: Bracheium Xpressbees Logistics
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium Xpressbees Logistics
    scope_type: logistics_scope
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.xpressbees_in.primary
    platform_ids:
    - platform.xpressbees
    platform_context_ids:
    - platform_context.xpressbees.in
    description: Xpressbees settlement scope; invoice gap retained.
    active: true
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  name: Bracheium Payment Gateways
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium Payment Gateways
    scope_type: payment_gateway_scope
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.cashfree_in.primary
    - platform_account.bracheium_brand_technologies.phonepe_in.primary
    - platform_account.bracheium_brand_technologies.easebuzz_in.primary
    platform_ids:
    - platform.cashfree
    - platform.phonepe
    - platform.easebuzz
    platform_context_ids:
    - platform_context.cashfree.in
    - platform_context.phonepe.in
    - platform_context.easebuzz.in
    description: Payment gateway scope with active Cashfree/PhonePe and Easebuzz context gap.
    active: true
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bracheium_brand_technologies.transactions_feed_future_context
  name: Bracheium Transactions Feed Future Context
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    scope_name: Bracheium Transactions Feed Future Context
    scope_type: transaction_feed_scope
    platform_account_ids:
    - platform_account.bracheium_brand_technologies.marketplace_transactions.primary
    platform_ids:
    - platform.marketplace_transactions
    platform_context_ids:
    - platform_context.marketplace_transactions.in
    description: Source-confirmed marketplace_transactions/transactions_report feed requiring schema/routing context.
    active: false
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

### 2.6 Business Flow Binding Cards
```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  name: Bracheium Marketplace to Increff/Unicommerce Operations
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    binding_name: Bracheium Marketplace to Increff/Unicommerce Operations
    binding_type: operational_flow
    business_scope_set_id: business_scope_set.bracheium_brand_technologies.operations_wms_oms
    money_flow_paths:
    - marketplace_to_operations_wms
    - order_to_shipment
    - return_to_wms
    participating_accounts:
    - platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.increff_wms.primary
      role: wms_operations_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
      role: oms_operations_source
      required: false
    evidence_table_ids:
    - table.zs_observe.increff_sales
    - table.zs_observe.increff_returns
    - table.zs_observe.unicommerce
    - table.zs_observe.unicommerce_order_sales_report
    account_data_binding_ids:
    - account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_oms
    - account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_settlement
    - account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_disbursment
    - account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_fee_preview
    - account_data_binding.bracheium_brand_technologies.flipkart_in.primary.oms
    - account_data_binding.bracheium_brand_technologies.flipkart_in.primary.cashback
    - account_data_binding.bracheium_brand_technologies.flipkart_in.primary.settlement
    - account_data_binding.bracheium_brand_technologies.flipkart_in.primary.commission
    - account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms
    - account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_settlement
    - account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_reverse
    - account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_sales
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_settlement
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_returns
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_forward_expenses
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse_expenses
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_other_charges_expenses
    - account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_brand_mapping
    - account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_oms
    - account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_settlement
    - account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_addition_charge
    - account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapper_gst
    - account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapping
    - account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_oms
    - account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_settlement
    - account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_returns
    - account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_oms
    - account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_settlement
    - account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_commission
    - account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_oms
    - account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_settlement
    - account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_sales
    - account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_returns
    - account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce
    - account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce_order_sales_report
    business_process_ids:
    - business_process.order_to_shipment_flow
    - business_process.delivery_rto_return_resolution
    reconciliation_profile_ids:
    - reconciliation_profile.order_to_shipment
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  name: Bracheium Shopify and Shiprocket Order Flow
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    binding_name: Bracheium Shopify and Shiprocket Order Flow
    binding_type: fulfilment_flow
    business_scope_set_id: business_scope_set.bracheium_brand_technologies.d2c_order_sources
    money_flow_paths:
    - d2c_order_reporting
    - order_to_shipment
    participating_accounts:
    - platform_account_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
      role: shopify_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
      role: shiprocket_order_source
      required: false
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.shiprocket_oms
    account_data_binding_ids:
    - account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
    - account_data_binding.bracheium_brand_technologies.shiprocket_order_source.primary.shiprocket_oms
    business_process_ids:
    - business_process.d2c_order_lifecycle
    - business_process.order_to_shipment_flow
    reconciliation_profile_ids: []
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  name: Bracheium D2C to Cashfree/PhonePe Payment Gateways
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    binding_name: Bracheium D2C to Cashfree/PhonePe Payment Gateways
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.bracheium_brand_technologies.payment_gateways
    money_flow_paths:
    - ecommerce_store_to_payment_gateway
    - payment_gateway_settlement
    participating_accounts:
    - platform_account_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
      role: store_order_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
      role: payment_source
      required: false
    - platform_account_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
      role: payment_source
      required: false
    - platform_account_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
      role: payment_source
      required: false
    evidence_table_ids:
    - table.zs_observe.shopify_oms
    - table.zs_observe.cashfree_payin
    - table.zs_observe.phonepe_payin
    account_data_binding_ids:
    - account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
    - account_data_binding.bracheium_brand_technologies.cashfree_in.primary.cashfree_payin
    - account_data_binding.bracheium_brand_technologies.phonepe_in.primary.phonepe_payin
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: curated
    active: true
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes:
    - Cashfree and PhonePe bindings are active. Easebuzz is configured but not table-bound in current platform context, so
      the full payment-gateway scope remains draft-for-review.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
    - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bracheium_brand_technologies.xpressbees_logistics_reconciliation
  name: Bracheium Xpressbees Logistics Reconciliation
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    binding_name: Bracheium Xpressbees Logistics Reconciliation
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.bracheium_brand_technologies.logistics_reconciliation
    money_flow_paths:
    - shipment_to_freight_invoice
    - cod_delivery_to_courier_remittance
    participating_accounts:
    - platform_account_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
      role: courier_settlement_source
      required: true
    evidence_table_ids:
    - table.zs_observe.xpressbees_settlement
    account_data_binding_ids:
    - account_data_binding.bracheium_brand_technologies.xpressbees_in.primary.xpressbees_settlement
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: curated
    active: true
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes:
    - Settlement is bound. Invoice is source-confirmed but not available in current canonical table coverage.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bracheium_brand_technologies.marketplace_transactions_future_context
  name: Bracheium Marketplace Transactions Feed Requires Context
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    binding_name: Bracheium Marketplace Transactions Feed Requires Context
    binding_type: analytics_flow
    business_scope_set_id: business_scope_set.bracheium_brand_technologies.transactions_feed_future_context
    money_flow_paths:
    - cross_marketplace_transaction_reporting
    participating_accounts:
    - platform_account_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
      role: transaction_feed_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: source_confirmed_context_missing
    active: false
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes:
    - Source confirms the feed and channel list, but table schema/routing is not available for active binding.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  name: Bracheium Bank-Crossing Flows Require Bank Binding
  fields:
    tenant_id: tenant.bracheium_brand_technologies
    group_id: group.bracheium_brand_technologies.mensa_brands
    binding_name: Bracheium Bank-Crossing Flows Require Bank Binding
    binding_type: money_flow
    business_scope_set_id: business_scope_set.bracheium_brand_technologies.payment_gateways
    money_flow_paths:
    - marketplace_to_bank
    - payment_gateway_to_bank
    - logistics_cod_to_bank
    participating_accounts:
    - platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
      role: settlement_or_remittance_source
      required: true
    - platform_account_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
      role: settlement_or_remittance_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: inferred
    active: false
    status: draft
    source_documents:
    - Bracheium Brand Technologies Pvt Ltd.docx
    - Cognee KB Design v4.md
    notes:
    - No bank account or bank-statement binding was supplied.
    evidence_refs:
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
    - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

## 3. Semantic Mappings
```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  client_config_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
  canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  - table.zs_observe.amazon_fee_preview
  future_platform_context_gaps:
  - Amazon MTR report
  - Amazon transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  client_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
  canonical_mapped_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  future_platform_context_gaps:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  - Flipkart transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  client_config_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
    JIT GSTR return, VHS + VFS expenses, Transactions'
  canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  future_platform_context_gaps:
  - Myntra seller reports
  - Myntra non-order expenses detail
  - Myntra JIT GSTR return
  - Myntra VHS expenses
  - Myntra VFS expenses
  - Myntra transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  client_config_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand
    mapping, Transactions'
  canonical_mapped_now:
  - table.zs_observe.meesho_sales
  - table.zs_observe.meesho_settlement
  - table.zs_observe.meesho_returns
  - table.zs_observe.meesho_reverse
  - table.zs_observe.meesho_forward_expenses
  - table.zs_observe.meesho_reverse_expenses
  - table.zs_observe.meesho_other_charges_expenses
  - table.zs_observe.meesho_brand_mapping
  future_platform_context_gaps:
  - Meesho adjustment detail
  - Meesho transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  client_config_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping,
    MBTPT/GST mapper, Transactions'
  canonical_mapped_now:
  - table.zs_observe.nykaa_oms
  - table.zs_observe.nykaa_settlement
  - table.zs_observe.nykaa_addition_charge
  - table.zs_observe.nykaa_mapper_gst
  - table.zs_observe.nykaa_mapping
  future_platform_context_gaps:
  - Nykaa transactions feed
  - Nykaa x2 storefront physical filters if separate
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  client_config_text: 'JioMart: OMS, Settlement, Returns, Transactions'
  canonical_mapped_now:
  - table.zs_observe.jiomart_oms
  - table.zs_observe.jiomart_settlement
  - table.zs_observe.jiomart_returns
  future_platform_context_gaps:
  - JioMart transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  client_config_text: 'Snapdeal: OMS, Settlement, Commission file 5-sheet, Transactions'
  canonical_mapped_now:
  - table.zs_observe.snapdeal_oms
  - table.zs_observe.snapdeal_settlement
  - table.zs_observe.snapdeal_commission
  future_platform_context_gaps:
  - Snapdeal transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  client_config_text: 'Tata Cliq: OMS, Settlement, Transactions'
  canonical_mapped_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  future_platform_context_gaps:
  - TataCliq transactions feed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.cred_in.primary
  client_config_text: 'Cred: Sales, Settlement, Returns, Transactions'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Cred sales
  - Cred settlement
  - Cred returns
  - Cred transactions
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  client_config_text: 'FirstCry: OMS WB, Settlement WB, Returns WB, RTO WB'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - FirstCry OMS WB
  - FirstCry settlement WB
  - FirstCry returns WB
  - FirstCry RTO WB
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.klip_in.primary
  client_config_text: 'Klip: Settlement only'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Klip settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  client_config_text: 'Blitz: Settlement only'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Blitz settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  client_config_text: 'Shopify: D2C OMS'
  canonical_mapped_now:
  - table.zs_observe.shopify_oms
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  client_config_text: 'Shiprocket: Sales / OMS'
  canonical_mapped_now:
  - table.zs_observe.shiprocket_oms
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  client_config_text: 'Increff: Sales, Returns, Returns processed'
  canonical_mapped_now:
  - table.zs_observe.increff_sales
  - table.zs_observe.increff_returns
  future_platform_context_gaps:
  - Increff returns processed detail if separate table is later provided
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  client_config_text: 'Unicommerce: Sales, Returns, Cancellations'
  canonical_mapped_now:
  - table.zs_observe.unicommerce
  - table.zs_observe.unicommerce_order_sales_report
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  client_config_text: 'Xpressbees: Settlement + Invoice'
  canonical_mapped_now:
  - table.zs_observe.xpressbees_settlement
  future_platform_context_gaps:
  - Xpressbees invoice
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  client_config_text: 'Cashfree: cashfree_payin Settlement Txns sheet'
  canonical_mapped_now:
  - table.zs_observe.cashfree_payin
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  client_config_text: 'PhonePe: phonepe_payin'
  canonical_mapped_now:
  - table.zs_observe.phonepe_payin
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  client_config_text: 'Easebuzz: easebuzz_settlement two-sheet header_1 + header_2'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Easebuzz settlement
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  client_config_text: marketplace_transactions / transactions_report
  canonical_mapped_now: []
  future_platform_context_gaps:
  - marketplace_transactions feed
  - transactions_report routing details
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

## 4. Future Context Gaps
```yaml
future_context_gap:
  platform_or_area: Bracheium Amazon India Seller Account
  missing_artifacts:
  - Amazon MTR report
  - Amazon transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Amazon India: OMS, Settlement, Disbursement, Fee preview, MTR report, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Flipkart Seller Account
  missing_artifacts:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  - Flipkart transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Myntra Seller Account
  missing_artifacts:
  - Myntra seller reports
  - Myntra non-order expenses detail
  - Myntra JIT GSTR return
  - Myntra VHS expenses
  - Myntra VFS expenses
  - Myntra transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Myntra: OMS, Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO, JIT
    GSTR return, VHS + VFS expenses, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Meesho Seller Account
  missing_artifacts:
  - Meesho adjustment detail
  - Meesho transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Meesho: Sales/OMS, Settlement, Returns/Reverse, Fwd/Rev expenses, Other charges, Adjustment, Brand mapping,
    Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Nykaa Seller Account
  missing_artifacts:
  - Nykaa transactions feed
  - Nykaa x2 storefront physical filters if separate
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Nykaa: OMS x2 storefronts, Settlement x2 + Popup new format, Payout summary, TDS, Additional shipping, MBTPT/GST
    mapper, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium JioMart Seller Account
  missing_artifacts:
  - JioMart transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'JioMart: OMS, Settlement, Returns, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Snapdeal Seller Account
  missing_artifacts:
  - Snapdeal transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Snapdeal: OMS, Settlement, Commission file 5-sheet, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Tata Cliq Seller Account
  missing_artifacts:
  - TataCliq transactions feed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Tata Cliq: OMS, Settlement, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Cred Marketplace Account
  missing_artifacts:
  - Cred sales
  - Cred settlement
  - Cred returns
  - Cred transactions
  impact: Marketplace cannot be actively bound until canonical platform/table context is authored.
  source_text: 'Cred: Sales, Settlement, Returns, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium FirstCry Marketplace Account
  missing_artifacts:
  - FirstCry OMS WB
  - FirstCry settlement WB
  - FirstCry returns WB
  - FirstCry RTO WB
  impact: Marketplace cannot be actively bound until canonical platform/table context is authored.
  source_text: 'FirstCry: OMS WB, Settlement WB, Returns WB, RTO WB'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Klip Marketplace Account
  missing_artifacts:
  - Klip settlement
  impact: Marketplace cannot be actively bound until canonical platform/table context is authored.
  source_text: 'Klip: Settlement only'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bracheium Blitz Marketplace Account
  missing_artifacts:
  - Blitz settlement
  impact: Marketplace cannot be actively bound until canonical platform/table context is authored.
  source_text: 'Blitz: Settlement only'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Xpressbees
  missing_artifacts:
  - Xpressbees invoice
  impact: Xpressbees settlement can be bound now; invoice requires canonical table context before active binding.
  source_text: 'Xpressbees: Settlement + Invoice'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Easebuzz
  missing_artifacts:
  - Easebuzz settlement
  impact: Gateway settlement cannot be actively bound until platform/table context is authored.
  source_text: 'Easebuzz: easebuzz_settlement two-sheet header_1 + header_2'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Marketplace transactions feed
  missing_artifacts:
  - marketplace_transactions feed
  - transactions_report routing details
  impact: Transaction feed cannot be bound until source schema and channel routing are authored.
  source_text: Dedicated marketplace_transactions feed and generic transactions_report
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

## 5. Canonical Resolution Gaps
```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bracheium_brand_technologies.cred_in.primary
  source_config_text: 'Cred: Sales, Settlement, Returns, Transactions'
  missing_or_unresolved_refs:
  - platform.cred
  - platform_context.cred.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  source_config_text: 'FirstCry: OMS WB, Settlement WB, Returns WB, RTO WB'
  missing_or_unresolved_refs:
  - platform.firstcry
  - platform_context.firstcry.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bracheium_brand_technologies.klip_in.primary
  source_config_text: 'Klip: Settlement only'
  missing_or_unresolved_refs:
  - platform.klip
  - platform_context.klip.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  source_config_text: 'Blitz: Settlement only'
  missing_or_unresolved_refs:
  - platform.blitz
  - platform_context.blitz.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  source_config_text: 'Easebuzz: easebuzz_settlement two-sheet header_1 + header_2'
  missing_or_unresolved_refs:
  - platform.easebuzz
  - platform_context.easebuzz.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  source_config_text: marketplace_transactions feed active for Amazon, Flipkart, Myntra, Meesho, Nykaa, JioMart, Snapdeal,
    Tata Cliq, Cred; generic transactions_report also configured
  missing_or_unresolved_refs:
  - platform.marketplace_transactions
  - platform_context.marketplace_transactions.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

## 6. Candidate Edge Registry
```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0001.3ddaa663f0bf
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_id: tenant.bracheium_brand_technologies
  source_type: tenant
  target_id: group.bracheium_brand_technologies.mensa_brands
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0002.cf18999c91f9
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0003.10663fd78d52
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  source_type: platform_account
  target_id: platform.amazon
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0004.19039d7b51e9
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  source_type: platform_account
  target_id: platform_context.amazon.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0005.0fe75faa27ed
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0006.fc78af75f0d6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_oms
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0007.40e33cd9cd56
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0008.cd25d3ea18bd
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0009.58a398022f5f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0010.72828e40adbd
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_disbursment
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_disbursment
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0011.1dac64132955
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_fee_preview
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0012.96e84f4ef2ea
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_fee_preview
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_fee_preview
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0013.a94486729828
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0014.e5c79aa83113
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  source_type: platform_account
  target_id: platform.flipkart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0015.f65752315a39
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  source_type: platform_account
  target_id: platform_context.flipkart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0016.a480471b3e6c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0017.92da9f7dfa1e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.oms
  source_type: account_data_binding
  target_id: table.flipkart.oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0018.d63d14deb3a3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0019.f3cf20f1ca32
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.cashback
  source_type: account_data_binding
  target_id: table.flipkart.cashback
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0020.b43607b0815f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0021.3b16e9aad0e2
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.settlement
  source_type: account_data_binding
  target_id: table.flipkart.settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0022.b3b62ada42d8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0023.dcec63e1b834
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.commission
  source_type: account_data_binding
  target_id: table.flipkart.commission
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0024.703b2014282f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0025.bbad8f2bbab6
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: platform.myntra
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0026.96d51f7abd94
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: platform_context.myntra.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0027.3a12340eca90
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0028.76d705715f3a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0029.f200d774aaf6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0030.694956dd2304
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0031.37b9d7d6b7f6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0032.5e384e6b4733
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0033.20e18db08f4b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0034.7d63ec5842d5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_non_order_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_non_order_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0035.530b569b6371
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0036.d8f648c1fdba
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0037.1f6ef0b75b82
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0038.d45350a3cc13
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: platform.meesho
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0039.0b3abfe31b74
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: platform_context.meesho.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0040.e6d363cab874
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_sales
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0041.919679084e09
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_sales
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_sales
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0042.991304daf7ee
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0043.e28daa502195
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0044.52fe62e6555a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0045.223c4891ccb7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_returns
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_returns
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0046.782bdd53bb9e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0047.afc723c53753
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0048.c742ee11af84
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_forward_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0049.c5e95650f3d3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_forward_expenses
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_forward_expenses
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0050.3201a4437906
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0051.2a7ada4054e7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse_expenses
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_reverse_expenses
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0052.ad911d8d8ae4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_other_charges_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0053.e9bb2d33c888
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_other_charges_expenses
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_other_charges_expenses
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0054.656f28968898
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_brand_mapping
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0055.76f5a8bfaafe
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_brand_mapping
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_brand_mapping
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0056.a5e99708f989
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0057.ada0823fc722
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: platform.nykaa
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0058.a18e1b0bd941
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: platform_context.nykaa_fashion.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0059.7f58b0230cea
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0060.214b85d0439a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_oms
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0061.0fca987d4d4f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0062.fe0332a24f0a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0063.ab1894db3863
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_addition_charge
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0064.8dd3abbb9c19
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_addition_charge
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_addition_charge
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0065.c50c621b0afc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapper_gst
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0066.835aa7311ff3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapper_gst
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_mapper_gst
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0067.65267038183f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapping
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0068.f1d609d8d0bf
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapping
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_mapping
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0069.0540318d633d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0070.5ab6258e0970
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  source_type: platform_account
  target_id: platform.jiomart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0071.cb55cd187ba0
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  source_type: platform_account
  target_id: platform_context.jiomart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0072.42a84aa0e617
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0073.baeb82f09521
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_oms
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0074.2d62fbcb60f0
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0075.4c27de430133
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0076.2bcb28fc6de2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0077.40fca5774e80
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_returns
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_returns
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0078.7a8c7054d6c0
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0079.8d5f27994306
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  source_type: platform_account
  target_id: platform.snapdeal
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0080.9ff544bbb5fc
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  source_type: platform_account
  target_id: platform_context.snapdeal.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0081.026c93df5ecf
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0082.8f1b22a80365
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_oms
  source_type: account_data_binding
  target_id: table.zs_observe.snapdeal_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0083.c42c85396fc3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0084.93ff79b70991
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.snapdeal_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0085.8931236b51e9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0086.9dc78673497f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_commission
  source_type: account_data_binding
  target_id: table.zs_observe.snapdeal_commission
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0087.b93fb0de6f3b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0088.4591a2b34dd4
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  source_type: platform_account
  target_id: platform.tatacliq
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0089.68d7e417d046
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  source_type: platform_account
  target_id: platform_context.tatacliq.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0090.deb8d80dc941
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0091.f477fc55d85b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_oms
  source_type: account_data_binding
  target_id: table.zs_observe.tatacliq_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0092.815adee0ccaa
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0093.15b86332e7b6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.tatacliq_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0094.44c237a80c2b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.cred_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0095.5e21e9cf2efc
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0096.46b9c3f7fe12
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.klip_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0097.ec1f911b7cd6
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0098.4fa263032403
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0099.04a573a0960b
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  source_type: platform_account
  target_id: platform.shopify
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0100.13335f9801cf
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  source_type: platform_account
  target_id: platform_context.shopify.in_and_global.d2c_oms_client_config
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0101.0a249642a18f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0102.dcd8d54d7ff3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
  source_type: account_data_binding
  target_id: table.zs_observe.shopify_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0103.c116d7d9ade2
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0104.43f0e8b37047
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  source_type: platform_account
  target_id: platform.shiprocket
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0105.ad823af0af47
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  source_type: platform_account
  target_id: platform_context.shiprocket.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0106.926f39a3bc07
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.shiprocket_order_source.primary.shiprocket_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0107.4a10a6b34792
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.shiprocket_order_source.primary.shiprocket_oms
  source_type: account_data_binding
  target_id: table.zs_observe.shiprocket_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0108.8baf9b3cb4aa
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0109.2233327e6843
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  source_type: platform_account
  target_id: platform.increff
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0110.b6fc2cf8b271
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  source_type: platform_account
  target_id: platform_context.increff.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0111.1af1af1ef5f6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_sales
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0112.7f66590e9146
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_sales
  source_type: account_data_binding
  target_id: table.zs_observe.increff_sales
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0113.70ffcbb4741c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0114.f77cce0922ee
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_returns
  source_type: account_data_binding
  target_id: table.zs_observe.increff_returns
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0115.41e542555b69
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0116.394b0358d2ab
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform.unicommerce
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0117.beed2e78bc5d
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform_context.unicommerce.in.d2c_oms
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0118.ff0582f440a2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0119.919d5396c9e0
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0120.e7bb57290ac3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0121.e077a8f75b88
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce_order_sales_report
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0122.e48d383d9801
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0123.6ae95eef34a4
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  source_type: platform_account
  target_id: platform.xpressbees
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0124.e231803e331b
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  source_type: platform_account
  target_id: platform_context.xpressbees.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0125.ccb13b318127
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.xpressbees_in.primary.xpressbees_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0126.506a5f4e2d6f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.xpressbees_in.primary.xpressbees_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.xpressbees_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0127.2bb0861ead63
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0128.3cbf6d8a852a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  source_type: platform_account
  target_id: platform.cashfree
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0129.2b437f1c86ee
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  source_type: platform_account
  target_id: platform_context.cashfree.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0130.05d2bd82dea4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.cashfree_in.primary.cashfree_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0131.f7a9ec12b17e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.cashfree_in.primary.cashfree_payin
  source_type: account_data_binding
  target_id: table.zs_observe.cashfree_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0132.c52bb7c12c3f
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0133.1d9bef4819e6
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  source_type: platform_account
  target_id: platform.phonepe
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0134.975ae653ddc4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  source_type: platform_account
  target_id: platform_context.phonepe.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0135.d87aabf797cc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  source_type: platform_account
  target_id: account_data_binding.bracheium_brand_technologies.phonepe_in.primary.phonepe_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0136.84178a38f368
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bracheium_brand_technologies.phonepe_in.primary.phonepe_payin
  source_type: account_data_binding
  target_id: table.zs_observe.phonepe_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0137.43006a9eb810
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0138.2754755b36db
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0139.649eee2e688f
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0140.950bf5ac7ccb
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0141.b569a0734308
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0142.30bf057c753b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0143.3c00da7b252c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0144.7fbfc755c49b
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0145.7cf2e17172e8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0146.1234b3a96653
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0147.b62e1d2457f5
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.canonical_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0148.d3ea713b72d1
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.marketplaces_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0149.433519f0d1f3
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.marketplaces_future_context
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.cred_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0150.6f4b119ef990
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.marketplaces_future_context
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0151.0fd515d0ee06
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.marketplaces_future_context
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.klip_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0152.9ca92a40b9e1
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.marketplaces_future_context
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0153.404bbe989c08
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.d2c_order_sources
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0154.55f395dd4085
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.d2c_order_sources
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0155.2ad499ff1a85
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.d2c_order_sources
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0156.f21f0011d261
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.operations_wms_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0157.e0a8b94f6794
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.operations_wms_oms
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0158.b573e50fadc6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.operations_wms_oms
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.increff
  - ev.bracheium_brand_technologies.docx.row.3_wms_fulfilment_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0159.73d685d74c7a
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.logistics_reconciliation
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0160.9feda127cb83
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.logistics_reconciliation
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0161.1d2ec181b5d9
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0162.0f5ab43cefce
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0163.56807f39dd94
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0164.46b5a4cc496a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0165.7e1ef3d36ab8
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_scope_set.bracheium_brand_technologies.transactions_feed_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0166.628aa416c94c
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bracheium_brand_technologies.transactions_feed_future_context
  source_type: business_scope_set
  target_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0167.e68e6b2bbfc7
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0168.3a07d4202ee5
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: business_scope_set.bracheium_brand_technologies.operations_wms_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0169.b5c48963878e
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0170.9ed867191ce2
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0171.e8a23fb28a6d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0172.b46a12822149
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0173.2cda473a2ee6
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0174.7537eecd2d35
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0175.6f64cf761c32
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0176.0ea23ebde995
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0177.ae57d6a4ffb7
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.increff_wms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0178.1f7da82352bf
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0179.63c73687d469
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0180.4647a7407460
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0181.31e9e6681a4c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0182.44774a1994c6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.amazon_in.primary.amazon_fee_preview
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0183.51a9e4e866e5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0184.030eeec50468
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0185.28e8fd0ae9ad
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0186.2685378a2dd2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0187.690e42fe21e7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0188.9a2d7ae5dac1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0189.fa02d8ad117c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0190.bc4a9b0b57df
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0191.f79e2c48ff23
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0192.cb6479c70ac9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_sales
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0193.a2dd100dafe1
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0194.200fd6e56eb8
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0195.7899c6e30141
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0196.3669f3035835
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_forward_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0197.cd808256b094
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_reverse_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0198.82db57a72ce4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_other_charges_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0199.fd037689130b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.meesho_in.primary.meesho_brand_mapping
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0200.2c4cfc55673d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0201.b28c2aa1cddc
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0202.df416a155cbd
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_addition_charge
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0203.9d5f1af08eba
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapper_gst
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0204.c6a3bdb3e411
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.nykaa_in.primary.nykaa_mapping
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0205.dd57b785dbcb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0206.b4235ff971c2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0207.bafb9a1dc4a7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.jiomart_in.primary.jiomart_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0208.7cb81020ddc7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0209.3ca46b045de4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0210.7ce302bb519d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.snapdeal_in.primary.snapdeal_commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0211.f047fa5b18e2
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0212.1a0e1fc1e9e7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.tatacliq_in.primary.tatacliq_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0213.66a44c14f6b0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_sales
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0214.f52db0a869b6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.increff_wms.primary.increff_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0215.cd2d53fc22c0
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0216.04be7e60ac40
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0217.76bd4d7f29ea
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.increff_sales
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0218.6d99e3c7b2a7
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.increff_returns
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0219.9a2587b9a428
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0220.2411b2a89338
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_to_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0221.29838c5af336
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0222.badcced61a58
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: business_scope_set.bracheium_brand_technologies.d2c_order_sources
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0223.cb62170c13ef
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0224.432f720b86b5
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.shiprocket_order_source.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0225.bc360cc896b6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0226.5a86da31b791
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.shiprocket_order_source.primary.shiprocket_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0227.2458ebc3240f
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: table.zs_observe.shopify_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0228.50b7ca631962
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.shopify_shiprocket_order_flow
  source_type: business_flow_binding
  target_id: table.zs_observe.shiprocket_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shiprocket
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0229.e65701994b22
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0230.88908be2a711
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0231.dcf8f18d2d04
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.shopify_d2c.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0232.85cafdca7725
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0233.d78b53cbfba7
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0234.96c183ca0f9c
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0235.bd84274dbba9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.shopify_d2c.primary.shopify_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0236.564188e02558
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.cashfree_in.primary.cashfree_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0237.b9874cad1ee6
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.phonepe_in.primary.phonepe_payin
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0238.ca1b26a93f66
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: table.zs_observe.shopify_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0239.97423c494e75
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: table.zs_observe.cashfree_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0240.405b3f1dc5e3
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.d2c_to_payment_gateways
  source_type: business_flow_binding
  target_id: table.zs_observe.phonepe_payin
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_d2c_other_order_sources.shopify
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.cashfree
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.phonepe
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0241.d16840762fcd
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_flow_binding.bracheium_brand_technologies.xpressbees_logistics_reconciliation
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0242.2d17ab5bf5be
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bracheium_brand_technologies.xpressbees_logistics_reconciliation
  source_type: business_flow_binding
  target_id: business_scope_set.bracheium_brand_technologies.logistics_reconciliation
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0243.2fe7220e364b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.xpressbees_logistics_reconciliation
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0244.6e52b075a5a4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bracheium_brand_technologies.xpressbees_logistics_reconciliation
  source_type: business_flow_binding
  target_id: account_data_binding.bracheium_brand_technologies.xpressbees_in.primary.xpressbees_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0245.ffe78f56cb96
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bracheium_brand_technologies.xpressbees_logistics_reconciliation
  source_type: business_flow_binding
  target_id: table.zs_observe.xpressbees_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.section.2_active_sales_channels_domestic_marketplaces
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0246.9d23cb5f7ffe
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_flow_binding.bracheium_brand_technologies.marketplace_transactions_future_context
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0247.3060cc12b1e4
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_transactions_future_context
  source_type: business_flow_binding
  target_id: business_scope_set.bracheium_brand_technologies.transactions_feed_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0248.da5667047187
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.marketplace_transactions_future_context
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0249.3d39a2407208
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bracheium_brand_technologies.mensa_brands
  source_type: group
  target_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0250.f641c2a32343
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: business_scope_set.bracheium_brand_technologies.payment_gateways
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0251.02b91b85cc16
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0252.2f66d5899000
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0253.2b29db46a6dc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0254.421897e54098
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0255.907c4591d80b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0256.63ae657c9963
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0257.acf399443f3a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0258.ef8c42cb9ab1
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0259.e418dfb31eb4
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.cashfree_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0260.106f4ce8ca5d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.phonepe_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.bracheium_brand_technologies.0261.5ab885b76441
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bracheium_brand_technologies.bank_crossing_flows_require_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bracheium_brand_technologies.xpressbees_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.nykaa
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.jiomart
```

## 7. Blocked / Non-Emitted Edges
```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.cred_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.cred
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.cred_in.primary
    edge: USES_PLATFORM
    target: platform.cred
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.cred_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.cred.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.cred_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.cred.in
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.firstcry
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.firstcry_in.primary
    edge: USES_PLATFORM
    target: platform.firstcry
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.firstcry_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.firstcry.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.firstcry_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.firstcry.in
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.klip_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.klip
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.klip_in.primary
    edge: USES_PLATFORM
    target: platform.klip
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.klip_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.klip.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.klip_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.klip.in
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.blitz
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.blitz_in.primary
    edge: USES_PLATFORM
    target: platform.blitz
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.blitz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.blitz.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.blitz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.blitz.in
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.easebuzz
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.easebuzz_in.primary
    edge: USES_PLATFORM
    target: platform.easebuzz
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.easebuzz.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.easebuzz_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.easebuzz.in
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  edge_type: USES_PLATFORM
  target_id: platform.marketplace_transactions
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
    edge: USES_PLATFORM
    target: platform.marketplace_transactions
```

```yaml
blocked_edge:
  source_id: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.marketplace_transactions.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.marketplace_transactions.in
```

## 8. Review Items
```yaml
review_item:
  item: tenant.bracheium_brand_technologies
  issue: Source text contains formatting around the client name. Tenant name normalized to Bracheium Brand Technologies Pvt
    Ltd.
  severity: low
  review_item_id: review.bracheium_brand_technologies.001
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
```

```yaml
review_item:
  item: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  issue: marketplace_transactions and transactions_report are source-confirmed, but channel routing/details need platform
    context before active binding.
  severity: high
  review_item_id: review.bracheium_brand_technologies.002
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
```

```yaml
review_item:
  item: platform_account.*
  issue: Exact seller, store, gateway, courier, and feed identifiers are not supplied in the client doc.
  severity: medium
  review_item_id: review.bracheium_brand_technologies.003
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.identity
```

```yaml
review_item:
  review_item_id: review.bracheium_brand_technologies.canonical_context_gap.001
  item: platform_account.bracheium_brand_technologies.cred_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.cred
  - platform_context.cred.in
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.cred
```

```yaml
review_item:
  review_item_id: review.bracheium_brand_technologies.canonical_context_gap.002
  item: platform_account.bracheium_brand_technologies.firstcry_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.firstcry
  - platform_context.firstcry.in
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.firstcry
```

```yaml
review_item:
  review_item_id: review.bracheium_brand_technologies.canonical_context_gap.003
  item: platform_account.bracheium_brand_technologies.klip_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.klip
  - platform_context.klip.in
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
review_item:
  review_item_id: review.bracheium_brand_technologies.canonical_context_gap.004
  item: platform_account.bracheium_brand_technologies.blitz_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.blitz
  - platform_context.blitz.in
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.klip_blitz
```

```yaml
review_item:
  review_item_id: review.bracheium_brand_technologies.canonical_context_gap.005
  item: platform_account.bracheium_brand_technologies.easebuzz_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.easebuzz
  - platform_context.easebuzz.in
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.4_payment_gateway_reconciliation.easebuzz
```

```yaml
review_item:
  review_item_id: review.bracheium_brand_technologies.canonical_context_gap.006
  item: platform_account.bracheium_brand_technologies.marketplace_transactions.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.marketplace_transactions
  - platform_context.marketplace_transactions.in
  evidence_refs:
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.amazon_india
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.flipkart
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.myntra
  - ev.bracheium_brand_technologies.docx.row.2_active_sales_channels_domestic_marketplaces.meesho
```

## 9. Refactored Validation Summary
```yaml
validation_summary:
  result: pass
  client_slug: bracheium_brand_technologies
  card_count: 79
  edge_count_emitted: 261
  blocked_edge_count: 12
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 21
    account_data_binding: 43
    business_scope_set: 7
    business_flow_binding: 6
  status_counts:
    active: 71
    draft: 8
  active_account_data_binding_count: 43
  draft_account_data_binding_count: 0
  demoted_account_data_binding_ids: []
  active_binding_missing_table_refs: []
  duplicate_card_ids: []
  edge_missing_refs_after_refactor: []
  canonical_resolution_gap_count: 6
  semantic_mapping_count: 21
  future_context_gap_count: 15
  review_item_count: 3
  source_evidence_count: 24
  shopify_source_policy: shopify_d2c_oms_v2.md is the active Shopify OMS canonical; shopify_d2c_oms.md is not used.
```
