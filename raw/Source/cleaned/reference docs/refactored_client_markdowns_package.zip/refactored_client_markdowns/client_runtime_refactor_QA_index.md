# Refactored Client Runtime Markdown Package — QA Index

This package contains the structured client runtime markdowns generated from the uploaded client JSON/DOCX inputs and the canonical platform/domain markdowns. Shopify scope uses `shopify_d2c_oms_v2.md` and excludes the earlier Shopify OMS file.

```yaml
package_validation_summary:
  generated_package: client_runtime_refactored_markdowns_v2
  generated_on: '2026-05-24'
  active_shopify_canonical: shopify_d2c_oms_v2.md
  superseded_shopify_canonical_excluded: shopify_d2c_oms.md
  canonical_cards_loaded_count: 9842
  canonical_markdown_card_counts:
    ajio_marketplace.md: 390
    amazon_marketplace.md: 348
    bank_statement.md: 421
    delhivery_logistics.md: 114
    dtdc_logistics.md: 61
    ecom_express.md: 10
    ekart_logistics.md: 58
    flipkart_marketplace.md: 291
    healthkart_marketplace.md: 438
    increff_operations.md: 406
    jiomart_marketplace.md: 384
    limeroad_marketplace.md: 314
    logistics_domain.md: 158
    logistics_reconciliation_patterns.md: 263
    meesho_marketplace.md: 718
    myntra_marketplace.md: 538
    nykaa_marketplace.md: 789
    payment_gateway.md: 1164
    shadowfax_logistics.md: 12
    shiprocket_logistics.md: 96
    shiprocket_logistics_aggregator.md: 90
    shopify_d2c_oms_v2.md: 849
    snapdeal_marketplace.md: 832
    target_plus.md: 286
    tatacliq_marketplace.md: 263
    unicommerce_d2c_oms.md: 231
    unicommerce_operations.md: 278
    walmart_marketplace.md: 282
    xpressbees_logistics.md: 34
  clients:
  - slug: ardeur_fashion
    title: Ardeur Fashion Limited
    markdown_file: ardeur_fashion_client_runtime_refactored.md
    normalized_json_file: ardeur_fashion_client_runtime_refactored.normalized.json
    result: pass
    card_count: 54
    edge_count_emitted: 179
    blocked_edge_count: 2
    demoted_account_data_binding_ids: []
    canonical_resolution_gap_count: 1
    source_evidence_count: 14
    future_context_gap_count: 5
    review_item_count: 3
  - slug: astrotalk
    title: AstroTalk
    markdown_file: astrotalk_client_runtime_refactored.md
    normalized_json_file: astrotalk_client_runtime_refactored.normalized.json
    result: pass
    card_count: 50
    edge_count_emitted: 153
    blocked_edge_count: 20
    demoted_account_data_binding_ids:
    - account_data_binding.astrotalk.amazon_in.primary.amazon_sku_master
    canonical_resolution_gap_count: 9
    source_evidence_count: 26
    future_context_gap_count: 11
    review_item_count: 3
  - slug: aza_fashions
    title: Aza Fashions Private Limited
    markdown_file: aza_fashions_client_runtime_refactored.md
    normalized_json_file: aza_fashions_client_runtime_refactored.normalized.json
    result: pass
    card_count: 34
    edge_count_emitted: 130
    blocked_edge_count: 10
    demoted_account_data_binding_ids: []
    canonical_resolution_gap_count: 5
    source_evidence_count: 18
    future_context_gap_count: 5
    review_item_count: 3
  - slug: bear_house_clothing
    title: Bear House Clothing Private Limited
    markdown_file: bear_house_clothing_client_runtime_refactored.md
    normalized_json_file: bear_house_clothing_client_runtime_refactored.normalized.json
    result: pass
    card_count: 42
    edge_count_emitted: 134
    blocked_edge_count: 4
    demoted_account_data_binding_ids: []
    canonical_resolution_gap_count: 2
    source_evidence_count: 14
    future_context_gap_count: 5
    review_item_count: 2
  - slug: bracheium_brand_technologies
    title: Bracheium Brand Technologies Pvt Ltd
    markdown_file: bracheium_brand_technologies_client_runtime_refactored.md
    normalized_json_file: bracheium_brand_technologies_client_runtime_refactored.normalized.json
    result: pass
    card_count: 79
    edge_count_emitted: 261
    blocked_edge_count: 12
    demoted_account_data_binding_ids: []
    canonical_resolution_gap_count: 6
    source_evidence_count: 24
    future_context_gap_count: 15
    review_item_count: 3
  aggregate_counts:
    cards: 259
    edges_emitted: 857
    blocked_edges: 48
    source_evidence: 96
    future_context_gaps: 41
    review_items: 14
```

## Files
- `ardeur_fashion_client_runtime_refactored.md` — Ardeur Fashion Limited; cards=54, edges=179, blocked_edges=2, result=pass
- `astrotalk_client_runtime_refactored.md` — AstroTalk; cards=50, edges=153, blocked_edges=20, result=pass
- `aza_fashions_client_runtime_refactored.md` — Aza Fashions Private Limited; cards=34, edges=130, blocked_edges=10, result=pass
- `bear_house_clothing_client_runtime_refactored.md` — Bear House Clothing Private Limited; cards=42, edges=134, blocked_edges=4, result=pass
- `bracheium_brand_technologies_client_runtime_refactored.md` — Bracheium Brand Technologies Pvt Ltd; cards=79, edges=261, blocked_edges=12, result=pass

## Important cleanup decisions
- Shopify canonical references were rewritten to `shopify_d2c_oms_v2.md`, and the old `platform_context.shopify.in.d2c_oms` was replaced by `platform_context.shopify.in_and_global.d2c_oms_client_config`.
- PayPal client country-specific contexts were mapped to the uploaded canonical `platform_context.paypal.global`; country/currency distinctions remain on the client account names and notes.
- Edges to source-observed but not-yet-canonical platform/context cards were not emitted; they are preserved as canonical resolution gaps and review items.
- AstroTalk Amazon SKU master was demoted from active account data binding to draft because the uploaded Amazon canonical markdown explicitly references it only as a related/missing table and does not provide a table card.