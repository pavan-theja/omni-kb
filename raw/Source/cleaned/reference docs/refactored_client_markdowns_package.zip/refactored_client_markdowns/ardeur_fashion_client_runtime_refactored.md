# Ardeur Fashion Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the previously JSON-shaped client runtime pack into a card/edge/evidence registry and applies canonical-platform boundary fixes against the uploaded domain markdowns. It intentionally emits only client runtime binding cards; it does not recreate platform/domain/table/metric semantics already owned by canonical markdowns.

```yaml
document_metadata:
  package_id: ardeur_fashion_business_hierarchy_runtime_cards_v1_0
  version: v1_0
  generated_date: '2026-05-24'
  created_for: Ardeur Fashion Limited
  client_slug: ardeur_fashion
  status: ready_for_review
  source_documents:
  - Ardeur Fashion Limited.docx
  - Cognee KB Design v4.md
  - ajio_marketplace.md
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - jiomart_marketplace.md
  - limeroad_marketplace.md
  - meesho_marketplace.md
  - myntra_marketplace.md
  - snapdeal_marketplace.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  source_client_profile:
    business: Multi-channel marketplace seller — India domestic only
    geography: India domestic only
    source_group_id: 65
    source_group_level_id: 221
    source_group_name: Zeal Bizfashion Ventures Private Limited
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: 'Client/runtime packs contain business hierarchy cards: tenant, group, platform_account, account_data_binding,
    business_scope_set, and business_flow_binding. Active table bindings are emitted only when the current canonical platform
    context or explicit client-table evidence supports the table. Client-mentioned artifacts without current table support
    are preserved as future_context_gaps with source text; no table mapping is fabricated.'
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  refactor_version: client_runtime_markdown_refactor_v2_structured
  refactored_on: '2026-05-24'
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  canonical_source_policy: This client layer binds tenant/group/account/runtime scope to canonical cards from the uploaded
    platform/domain markdowns. It does not recreate platform/table/domain semantics.
  docx_source_title: Ardeur Fashion Limited
```

## 0. Parser Instructions and Refactor Manifest
```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM or USES_PLATFORM_CONTEXT if the target canonical platform/context card is absent.
  - Do not emit active BINDS_TO_TABLE edges for missing canonical table cards.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
```

```yaml
clean_refactor_manifest:
  source_json: ardeur_fashion.json
  source_docx: Ardeur Fashion Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9842
  corrections_applied:
  - No source-document/id replacement corrections were needed beyond standard structuring.
  id_replacement_hits: []
  demoted_binding_ids: []
  blocked_edge_count: 2
  canonical_resolution_gap_count: 1
```

## 1. Source Intake and Evidence Registry
```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.identity
  source_document: Ardeur Fashion Limited.docx
  source_section: 1. Identity
  evidence_type: docx_section
  summary: Client identity, business model, group identifiers, configured operational stack, and region/currency hints from
    the client DOCX.
  raw_lines:
  - '* Business: Multi-channel marketplace seller — India domestic only'
  - '* OMS/WMS: Unicommerce (primary order management)'
  - '* No D2C / Shopify channel configured'
  - '* No logistics settlement files configured (courier reconciliation not in scope)'
  - '* No payment gateway files configured'
  - '* GROUP LEVEL ID :  221'
  - '* GROUP ID :  65'
  - '* GROUP NAME : **Zeal Bizfashion Ventures Private Limited**'
  - '* CLIENT NAME : **Ardeur Fashion Limited**'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.section.2_active_sales_channels
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads) |'
  - '| Myntra  | OMS (JIT + PPMP), Seller reports (JIT + PPMP + SJIT), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
    (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return |'
  - '| Meesho  | Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment, Adhoc (Ads, Referral)
    |'
  - '| Ajio    | OMS (order report), Settlement, Credit note, Returns/reverse |'
  - '| JioMart | OMS, Shipment report, Settlement, Returns |'
  - '| Snapdeal | OMS, Settlement, Commission file (multi-sheet) |'
  - '| Tata Cliq | OMS, Settlement       |'
  - '| Limeroad | OMS, Settlement (multi-sheet), Adjustment/Adhoc |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.section.3_oms_layer
  source_document: Ardeur Fashion Limited.docx
  source_section: 3. OMS layer
  evidence_type: docx_section
  summary: Client DOCX section covering 3. OMS layer.
  raw_lines:
  - '| System | Files configured |'
  - '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  - '| Zeal   | Item master (SKU/product mapping) |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Disbursement
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement |'
  source_line_number_in_docx_text_extract: 15
  summary: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads) |'
  source_line_number_in_docx_text_extract: 16
  summary: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (JIT + PPMP), Seller reports (JIT + PPMP + SJIT), Fwd/Rev settlement (JIT + PPMP), Non-order
      settlement (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return
  raw_text: '| Myntra  | OMS (JIT + PPMP), Seller reports (JIT + PPMP + SJIT), Fwd/Rev settlement (JIT + PPMP), Non-order
    settlement (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return |'
  source_line_number_in_docx_text_extract: 17
  summary: 'Myntra: OMS (JIT + PPMP), Seller reports (JIT + PPMP + SJIT), Fwd/Rev settlement (JIT + PPMP), Non-order settlement
    (JIT + PPMP), Non-order expenses, Returns/RTO (JIT + PPMP), JIT GSTR return'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Meesho
  columns:
    channel: Meesho
    data_types_configured: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment, Adhoc
      (Ads, Referral)
  raw_text: '| Meesho  | Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment, Adhoc (Ads,
    Referral) |'
  source_line_number_in_docx_text_extract: 18
  summary: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment, Adhoc (Ads,
    Referral)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Ajio
  columns:
    channel: Ajio
    data_types_configured: OMS (order report), Settlement, Credit note, Returns/reverse
  raw_text: '| Ajio    | OMS (order report), Settlement, Credit note, Returns/reverse |'
  source_line_number_in_docx_text_extract: 19
  summary: 'Ajio: OMS (order report), Settlement, Credit note, Returns/reverse'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: JioMart
  columns:
    channel: JioMart
    data_types_configured: OMS, Shipment report, Settlement, Returns
  raw_text: '| JioMart | OMS, Shipment report, Settlement, Returns |'
  source_line_number_in_docx_text_extract: 20
  summary: 'JioMart: OMS, Shipment report, Settlement, Returns'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Snapdeal
  columns:
    channel: Snapdeal
    data_types_configured: OMS, Settlement, Commission file (multi-sheet)
  raw_text: '| Snapdeal | OMS, Settlement, Commission file (multi-sheet) |'
  source_line_number_in_docx_text_extract: 21
  summary: 'Snapdeal: OMS, Settlement, Commission file (multi-sheet)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Tata Cliq
  columns:
    channel: Tata Cliq
    data_types_configured: OMS, Settlement
  raw_text: '| Tata Cliq | OMS, Settlement       |'
  source_line_number_in_docx_text_extract: 22
  summary: 'Tata Cliq: OMS, Settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
  source_document: Ardeur Fashion Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Limeroad
  columns:
    channel: Limeroad
    data_types_configured: OMS, Settlement (multi-sheet), Adjustment/Adhoc
  raw_text: '| Limeroad | OMS, Settlement (multi-sheet), Adjustment/Adhoc |'
  source_line_number_in_docx_text_extract: 23
  summary: 'Limeroad: OMS, Settlement (multi-sheet), Adjustment/Adhoc'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
  source_document: Ardeur Fashion Limited.docx
  source_section: 3. OMS layer
  evidence_type: configured_source_row
  row_key: Unicommerce
  columns:
    system: Unicommerce
    files_configured: Sales, Returns, Cancellations, Sales order report
  raw_text: '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  source_line_number_in_docx_text_extract: 27
  summary: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
  confidence: high
```

```yaml
source_evidence:
  id: ev.ardeur_fashion.docx.row.3_oms_layer.zeal
  source_document: Ardeur Fashion Limited.docx
  source_section: 3. OMS layer
  evidence_type: configured_source_row
  row_key: Zeal
  columns:
    system: Zeal
    files_configured: Item master (SKU/product mapping)
  raw_text: '| Zeal   | Item master (SKU/product mapping) |'
  source_line_number_in_docx_text_extract: 28
  summary: 'Zeal: Item master (SKU/product mapping)'
  confidence: high
```

## 2. Client Runtime Candidate Cards
### 2.1 Tenant Cards
```yaml
candidate_card:
  card_type: tenant
  card_id: tenant.ardeur_fashion
  name: Ardeur Fashion Limited
  fields:
    tenant_name: Ardeur Fashion Limited
    tenant_code: ARDEUR
    description: India domestic multi-channel marketplace seller using ZenStatement for marketplace settlement, marketplace
      order/return analytics, Unicommerce OMS, and SKU/product mapping reasoning.
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    evidence_refs:
    - ev.ardeur_fashion.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.2 Group Cards
```yaml
candidate_card:
  card_type: group
  card_id: group.ardeur_fashion.zeal_bizfashion_ventures
  name: Zeal Bizfashion Ventures Private Limited
  fields:
    tenant_id: tenant.ardeur_fashion
    group_name: Zeal Bizfashion Ventures Private Limited
    group_code: ZEAL_BIZFASHION
    group_type: legal_entity
    business_meaning: Zeal Bizfashion Ventures Private Limited operating/legal group for Ardeur Fashion marketplace commerce
      operations.
    country_or_region: India
    default_currency: INR
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    - Cognee KB Design v4.md
    source_scope_identifiers:
      group_id: 65
      group_level_id: 221
      representation_rule: Use these only through Account Data Binding scope_keys.
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    evidence_refs:
    - ev.ardeur_fashion.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.3 Platform Account Cards
```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.amazon_in.primary
  name: Ardeur Amazon India Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Ardeur Amazon India Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: amazon_marketplace.md
      platform_context_id_source_file: amazon_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.flipkart_in.primary
  name: Ardeur Flipkart Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Ardeur Flipkart Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: flipkart_marketplace.md
      platform_context_id_source_file: flipkart_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.myntra_in.primary
  name: Ardeur Myntra Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: Ardeur Myntra Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: myntra_marketplace.md
      platform_context_id_source_file: myntra_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.meesho_in.primary
  name: Ardeur Meesho Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.meesho
    platform_context_id: platform_context.meesho.in
    account_name: Ardeur Meesho Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: meesho_marketplace.md
      platform_context_id_source_file: meesho_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.ajio_in.primary
  name: Ardeur AJIO Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.ajio
    platform_context_id: platform_context.ajio.in
    account_name: Ardeur AJIO Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'AJIO: OMS order report, Settlement, Credit note, Returns/reverse'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: ajio_marketplace.md
      platform_context_id_source_file: ajio_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.jiomart_in.primary
  name: Ardeur JioMart Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.jiomart
    platform_context_id: platform_context.jiomart.in
    account_name: Ardeur JioMart Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'JioMart: OMS, Shipment report, Settlement, Returns'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: jiomart_marketplace.md
      platform_context_id_source_file: jiomart_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.snapdeal_in.primary
  name: Ardeur Snapdeal Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.snapdeal
    platform_context_id: platform_context.snapdeal.in
    account_name: Ardeur Snapdeal Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file multi-sheet'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: snapdeal_marketplace.md
      platform_context_id_source_file: snapdeal_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.tatacliq_in.primary
  name: Ardeur Tata Cliq Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.tatacliq
    platform_context_id: platform_context.tatacliq.in
    account_name: Ardeur Tata Cliq Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Tata Cliq: OMS, Settlement'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: tatacliq_marketplace.md
      platform_context_id_source_file: tatacliq_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.limeroad_in.primary
  name: Ardeur LimeRoad Seller Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.limeroad
    platform_context_id: platform_context.limeroad.in
    account_name: Ardeur LimeRoad Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Limeroad: OMS, Settlement multi-sheet, Adjustment/Adhoc'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: limeroad_marketplace.md
      platform_context_id_source_file: limeroad_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  name: Ardeur Unicommerce OMS Account
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.unicommerce
    platform_context_id: platform_context.unicommerce.in.d2c_oms
    account_name: Ardeur Unicommerce OMS Account
    account_type: oms_account
    account_role: oms_source
    source_account_identifier: null
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: unicommerce_operations.md
      platform_context_id_source_file: unicommerce_d2c_oms.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.ardeur_fashion.zeal_item_master.primary
  name: Ardeur Zeal Item Master Source
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    platform_id: platform.zeal_item_master
    platform_context_id: platform_context.zeal_item_master.in
    account_name: Ardeur Zeal Item Master Source
    account_type: reference_data_account
    account_role: sku_product_reference
    source_account_identifier: null
    source_config_text: 'Zeal: Item master (SKU/product mapping)'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.3_oms_layer.zeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

### 2.4 Account Data Binding Cards
```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_oms
  name: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    notes:
    - Bind platform_account.ardeur_fashion.amazon_in.primary to table.zs_observe.amazon_oms using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_settlement
  name: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    notes:
    - Bind platform_account.ardeur_fashion.amazon_in.primary to table.zs_observe.amazon_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_disbursment
  name: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_disbursment
  fields:
    platform_account_id: platform_account.ardeur_fashion.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    notes:
    - Bind platform_account.ardeur_fashion.amazon_in.primary to table.zs_observe.amazon_disbursment using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - amazon_marketplace.md
    registry_notes:
    - Canonical source uses the spelling disbursment.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.flipkart_in.primary.oms
  name: account_data_binding.ardeur_fashion.flipkart_in.primary.oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
    table_id: table.flipkart.oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.ardeur_fashion.flipkart_in.primary to table.flipkart.oms using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.flipkart_in.primary.cashback
  name: account_data_binding.ardeur_fashion.flipkart_in.primary.cashback
  fields:
    platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
    table_id: table.flipkart.cashback
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.ardeur_fashion.flipkart_in.primary to table.flipkart.cashback using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.flipkart_in.primary.settlement
  name: account_data_binding.ardeur_fashion.flipkart_in.primary.settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.ardeur_fashion.flipkart_in.primary to table.flipkart.settlement using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.flipkart_in.primary.commission
  name: account_data_binding.ardeur_fashion.flipkart_in.primary.commission
  fields:
    platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
    table_id: table.flipkart.commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.ardeur_fashion.flipkart_in.primary to table.flipkart.commission using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms
  name: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return'
    notes:
    - Bind platform_account.ardeur_fashion.myntra_in.primary to table.zs_observe.myntra_oms using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_settlement
  name: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return'
    notes:
    - Bind platform_account.ardeur_fashion.myntra_in.primary to table.zs_observe.myntra_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_reverse
  name: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_reverse
  fields:
    platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return'
    notes:
    - Bind platform_account.ardeur_fashion.myntra_in.primary to table.zs_observe.myntra_reverse using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_non_order_settlement
  name: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_non_order_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return'
    notes:
    - Bind platform_account.ardeur_fashion.myntra_in.primary to table.zs_observe.myntra_non_order_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms_settlement
  name: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
      Returns/RTO, JIT GSTR return'
    notes:
    - Bind platform_account.ardeur_fashion.myntra_in.primary to table.zs_observe.myntra_oms_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - myntra_marketplace.md
    registry_notes:
    - Partial reconciliation-helper table; bind only when explicit OMS-settlement diagnostics are needed.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_sales
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_sales
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_sales
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_sales using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_settlement
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_returns
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_returns
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_returns using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_reverse using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_forward_expenses
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_forward_expenses
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_forward_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_forward_expenses using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse_expenses
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse_expenses
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_reverse_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_reverse_expenses using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_other_charges_expenses
  name: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_other_charges_expenses
  fields:
    platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
    table_id: table.zs_observe.meesho_other_charges_expenses
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment,
      Adhoc Ads/Referral'
    notes:
    - Bind platform_account.ardeur_fashion.meesho_in.primary to table.zs_observe.meesho_other_charges_expenses using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - meesho_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: meesho_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_oms
  name: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
    table_id: table.zs_observe.ajio_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'AJIO: OMS order report, Settlement, Credit note, Returns/reverse'
    notes:
    - Bind platform_account.ardeur_fashion.ajio_in.primary to table.zs_observe.ajio_oms using client-level group_id and group_level_id
      scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_settlement
  name: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
    table_id: table.zs_observe.ajio_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'AJIO: OMS order report, Settlement, Credit note, Returns/reverse'
    notes:
    - Bind platform_account.ardeur_fashion.ajio_in.primary to table.zs_observe.ajio_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_credit_note
  name: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_credit_note
  fields:
    platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
    table_id: table.zs_observe.ajio_credit_note
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'AJIO: OMS order report, Settlement, Credit note, Returns/reverse'
    notes:
    - Bind platform_account.ardeur_fashion.ajio_in.primary to table.zs_observe.ajio_credit_note using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_reverse
  name: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_reverse
  fields:
    platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
    table_id: table.zs_observe.ajio_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'AJIO: OMS order report, Settlement, Credit note, Returns/reverse'
    notes:
    - Bind platform_account.ardeur_fashion.ajio_in.primary to table.zs_observe.ajio_reverse using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_oms
  name: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
    table_id: table.zs_observe.jiomart_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'JioMart: OMS, Shipment report, Settlement, Returns'
    notes:
    - Bind platform_account.ardeur_fashion.jiomart_in.primary to table.zs_observe.jiomart_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_shipment
  name: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_shipment
  fields:
    platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
    table_id: table.zs_observe.jiomart_shipment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'JioMart: OMS, Shipment report, Settlement, Returns'
    notes:
    - Bind platform_account.ardeur_fashion.jiomart_in.primary to table.zs_observe.jiomart_shipment using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_settlement
  name: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
    table_id: table.zs_observe.jiomart_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'JioMart: OMS, Shipment report, Settlement, Returns'
    notes:
    - Bind platform_account.ardeur_fashion.jiomart_in.primary to table.zs_observe.jiomart_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_returns
  name: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_returns
  fields:
    platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
    table_id: table.zs_observe.jiomart_returns
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'JioMart: OMS, Shipment report, Settlement, Returns'
    notes:
    - Bind platform_account.ardeur_fashion.jiomart_in.primary to table.zs_observe.jiomart_returns using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - jiomart_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: jiomart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_oms
  name: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file multi-sheet'
    notes:
    - Bind platform_account.ardeur_fashion.snapdeal_in.primary to table.zs_observe.snapdeal_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - snapdeal_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: snapdeal_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_settlement
  name: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file multi-sheet'
    notes:
    - Bind platform_account.ardeur_fashion.snapdeal_in.primary to table.zs_observe.snapdeal_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - snapdeal_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: snapdeal_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_commission
  name: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_commission
  fields:
    platform_account_id: platform_account.ardeur_fashion.snapdeal_in.primary
    table_id: table.zs_observe.snapdeal_commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Snapdeal: OMS, Settlement, Commission file multi-sheet'
    notes:
    - Bind platform_account.ardeur_fashion.snapdeal_in.primary to table.zs_observe.snapdeal_commission using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - snapdeal_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: snapdeal_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_oms
  name: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Tata Cliq: OMS, Settlement'
    notes:
    - Bind platform_account.ardeur_fashion.tatacliq_in.primary to table.zs_observe.tatacliq_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - tatacliq_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: tatacliq_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_settlement
  name: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Tata Cliq: OMS, Settlement'
    notes:
    - Bind platform_account.ardeur_fashion.tatacliq_in.primary to table.zs_observe.tatacliq_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - tatacliq_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: tatacliq_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_oms
  name: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_oms
  fields:
    platform_account_id: platform_account.ardeur_fashion.limeroad_in.primary
    table_id: table.zs_observe.limeroad_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Limeroad: OMS, Settlement multi-sheet, Adjustment/Adhoc'
    notes:
    - Bind platform_account.ardeur_fashion.limeroad_in.primary to table.zs_observe.limeroad_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - limeroad_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: limeroad_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_settlement
  name: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_settlement
  fields:
    platform_account_id: platform_account.ardeur_fashion.limeroad_in.primary
    table_id: table.zs_observe.limeroad_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Limeroad: OMS, Settlement multi-sheet, Adjustment/Adhoc'
    notes:
    - Bind platform_account.ardeur_fashion.limeroad_in.primary to table.zs_observe.limeroad_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - limeroad_marketplace.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: limeroad_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce
  name: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce
  fields:
    platform_account_id: platform_account.ardeur_fashion.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    notes:
    - Bind platform_account.ardeur_fashion.unicommerce_oms.primary to table.zs_observe.unicommerce using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce_order_sales_report
  name: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce_order_sales_report
  fields:
    platform_account_id: platform_account.ardeur_fashion.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce_order_sales_report
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 65
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 221
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    notes:
    - Bind platform_account.ardeur_fashion.unicommerce_oms.primary to table.zs_observe.unicommerce_order_sales_report using
      client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Ardeur Fashion Limited.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

### 2.5 Business Scope Set Cards
```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  name: Ardeur Domestic Marketplace Accounts
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    scope_name: Ardeur Domestic Marketplace Accounts
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.ardeur_fashion.amazon_in.primary
    - platform_account.ardeur_fashion.flipkart_in.primary
    - platform_account.ardeur_fashion.myntra_in.primary
    - platform_account.ardeur_fashion.meesho_in.primary
    - platform_account.ardeur_fashion.ajio_in.primary
    - platform_account.ardeur_fashion.jiomart_in.primary
    - platform_account.ardeur_fashion.snapdeal_in.primary
    - platform_account.ardeur_fashion.tatacliq_in.primary
    - platform_account.ardeur_fashion.limeroad_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    - platform.meesho
    - platform.ajio
    - platform.jiomart
    - platform.snapdeal
    - platform.tatacliq
    - platform.limeroad
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    - platform_context.meesho.in
    - platform_context.ajio.in
    - platform_context.jiomart.in
    - platform_context.snapdeal.in
    - platform_context.tatacliq.in
    - platform_context.limeroad.in
    description: India domestic marketplace scope across configured seller accounts.
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.ardeur_fashion.unicommerce_oms
  name: Ardeur Unicommerce OMS
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    scope_name: Ardeur Unicommerce OMS
    scope_type: single_account
    platform_account_ids:
    - platform_account.ardeur_fashion.unicommerce_oms.primary
    platform_ids:
    - platform.unicommerce
    platform_context_ids:
    - platform_context.unicommerce.in.d2c_oms
    description: Unicommerce OMS/order/shipment reporting scope.
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.ardeur_fashion.reference_data_future_context
  name: Ardeur Reference Data Future Context
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    scope_name: Ardeur Reference Data Future Context
    scope_type: reference_data_scope
    platform_account_ids:
    - platform_account.ardeur_fashion.zeal_item_master.primary
    platform_ids:
    - platform.zeal_item_master
    platform_context_ids:
    - platform_context.zeal_item_master.in
    description: Source-confirmed item master scope requiring table/context authoring.
    active: false
    status: draft
    source_documents:
    - Ardeur Fashion Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.ardeur_fashion.docx.row.3_oms_layer.zeal
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

### 2.6 Business Flow Binding Cards
```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  name: Ardeur Marketplace to Unicommerce Operations
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    binding_name: Ardeur Marketplace to Unicommerce Operations
    binding_type: operational_flow
    business_scope_set_id: business_scope_set.ardeur_fashion.unicommerce_oms
    money_flow_paths:
    - marketplace_to_oms_operations
    - order_to_shipment
    participating_accounts:
    - platform_account_id: platform_account.ardeur_fashion.amazon_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.snapdeal_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.tatacliq_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.limeroad_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.unicommerce_oms.primary
      role: oms_operations_source
      required: true
    evidence_table_ids:
    - table.zs_observe.unicommerce
    - table.zs_observe.unicommerce_order_sales_report
    account_data_binding_ids:
    - account_data_binding.ardeur_fashion.amazon_in.primary.amazon_oms
    - account_data_binding.ardeur_fashion.amazon_in.primary.amazon_settlement
    - account_data_binding.ardeur_fashion.amazon_in.primary.amazon_disbursment
    - account_data_binding.ardeur_fashion.flipkart_in.primary.oms
    - account_data_binding.ardeur_fashion.flipkart_in.primary.cashback
    - account_data_binding.ardeur_fashion.flipkart_in.primary.settlement
    - account_data_binding.ardeur_fashion.flipkart_in.primary.commission
    - account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms
    - account_data_binding.ardeur_fashion.myntra_in.primary.myntra_settlement
    - account_data_binding.ardeur_fashion.myntra_in.primary.myntra_reverse
    - account_data_binding.ardeur_fashion.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_sales
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_settlement
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_returns
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_forward_expenses
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse_expenses
    - account_data_binding.ardeur_fashion.meesho_in.primary.meesho_other_charges_expenses
    - account_data_binding.ardeur_fashion.ajio_in.primary.ajio_oms
    - account_data_binding.ardeur_fashion.ajio_in.primary.ajio_settlement
    - account_data_binding.ardeur_fashion.ajio_in.primary.ajio_credit_note
    - account_data_binding.ardeur_fashion.ajio_in.primary.ajio_reverse
    - account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_oms
    - account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_shipment
    - account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_settlement
    - account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_returns
    - account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_oms
    - account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_settlement
    - account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_commission
    - account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_oms
    - account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_settlement
    - account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_oms
    - account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_settlement
    - account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce
    - account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce_order_sales_report
    business_process_ids:
    - business_process.order_to_shipment_flow
    reconciliation_profile_ids:
    - reconciliation_profile.order_to_shipment
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - Ardeur Fashion Limited.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  name: Ardeur Marketplace Settlement to Bank Requires Bank Binding
  fields:
    tenant_id: tenant.ardeur_fashion
    group_id: group.ardeur_fashion.zeal_bizfashion_ventures
    binding_name: Ardeur Marketplace Settlement to Bank Requires Bank Binding
    binding_type: money_flow
    business_scope_set_id: business_scope_set.ardeur_fashion.domestic_marketplaces
    money_flow_paths:
    - marketplace_to_bank
    participating_accounts:
    - platform_account_id: platform_account.ardeur_fashion.amazon_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.snapdeal_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.tatacliq_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.ardeur_fashion.limeroad_in.primary
      role: settlement_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: inferred
    active: false
    status: draft
    source_documents:
    - Ardeur Fashion Limited.docx
    - Cognee KB Design v4.md
    notes:
    - The client doc has no bank account or bank-statement binding. Keep the cross-domain bank flow inactive until bank destination
      evidence is provided.
    evidence_refs:
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
    - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

## 3. Semantic Mappings
```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.amazon_in.primary
  client_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
  canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.flipkart_in.primary
  client_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  canonical_mapped_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  future_platform_context_gaps:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.myntra_in.primary
  client_config_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses,
    Returns/RTO, JIT GSTR return'
  canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  future_platform_context_gaps:
  - Myntra seller reports JIT/PPMP/SJIT
  - Myntra non-order expenses detail
  - Myntra JIT GSTR return
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.meesho_in.primary
  client_config_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment, Adhoc
    Ads/Referral'
  canonical_mapped_now:
  - table.zs_observe.meesho_sales
  - table.zs_observe.meesho_settlement
  - table.zs_observe.meesho_returns
  - table.zs_observe.meesho_reverse
  - table.zs_observe.meesho_forward_expenses
  - table.zs_observe.meesho_reverse_expenses
  - table.zs_observe.meesho_other_charges_expenses
  future_platform_context_gaps:
  - Meesho adjustment detail
  - Meesho adhoc ads/referral detail
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.ajio_in.primary
  client_config_text: 'AJIO: OMS order report, Settlement, Credit note, Returns/reverse'
  canonical_mapped_now:
  - table.zs_observe.ajio_oms
  - table.zs_observe.ajio_settlement
  - table.zs_observe.ajio_credit_note
  - table.zs_observe.ajio_reverse
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.jiomart_in.primary
  client_config_text: 'JioMart: OMS, Shipment report, Settlement, Returns'
  canonical_mapped_now:
  - table.zs_observe.jiomart_oms
  - table.zs_observe.jiomart_shipment
  - table.zs_observe.jiomart_settlement
  - table.zs_observe.jiomart_returns
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.snapdeal_in.primary
  client_config_text: 'Snapdeal: OMS, Settlement, Commission file multi-sheet'
  canonical_mapped_now:
  - table.zs_observe.snapdeal_oms
  - table.zs_observe.snapdeal_settlement
  - table.zs_observe.snapdeal_commission
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.tatacliq_in.primary
  client_config_text: 'Tata Cliq: OMS, Settlement'
  canonical_mapped_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.limeroad_in.primary
  client_config_text: 'Limeroad: OMS, Settlement multi-sheet, Adjustment/Adhoc'
  canonical_mapped_now:
  - table.zs_observe.limeroad_oms
  - table.zs_observe.limeroad_settlement
  future_platform_context_gaps:
  - Limeroad adjustment/adhoc detail
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  client_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
  canonical_mapped_now:
  - table.zs_observe.unicommerce
  - table.zs_observe.unicommerce_order_sales_report
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.ardeur_fashion.zeal_item_master.primary
  client_config_text: 'Zeal: Item master (SKU/product mapping)'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - Zeal item master SKU/product mapping table
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

## 4. Future Context Gaps
```yaml
future_context_gap:
  platform_or_area: Ardeur Flipkart Seller Account
  missing_artifacts:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Ardeur Myntra Seller Account
  missing_artifacts:
  - Myntra seller reports JIT/PPMP/SJIT
  - Myntra non-order expenses detail
  - Myntra JIT GSTR return
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Myntra: OMS (JIT + PPMP), Seller reports, Fwd/Rev settlement, Non-order settlement, Non-order expenses, Returns/RTO,
    JIT GSTR return'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Ardeur Meesho Seller Account
  missing_artifacts:
  - Meesho adjustment detail
  - Meesho adhoc ads/referral detail
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Meesho: Sales/OMS, Settlement, Returns, Reverse/RTO, Fwd/Rev expenses, Other charges, Adjustment, Adhoc Ads/Referral'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Ardeur LimeRoad Seller Account
  missing_artifacts:
  - Limeroad adjustment/adhoc detail
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Limeroad: OMS, Settlement multi-sheet, Adjustment/Adhoc'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Zeal item master
  missing_artifacts:
  - Zeal item master SKU/product mapping table
  impact: SKU/product mapping cannot be actively bound until a table card/source schema is available.
  source_text: 'Zeal: Item master (SKU/product mapping)'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

## 5. Canonical Resolution Gaps
```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.ardeur_fashion.zeal_item_master.primary
  source_config_text: 'Zeal: Item master (SKU/product mapping)'
  missing_or_unresolved_refs:
  - platform.zeal_item_master
  - platform_context.zeal_item_master.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

## 6. Candidate Edge Registry
```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0001.f40e337dcd26
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_id: tenant.ardeur_fashion
  source_type: tenant
  target_id: group.ardeur_fashion.zeal_bizfashion_ventures
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0002.ba997e5dd474
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0003.03e74b3c340c
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.amazon_in.primary
  source_type: platform_account
  target_id: platform.amazon
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0004.2d42b5245935
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.amazon_in.primary
  source_type: platform_account
  target_id: platform_context.amazon.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0005.3074948c56ee
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0006.8a3003952e7c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_oms
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0007.9c45cb432c10
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0008.fda9d2b0f47c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0009.e5e9ca2ef1b2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0010.a122f8eecaac
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_disbursment
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_disbursment
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0011.37715d96e338
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0012.13adea093809
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.flipkart_in.primary
  source_type: platform_account
  target_id: platform.flipkart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0013.5c2b6b70951a
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.flipkart_in.primary
  source_type: platform_account
  target_id: platform_context.flipkart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0014.3b1bd2ef1406
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0015.5ea32e71fdd6
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.flipkart_in.primary.oms
  source_type: account_data_binding
  target_id: table.flipkart.oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0016.b70e69ddce5a
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0017.747fd9866209
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.flipkart_in.primary.cashback
  source_type: account_data_binding
  target_id: table.flipkart.cashback
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0018.b62d02938981
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0019.9c466aae6c3b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.flipkart_in.primary.settlement
  source_type: account_data_binding
  target_id: table.flipkart.settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0020.7b353e85b775
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0021.0447c916c2fe
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.flipkart_in.primary.commission
  source_type: account_data_binding
  target_id: table.flipkart.commission
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0022.dbab07240ceb
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0023.696289f06a13
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: platform.myntra
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0024.3057c1d56397
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: platform_context.myntra.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0025.23f56ab7cb9f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0026.9103b249ec94
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0027.1f5a335e5d3c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0028.4f06a267fc73
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0029.ecbf0a2b72df
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0030.9b9c33a81207
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0031.7e4690ea755d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0032.10cc5ae9153a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_non_order_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_non_order_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0033.3317f47957dc
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0034.f59a11c51d2b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0035.6ac49a2a6ec7
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0036.007396c84c18
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: platform.meesho
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0037.5aea79817847
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: platform_context.meesho.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0038.c19ac29eb9a0
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_sales
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0039.cebab6d9e904
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_sales
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_sales
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0040.1d06cf9f9d59
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0041.c9547dcf5e61
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0042.3bb7f387d8c6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0043.e208177d42fb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_returns
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_returns
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0044.24a3b41da4fd
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0045.146f2331d90d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0046.7ef8bcb5f900
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_forward_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0047.f45e931ab011
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_forward_expenses
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_forward_expenses
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0048.5c230ac28fea
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0049.f3618ab952f9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse_expenses
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_reverse_expenses
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0050.a278a1169ed4
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.meesho_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_other_charges_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0051.3d392dd1d34c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_other_charges_expenses
  source_type: account_data_binding
  target_id: table.zs_observe.meesho_other_charges_expenses
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0052.322a3b7f1f87
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0053.7275bc8dcfcb
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.ajio_in.primary
  source_type: platform_account
  target_id: platform.ajio
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0054.5e1d2f665d73
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.ajio_in.primary
  source_type: platform_account
  target_id: platform_context.ajio.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0055.f65b1955f449
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0056.69bb751a7a37
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_oms
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0057.151b675c9186
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0058.705f1e8127e3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0059.19af703938d9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_credit_note
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0060.9716ff17c96a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_credit_note
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_credit_note
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0061.6f7bae612baf
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0062.5641f2b3e470
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0063.c1b906623428
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0064.dae27ce32433
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.jiomart_in.primary
  source_type: platform_account
  target_id: platform.jiomart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0065.97fb86e8e678
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.jiomart_in.primary
  source_type: platform_account
  target_id: platform_context.jiomart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0066.29797c3a4ae3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0067.b3929a830e05
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_oms
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0068.f91a2dca94d7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_shipment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0069.98d6505ccc9a
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_shipment
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_shipment
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0070.e4ef76efe019
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0071.865e38a45549
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0072.752c527e999c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.jiomart_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0073.165ffac9f1dd
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_returns
  source_type: account_data_binding
  target_id: table.zs_observe.jiomart_returns
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0074.27435e457bfc
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0075.9842368aa233
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.snapdeal_in.primary
  source_type: platform_account
  target_id: platform.snapdeal
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0076.b4fb0fd35200
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.snapdeal_in.primary
  source_type: platform_account
  target_id: platform_context.snapdeal.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0077.02262a432e55
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.snapdeal_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0078.72ce2fba630b
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_oms
  source_type: account_data_binding
  target_id: table.zs_observe.snapdeal_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0079.5434b776ef49
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.snapdeal_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0080.74de970e4d0e
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.snapdeal_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0081.c9503c306f83
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.snapdeal_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0082.b7e94ab1d1f7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_commission
  source_type: account_data_binding
  target_id: table.zs_observe.snapdeal_commission
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.snapdeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0083.bcb4d1c2792b
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0084.545641a29a8a
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.tatacliq_in.primary
  source_type: platform_account
  target_id: platform.tatacliq
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0085.de01d91b36a8
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.tatacliq_in.primary
  source_type: platform_account
  target_id: platform_context.tatacliq.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0086.b24492e8118e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.tatacliq_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0087.4ad15ede2ec9
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_oms
  source_type: account_data_binding
  target_id: table.zs_observe.tatacliq_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0088.139f70b4a3eb
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.tatacliq_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0089.e967383a2c53
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.tatacliq_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0090.ae7b1b71a14c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.limeroad_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0091.2b3f318eefc2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.limeroad_in.primary
  source_type: platform_account
  target_id: platform.limeroad
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0092.967533db6e52
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.limeroad_in.primary
  source_type: platform_account
  target_id: platform_context.limeroad.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0093.70a1c0913950
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.limeroad_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0094.bdedcd358ee7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_oms
  source_type: account_data_binding
  target_id: table.zs_observe.limeroad_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0095.793a0f630464
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.limeroad_in.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0096.00df1c84a5a3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.limeroad_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.limeroad
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0097.a478ee6c7f81
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0098.d985e1389cb1
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform.unicommerce
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0099.4049af504a05
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform_context.unicommerce.in.d2c_oms
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0100.8d5aee4693c5
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0101.a958a06a638c
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0102.b5016ad88f92
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0103.f483e9ab8afb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce_order_sales_report
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0104.7e82571b3f08
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: platform_account.ardeur_fashion.zeal_item_master.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.3_oms_layer.zeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0105.4b448bfcded9
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0106.2f4228064611
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0107.6447be84b00e
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0108.65a141aa5860
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0109.b229523ca950
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0110.5c25cb793efd
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0111.a8829d948192
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0112.8614fe059993
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0113.4808b0ddc6c2
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0114.eb83d130f4e6
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.limeroad_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0115.3b4542c7bdef
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: business_scope_set.ardeur_fashion.unicommerce_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0116.0d6dfbbd9d59
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.unicommerce_oms
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0117.9dcfd747c162
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: business_scope_set.ardeur_fashion.reference_data_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.3_oms_layer.zeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0118.9b49d24d59a4
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.ardeur_fashion.reference_data_future_context
  source_type: business_scope_set
  target_id: platform_account.ardeur_fashion.zeal_item_master.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.zeal
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0119.fce4e7a3a27d
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0120.bff2c9c061bb
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: business_scope_set.ardeur_fashion.unicommerce_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0121.2744244548dc
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0122.d28dfa6c06aa
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0123.5746af1ef9d4
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0124.dace82b2322a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0125.85520f604805
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0126.f7e703e4abf8
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0127.4d7499f8113d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0128.3f4e7e0be588
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0129.22c1fe5b9401
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.limeroad_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0130.997c0aee409d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0131.f67efa425a99
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0132.57e684682f1b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0133.1d0077e219ce
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0134.0ea4d25d9e2f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0135.7e9d06cc58cc
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0136.72269c56b116
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0137.6a794aa39102
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0138.8eab551f75c5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0139.4d01d8850072
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0140.1d138b80bf98
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0141.9cda4ec71c31
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0142.b005b54fd8ac
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0143.43e29e2f586b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_sales
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0144.b6e90423d9a4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0145.d41b8e627e9e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0146.be4db84cbf67
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0147.947d6fa10344
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_forward_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0148.1b4e3c9007f3
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_reverse_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0149.e984b02b57f4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.meesho_in.primary.meesho_other_charges_expenses
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0150.53384193a014
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0151.054fa1f5651b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0152.3b4a5d410204
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_credit_note
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0153.450b0be944ce
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.ajio_in.primary.ajio_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0154.159764c5f9fe
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0155.2286af22c27c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_shipment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0156.41bb64c21fcb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0157.32aa8a7e1038
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.jiomart_in.primary.jiomart_returns
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0158.c1e4225d6e37
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0159.d34e8bad6466
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0160.59814cc2758c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.snapdeal_in.primary.snapdeal_commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0161.96d7ac9b6982
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0162.e6cee549feec
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.tatacliq_in.primary.tatacliq_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0163.c6a561113049
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0164.937e70aae13f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.limeroad_in.primary.limeroad_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0165.20ffd77a1abd
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0166.b7a05279ad21
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.ardeur_fashion.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0167.56850313e3ff
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0168.9d8af13dd06e
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.ardeur_fashion.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0169.183aeddbfe75
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.ardeur_fashion.zeal_bizfashion_ventures
  source_type: group
  target_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0170.ef40366305df
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: business_scope_set.ardeur_fashion.domestic_marketplaces
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0171.3120bf647923
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0172.f3d2fe934842
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0173.42ec6e1ad74d
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0174.e25ebba32012
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.meesho_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0175.aa089386ab01
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0176.cb211a266be1
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.jiomart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0177.7a28ec468e77
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.snapdeal_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0178.84d606f94dd3
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

```yaml
candidate_edge:
  edge_id: edge.client.ardeur_fashion.0179.8e1168c98a03
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.ardeur_fashion.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.ardeur_fashion.limeroad_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.amazon_india
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.flipkart
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.myntra
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.meesho
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.ajio
  - ev.ardeur_fashion.docx.row.2_active_sales_channels.jiomart
```

## 7. Blocked / Non-Emitted Edges
```yaml
blocked_edge:
  source_id: platform_account.ardeur_fashion.zeal_item_master.primary
  edge_type: USES_PLATFORM
  target_id: platform.zeal_item_master
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.ardeur_fashion.zeal_item_master.primary
    edge: USES_PLATFORM
    target: platform.zeal_item_master
```

```yaml
blocked_edge:
  source_id: platform_account.ardeur_fashion.zeal_item_master.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.zeal_item_master.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.ardeur_fashion.zeal_item_master.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.zeal_item_master.in
```

## 8. Review Items
```yaml
review_item:
  item: tenant.ardeur_fashion
  issue: Confirm tenant_code ARDEUR and whether group_name Zeal Bizfashion Ventures Private Limited should be modeled as legal_entity
    or operational unit.
  severity: low
  review_item_id: review.ardeur_fashion.001
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
```

```yaml
review_item:
  item: group.ardeur_fashion.zeal_bizfashion_ventures
  issue: Source group_level_id 221 is also present in the AstroTalk client doc uploaded in this batch; confirm both values
    before production account filtering.
  severity: medium
  review_item_id: review.ardeur_fashion.002
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
```

```yaml
review_item:
  item: platform_account.*
  issue: Exact seller IDs/account identifiers are not supplied in the client doc; group_id and group_level_id are used as
    runtime table filters.
  severity: medium
  review_item_id: review.ardeur_fashion.003
  evidence_refs:
  - ev.ardeur_fashion.docx.identity
```

```yaml
review_item:
  review_item_id: review.ardeur_fashion.canonical_context_gap.001
  item: platform_account.ardeur_fashion.zeal_item_master.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.zeal_item_master
  - platform_context.zeal_item_master.in
  evidence_refs:
  - ev.ardeur_fashion.docx.row.3_oms_layer.zeal
```

## 9. Refactored Validation Summary
```yaml
validation_summary:
  result: pass
  client_slug: ardeur_fashion
  card_count: 54
  edge_count_emitted: 179
  blocked_edge_count: 2
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 11
    account_data_binding: 36
    business_scope_set: 3
    business_flow_binding: 2
  status_counts:
    active: 52
    draft: 2
  active_account_data_binding_count: 36
  draft_account_data_binding_count: 0
  demoted_account_data_binding_ids: []
  active_binding_missing_table_refs: []
  duplicate_card_ids: []
  edge_missing_refs_after_refactor: []
  canonical_resolution_gap_count: 1
  semantic_mapping_count: 11
  future_context_gap_count: 5
  review_item_count: 3
  source_evidence_count: 14
  shopify_source_policy: shopify_d2c_oms_v2.md is the active Shopify OMS canonical; shopify_d2c_oms.md is not used.
```
