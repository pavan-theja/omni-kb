# Bear House Clothing Private Limited — Refactored Client Runtime KB Markdown

This markdown is structured for deterministic graph ingestion. It converts the previously JSON-shaped client runtime pack into a card/edge/evidence registry and applies canonical-platform boundary fixes against the uploaded domain markdowns. It intentionally emits only client runtime binding cards; it does not recreate platform/domain/table/metric semantics already owned by canonical markdowns.

```yaml
document_metadata:
  package_id: bear_house_clothing_business_hierarchy_runtime_cards_v1_0
  version: v1_0
  generated_date: '2026-05-24'
  created_for: Bear House Clothing Private Limited
  client_slug: bear_house_clothing
  status: ready_for_review
  source_documents:
  - Bear House Clothing Private Limited.docx
  - Cognee KB Design v4.md
  - ajio_marketplace.md
  - amazon_marketplace.md
  - flipkart_marketplace.md
  - myntra_marketplace.md
  - nykaa_marketplace.md
  - tatacliq_marketplace.md
  - unicommerce_d2c_oms.md
  source_client_profile:
    business: Fashion/lifestyle brand — premium marketplace focus
    geography: India only
    source_group_id: 116
    source_group_level_id: 330
    source_group_name: Bear House
    default_currency: INR
    currencies_in_scope:
    - INR
  build_policy: 'Client/runtime packs contain business hierarchy cards: tenant, group, platform_account, account_data_binding,
    business_scope_set, and business_flow_binding. Active table bindings are emitted only when the current canonical platform
    context or explicit client-table evidence supports the table. Client-mentioned artifacts without current table support
    are preserved as future_context_gaps with source text; no table mapping is fabricated.'
  scope_policy: Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as
    universal table, metric, process, or reconciliation-card properties.
  refactor_version: client_runtime_markdown_refactor_v2_structured
  refactored_on: '2026-05-24'
  client_runtime_layer: true
  allowed_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  forbidden_in_this_client_layer:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  canonical_source_policy: This client layer binds tenant/group/account/runtime scope to canonical cards from the uploaded
    platform/domain markdowns. It does not recreate platform/table/domain semantics.
  docx_source_title: Bear House Clothing Private Limited
```

## 0. Parser Instructions and Refactor Manifest
```yaml
parser_instructions:
  create_only_card_types:
  - tenant
  - group
  - platform_account
  - account_data_binding
  - business_scope_set
  - business_flow_binding
  do_not_create_from_this_file:
  - platform
  - platform_context
  - domain
  - table
  - column
  - metric
  - business_process
  - workflow_step
  - reconciliation_profile
  - matching_logic
  - bank_account
  - payment_gateway_account
  - logistics_account
  - erp_accounting_mapping
  - statutory_tax_filing
  edge_reference_policy:
  - Emit client runtime edges only when source_id and target_id resolve either to a client runtime card in this file or to
    an uploaded canonical card.
  - Do not emit USES_PLATFORM or USES_PLATFORM_CONTEXT if the target canonical platform/context card is absent.
  - Do not emit active BINDS_TO_TABLE edges for missing canonical table cards.
  - Runtime filters belong in account_data_binding.scope_keys; do not push group_id/group_level_id into platform/table/metric/process
    cards.
  source_correction_policy:
    active_shopify_canonical: shopify_d2c_oms_v2.md
    superseded_shopify_canonical: shopify_d2c_oms.md
    replacement_ids:
      platform_context.shopify.in.d2c_oms: platform_context.shopify.in_and_global.d2c_oms_client_config
      platform_context.paypal.in: platform_context.paypal.global
      platform_context.paypal.us: platform_context.paypal.global
    replacement_documents:
      shopify_d2c_oms.md: shopify_d2c_oms_v2.md
      Client Tables - Shopify.md: shopify_d2c_oms_v2.md
```

```yaml
clean_refactor_manifest:
  source_json: bear_house_clothing.json
  source_docx: Bear House Clothing Private Limited.docx
  canonical_markdowns_loaded_count: 29
  canonical_cards_loaded_count: 9842
  corrections_applied:
  - No source-document/id replacement corrections were needed beyond standard structuring.
  id_replacement_hits: []
  demoted_binding_ids: []
  blocked_edge_count: 4
  canonical_resolution_gap_count: 2
```

## 1. Source Intake and Evidence Registry
```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.identity
  source_document: Bear House Clothing Private Limited.docx
  source_section: 1. Identity
  evidence_type: docx_section
  summary: Client identity, business model, group identifiers, configured operational stack, and region/currency hints from
    the client DOCX.
  raw_lines:
  - '* Business: Fashion/lifestyle brand — premium marketplace focus, no mass-market channels (no Meesho, JioMart, Snapdeal)'
  - '* Geography: India only'
  - '* OMS/WMS: Unicommerce (marketplace sync)'
  - '* Logistics: Bluedart, GoSwift'
  - '* Payment gateways: Not configured'
  - '* D2C / Shopify: Not configured'
  - '* GROUP LEVEL ID :  330'
  - '* GROUP ID : **116**'
  - '* CLIENT NAME : **Bear House Clothing Private Limited**'
  - '* GROUP NAME : Bear House'
  - '> Channel selection (Myntra PPMP, Ajio, Nykaa x4, Tata Cliq, Flipkart, Amazon) strongly indicates a premium or mid-premium
    fashion brand. Absence of mass-market channels, payment gateways, and Shopify suggests marketplace-only revenue with no
    active D2C operation in scope.'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.section.2_active_sales_channels
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: docx_section
  summary: Client DOCX section covering 2. Active sales channels.
  raw_lines:
  - '| Channel | Data types configured |'
  - '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement |'
  - '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads) |'
  - '| Myntra  | OMS (PPMP only), Seller reports (Fwd + Rev PPMP), Fwd/Rev settlement (PPMP), Non-order settlement (PPMP),
    Non-order expenses, Returns/RTO (PPMP) |'
  - '| Ajio    | OMS, Settlement, Credit note, Returns |'
  - '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format, Payout summary,
    TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  - '| Tata Cliq | OMS, Settlement       |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.section.3_oms_layer
  source_document: Bear House Clothing Private Limited.docx
  source_section: 3. OMS layer
  evidence_type: docx_section
  summary: Client DOCX section covering 3. OMS layer.
  raw_lines:
  - '| System | Files configured |'
  - '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.section.4_logistics_courier_reconciliation
  source_document: Bear House Clothing Private Limited.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: docx_section
  summary: Client DOCX section covering 4. Logistics — courier reconciliation.
  raw_lines:
  - '| Courier | Files configured |'
  - '| Bluedart | Settlement + Invoice (PP Teabox variant) |'
  - '| GoSwift | Settlement + Invoice |'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Amazon India
  columns:
    channel: Amazon India
    data_types_configured: OMS (B2C + B2B), Settlement, Disbursement
  raw_text: '| Amazon India | OMS (B2C + B2B), Settlement, Disbursement |'
  source_line_number_in_docx_text_extract: 17
  summary: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Flipkart
  columns:
    channel: Flipkart
    data_types_configured: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)
  raw_text: '| Flipkart | OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads) |'
  source_line_number_in_docx_text_extract: 18
  summary: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Myntra
  columns:
    channel: Myntra
    data_types_configured: OMS (PPMP only), Seller reports (Fwd + Rev PPMP), Fwd/Rev settlement (PPMP), Non-order settlement
      (PPMP), Non-order expenses, Returns/RTO (PPMP)
  raw_text: '| Myntra  | OMS (PPMP only), Seller reports (Fwd + Rev PPMP), Fwd/Rev settlement (PPMP), Non-order settlement
    (PPMP), Non-order expenses, Returns/RTO (PPMP) |'
  source_line_number_in_docx_text_extract: 19
  summary: 'Myntra: OMS (PPMP only), Seller reports (Fwd + Rev PPMP), Fwd/Rev settlement (PPMP), Non-order settlement (PPMP),
    Non-order expenses, Returns/RTO (PPMP)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Ajio
  columns:
    channel: Ajio
    data_types_configured: OMS, Settlement, Credit note, Returns
  raw_text: '| Ajio    | OMS, Settlement, Credit note, Returns |'
  source_line_number_in_docx_text_extract: 20
  summary: 'Ajio: OMS, Settlement, Credit note, Returns'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Nykaa
  columns:
    channel: Nykaa
    data_types_configured: OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format,
      Payout summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions
  raw_text: '| Nykaa   | OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format, Payout
    summary, TDS, Additional shipping, MBTPT/GST mapper, Transactions |'
  source_line_number_in_docx_text_extract: 21
  summary: 'Nykaa: OMS x4 storefronts (Fashion, Popup, Mid-Fashion, Mid-Popup), Settlement x4 + Popup new format, Payout summary,
    TDS, Additional shipping, MBTPT/GST mapper, Transactions'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
  source_document: Bear House Clothing Private Limited.docx
  source_section: 2. Active sales channels
  evidence_type: configured_source_row
  row_key: Tata Cliq
  columns:
    channel: Tata Cliq
    data_types_configured: OMS, Settlement
  raw_text: '| Tata Cliq | OMS, Settlement       |'
  source_line_number_in_docx_text_extract: 22
  summary: 'Tata Cliq: OMS, Settlement'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
  source_document: Bear House Clothing Private Limited.docx
  source_section: 3. OMS layer
  evidence_type: configured_source_row
  row_key: Unicommerce
  columns:
    system: Unicommerce
    files_configured: Sales, Returns, Cancellations, Sales order report
  raw_text: '| Unicommerce | Sales, Returns, Cancellations, Sales order report |'
  source_line_number_in_docx_text_extract: 26
  summary: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  source_document: Bear House Clothing Private Limited.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: Bluedart
  columns:
    courier: Bluedart
    files_configured: Settlement + Invoice (PP Teabox variant)
  raw_text: '| Bluedart | Settlement + Invoice (PP Teabox variant) |'
  source_line_number_in_docx_text_extract: 30
  summary: 'Bluedart: Settlement + Invoice (PP Teabox variant)'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
  source_document: Bear House Clothing Private Limited.docx
  source_section: 4. Logistics — courier reconciliation
  evidence_type: configured_source_row
  row_key: GoSwift
  columns:
    courier: GoSwift
    files_configured: Settlement + Invoice
  raw_text: '| GoSwift | Settlement + Invoice |'
  source_line_number_in_docx_text_extract: 31
  summary: 'GoSwift: Settlement + Invoice'
  confidence: high
```

```yaml
source_evidence:
  id: ev.bear_house_clothing.docx.note.1_identity.001
  source_document: Bear House Clothing Private Limited.docx
  source_section: 1. Identity
  evidence_type: source_note
  raw_text: Channel selection (Myntra PPMP, Ajio, Nykaa x4, Tata Cliq, Flipkart, Amazon) strongly indicates a premium or mid-premium
    fashion brand. Absence of mass-market channels, payment gateways, and Shopify suggests marketplace-only revenue with no
    active D2C operation in scope.
  summary: Channel selection (Myntra PPMP, Ajio, Nykaa x4, Tata Cliq, Flipkart, Amazon) strongly indicates a premium or mid-premium
    fashion brand. Absence of mass-market channels, payment gateways, and Shopify suggests marketplace-only revenue with no
    active D2C operation in scope.
  source_line_number_in_docx_text_extract: 13
  confidence: high
```

## 2. Client Runtime Candidate Cards
### 2.1 Tenant Cards
```yaml
candidate_card:
  card_type: tenant
  card_id: tenant.bear_house_clothing
  name: Bear House Clothing Private Limited
  fields:
    tenant_name: Bear House Clothing Private Limited
    tenant_code: BEAR_HOUSE
    description: India premium fashion/lifestyle marketplace-focused client using ZenStatement for marketplace settlement,
      OMS, and courier reconciliation scope; no configured D2C/payment gateway layer.
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    evidence_refs:
    - ev.bear_house_clothing.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.2 Group Cards
```yaml
candidate_card:
  card_type: group
  card_id: group.bear_house_clothing.bear_house
  name: Bear House
  fields:
    tenant_id: tenant.bear_house_clothing
    group_name: Bear House
    group_code: BEAR_HOUSE
    group_type: brand
    business_meaning: Bear House marketplace-focused premium fashion operating brand with Unicommerce OMS and courier settlement/invoice
      scope.
    country_or_region: India
    default_currency: INR
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    source_scope_identifiers:
      group_id: 116
      group_level_id: 330
      representation_rule: Use these only through Account Data Binding scope_keys.
    notes:
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    evidence_refs:
    - ev.bear_house_clothing.docx.identity
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

### 2.3 Platform Account Cards
```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.amazon_in.primary
  name: Bear House Amazon India Seller Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.amazon
    platform_context_id: platform_context.amazon.in
    account_name: Bear House Amazon India Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: amazon_marketplace.md
      platform_context_id_source_file: amazon_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.flipkart_in.primary
  name: Bear House Flipkart Seller Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.flipkart
    platform_context_id: platform_context.flipkart.in
    account_name: Bear House Flipkart Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: flipkart_marketplace.md
      platform_context_id_source_file: flipkart_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.myntra_in.primary
  name: Bear House Myntra PPMP Seller Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.myntra
    platform_context_id: platform_context.myntra.in
    account_name: Bear House Myntra PPMP Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement
      PPMP, Non-order expenses, Returns/RTO PPMP'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: myntra_marketplace.md
      platform_context_id_source_file: myntra_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.ajio_in.primary
  name: Bear House AJIO Seller Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.ajio
    platform_context_id: platform_context.ajio.in
    account_name: Bear House AJIO Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'AJIO: OMS, Settlement, Credit note, Returns'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: ajio_marketplace.md
      platform_context_id_source_file: ajio_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.nykaa_in.primary
  name: Bear House Nykaa Seller Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.nykaa
    platform_context_id: platform_context.nykaa_fashion.in
    account_name: Bear House Nykaa Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: nykaa_marketplace.md
      platform_context_id_source_file: nykaa_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.tatacliq_in.primary
  name: Bear House Tata Cliq Seller Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.tatacliq
    platform_context_id: platform_context.tatacliq.in
    account_name: Bear House Tata Cliq Seller Account
    account_type: seller_account
    account_role: marketplace_seller
    source_account_identifier: null
    source_config_text: 'Tata Cliq: OMS, Settlement'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: tatacliq_marketplace.md
      platform_context_id_source_file: tatacliq_marketplace.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  name: Bear House Unicommerce OMS Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.unicommerce
    platform_context_id: platform_context.unicommerce.in.d2c_oms
    account_name: Bear House Unicommerce OMS Account
    account_type: oms_account
    account_role: oms_source
    source_account_identifier: null
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: resolved_to_uploaded_canonical_card
      platform_context_id_status: resolved_to_uploaded_canonical_card
      platform_id_source_file: unicommerce_operations.md
      platform_context_id_source_file: unicommerce_d2c_oms.md
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.bluedart_in.primary
  name: Bear House BlueDart Logistics Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.bluedart
    platform_context_id: platform_context.bluedart.in
    account_name: Bear House BlueDart Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'BlueDart: Settlement + Invoice (PP Teabox variant)'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

```yaml
candidate_card:
  card_type: platform_account
  card_id: platform_account.bear_house_clothing.goswift_in.primary
  name: Bear House GoSwift Logistics Account
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    platform_id: platform.goswift
    platform_context_id: platform_context.goswift.in
    account_name: Bear House GoSwift Logistics Account
    account_type: logistics_account
    account_role: courier_reconciliation_source
    source_account_identifier: null
    source_config_text: 'GoSwift: Settlement + Invoice'
    country_or_region: India
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    notes:
    - The client document confirms this platform/system is configured. Exact seller/merchant/store account identifier was
      not supplied.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_resolution:
      platform_id_status: source_observed_missing_uploaded_canonical_card
      platform_context_id_status: source_observed_missing_uploaded_canonical_card
      platform_id_source_file: null
      platform_context_id_source_file: null
      emit_platform_edges_only_when_resolved: true
```

### 2.4 Account Data Binding Cards
```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_oms
  name: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_oms
  fields:
    platform_account_id: platform_account.bear_house_clothing.amazon_in.primary
    table_id: table.zs_observe.amazon_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    notes:
    - Bind platform_account.bear_house_clothing.amazon_in.primary to table.zs_observe.amazon_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_settlement
  name: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.amazon_in.primary
    table_id: table.zs_observe.amazon_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    notes:
    - Bind platform_account.bear_house_clothing.amazon_in.primary to table.zs_observe.amazon_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - amazon_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_disbursment
  name: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_disbursment
  fields:
    platform_account_id: platform_account.bear_house_clothing.amazon_in.primary
    table_id: table.zs_observe.amazon_disbursment
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
    notes:
    - Bind platform_account.bear_house_clothing.amazon_in.primary to table.zs_observe.amazon_disbursment using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - amazon_marketplace.md
    registry_notes:
    - Canonical source uses the spelling disbursment.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: amazon_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.flipkart_in.primary.oms
  name: account_data_binding.bear_house_clothing.flipkart_in.primary.oms
  fields:
    platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
    table_id: table.flipkart.oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.bear_house_clothing.flipkart_in.primary to table.flipkart.oms using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.flipkart_in.primary.cashback
  name: account_data_binding.bear_house_clothing.flipkart_in.primary.cashback
  fields:
    platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
    table_id: table.flipkart.cashback
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.bear_house_clothing.flipkart_in.primary to table.flipkart.cashback using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.flipkart_in.primary.settlement
  name: account_data_binding.bear_house_clothing.flipkart_in.primary.settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
    table_id: table.flipkart.settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.bear_house_clothing.flipkart_in.primary to table.flipkart.settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.flipkart_in.primary.commission
  name: account_data_binding.bear_house_clothing.flipkart_in.primary.commission
  fields:
    platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
    table_id: table.flipkart.commission
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
    notes:
    - Bind platform_account.bear_house_clothing.flipkart_in.primary to table.flipkart.commission using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - flipkart_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: flipkart_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms
  name: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms
  fields:
    platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
    table_id: table.zs_observe.myntra_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement
      PPMP, Non-order expenses, Returns/RTO PPMP'
    notes:
    - Bind platform_account.bear_house_clothing.myntra_in.primary to table.zs_observe.myntra_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_settlement
  name: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
    table_id: table.zs_observe.myntra_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement
      PPMP, Non-order expenses, Returns/RTO PPMP'
    notes:
    - Bind platform_account.bear_house_clothing.myntra_in.primary to table.zs_observe.myntra_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_reverse
  name: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_reverse
  fields:
    platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
    table_id: table.zs_observe.myntra_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement
      PPMP, Non-order expenses, Returns/RTO PPMP'
    notes:
    - Bind platform_account.bear_house_clothing.myntra_in.primary to table.zs_observe.myntra_reverse using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_non_order_settlement
  name: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_non_order_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
    table_id: table.zs_observe.myntra_non_order_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement
      PPMP, Non-order expenses, Returns/RTO PPMP'
    notes:
    - Bind platform_account.bear_house_clothing.myntra_in.primary to table.zs_observe.myntra_non_order_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - myntra_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms_settlement
  name: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
    table_id: table.zs_observe.myntra_oms_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement
      PPMP, Non-order expenses, Returns/RTO PPMP'
    notes:
    - Bind platform_account.bear_house_clothing.myntra_in.primary to table.zs_observe.myntra_oms_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - myntra_marketplace.md
    registry_notes:
    - Partial reconciliation-helper table; bind only when explicit OMS-settlement diagnostics are needed.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: myntra_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_oms
  name: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_oms
  fields:
    platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
    table_id: table.zs_observe.ajio_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'AJIO: OMS, Settlement, Credit note, Returns'
    notes:
    - Bind platform_account.bear_house_clothing.ajio_in.primary to table.zs_observe.ajio_oms using client-level group_id and
      group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_settlement
  name: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
    table_id: table.zs_observe.ajio_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'AJIO: OMS, Settlement, Credit note, Returns'
    notes:
    - Bind platform_account.bear_house_clothing.ajio_in.primary to table.zs_observe.ajio_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_credit_note
  name: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_credit_note
  fields:
    platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
    table_id: table.zs_observe.ajio_credit_note
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'AJIO: OMS, Settlement, Credit note, Returns'
    notes:
    - Bind platform_account.bear_house_clothing.ajio_in.primary to table.zs_observe.ajio_credit_note using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_reverse
  name: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_reverse
  fields:
    platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
    table_id: table.zs_observe.ajio_reverse
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'AJIO: OMS, Settlement, Credit note, Returns'
    notes:
    - Bind platform_account.bear_house_clothing.ajio_in.primary to table.zs_observe.ajio_reverse using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - ajio_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: ajio_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_oms
  name: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_oms
  fields:
    platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
    table_id: table.zs_observe.nykaa_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bear_house_clothing.nykaa_in.primary to table.zs_observe.nykaa_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_settlement
  name: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
    table_id: table.zs_observe.nykaa_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bear_house_clothing.nykaa_in.primary to table.zs_observe.nykaa_settlement using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_addition_charge
  name: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_addition_charge
  fields:
    platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
    table_id: table.zs_observe.nykaa_addition_charge
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bear_house_clothing.nykaa_in.primary to table.zs_observe.nykaa_addition_charge using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapper_gst
  name: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapper_gst
  fields:
    platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapper_gst
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bear_house_clothing.nykaa_in.primary to table.zs_observe.nykaa_mapper_gst using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapping
  name: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapping
  fields:
    platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
    table_id: table.zs_observe.nykaa_mapping
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
      MBTPT/GST mapper, Transactions'
    notes:
    - Bind platform_account.bear_house_clothing.nykaa_in.primary to table.zs_observe.nykaa_mapping using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - nykaa_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: nykaa_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_oms
  name: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_oms
  fields:
    platform_account_id: platform_account.bear_house_clothing.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_oms
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Tata Cliq: OMS, Settlement'
    notes:
    - Bind platform_account.bear_house_clothing.tatacliq_in.primary to table.zs_observe.tatacliq_oms using client-level group_id
      and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - tatacliq_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: tatacliq_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_settlement
  name: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_settlement
  fields:
    platform_account_id: platform_account.bear_house_clothing.tatacliq_in.primary
    table_id: table.zs_observe.tatacliq_settlement
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Tata Cliq: OMS, Settlement'
    notes:
    - Bind platform_account.bear_house_clothing.tatacliq_in.primary to table.zs_observe.tatacliq_settlement using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - tatacliq_marketplace.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: tatacliq_marketplace.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce
  name: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce
  fields:
    platform_account_id: platform_account.bear_house_clothing.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    notes:
    - Bind platform_account.bear_house_clothing.unicommerce_oms.primary to table.zs_observe.unicommerce using client-level
      group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

```yaml
candidate_card:
  card_type: account_data_binding
  card_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce_order_sales_report
  name: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce_order_sales_report
  fields:
    platform_account_id: platform_account.bear_house_clothing.unicommerce_oms.primary
    table_id: table.zs_observe.unicommerce_order_sales_report
    table_support_level: canonical_platform_context
    scope_keys:
    - business_key: group_id
      column: group_id
      operator: '='
      value: 116
      data_type: integer
    - business_key: group_level_id
      column: group_level_id
      operator: '='
      value: 330
      data_type: integer
    source_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
    notes:
    - Bind platform_account.bear_house_clothing.unicommerce_oms.primary to table.zs_observe.unicommerce_order_sales_report
      using client-level group_id and group_level_id scope filters.
    - Runtime filters are held in Account Data Binding scope_keys. group_id and group_level_id are not stored as universal
      table, metric, process, or reconciliation-card properties.
    active: true
    status: active
    confidence: curated
    source_documents:
    - Bear House Clothing Private Limited.docx
    - unicommerce_d2c_oms.md
    evidence_refs:
    - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
    canonical_table_resolution:
      table_id_status: resolved_to_uploaded_canonical_card
      table_source_file: unicommerce_operations.md
```

### 2.5 Business Scope Set Cards
```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bear_house_clothing.premium_marketplaces
  name: Bear House Premium Marketplace Accounts
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    scope_name: Bear House Premium Marketplace Accounts
    scope_type: platform_account_group
    platform_account_ids:
    - platform_account.bear_house_clothing.amazon_in.primary
    - platform_account.bear_house_clothing.flipkart_in.primary
    - platform_account.bear_house_clothing.myntra_in.primary
    - platform_account.bear_house_clothing.ajio_in.primary
    - platform_account.bear_house_clothing.nykaa_in.primary
    - platform_account.bear_house_clothing.tatacliq_in.primary
    platform_ids:
    - platform.amazon
    - platform.flipkart
    - platform.myntra
    - platform.ajio
    - platform.nykaa
    - platform.tatacliq
    platform_context_ids:
    - platform_context.amazon.in
    - platform_context.flipkart.in
    - platform_context.myntra.in
    - platform_context.ajio.in
    - platform_context.nykaa_fashion.in
    - platform_context.tatacliq.in
    description: Premium marketplace scope; excludes mass-market channels explicitly absent from the source doc.
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bear_house_clothing.unicommerce_oms
  name: Bear House Unicommerce OMS
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    scope_name: Bear House Unicommerce OMS
    scope_type: single_account
    platform_account_ids:
    - platform_account.bear_house_clothing.unicommerce_oms.primary
    platform_ids:
    - platform.unicommerce
    platform_context_ids:
    - platform_context.unicommerce.in.d2c_oms
    description: Unicommerce OMS layer for marketplace sync.
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_scope_set
  card_id: business_scope_set.bear_house_clothing.logistics_future_context
  name: Bear House Logistics Future Context
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    scope_name: Bear House Logistics Future Context
    scope_type: logistics_scope
    platform_account_ids:
    - platform_account.bear_house_clothing.bluedart_in.primary
    - platform_account.bear_house_clothing.goswift_in.primary
    platform_ids:
    - platform.bluedart
    - platform.goswift
    platform_context_ids:
    - platform_context.bluedart.in
    - platform_context.goswift.in
    description: Configured courier sources whose canonical table context is not currently available.
    active: false
    status: draft
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    notes: []
    evidence_refs:
    - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
    - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

### 2.6 Business Flow Binding Cards
```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  name: Bear House Marketplace to Unicommerce Operations
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    binding_name: Bear House Marketplace to Unicommerce Operations
    binding_type: operational_flow
    business_scope_set_id: business_scope_set.bear_house_clothing.unicommerce_oms
    money_flow_paths:
    - marketplace_to_oms_operations
    - order_to_shipment
    participating_accounts:
    - platform_account_id: platform_account.bear_house_clothing.amazon_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.tatacliq_in.primary
      role: marketplace_order_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.unicommerce_oms.primary
      role: oms_operations_source
      required: true
    evidence_table_ids:
    - table.zs_observe.unicommerce
    - table.zs_observe.unicommerce_order_sales_report
    account_data_binding_ids:
    - account_data_binding.bear_house_clothing.amazon_in.primary.amazon_oms
    - account_data_binding.bear_house_clothing.amazon_in.primary.amazon_settlement
    - account_data_binding.bear_house_clothing.amazon_in.primary.amazon_disbursment
    - account_data_binding.bear_house_clothing.flipkart_in.primary.oms
    - account_data_binding.bear_house_clothing.flipkart_in.primary.cashback
    - account_data_binding.bear_house_clothing.flipkart_in.primary.settlement
    - account_data_binding.bear_house_clothing.flipkart_in.primary.commission
    - account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms
    - account_data_binding.bear_house_clothing.myntra_in.primary.myntra_settlement
    - account_data_binding.bear_house_clothing.myntra_in.primary.myntra_reverse
    - account_data_binding.bear_house_clothing.myntra_in.primary.myntra_non_order_settlement
    - account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms_settlement
    - account_data_binding.bear_house_clothing.ajio_in.primary.ajio_oms
    - account_data_binding.bear_house_clothing.ajio_in.primary.ajio_settlement
    - account_data_binding.bear_house_clothing.ajio_in.primary.ajio_credit_note
    - account_data_binding.bear_house_clothing.ajio_in.primary.ajio_reverse
    - account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_oms
    - account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_settlement
    - account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_addition_charge
    - account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapper_gst
    - account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapping
    - account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_oms
    - account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_settlement
    - account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce
    - account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce_order_sales_report
    business_process_ids:
    - business_process.order_to_shipment_flow
    reconciliation_profile_ids:
    - reconciliation_profile.order_to_shipment
    conditions: []
    confidence: curated
    active: true
    status: active
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - Client-specific flow binding. Account and table filters are resolved through Account Data Binding.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
    - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
    create_action: upsert
    client_runtime_only: true
    review_status: accepted
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bear_house_clothing.logistics_courier_reconciliation_future_context
  name: Bear House Courier Reconciliation Requires Logistics Table Context
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    binding_name: Bear House Courier Reconciliation Requires Logistics Table Context
    binding_type: reconciliation_flow
    business_scope_set_id: business_scope_set.bear_house_clothing.logistics_future_context
    money_flow_paths:
    - shipment_to_freight_invoice
    - cod_delivery_to_courier_remittance
    participating_accounts:
    - platform_account_id: platform_account.bear_house_clothing.bluedart_in.primary
      role: courier_invoice_or_settlement_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.goswift_in.primary
      role: courier_invoice_or_settlement_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: source_confirmed_context_missing
    active: false
    status: draft
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - BlueDart and GoSwift files are configured but no current canonical table cards are available for active Account Data
      Binding.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
    - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

```yaml
candidate_card:
  card_type: business_flow_binding
  card_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  name: Bear House Marketplace Settlement to Bank Requires Bank Binding
  fields:
    tenant_id: tenant.bear_house_clothing
    group_id: group.bear_house_clothing.bear_house
    binding_name: Bear House Marketplace Settlement to Bank Requires Bank Binding
    binding_type: money_flow
    business_scope_set_id: business_scope_set.bear_house_clothing.premium_marketplaces
    money_flow_paths:
    - marketplace_to_bank
    participating_accounts:
    - platform_account_id: platform_account.bear_house_clothing.amazon_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
      role: settlement_source
      required: true
    - platform_account_id: platform_account.bear_house_clothing.tatacliq_in.primary
      role: settlement_source
      required: true
    evidence_table_ids: []
    account_data_binding_ids: []
    business_process_ids: []
    reconciliation_profile_ids: []
    conditions: []
    confidence: inferred
    active: false
    status: draft
    source_documents:
    - Bear House Clothing Private Limited.docx
    - Cognee KB Design v4.md
    notes:
    - No bank account or bank-statement binding was supplied; marketplace-to-bank remains inactive.
    evidence_refs:
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
    - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
    create_action: upsert
    client_runtime_only: true
    review_status: review_required
```

## 3. Semantic Mappings
```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.amazon_in.primary
  client_config_text: 'Amazon India: OMS (B2C + B2B), Settlement, Disbursement'
  canonical_mapped_now:
  - table.zs_observe.amazon_oms
  - table.zs_observe.amazon_settlement
  - table.zs_observe.amazon_disbursment
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.flipkart_in.primary
  client_config_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  canonical_mapped_now:
  - table.flipkart.oms
  - table.flipkart.cashback
  - table.flipkart.settlement
  - table.flipkart.commission
  future_platform_context_gaps:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.myntra_in.primary
  client_config_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement PPMP,
    Non-order expenses, Returns/RTO PPMP'
  canonical_mapped_now:
  - table.zs_observe.myntra_oms
  - table.zs_observe.myntra_settlement
  - table.zs_observe.myntra_reverse
  - table.zs_observe.myntra_non_order_settlement
  - table.zs_observe.myntra_oms_settlement
  future_platform_context_gaps:
  - Myntra PPMP seller reports
  - Myntra non-order expenses detail
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.ajio_in.primary
  client_config_text: 'AJIO: OMS, Settlement, Credit note, Returns'
  canonical_mapped_now:
  - table.zs_observe.ajio_oms
  - table.zs_observe.ajio_settlement
  - table.zs_observe.ajio_credit_note
  - table.zs_observe.ajio_reverse
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.nykaa_in.primary
  client_config_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping,
    MBTPT/GST mapper, Transactions'
  canonical_mapped_now:
  - table.zs_observe.nykaa_oms
  - table.zs_observe.nykaa_settlement
  - table.zs_observe.nykaa_addition_charge
  - table.zs_observe.nykaa_mapper_gst
  - table.zs_observe.nykaa_mapping
  future_platform_context_gaps:
  - Nykaa transactions feed
  - Nykaa storefront-level account split if physically separate tables/filters are needed
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.tatacliq_in.primary
  client_config_text: 'Tata Cliq: OMS, Settlement'
  canonical_mapped_now:
  - table.zs_observe.tatacliq_oms
  - table.zs_observe.tatacliq_settlement
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  client_config_text: 'Unicommerce: Sales, Returns, Cancellations, Sales order report'
  canonical_mapped_now:
  - table.zs_observe.unicommerce
  - table.zs_observe.unicommerce_order_sales_report
  future_platform_context_gaps: []
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.bluedart_in.primary
  client_config_text: 'BlueDart: Settlement + Invoice (PP Teabox variant)'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - BlueDart settlement
  - BlueDart invoice
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

```yaml
semantic_mapping:
  platform_account_id: platform_account.bear_house_clothing.goswift_in.primary
  client_config_text: 'GoSwift: Settlement + Invoice'
  canonical_mapped_now: []
  future_platform_context_gaps:
  - GoSwift settlement
  - GoSwift invoice
  mapping_policy: Map only to current canonical/client-table coverage. Preserve missing artifacts as future_context_gaps;
    do not fabricate table cards.
  notes: []
```

## 4. Future Context Gaps
```yaml
future_context_gap:
  platform_or_area: Bear House Flipkart Seller Account
  missing_artifacts:
  - Flipkart Adhoc Ads/TDS/Rebates/VAS/Google Ads
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Flipkart: OMS + Cashback, Settlement, Commission, Adhoc (Ads/TDS/Rebates/VAS/Google Ads)'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bear House Myntra PPMP Seller Account
  missing_artifacts:
  - Myntra PPMP seller reports
  - Myntra non-order expenses detail
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Myntra: OMS PPMP only, Seller reports Fwd/Rev PPMP, Fwd/Rev settlement PPMP, Non-order settlement PPMP, Non-order
    expenses, Returns/RTO PPMP'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: Bear House Nykaa Seller Account
  missing_artifacts:
  - Nykaa transactions feed
  - Nykaa storefront-level account split if physically separate tables/filters are needed
  impact: Client mentions these artifacts, but current canonical coverage does not expose queryable table cards for them.
  source_text: 'Nykaa: OMS x4 storefronts, Settlement x4 + Popup new format, Payout summary, TDS, Additional shipping, MBTPT/GST
    mapper, Transactions'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: BlueDart
  missing_artifacts:
  - BlueDart settlement
  - BlueDart invoice
  impact: Courier reconciliation cannot be actively bound until BlueDart platform/table context is added.
  source_text: 'BlueDart: Settlement + Invoice (PP Teabox variant)'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

```yaml
future_context_gap:
  platform_or_area: GoSwift
  missing_artifacts:
  - GoSwift settlement
  - GoSwift invoice
  impact: Courier reconciliation cannot be actively bound until GoSwift platform/table context is added.
  source_text: 'GoSwift: Settlement + Invoice'
  required_next_context: Add or confirm canonical platform/table context before creating active Account Data Binding.
```

## 5. Canonical Resolution Gaps
```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bear_house_clothing.bluedart_in.primary
  source_config_text: 'BlueDart: Settlement + Invoice (PP Teabox variant)'
  missing_or_unresolved_refs:
  - platform.bluedart
  - platform_context.bluedart.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

```yaml
canonical_resolution_gap:
  platform_account_id: platform_account.bear_house_clothing.goswift_in.primary
  source_config_text: 'GoSwift: Settlement + Invoice'
  missing_or_unresolved_refs:
  - platform.goswift
  - platform_context.goswift.in
  resolution_policy: Preserve the platform_account as source-observed client scope, but do not emit USES_PLATFORM/USES_PLATFORM_CONTEXT
    edges until canonical platform/context cards exist in the uploaded KB set.
  status: review_required
```

## 6. Candidate Edge Registry
```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0001.41716da71aca
  edge_type: HAS_GROUP
  canonical_edge_type: HAS_GROUP
  source_id: tenant.bear_house_clothing
  source_type: tenant
  target_id: group.bear_house_clothing.bear_house
  target_type: group
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0002.d64acd87eb39
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0003.ac719aa4c6e2
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.amazon_in.primary
  source_type: platform_account
  target_id: platform.amazon
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0004.1448f1239e70
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.amazon_in.primary
  source_type: platform_account
  target_id: platform_context.amazon.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0005.7d2a1012c10f
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0006.72c649f97ddb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_oms
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0007.7f0a5e4f7377
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0008.4b4e59b254ea
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0009.841763ce9dd6
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.amazon_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0010.fef47e241d59
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_disbursment
  source_type: account_data_binding
  target_id: table.zs_observe.amazon_disbursment
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0011.02e7a8db65ff
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0012.bf29ac529779
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.flipkart_in.primary
  source_type: platform_account
  target_id: platform.flipkart
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0013.e83d23cfc3a4
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.flipkart_in.primary
  source_type: platform_account
  target_id: platform_context.flipkart.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0014.18d201425582
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0015.8889b7f8812d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.flipkart_in.primary.oms
  source_type: account_data_binding
  target_id: table.flipkart.oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0016.6ebc8c2eb70d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0017.4777dcda7be8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.flipkart_in.primary.cashback
  source_type: account_data_binding
  target_id: table.flipkart.cashback
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0018.2add37a92d0e
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0019.63b79ddf2c21
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.flipkart_in.primary.settlement
  source_type: account_data_binding
  target_id: table.flipkart.settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0020.8dc9a7ed4fcf
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.flipkart_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0021.68a191067e88
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.flipkart_in.primary.commission
  source_type: account_data_binding
  target_id: table.flipkart.commission
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0022.cec56b31ce83
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0023.e6a2983b7c21
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: platform.myntra
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0024.dba96e173616
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: platform_context.myntra.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0025.8be7ce11104c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0026.ebd8970b4331
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0027.4652a6f31c42
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0028.9afe9532ee76
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0029.7aaac4710fb9
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0030.4fec060c998f
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0031.d58e93f6c981
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0032.ef1bddbdc24d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_non_order_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_non_order_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0033.5ec9bf02322c
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.myntra_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0034.20ae79ee4221
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.myntra_oms_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0035.d6517dc1114d
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0036.f203c68da5d8
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.ajio_in.primary
  source_type: platform_account
  target_id: platform.ajio
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0037.7ee7b146e1d3
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.ajio_in.primary
  source_type: platform_account
  target_id: platform_context.ajio.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0038.bbc35d4aedad
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0039.e9db509e6a66
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_oms
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0040.7323ee52c653
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0041.5605d90750e3
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0042.336d844a1e5d
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_credit_note
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0043.88847cde1f21
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_credit_note
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_credit_note
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0044.029becc2d809
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.ajio_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0045.72660b374236
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_reverse
  source_type: account_data_binding
  target_id: table.zs_observe.ajio_reverse
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0046.1d3e53df4409
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0047.e6c093701ce4
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: platform.nykaa
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0048.f05f11316481
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: platform_context.nykaa_fashion.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0049.7b808c07b962
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0050.f2ae8570df4d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_oms
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0051.d7d3f80684e3
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0052.71c941e2f052
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0053.1ce19a5f2715
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_addition_charge
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0054.57c0f3461aeb
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_addition_charge
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_addition_charge
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0055.3b79dfd155a7
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapper_gst
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0056.d665821e56c8
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapper_gst
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_mapper_gst
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0057.571bae03190b
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.nykaa_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapping
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0058.2b92931c9dff
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapping
  source_type: account_data_binding
  target_id: table.zs_observe.nykaa_mapping
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0059.0f4d618f2fe6
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0060.f3d270ff04d7
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.tatacliq_in.primary
  source_type: platform_account
  target_id: platform.tatacliq
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0061.095bf816a1c6
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.tatacliq_in.primary
  source_type: platform_account
  target_id: platform_context.tatacliq.in
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0062.6bcc4c071bf2
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.tatacliq_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0063.14030ea0043d
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_oms
  source_type: account_data_binding
  target_id: table.zs_observe.tatacliq_oms
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0064.401dde200aab
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.tatacliq_in.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0065.20c7bdb428e7
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_settlement
  source_type: account_data_binding
  target_id: table.zs_observe.tatacliq_settlement
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0066.af51bcccdf31
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0067.791043a76e7e
  edge_type: USES_PLATFORM
  canonical_edge_type: USES_PLATFORM
  source_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform.unicommerce
  target_type: platform
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0068.9d9bf1bb3677
  edge_type: USES_PLATFORM_CONTEXT
  canonical_edge_type: USES_PLATFORM_CONTEXT
  source_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  source_type: platform_account
  target_id: platform_context.unicommerce.in.d2c_oms
  target_type: platform_context
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0069.546aaf1e83c1
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0070.3e21112f66c5
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0071.c50281746fd8
  edge_type: HAS_ACCOUNT_DATA_BINDING
  canonical_edge_type: HAS_ACCOUNT_DATA_BINDING
  source_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  source_type: platform_account
  target_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0072.27137889eb63
  edge_type: BINDS_TO_TABLE
  canonical_edge_type: BINDS_TO_TABLE
  source_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce_order_sales_report
  source_type: account_data_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0073.a1a937615ff8
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.bluedart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0074.8b122b0dc30c
  edge_type: HAS_PLATFORM_ACCOUNT
  canonical_edge_type: HAS_PLATFORM_ACCOUNT
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: platform_account.bear_house_clothing.goswift_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0075.4a0fe964b1dd
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: business_scope_set.bear_house_clothing.premium_marketplaces
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0076.de2020d3d096
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.premium_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0077.cca032e451d8
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.premium_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0078.16aa908cf16a
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.premium_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0079.ca2f5832041d
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.premium_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0080.89d5077cbc70
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.premium_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0081.f7a4aeee4c03
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.premium_marketplaces
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0082.4264529b5119
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: business_scope_set.bear_house_clothing.unicommerce_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0083.711b4bd99c19
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.unicommerce_oms
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.3_oms_layer.unicommerce
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0084.ef5def7cbac4
  edge_type: HAS_BUSINESS_SCOPE_SET
  canonical_edge_type: HAS_BUSINESS_SCOPE_SET
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: business_scope_set.bear_house_clothing.logistics_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0085.ed22a654e8c2
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.logistics_future_context
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.bluedart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0086.e29768d7aa98
  edge_type: INCLUDES_PLATFORM_ACCOUNT
  canonical_edge_type: INCLUDES_PLATFORM_ACCOUNT
  source_id: business_scope_set.bear_house_clothing.logistics_future_context
  source_type: business_scope_set
  target_id: platform_account.bear_house_clothing.goswift_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0087.fdde6ded03d3
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0088.86f6a085c625
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: business_scope_set.bear_house_clothing.unicommerce_oms
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0089.6f2c3ccc0e32
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0090.ec1374ba5e67
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0091.6dc28145ccfa
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0092.99d8e5ca8a20
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0093.dce2dd9dba95
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0094.cc8992c3e217
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0095.eb238fad5ec2
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.unicommerce_oms.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0096.c0c48e0cbe6d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0097.864b10722555
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0098.5b6fa781aaa7
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.amazon_in.primary.amazon_disbursment
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0099.364b60dd3cf4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0100.37970525db72
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.cashback
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0101.1f438111eb7d
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0102.2d9f8a778d7e
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.flipkart_in.primary.commission
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0103.b9ec7b755000
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0104.2540ebfc4bc9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0105.f27542993e63
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0106.e86ea21bb8c5
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_non_order_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0107.553d6e363e3b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.myntra_in.primary.myntra_oms_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0108.51685081e096
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0109.698ef4a83a08
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0110.78af09fa294b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_credit_note
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0111.6b1d8329a1b9
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.ajio_in.primary.ajio_reverse
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0112.2bbfa2941291
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0113.40f99404481a
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0114.52a5de170b13
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_addition_charge
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0115.286b6294a67c
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapper_gst
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0116.1f56d9ebdc9f
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.nykaa_in.primary.nykaa_mapping
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0117.2135023976d4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_oms
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0118.66c73a8d013b
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.tatacliq_in.primary.tatacliq_settlement
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0119.af5d732434fb
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0120.b8917b0f49e4
  edge_type: USES_ACCOUNT_DATA_BINDING
  canonical_edge_type: USES_ACCOUNT_DATA_BINDING
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: account_data_binding.bear_house_clothing.unicommerce_oms.primary.unicommerce_order_sales_report
  target_type: account_data_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0121.02764024db98
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0122.ce06c85b93c0
  edge_type: USES_EVIDENCE_TABLE
  canonical_edge_type: USES_EVIDENCE_TABLE
  source_id: business_flow_binding.bear_house_clothing.marketplace_to_unicommerce_operations
  source_type: business_flow_binding
  target_id: table.zs_observe.unicommerce_order_sales_report
  target_type: table
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: active
  review_status: accepted
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0123.f6c048617517
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: business_flow_binding.bear_house_clothing.logistics_courier_reconciliation_future_context
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0124.faa43fbb411c
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bear_house_clothing.logistics_courier_reconciliation_future_context
  source_type: business_flow_binding
  target_id: business_scope_set.bear_house_clothing.logistics_future_context
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0125.4d3c30a8f086
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.logistics_courier_reconciliation_future_context
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.bluedart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0126.7b9c2f440b44
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.logistics_courier_reconciliation_future_context
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.goswift_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0127.9e17cd1864bf
  edge_type: HAS_BUSINESS_FLOW_BINDING
  canonical_edge_type: HAS_BUSINESS_FLOW_BINDING
  source_id: group.bear_house_clothing.bear_house
  source_type: group
  target_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  target_type: business_flow_binding
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0128.1ba0c2aaa70a
  edge_type: USES_BUSINESS_SCOPE_SET
  canonical_edge_type: USES_BUSINESS_SCOPE_SET
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: business_scope_set.bear_house_clothing.premium_marketplaces
  target_type: business_scope_set
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0129.dd352bf4558f
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.amazon_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0130.18a2a4f87eff
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.flipkart_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0131.2fc0075577e0
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.myntra_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0132.d525fa637b4b
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.ajio_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0133.11ecb31d2761
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.nykaa_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

```yaml
candidate_edge:
  edge_id: edge.client.bear_house_clothing.0134.33594f48221a
  edge_type: PARTICIPATES_WITH_ACCOUNT
  canonical_edge_type: PARTICIPATES_WITH_ACCOUNT
  source_id: business_flow_binding.bear_house_clothing.marketplace_settlement_to_bank_requires_bank_binding
  source_type: business_flow_binding
  target_id: platform_account.bear_house_clothing.tatacliq_in.primary
  target_type: platform_account
  edge_class: client_runtime_binding
  canonical_cognee_edge: true
  materialize_inverse: false
  confidence: curated
  status: draft
  review_status: review_required
  evidence_refs:
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.amazon_india
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.flipkart
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.myntra
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.ajio
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.nykaa
  - ev.bear_house_clothing.docx.row.2_active_sales_channels.tata_cliq
```

## 7. Blocked / Non-Emitted Edges
```yaml
blocked_edge:
  source_id: platform_account.bear_house_clothing.bluedart_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.bluedart
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bear_house_clothing.bluedart_in.primary
    edge: USES_PLATFORM
    target: platform.bluedart
```

```yaml
blocked_edge:
  source_id: platform_account.bear_house_clothing.bluedart_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.bluedart.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bear_house_clothing.bluedart_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.bluedart.in
```

```yaml
blocked_edge:
  source_id: platform_account.bear_house_clothing.goswift_in.primary
  edge_type: USES_PLATFORM
  target_id: platform.goswift
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bear_house_clothing.goswift_in.primary
    edge: USES_PLATFORM
    target: platform.goswift
```

```yaml
blocked_edge:
  source_id: platform_account.bear_house_clothing.goswift_in.primary
  edge_type: USES_PLATFORM_CONTEXT
  target_id: platform_context.goswift.in
  blocked_reason: target_id_missing_from_client_cards_and_uploaded_canonical_cards
  original_edge:
    source: platform_account.bear_house_clothing.goswift_in.primary
    edge: USES_PLATFORM_CONTEXT
    target: platform_context.goswift.in
```

## 8. Review Items
```yaml
review_item:
  item: tenant.bear_house_clothing
  issue: Confirm tenant_code BEAR_HOUSE and exact legal/brand grouping if needed.
  severity: low
  review_item_id: review.bear_house_clothing.001
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
```

```yaml
review_item:
  item: platform_account.*
  issue: Exact seller/courier identifiers are not supplied in the client doc; runtime table scope uses group_id and group_level_id
    where supported.
  severity: medium
  review_item_id: review.bear_house_clothing.002
  evidence_refs:
  - ev.bear_house_clothing.docx.identity
```

```yaml
review_item:
  review_item_id: review.bear_house_clothing.canonical_context_gap.001
  item: platform_account.bear_house_clothing.bluedart_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.bluedart
  - platform_context.bluedart.in
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.bluedart
```

```yaml
review_item:
  review_item_id: review.bear_house_clothing.canonical_context_gap.002
  item: platform_account.bear_house_clothing.goswift_in.primary
  issue: Platform account is source-observed in the client DOCX, but one or more platform/platform_context cards are not present
    in the uploaded canonical markdown set. USES_PLATFORM/USES_PLATFORM_CONTEXT edges were blocked until those canonical cards
    exist.
  severity: medium
  missing_or_unresolved_refs:
  - platform.goswift
  - platform_context.goswift.in
  evidence_refs:
  - ev.bear_house_clothing.docx.row.4_logistics_courier_reconciliation.goswift
```

## 9. Refactored Validation Summary
```yaml
validation_summary:
  result: pass
  client_slug: bear_house_clothing
  card_count: 42
  edge_count_emitted: 134
  blocked_edge_count: 4
  card_type_counts:
    tenant: 1
    group: 1
    platform_account: 9
    account_data_binding: 25
    business_scope_set: 3
    business_flow_binding: 3
  status_counts:
    active: 39
    draft: 3
  active_account_data_binding_count: 25
  draft_account_data_binding_count: 0
  demoted_account_data_binding_ids: []
  active_binding_missing_table_refs: []
  duplicate_card_ids: []
  edge_missing_refs_after_refactor: []
  canonical_resolution_gap_count: 2
  semantic_mapping_count: 9
  future_context_gap_count: 5
  review_item_count: 2
  source_evidence_count: 14
  shopify_source_policy: shopify_d2c_oms_v2.md is the active Shopify OMS canonical; shopify_d2c_oms.md is not used.
```
